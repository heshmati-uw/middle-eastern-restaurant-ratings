"""Metadata-only inventory of raw review sources; does not retag or read entire files."""
from pathlib import Path
import json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'dictionary_focus';O.mkdir(exist_ok=True)
CFG=json.loads((H/'config.json').read_text());ROOT=Path(CFG['source_root'])/'data'
def main():
    files=[]
    directories=[ROOT/'Google Reviews',ROOT/'Google Reviews/full-review-by-state',ROOT/'Google Reviews/full-review-by-state/raw data',ROOT/'Archive']
    # Avoid traversing unrelated documentation trees or hydrating multi-GB text files.
    for folder in directories:
        if folder.exists():
            for p in folder.iterdir():
                if p.is_file():files.append({'path':str(p),'bytes':p.stat().st_size})
    raw=[x for x in files if Path(x['path']).name.startswith('review-') and x['path'].endswith(('.json','.json.gz'))]
    schemas=[];seen=set()
    for item in raw:
        p=Path(item['path']);state=p.name.removeprefix('review-').removesuffix('.gz').removesuffix('.json')
        if state in seen:continue
        seen.add(state)
        schemas.append({'state':state,'path':str(p),'content_not_opened':True})
    dta=ROOT/'Google Reviews/Goog_Rev_2016_2017.dta'
    reader=pd.read_stata(dta,iterator=True,convert_categoricals=False)
    columns=list(reader.variable_labels())
    summary={'root':str(ROOT),'directories_inspected':[str(p) for p in directories],'files_in_inventory':len(files),'raw_state_review_files':raw,
      'raw_state_schema_checks':schemas,'states_observed_in_raw_review_filenames':sorted(seen),
      'national_stata_file':{'path':str(dta),'rows':reader._nobs,'columns':columns,'contains_review_text_column':'text' in columns},
      'current_outcome_source':str(ROOT/'Google Reviews/Reviews_Data_Combined.csv'),
      'current_tag_source':str(Path(CFG['source_root'])/CFG['review_panel']),
      'full_raw_text_retagging_performed_in_this_step':False,
      'note':'Bounded metadata-only inventory; raw JSON bodies were not opened. This does not establish complete state/date coverage. Current dictionary comparisons retain the previously saved text-corpus tags.'}
    (O/'raw_source_inventory.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'raw_states_observed':sorted(seen),'stata_rows':reader._nobs,'stata_text_column':'text' in columns,'inventory_files':len(files)}))
if __name__=='__main__':main()
