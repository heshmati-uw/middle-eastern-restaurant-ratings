# Recompute the three focal comparisons to verify p-values and intervals directly.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
dest<-file.path(here,'dictionary_focus');dir.create(dest,showWarnings=FALSE)
small<-file.path(here,'county_fe_regressions','inputs')
out<-if(dir.exists(small))small else file.path(here,'expanded_positioning')
r<-fread(file=file.path(out,'expanded_comparison_results.csv'))
# Older exports retained confidence-interval names in the low/high column labels.
for(stem in c('low','high')){
  old<-names(r)[startsWith(names(r),paste0(stem,'.'))]
  if(length(old)==1)setnames(r,old,stem)
}
pairs<-c('WPME vs ME','WPME vs MED','ME vs MED')
r<-r[weeks==4 & comparison %chin% pairs]
a<-fread(file=file.path(out,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))
cfg<-fromJSON(file.path(here,'shock_specifications.json'),simplifyVector=FALSE)
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
max_error<-0
for(event in c('Election','Ban')){
  p<-fread(file=file.path(out,paste0('periods_',tolower(event),'_4w.csv')))
  for(def in unique(r$definition)){
    q<-merge(p,a[definition==def & group %chin% c('ME','WPME','MED') & !is.na(gop_share)],by='gmap_id')
    for(pair in pairs)for(t in 0:1){
      members<-strsplit(pair,' vs ',fixed=TRUE)[[1]]
      d<-q[group %chin% members & trump==t];d[,treated:=as.integer(group==members[1])]
      fit<-feols(change~treated,data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
      V<-vcov(fit);b<-unname(coef(fit)['treated']);se<-sqrt(V['treated','treated']);G<-uniqueN(d$county_fips);N<-nrow(d);K<-2L
      pmanual<-2*pt(abs(b/se),df=G-1,lower.tail=FALSE)
      ci<-b+c(-1,1)*qt(.975,G-1)*se
      saved<-r[shock==event & definition==def & comparison==pair & trump==t]
      stopifnot(nrow(saved)==1,nrow(d)==saved$restaurants)
      err<-max(abs(c(b-saved$estimate,se-saved$se,pmanual-saved$p,ci[1]-saved$low,ci[2]-saved$high)))
      stopifnot(err<1e-10);max_error<-max(max_error,err)
      ix<-which(r$shock==event & r$definition==def & r$comparison==pair & r$trump==t)
      r[ix,`:=`(statistic=b/se,df=G-1,df_K=K,cr1_correction=G/(G-1)*(N-1)/(N-K),
                pre_start=cfg$sensitivity_windows[[if(event=='Election')1 else 3]]$pre_start)]
    }
  }
}
r[,p_holm_three_pairs:=p.adjust(p,'holm'),by=.(definition,shock,trump)]
r[,p_holm_all_sixty:=p.adjust(p,'holm')]
r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(r,file.path(dest,'four_week_dictionary_comparisons.csv'))
di<-fread(file=file.path(out,'expanded_county_difference_results.csv'))
for(stem in c('low','high')){
  old<-names(di)[startsWith(names(di),paste0(stem,'.'))];if(length(old)==1)setnames(di,old,stem)
}
di<-di[weeks==4 & comparison %chin% pairs]
di[,p_holm_three_pairs:=p.adjust(p,'holm'),by=.(definition,shock)]
di[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(di,file.path(dest,'four_week_dictionary_county_differences.csv'))
verification<-list(comparisons_recomputed=nrow(r),two_sided_county_t_pvalues_verified=TRUE,
                    confidence_intervals_verified=TRUE,max_error=max_error,
                    significance_convention='+ p<.10; * p<.05; ** p<.01; *** p<.001; raw p-values',
                    existing_estimates_unchanged=TRUE)
write_json(verification,file.path(dest,'dictionary_focus_verification.json'),pretty=TRUE,auto_unbox=TRUE)
print(r[definition=='expanded_broad_pre',.(shock,trump,comparison,estimate,p,symbol,focal_restaurants,control_restaurants,p_holm_three_pairs)])
