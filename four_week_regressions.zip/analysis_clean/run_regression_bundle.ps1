param([string]$Python='python',[string]$Rscript='Rscript')
$ErrorActionPreference='Stop'
foreach($name in @('prepare_dictionary_focus.R','run_county_fe_regressions.R','county_fe_pretrends.R','run_joint_group_regressions.R','joint_county_fe_pretrends.R')){
  & $Rscript --vanilla "$PSScriptRoot/$name"
  if($LASTEXITCODE -ne 0){throw "Failed: $name"}
}
foreach($name in @('verify_county_fe.py','verify_joint_regressions.py')){
  & $Python "$PSScriptRoot/$name"
  if($LASTEXITCODE -ne 0){throw "Failed: $name"}
}
foreach($mode in @('raw','county_fe','joint_fe')){
  & $Rscript --vanilla "$PSScriptRoot/plot_dictionary_focus.R" $mode
  if($LASTEXITCODE -ne 0){throw "Plotting failed: $mode"}
}
foreach($name in @('report_dictionary_focus.py','report_county_fe_regressions.py')){
  & $Python "$PSScriptRoot/$name"
  if($LASTEXITCODE -ne 0){throw "Failed: $name"}
}
