from pathlib import Path
from html import escape
from html.parser import HTMLParser
import json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'dictionary_focus'
def table(headers,rows):
    return '<div class="scroll"><table><tr>'+''.join('<th>'+escape(str(h))+'</th>' for h in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</table></div>'
def mark(p):return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else '+' if p<.1 else ''
def main():
    r=pd.read_csv(O/'four_week_dictionary_comparisons.csv',keep_default_na=False)
    di=pd.read_csv(O/'four_week_dictionary_county_differences.csv',keep_default_na=False)
    inv=json.loads((O/'raw_source_inventory.json').read_text());v=json.loads((O/'dictionary_focus_verification.json').read_text())
    body='''<h1>Four-week dictionary sensitivity: WPME, ME and Mediterranean</h1>
    <p class="lead">The apparent WPME advantage in Trump counties depends on how dish tags partition Mediterranean restaurants. Under the main expanded pre-election dictionary, WPME–ME is +0.167 after the election (p=.153) and +0.060 after the ban (p=.513); WPME–MED is +0.231 after the election (p=.082, marked +) and +0.018 after the ban (p=.867). No one of the 60 displayed comparisons survives Holm adjustment across the three pairs within its definition/event/county condition at 5%.</p>
    <h2>How the p-values are calculated</h2>
    <ol><li>Within each restaurant and each four-week period, calculate the review-count-weighted average rating from the common weekly source.</li>
    <li>Keep restaurants with reviews on both sides; calculate each restaurant’s after-minus-before rating change.</li>
    <li>Regress that change on an intercept and a first-group indicator. Every restaurant has equal regression weight. The coefficient is exactly the difference in the two groups’ mean changes.</li>
    <li>Calculate standard errors clustered by county, allowing restaurants in the same county to have correlated changes. Use the CR1 correction G/(G−1) × (N−1)/(N−2), where G is the number of counties and N the number of restaurants.</li>
    <li>Calculate t = estimate / county-clustered SE, then the two-sided p = 2 × Pr(T<sub>G−1</sub> ≥ |t|). Matching 95% intervals use the same t distribution. There are no added covariates or trend adjustments in these raw-change contrasts.</li></ol>
    <p><strong>Example:</strong> Election WPME–MED in Trump counties has estimate 0.230604, SE 0.131670, t = 1.75138, 129 counties and 128 degrees of freedom. Its p-value is 0.082275, with 95% interval [−0.029927, 0.491136]. Thus it gets a +, not a 5% significance star. This calculation uses 183 WPME and 101 MED restaurants; review counts are not treated as independent sample units for the test.</p>
    <p>Direct county-type tests regress restaurant changes on group, Trump-county, and their interaction. The interaction tests whether the relative change differs across county types; its CR1 correction uses K=4 instead of K=2. The headline p-values are two-sided. County clustering is an approximate sampling-inference method, not a randomization test or a causal-identification guarantee.</p>
    <h2>New significance convention</h2>
    <p><strong>+ p&lt;.10; * p&lt;.05; ** p&lt;.01; *** p&lt;.001.</strong> Symbols use unadjusted p-values. This replaces the earlier symbol convention; estimates, standard errors and numeric p-values have not changed. A + can accompany a 95% interval crossing zero because it denotes a 10%, rather than 5%, cutoff. Multiplicity-adjusted p-values are listed separately.</p>
    <h2>Dates and definitions</h2>
    <p>Election: Oct 10–Nov 6 versus Nov 14–Dec 11, 2016. Ban: Dec 26, 2016–Jan 22, 2017 versus Jan 30–Feb 26, 2017. Mixed event weeks are excluded. Primary-ME classification is held fixed across dictionaries. Primary-Mediterranean restaurants are repartitioned into WPME and MED; missing eligible review text is unknown, not MED.</p>
    <p>Blue = pre-election baba-only or conservative core dictionary; red = main broad pre-election dictionary. Grey = legacy baba flag or all-saved-period broad tag; these can use post-event information and are descriptive sensitivities only. The three pre-election definitions share the eligible text universe, but move restaurants between WPME and MED. Consequently, WPME–ME and ME–MED sample sizes change across definitions even though ME itself stays fixed.</p>'''
    names=[('WPME vs ME','dictionary_WPME_ME'),('WPME vs MED','dictionary_WPME_MED'),('ME vs MED','dictionary_ME_MED')]
    defs=['legacy_baba','pre_baba','expanded_core_pre','expanded_broad_pre','expanded_broad_all_saved']
    for pair,name in names:
        body+=f'<h2>{escape(pair)}</h2><p>Positive means the first group gained ground relative to the second. N shows first-group / second-group restaurants. All panels within this figure share the same effect scale. Click the image for full resolution.</p><a href="{name}.png"><img src="{name}.png" alt="{pair} dictionary sensitivity"></a>'
        rows=[]
        for definition in defs:
            row=[definition]
            for event in ['Election','Ban']:
                for t in [1,0]:
                    x=r[r.definition.eq(definition)&r.shock.eq(event)&r.trump.eq(t)&r.comparison.eq(pair)].iloc[0]
                    row.append(f'{x.estimate:+.3f}{mark(x.p)}; p={x.p:.4f}; N={x.focal_restaurants}/{x.control_restaurants}')
            rows.append(row)
        body+=table(['Definition','Election Trump','Election non-Trump','Ban Trump','Ban non-Trump'],rows)
    body+='''<h2>What is robust?</h2>
    <p>There is no clear ME–MED difference under any displayed dictionary, event or county group. WPME tends to improve relative to ME and MED in Trump counties under the narrower pre-election dictionaries, but the estimates shrink with the main broad dictionary. The only raw p&lt;.05 among all 60 plotted cells is pre-election baba-only WPME–ME after the ban: +0.721, p=.0495, based on 15 WPME restaurants. Its Holm p across the three focal pairs is .1484. Under broad pre-election tags the corresponding estimate is +0.060, p=.5126, with 206 WPME restaurants.</p>
    <p>The main election Trump WPME–MED p=.0823 becomes .2468 after adjustment across the three focal pairs, and .8228 under the previously reported ten-baseline adjustment. Narrowing the display does not erase the larger earlier search over windows and baselines. These focused-family adjustments are exploratory. None of this establishes parallel trends or a causal protective effect of Mediterranean labeling.</p>
    <h2>Main broad dictionary: direct county-type comparisons</h2>'''
    q=di[di.definition.eq('expanded_broad_pre')]
    body+=table(['Event','Comparison','Trump minus non-Trump contrast','Raw p','Holm p across three pairs'],[[x.shock,x.comparison,f'{x.estimate:+.3f}{mark(x.p)}',f'{x.p:.4f}',f'{x.p_holm_three_pairs:.4f}'] for x in q.itertuples()])
    body+='''<h2>Your raw data folder and the current tag limitation</h2>
    <p>The raw-data root is available. The outcomes already use the full combined weekly Google file and eligible businesses from the full metadata. The dish tags used in these plots still come from the saved July 2016–June 2017 individual-review panel, with pre-election dates selected for the main definitions. The earlier unknown-tag count reflects that processing subset, not evidence that you lack raw reviews.</p>
    <p>A bounded metadata-only inventory confirms raw state review JSON/GZ files in the supplied folder. It is not a completeness audit and does not establish all-state/date coverage. The 10.5 GB Goog_Rev_2016_2017.dta file has 23,041,783 business-week rows and no review-text column, so it cannot itself supply additional dish mentions. Rebuilding national tags requires processing the raw individual-review text sources, with duplicates and date coverage checked. That full raw-text retagging pass has not been run for these figures.</p>'''
    body+=table(['Observed raw-review filename state','Example file'],[[x['state'],x['path']] for x in inv['raw_state_schema_checks']])
    body+='<h2>Verification and downloads</h2>'
    body+=f'<p>All {v["comparisons_recomputed"]} plotted regressions were recomputed and checked against the saved coefficients, county-clustered standard errors, two-sided t p-values, and matching confidence intervals. Maximum discrepancy: {v["max_error"]:.2g}. No estimates changed when significance symbols changed.</p>'
    files=['four_week_dictionary_comparisons.csv','four_week_dictionary_county_differences.csv','dictionary_focus_verification.json','raw_source_inventory.json','../prepare_dictionary_focus.R','../plot_dictionary_focus.R','../report_dictionary_focus.py','../audit_raw_review_inventory.py','../expanded_dish_dictionary.json']
    body+='<ul>'+''.join(f'<li><a href="{x}">{escape(x)}</a></li>' for x in files)+'</ul>'
    style='body{font:16px/1.6 system-ui;max-width:1400px;margin:35px auto;padding:0 24px;color:#26343d}h1,h2{color:#173f46}.lead{font-size:19px}img{width:100%;height:auto}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:10px;border-bottom:1px solid #d8e2e6}th{background:#edf4f5}a{color:#17657d}'
    path=O/'dictionary_focus_report.html';path.write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Four-week dictionary sensitivity</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    class Links(HTMLParser):
        def handle_starttag(self,tag,attrs):
            a=dict(attrs);p=a.get('href',a.get('src',''))
            if p and not p.startswith(('http','#')):assert (O/p).exists(),p
    Links().feed(path.read_text(encoding='utf-8'));print(path)
if __name__=='__main__':main()
