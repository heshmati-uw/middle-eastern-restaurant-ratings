"""Verify core-only Mediterranean comparisons independently and render report."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'precinct_core_mediterranean'
r=pd.read_csv(O/'interaction_results.csv');d=pd.read_csv(O/'verification_designs.csv',dtype={'county_fips':str,'fixed_effect':str,'county_group':str},low_memory=False)
errors=[]
for row in r.itertuples():
 z=d[d.model_id.eq(row.id)].copy();cols=row.variables.split(';');v=z[cols+['change']];v=v-v.groupby(z.fixed_effect).transform('mean')
 x=v[cols].to_numpy();y=v.change.to_numpy();inv=np.linalg.pinv(x.T@x);b=inv@x.T@y;res=y-x@b
 scores=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
 cov=inv@scores.T@scores@inv*g/(g-1)*(n-1)/(n-row.df_K);j=cols.index('first_share');errors.extend([abs(b[j]-row.estimate),abs(np.sqrt(cov[j,j])-row.se)])
assert len(r)==80 and max(errors)<1e-8
(O/'verification.json').write_text(json.dumps({'models_independently_verified':len(r),'max_coefficient_or_se_error':max(errors),'inference':'County-clustered CR1, t df=counties-1','definition':'expanded_core_pre','weighting':'Equal restaurant weights'},indent=2))
main=r[r.model.eq('Precinct share + county FE')&r['sample'].eq('Main matched sample')].copy()
primary=main[main.stratum.eq('All counties')].copy()
coverage=pd.read_csv(H/'precinct_core/population_coverage.csv').groupby('group')[['population','spatial_matches','eligible']].sum().reset_index()
def fmt(q):
 q=q.copy();q['Gradient (SE)']=q.apply(lambda z:f'{z.estimate:+.4f}{z.symbol if isinstance(z.symbol,str) else ""} ({z.se:.4f})',axis=1)
 q['95% CI']=q.apply(lambda z:f'[{z.low:+.4f}, {z.high:+.4f}]',axis=1);q['Raw p']=q.p.map(lambda v:f'{v:.4f}')
 return q
cols=['shock','comparison','stratum','Gradient (SE)','95% CI','Raw p','restaurants','first_restaurants','MED_restaurants','counties']
allcols=['shock','comparison','stratum','model','sample','exposure','Gradient (SE)','95% CI','Raw p','restaurants','counties']
tab=lambda q:q.to_html(index=False,border=0)
links='''<p><a href="interaction_results.csv">All results CSV</a> · <a href="verification.json">Independent verification</a> · <a href="../precinct_mediterranean.R">R code</a> · <a href="../report_precinct_mediterranean.py">Verification/report code</a> · <a href="../precinct_core/precinct_report.html">ME–WPME core-only report</a></p>'''
html='''<!doctype html><html><head><meta charset="utf-8"><title>Core tags: Mediterranean comparisons at precinct level</title><style>body{font:16px/1.5 system-ui;color:#243343;max-width:1350px;margin:36px auto;padding:0 24px}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3f6;position:sticky;top:0}td:nth-child(-n+3){text-align:left}.note{background:#edf3f6;padding:18px}.scroll{overflow:auto;max-height:650px}img{width:100%}code{white-space:normal}</style></head><body><h1>ME and WPME versus Mediterranean: core tags only</h1>
<p>Four complete weeks on each side of the election and ban; all ten shared-food tags excluded; equal restaurant weights and county-clustered inference.</p>
<div class="note">Estimates are <b>changes in the first-group-minus-MED rating-change gap per +10 percentage points of precinct Trump support</b>. Negative means the first group loses more ground relative to MED in more pro-Trump precincts. Positive means it gains relative ground. This is a political gradient, not the average event effect.</div>
<h2>Pooled primary models</h2>'''+tab(fmt(primary)[cols])+'''
<p>None of the four pooled primary gradients reaches p&lt;.05. Election slopes are negative; ban slopes are positive. Confidence intervals include zero in each case. No causal effect is established by these observational comparisons.</p>
<h2>ME versus Mediterranean</h2><img src="ME_MED_gradient.png" alt="ME minus Mediterranean across precinct Trump support, election and ban">
<h2>WPME versus Mediterranean</h2><img src="WPME_MED_gradient.png" alt="WPME minus Mediterranean across precinct Trump support, election and ban">
<p>Lines show the fitted first-group-minus-MED difference in rating changes; shaded areas are pointwise 95% county-clustered confidence intervals. Each plot uses the overlap of the two groups’ 5th–95th percentile vote-share ranges. A line above zero means the first group has a larger change at that local vote share; its slope is the interaction tested in the table.</p>
<h2>Trump and non-Trump county subsets</h2>'''+tab(fmt(main[~main.stratum.eq('All counties')])[cols])+'''
<p>Two main subgroup results reach only the raw 10% threshold: election WPME–MED in Trump counties (negative), and ban ME–MED in non-Trump counties (positive). Neither reaches the raw 5% threshold. All twelve main pooled/subgroup gradients are reported; Holm adjustments are saved separately. County strata follow the existing above-50%-Trump county definition, while the tested exposure remains continuous precinct share.</p>
<h2>Definitions and sample</h2><p><b>ME:</b> the fixed primary-ME category list. <b>WPME:</b> primary Mediterranean plus at least one of the 27 core dish tags in reviews dated before November 8, 2016. <b>MED:</b> primary Mediterranean with observed pre-election review text and no detected core tag. MED now includes the 1,058 businesses previously tagged only by shared foods. It is not verified absence of Middle Eastern food. No eligible review text means unknown and remains excluded.</p>'''+tab(coverage)+'''
<p>Population counts above precede event-window review requirements. Main tables count restaurants with reviews on both sides, eligible precinct matching, and counties containing both comparison groups. Each pair has its own common-county sample; coefficients from different pairs therefore need not add up. Review-count weights aggregate ratings within restaurant-periods; each restaurant then receives unit regression weight.</p>
<h2>Model and sensitivity checks</h2><p><code>Change = county FE + firstGroup + precinctShare10 + firstGroup × precinctShare10 + error</code>, with <code>precinctShare10=(TrumpShare−.50)/.10</code>. Four-week windows and mixed-week exclusions match the previous precinct analysis. County-FE change models correspond to restaurant FE plus county-by-period effects in a two-period panel.</p>
<p>Sensitivities include a county-share benchmark on the same sample; adding a firstGroup×county-share interaction; county-by-group FE; baseline rating and log(1+pre-period reviews); a minimum of 100 precinct votes; excluding locations within approximately 50 m of precinct boundaries; and a two-party share denominator. County-by-group FE requires at least two restaurants of each group in retained counties, so changes the sample. Baseline adjustment changes the conditional identifying assumption. The county-gradient sensitivity is an added regressor on the same sample.</p>
<p>For pooled ban ME–MED, the added county-gradient model gives +.0759 per 10 points (raw p=.0207); county-by-group FE gives +.0656 (p=.0742), and baseline adjustment gives +.0156 (p=.3667). This positive association varies across specifications and points opposite ME losing more ground. All 80 exploratory models are shown below, rather than selecting one result by significance.</p>
<h2>Pre-event placebo checks</h2>'''+tab(fmt(r[r.model.isin(['Event gradient on placebo subset','Pre-event placebo gradient'])])[allcols])+'''
<p>Placebo gradients use the immediately earlier complete four-week block and a smaller history-observed subset, with event gradients reestimated on that same subset. Election placebo: September 12–October 9 to October 10–November 6, 2016. Ban placebo: November 28–December 25 to December 26–January 22. Non-rejection is not proof of parallel trends.</p>
<h2>All 80 specifications</h2><p>Raw two-sided p-value symbols: + &lt;.10; * &lt;.05; ** &lt;.01; *** &lt;.001. Separate CSV columns give Holm corrections over four pooled primary tests, twelve main pooled/subgroup tests, and all eighty models. These families exclude the earlier ME–WPME analyses; the full project contains additional exploratory tests.</p><div class="scroll">'''+tab(fmt(r)[allcols])+'''</div>
<p>Precinct geometry and votes reuse the verified <a href="../precinct_core/precinct_linkage_audit.json">2016 linkage</a>, sourced from <a href="https://github.com/noahdasanaike/sage">SAGE</a> and its documented upstream sources. Matching, vote denominators, and geographic exclusions are unchanged. Local resident voting is not reviewer residence or individual ideology. All 80 coefficients and clustered standard errors were independently reproduced in NumPy.</p>'''+links+'''</body></html>'''
(O/'precinct_mediterranean_report.html').write_text(html,encoding='utf-8')
print(fmt(primary)[cols].to_string(index=False));print('Max independent verification error',max(errors))
