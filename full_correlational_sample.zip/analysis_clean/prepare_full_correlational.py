"""Freeze the unselected full eligible sample for descriptive political associations."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'correlational_full_sample';O.mkdir(exist_ok=True)
groups=['ME','WPME','MED']
labels=pd.read_csv(S/'all_group_assignments.csv',dtype={'county_fips':str})
geo=pd.read_csv(S/'restaurant_precinct_assignments.csv',dtype={'county_fips':str})
assert not labels.gmap_id.duplicated().any() and not geo.gmap_id.duplicated().any()
keep=['gmap_id','latitude','longitude','state','precinct_id','precinct_share','precinct_share_2party','eligible_precinct','trump_votes','clinton_votes','total_max','boundary_distance_m_approx']
meta=labels.merge(geo[keep],on='gmap_id',how='left',validate='one_to_one')
meta['precinct_valid']=meta.eligible_precinct.astype(str).str.lower().eq('true')&meta.precinct_id.notna()&meta.precinct_share.between(0,1)
meta['county_valid']=meta.county_fips.notna()&meta.gop_share.between(0,1)
meta['trump_county']=np.where(meta.county_valid,(meta.gop_share>.5).astype(int),np.nan)
meta['trump_precinct']=np.where(meta.precinct_valid,(meta.precinct_share>.5).astype(int),np.nan)
assert meta.loc[meta.county_valid,'trump'].eq(meta.loc[meta.county_valid,'trump_county']).all()
design={'goal':'Descriptive and correlational associations; no causal election or ban claims','groups':{'ME':'Primary ME category list unchanged','WPME':'Primary Mediterranean plus core dish evidence in full raw pre-election reviews','MED':'Primary Mediterranean with observed eligible pre-election review text and no core mention; shared mentions allowed'},'geographic_classification':'Trump = strictly more than 50% of published all-candidate 2016 votes. Non-Trump includes <=50%; not necessarily Clinton-majority. County and precinct classifications are separate.','primary_windows':{'Election':{'pre':['2016-10-10','2016-11-06'],'post':['2016-11-14','2016-12-11']},'Ban':{'pre':['2016-12-26','2017-01-22'],'post':['2017-01-30','2017-02-26']}},'holidays':'Included; event mixed weeks omitted','eligibility':'Known ME/WPME/MED label, rating in both four-week periods, valid voting geography at the level reported. No price, format, matching, shared-county, or all-three-in-local-area restriction.','weighting':'Reviews aggregated to each restaurant-period rating. Every restaurant unit weight for group averages, mean changes and regressions. Not review-weighted across restaurants.','main_model':'Restaurant rating change regressed on cuisine indicators, separately by event, geography level and Trump/non-Trump category. All three groups in one model; every contrast uses the same sample.','inference':'County-clustered CR1 covariance with finite sample adjustment, t df = counties-1. County clustering for precinct analyses too.','political_heterogeneity':'Pooled cuisine x political-category cell-mean model per event/geography; test difference of cuisine gaps across political categories, accounting for shared-county covariance.','continuous_supplement':'Change regressed on cuisine indicators and cuisine-specific linear slopes of county or precinct Trump share; centered at 50%, scaled per 10 percentage points.','limitations':['Observational comparisons with demonstrated pretrend concerns','County/precinct voting describes location, not reviewer ideology','Selective restaurant review observation and changing reviewers','MED no core mention is no observed evidence, not proof of menu absence','County/precinct classifications and event cohorts differ','Many exploratory contrasts; raw p and Holm-adjusted companion values reported transparently']}
(O/'analysis_design.json').write_text(json.dumps(design,indent=2))
population=[]
for level in ['County','Precinct']:
 valid=meta.county_valid if level=='County' else meta.county_valid&meta.precinct_valid
 for g in ['ME','WPME','MED','Unknown']:
  z=meta[meta.group.eq(g)]
  population.append(dict(level=level,group=g,source_population=len(z),geography_eligible=int(valid[z.index].sum())))
pd.DataFrame(population).to_csv(O/'population_coverage.csv',index=False)
out=[];flow=[];cross=[]
for event in ['Election','Ban']:
 p=pd.read_csv(S/'inputs'/f'periods_{event.lower()}_4w.csv');assert not p.gmap_id.duplicated().any()
 q=p.merge(meta,on='gmap_id',validate='one_to_one');q=q[q.group.isin(groups)].copy()
 assert np.allclose(q.change,q.rating_post-q.rating_pre,equal_nan=True)
 outcome=q.rating_pre.between(1,5)&q.rating_post.between(1,5)&q.reviews_pre.gt(0)&q.reviews_post.gt(0)
 for level in ['County','Precinct']:
  valid=q.county_valid if level=='County' else q.county_valid&q.precinct_valid
  z=q[outcome&valid].copy();z['event']=event;z['level']=level;z['political_trump']=z.trump_county if level=='County' else z.trump_precinct;z['vote_share']=z.gop_share if level=='County' else z.precinct_share;z['share10']=(z.vote_share-.5)/.1
  assert z.political_trump.isin([0,1]).all();out.append(z)
  for g in groups:
   for t in [1,0]:
    zz=z[z.group.eq(g)&z.political_trump.eq(t)]
    flow.append(dict(event=event,level=level,group=g,political_trump=t,restaurants=len(zz),counties=zz.county_fips.nunique(),precincts=zz.precinct_id.nunique(),states=zz.state.nunique(),reviews_pre=zz.reviews_pre.sum(),reviews_post=zz.reviews_post.sum()))
 z=q[outcome&q.county_valid&q.precinct_valid]
 for key,zz in z.groupby(['group','trump_county','trump_precinct']):cross.append(dict(event=event,group=key[0],trump_county=key[1],trump_precinct=key[2],restaurants=len(zz)))
data=pd.concat(out,ignore_index=True);assert not data.duplicated(['event','level','gmap_id']).any();data.to_csv(O/'restaurant_changes.csv',index=False);pd.DataFrame(flow).to_csv(O/'sample_sizes.csv',index=False);pd.DataFrame(cross).to_csv(O/'county_precinct_crosswalk_counts.csv',index=False)
states=data.groupby(['event','level','political_trump','state','group']).size().rename('restaurants').reset_index();states.to_csv(O/'state_coverage.csv',index=False)
# Retain a fixed event-specific restaurant cohort for raw weekly trends, without
# further dropping restaurants for sparse weekly histories or balancing groups.
w=pd.read_csv(S/'inputs/expanded_common_weekly.csv');weekly=[]
for event,mixed in [('Election','2016-11-07'),('Ban','2017-01-23')]:
 start=(pd.Timestamp(mixed)-pd.Timedelta(days=70)).strftime('%Y-%m-%d');end=(pd.Timestamp(mixed)+pd.Timedelta(days=28)).strftime('%Y-%m-%d')
 ww=w[w.week.between(start,end)&w.week.ne(mixed)&w.reviews.gt(0)&w.rating.notna()]
 for level in ['County','Precinct']:
  a=data[data.event.eq(event)&data.level.eq(level)][['gmap_id','group','county_fips','precinct_id','political_trump']]
  z=ww.merge(a,on='gmap_id',validate='many_to_one');z['event']=event;z['level']=level;weekly.append(z)
pd.concat(weekly,ignore_index=True).to_csv(O/'weekly_observations.csv',index=False)
sources=[S/'all_group_assignments.csv',S/'restaurant_precinct_assignments.csv',S/'inputs/periods_election_4w.csv',S/'inputs/periods_ban_4w.csv',S/'inputs/expanded_common_weekly.csv']
(O/'input_checksums.json').write_text(json.dumps({p.relative_to(H.parent).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2))
print(pd.DataFrame(flow)[['event','level','political_trump','group','restaurants']].to_string(index=False))
