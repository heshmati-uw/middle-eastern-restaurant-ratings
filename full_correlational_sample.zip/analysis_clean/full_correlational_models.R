args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
o<-file.path(h,'full_pre_election_core','correlational_full_sample')
d<-fread(file.path(o,'restaurant_changes.csv'),colClasses=c(county_fips='character'))
d[,`:=`(isME=as.integer(group=='ME'),isWP=as.integer(group=='WPME'),isMED=as.integer(group=='MED'))]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
means<-list();contrasts<-list();heterogeneity<-list();slopes<-list();slopecontrasts<-list();modelinfo<-list();coefficients<-list();covariances<-list();modelinputs<-list();mid<-0L
Lpair<-list(ME_WPME=c(1,-1,0),ME_MED=c(1,0,-1),WPME_MED=c(0,1,-1))
summaryfit<-function(fit,x,y,event,level,kind,political=NA_integer_){
 mid<<-mid+1L;G<-uniqueN(x$county_fips);K<-attr(vcov(fit,attr=TRUE),'df.K');B<-coef(fit);V<-vcov(fit)
 modelinfo[[mid]]<<-data.table(model_id=mid,event,level,kind,political_trump=political,outcome=y,restaurants=nrow(x),counties=G,df_K=K)
 coefficients[[mid]]<<-data.table(model_id=mid,term=names(B),estimate=unname(B),se=sqrt(diag(V)))
 vv<-as.data.table(as.table(V));setnames(vv,c('term1','term2','value'));vv[,model_id:=mid];covariances[[mid]]<<-vv
 input<-data.table(model_id=mid,gmap_id=x$gmap_id,county_fips=x$county_fips,y=x[[y]])
 for(n in names(B))input[[n]]<-x[[n]]
 modelinputs[[mid]]<<-input
 list(id=mid,B=B,V=V,G=G,K=K)
}
contrast<-function(s,L){b<-sum(L*s$B);se<-sqrt(as.numeric(t(L)%*%s$V%*%L));p<-2*pt(-abs(b/se),s$G-1);c(estimate=b,se=se,p=p,low=b-qt(.975,s$G-1)*se,high=b+qt(.975,s$G-1)*se)}
for(en in c('Election','Ban'))for(lev in c('County','Precinct')){
 q<-d[event==en&level==lev]
 for(t in c(1,0)){
  x<-q[political_trump==t];stopifnot(uniqueN(x$group)==3L)
  for(y in c('rating_pre','rating_post','change')){
   fit<-feols(as.formula(paste0(y,'~0+isME+isWP+isMED')),x,vcov=~county_fips,ssc=ss)
   s<-summaryfit(fit,x,y,en,lev,'Group means',t)
   for(g in c('ME','WPME','MED')){
    L<-switch(g,ME=c(1,0,0),WPME=c(0,1,0),MED=c(0,0,1));a<-contrast(s,L)
    means[[length(means)+1L]]<-cbind(data.table(model_id=s$id,event=en,level=lev,political_trump=t,group=g,outcome=y,restaurants=x[group==g,.N],counties=uniqueN(x[group==g]$county_fips),cluster_count=s$G),as.data.table(as.list(a)))
   }
   if(y=='change')for(pair in names(Lpair)){
    a<-contrast(s,Lpair[[pair]]);gg<-strsplit(pair,'_')[[1]]
    contrasts[[length(contrasts)+1L]]<-cbind(data.table(model_id=s$id,event=en,level=lev,political_trump=t,pair,first_N=x[group==gg[1],.N],second_N=x[group==gg[2],.N],ME_N=x[group=='ME',.N],WPME_N=x[group=='WPME',.N],MED_N=x[group=='MED',.N],counties=s$G),as.data.table(as.list(a)))
   }
  }
 }
 # Political differences of cuisine contrasts: pooled model retains covariance
 # between Trump and non-Trump precincts inside the same county.
 q[,`:=`(ME0=isME*(1-political_trump),WP0=isWP*(1-political_trump),MED0=isMED*(1-political_trump),ME1=isME*political_trump,WP1=isWP*political_trump,MED1=isMED*political_trump)]
 fit<-feols(change~0+ME0+WP0+MED0+ME1+WP1+MED1,q,vcov=~county_fips,ssc=ss);s<-summaryfit(fit,q,'change',en,lev,'Political difference of cuisine contrasts')
 for(pair in names(Lpair)){
  a<-contrast(s,c(-Lpair[[pair]],Lpair[[pair]]))
  heterogeneity[[length(heterogeneity)+1L]]<-cbind(data.table(model_id=s$id,event=en,level=lev,pair,restaurants=nrow(q),counties=s$G),as.data.table(as.list(a)))
 }
 # Continuous location-voting associations, per 10 percentage points.
 q[,`:=`(sME=isME*share10,sWP=isWP*share10,sMED=isMED*share10)]
 fit<-feols(change~0+isME+isWP+isMED+sME+sWP+sMED,q,vcov=~county_fips,ssc=ss);s<-summaryfit(fit,q,'change',en,lev,'Continuous vote share')
 for(k in 1:3){L<-rep(0,6);L[k+3]<-1;a<-contrast(s,L);g<-c('ME','WPME','MED')[k]
  slopes[[length(slopes)+1L]]<-cbind(data.table(model_id=s$id,event=en,level=lev,group=g,restaurants=q[group==g,.N],counties=s$G),as.data.table(as.list(a)))
 }
 for(pair in names(Lpair)){
  a<-contrast(s,c(0,0,0,Lpair[[pair]]));slopecontrasts[[length(slopecontrasts)+1L]]<-cbind(data.table(model_id=s$id,event=en,level=lev,pair,restaurants=nrow(q),counties=s$G),as.data.table(as.list(a)))
 }
}
writeout<-function(x,name,adjust=FALSE){z<-rbindlist(x,fill=TRUE);if('p'%in%names(z)){z[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')];if(adjust)z[,p_holm:=p.adjust(p,'holm')]};fwrite(z,file.path(o,name));z}
mm<-writeout(means,'group_means.csv');cc<-writeout(contrasts,'cuisine_contrasts.csv',TRUE);hh<-writeout(heterogeneity,'political_heterogeneity.csv',TRUE);sslope<-writeout(slopes,'continuous_group_slopes.csv',TRUE);sgap<-writeout(slopecontrasts,'continuous_cuisine_slope_differences.csv',TRUE)
invisible(writeout(modelinfo,'model_info.csv'));invisible(writeout(coefficients,'model_coefficients.csv'));invisible(writeout(covariances,'model_covariances.csv'));invisible(writeout(modelinputs,'model_verification_inputs.csv'))
# Fixed cohort for each plot, retaining all mean-analysis restaurants with any
# observed week. No extra matching or complete-case weekly panel restriction.
w<-fread(file.path(o,'weekly_observations.csv'));w[,week:=as.IDate(week)]
weekly<-w[,.(rating=mean(rating),restaurants=.N,reviews=sum(reviews)),by=.(event,level,political_trump,group,week)];setorder(weekly,event,level,political_trump,group,week);fwrite(weekly,file.path(o,'weekly_group_means.csv'))
cols<-c('#185b7a','#c45a3c','#6b7d35');gn<-c('ME','WPME','MED')
for(en in c('Election','Ban'))for(lev in c('County','Precinct')){
 mixed<-as.IDate(if(en=='Election')'2016-11-07' else '2017-01-23');date<-as.Date(mixed)+(if(en=='Election')1L else 4L)
 z<-weekly[event==en&level==lev];yr<-range(z$rating);nr<-c(0,max(z$restaurants)*1.08)
 png(file.path(o,paste0(en,'_',lev,'_trends.png')),width=2100,height=1500,res=180);par(mfrow=c(2,2),mar=c(5,5,3,1),oma=c(3,0,1,0))
 for(t in c(1,0)){
  a<-z[political_trump==t];dates<-sort(unique(a$week));plot(range(dates),yr,type='n',xaxt='n',xlab='',ylab='Restaurant-weighted rating (stars)',main=paste(en,if(t==1)'| Trump-majority' else '| Non-Trump',tolower(lev)))
  axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=date,lty=2,col='grey50')
  for(k in 1:3){b<-a[group==gn[k]];lines(b$week,b$rating,col=cols[k],lwd=2);points(b$week,b$rating,col=cols[k],pch=c(16,17,15)[k],cex=.6)}
  legend('bottomleft',legend=c('ME','WPME','Mediterranean'),col=cols,lty=1,pch=c(16,17,15),bty='n',cex=.7,horiz=TRUE)
 }
 for(t in c(1,0)){
  a<-z[political_trump==t];dates<-sort(unique(a$week));plot(range(dates),nr,type='n',xaxt='n',xlab='',ylab='Restaurants observed that week',main=if(t==1)'Trump-majority: weekly sample sizes' else 'Non-Trump: weekly sample sizes')
  axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=date,lty=2,col='grey50')
  for(k in 1:3){b<-a[group==gn[k]];lines(b$week,b$restaurants,col=cols[k],lwd=2);points(b$week,b$restaurants,col=cols[k],pch=c(16,17,15)[k],cex=.6)}
 }
 mtext('Full eligible four-week outcome cohort; holidays included; mixed event week omitted.',side=1,outer=TRUE,line=.5,cex=.75)
 mtext('Each observed restaurant has equal weight within a week. Weekly composition varies; descriptive associations.',side=1,outer=TRUE,line=1.6,cex=.72);dev.off()
 # Forest plot for the three cuisine contrasts, identical samples across contrasts.
 a<-cc[event==en&level==lev];yr<-range(c(a$low,a$high,0));png(file.path(o,paste0(en,'_',lev,'_contrasts.png')),width=1900,height=950,res=180);par(mfrow=c(1,2),mar=c(5,9,4,1),oma=c(2,0,0,0))
 for(t in c(1,0)){
  z<-a[political_trump==t][match(names(Lpair),pair)];ys<-3:1;plot(yr,c(.5,3.5),type='n',yaxt='n',xlab='First cuisine change minus second (stars)',ylab='',main=paste(en,lev,if(t==1)'| Trump-majority' else '| Non-Trump'))
  axis(2,at=ys,labels=c('ME vs WPME','ME vs Mediterranean','WPME vs Mediterranean'),las=1,cex.axis=.75);abline(v=0,lty=2,col='grey55');segments(z$low,ys,z$high,ys,col=cols,lwd=2);points(z$estimate,ys,col=cols,pch=16,cex=1.1)
  for(j in 1:3)mtext(sprintf('%s: N=%d/%d; p=%.4f%s',gsub('_',' vs ',z$pair[j]),z$first_N[j],z$second_N[j],z$p[j],z$symbol[j]),side=3,line=.1-(j-1)*.7,cex=.55)
 }
 mtext('Pointwise 95% county-clustered intervals; equal restaurant weights; observational relative changes.',side=1,outer=TRUE,line=.5,cex=.7);dev.off()
}
print(cc[,.(event,level,political_trump,pair,first_N,second_N,estimate,p,symbol)]);print(hh[,.(event,level,pair,estimate,p,symbol)])
