args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
o<-file.path(h,'full_pre_election_core','correlational_full_sample','continuous_dictionary')
d<-fread(file.path(o,'restaurant_changes_by_dictionary.csv'),colClasses=c(county_fips='character'));ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
defs<-c('legacy_baba','pre_baba','expanded_core_pre','expanded_broad_pre','expanded_broad_all_saved','full_core_pre')
labels<-c('Legacy baba flag','Pre-election baba','Pre-election core (saved)','Pre-election broad','All-saved broad','Full-raw pre-election core')
results<-list();info<-list();coefficients<-list();covariances<-list();inputs<-list();joint<-list();mid<-0L
for(def in defs)for(en in c('Election','Ban'))for(lev in c('County','Precinct')){
 x<-d[definition==def&event==en&level==lev];x[,`:=`(isME=as.integer(group=='ME'),isWP=as.integer(group=='WPME'))];x[,`:=`(sME=isME*share10,sWP=isWP*share10)]
 if(lev=='County'){
  stopifnot(x[,max(vote_share)-min(vote_share),by=county_fips][,max(V1)]<1e-10)
  fit<-feols(change~isME+isWP+sME+sWP|county_fips,x,vcov=~county_fips,ssc=ss,fixef.rm='none')
 }else fit<-feols(change~isME+isWP+share10+sME+sWP|county_fips,x,vcov=~county_fips,ssc=ss,fixef.rm='none')
 stopifnot(nobs(fit)==nrow(x));mid<-mid+1L;B<-coef(fit);V<-vcov(fit);G<-uniqueN(x$county_fips);K<-attr(vcov(fit,attr=TRUE),'df.K');mixed<-x[,.(groups=uniqueN(group),n=.N),by=county_fips]
 info[[mid]]<-data.table(model_id=mid,definition=def,event=en,level=lev,restaurants=nrow(x),ME_N=x[group=='ME',.N],WPME_N=x[group=='WPME',.N],MED_N=x[group=='MED',.N],counties=G,df_K=K,mixed_cuisine_counties=mixed[groups>1,.N],mixed_cuisine_restaurants=mixed[groups>1,sum(n)])
 coefficients[[mid]]<-data.table(model_id=mid,term=names(B),estimate=unname(B),se=sqrt(diag(V)));vv<-as.data.table(as.table(V));setnames(vv,c('term1','term2','value'));vv[,model_id:=mid];covariances[[mid]]<-vv
 ip<-data.table(model_id=mid,gmap_id=x$gmap_id,county_fips=x$county_fips,y=x$change);for(n in names(B))ip[[n]]<-x[[n]];inputs[[mid]]<-ip
 for(pair in c('ME_WPME','ME_MED','WPME_MED')){
  L<-setNames(rep(0,length(B)),names(B));if(pair %in% c('ME_WPME','ME_MED'))L['sME']<-1;if(pair=='ME_WPME')L['sWP']<- -1;if(pair=='WPME_MED')L['sWP']<-1
  b<-sum(L*B);se<-sqrt(as.numeric(t(L)%*%V%*%L));p<-2*pt(-abs(b/se),G-1);members<-strsplit(pair,'_')[[1]]
  results[[length(results)+1L]]<-data.table(model_id=mid,definition=def,event=en,level=lev,pair,estimate=b,se,p,low=b-qt(.975,G-1)*se,high=b+qt(.975,G-1)*se,first_N=x[group==members[1],.N],second_N=x[group==members[2],.N],restaurants=nrow(x),ME_N=x[group=='ME',.N],WPME_N=x[group=='WPME',.N],MED_N=x[group=='MED',.N],counties=G)
 }
 ii<-match(c('sME','sWP'),names(B));F<-as.numeric(t(B[ii])%*%solve(V[ii,ii],B[ii])/2);joint[[mid]]<-data.table(model_id=mid,definition=def,event=en,level=lev,F,df1=2,df2=G-1,p=pf(F,2,G-1,lower.tail=FALSE))
}
r<-rbindlist(results);r[,`:=`(symbol=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default=''),p_holm_72=p.adjust(p,'holm'))]
fwrite(r,file.path(o,'dictionary_slope_results.csv'));fwrite(rbindlist(info),file.path(o,'model_info.csv'));fwrite(rbindlist(coefficients),file.path(o,'model_coefficients.csv'));fwrite(rbindlist(covariances),file.path(o,'model_covariances.csv'));fwrite(rbindlist(inputs,fill=TRUE),file.path(o,'model_verification_inputs.csv'));fwrite(rbindlist(joint),file.path(o,'joint_interaction_tests.csv'))
# Same design for each dictionary: full eligible three-group sample, not the
# historical pairwise shared-county subset. All three contrasts share a model.
for(pair_code in c('ME_WPME','ME_MED','WPME_MED')){
 a<-r[pair==pair_code];bounds<-range(c(a$low,a$high,0));span<-diff(bounds);left<-bounds[1]-.06*span;right<-bounds[2]+.06*span;pcol<-right+.08*span;far<-right+.38*span
 draw<-function(){
  par(mfrow=c(2,2),mar=c(4.5,10,4.5,1),oma=c(4,0,3,0),family='sans',las=1)
  for(en in c('Election','Ban'))for(lev in c('County','Precinct')){
   z<-a[event==en&level==lev][match(defs,definition)];yy<-6:1;grey<-z$definition %chin% c('legacy_baba','expanded_broad_all_saved');main<-z$definition=='full_core_pre';col<-ifelse(grey,'#8B969D',ifelse(main,'#0B6A5F',ifelse(z$definition=='expanded_broad_pre','#B64B40','#376B92')))
   plot(c(left,far),c(.5,6.9),type='n',xaxt='n',yaxt='n',xlab='',ylab='',bty='l');ticks<-pretty(c(left,right),n=5);ticks<-ticks[ticks>=left&ticks<=right];axis(1,at=ticks,labels=ticks,cex.axis=.8);abline(v=0,lty=2,col='#929BA1');segments(left,yy,right,yy,col='#E5EAED',lwd=.7)
   axis(2,at=yy,labels=paste0(labels,'\nN=',format(z$first_N,big.mark=',',trim=TRUE),' / ',format(z$second_N,big.mark=',',trim=TRUE)),tick=FALSE,cex.axis=.72)
   arrows(z$low,yy,z$high,yy,angle=90,code=3,length=.04,col=col,lwd=1.5);points(z$estimate,yy,pch=ifelse(grey,1,16),cex=ifelse(main,1.35,1.05),col=col)
   pv<-ifelse(z$p<.001,'<.001',formatC(z$p,format='f',digits=4));text(pcol,yy,paste0(pv,z$symbol),adj=0,cex=.8,col=col);text(pcol,6.7,'Raw p',adj=0,font=2,cex=.78)
   title(main=paste(en,'|',lev,'vote share'),cex.main=1.05);mtext('Cuisine slope difference per +10pp Trump share (rating stars)',side=1,line=2.7,cex=.74)
  }
  mtext(paste(gsub('_',' vs ',pair_code),'| Continuous vote share | County fixed effects'),outer=TRUE,side=3,line=1,font=2,cex=1.05)
  mtext('Joint three-group models; equal restaurant weights; pointwise 95% county-clustered intervals.',outer=TRUE,side=1,line=2.5,cex=.75)
  mtext('N = first / second group; third group also included. Green = current full-raw core; red = older broad.',outer=TRUE,side=1,line=1.3,cex=.72)
  mtext('Grey definitions can use post-event information. Raw p: + <.10, * <.05, ** <.01, *** <.001.',outer=TRUE,side=1,line=.2,cex=.74)
 }
 png(file.path(o,paste0('continuous_dictionary_',pair_code,'.png')),width=2500,height=1800,res=170,type='cairo');draw();dev.off()
 svg(file.path(o,paste0('continuous_dictionary_',pair_code,'.svg')),width=2500/170,height=1800/170);draw();dev.off()
}
print(r[definition=='full_core_pre',.(event,level,pair,estimate,p,first_N,second_N)]);print(r[p<.1,.(definition,event,level,pair,estimate,p)])
