"""Six dictionary definitions on common outcome and geographic source files."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'correlational_full_sample/continuous_dictionary';O.mkdir(exist_ok=True);I=O/'inputs';I.mkdir(exist_ok=True)
old=pd.read_csv(H/'county_fe_regressions/inputs/expanded_group_assignments.csv',dtype={'county_fips':str});new=pd.read_csv(S/'all_group_assignments.csv',dtype={'county_fips':str})
cols=['gmap_id','definition','group','primary_category','county_fips','gop_share'];labels=pd.concat([old[cols],new[cols]],ignore_index=True);labels=labels[labels.group.isin(['ME','WPME','MED'])&labels.county_fips.notna()&labels.gop_share.between(0,1)].copy();assert not labels.duplicated(['definition','gmap_id']).any()
geo=pd.read_csv(S/'restaurant_precinct_assignments.csv',dtype={'county_fips':str},usecols=['gmap_id','precinct_id','precinct_share','eligible_precinct','state']);assert not geo.gmap_id.duplicated().any();labels=labels.merge(geo,on='gmap_id',how='left',validate='many_to_one');labels['precinct_valid']=labels.eligible_precinct.astype(str).str.lower().eq('true')&labels.precinct_id.notna()&labels.precinct_share.between(0,1)
defs=['legacy_baba','pre_baba','expanded_core_pre','expanded_broad_pre','expanded_broad_all_saved','full_core_pre']
assert set(labels.definition.unique())==set(defs)
descriptions=[('legacy_baba','Legacy baba flag','Inherited saved baba flag; timing can include post-event evidence','Historical corpus/flag',True),('pre_baba','Pre-election baba','Baba ghanoush variants only','Saved pre-election text, starting July 2016',False),('expanded_core_pre','Pre-election core','Core dishes only','Saved pre-election text, starting July 2016',False),('expanded_broad_pre','Pre-election broad','Core plus shared dishes','Saved pre-election text, starting July 2016',False),('expanded_broad_all_saved','All-saved broad','Core plus shared dishes; can include post-event evidence','Saved July 2016-June 2017 text',True),('full_core_pre','Full-raw pre-election core','Core dishes only; current primary definition','All raw eligible pre-election review history',False)]
pd.DataFrame(descriptions,columns=['definition','label','dictionary','review_coverage','can_use_post_event']).to_csv(O/'dictionary_definitions.csv',index=False)
design={'question':'Dictionary sensitivity of continuous voting-share associations with county FE','definitions':defs,'comparisons':['ME_WPME','ME_MED','WPME_MED'],'share_levels':['County','Precinct'],'political_measure':'Actual 2016 Trump share of all-candidate votes; per 10 percentage points; no majority split','model':'One joint three-group county-FE regression for each definition/event/share level, so all three contrasts share a sample and covariance matrix. County-vote common main effect absorbed; precinct common slope estimable.','sample':'Full eligible outcome sample for each definition; no matching, price filter, pairwise common-county or three-group-in-each-county restriction','weights':'Every restaurant unit weight','inference':'County-clustered CR1, fixest nonnested FE adjustment, t df=counties-1','windows':'Election Oct10-Nov6 vs Nov14-Dec11 2016; ban Dec26-Jan22 vs Jan30-Feb26 2017. Mixed weeks omitted, holidays retained.','interpretation':'Conditional associations, not causal effects','sensitivity_limitations':['Grey rows may use post-event evidence','Full-raw core versus saved-core changes review coverage and restaurant classification, not only lexicon','Each row may include a different sample; same-row comparisons share one sample','No outcome-selected classification or specification tuning']}
(O/'analysis_design.json').write_text(json.dumps(design,indent=2));frames=[];flow=[]
for event in ['Election','Ban']:
 # Use the complete expanded outcome frame. The later full-core input subset
 # would wrongly omit old all-saved-only labels without pre-election text.
 frozen=I/f'periods_{event.lower()}_4w.csv'
 if frozen.exists():periods=pd.read_csv(frozen)
 else:
  periods=pd.read_csv(H/'expanded_positioning'/f'periods_{event.lower()}_4w.csv');periods=periods[periods.gmap_id.isin(labels.gmap_id.unique())];periods.to_csv(frozen,index=False)
 assert not periods.gmap_id.duplicated().any()
 q=labels.merge(periods,on='gmap_id',validate='many_to_one');q=q[q.rating_pre.between(1,5)&q.rating_post.between(1,5)&q.reviews_pre.gt(0)&q.reviews_post.gt(0)]
 assert np.allclose(q.change,q.rating_post-q.rating_pre)
 for level in ['County','Precinct']:
  z=q.copy() if level=='County' else q[q.precinct_valid].copy();z['event']=event;z['level']=level;z['vote_share']=z.gop_share if level=='County' else z.precinct_share;z['share10']=(z.vote_share-.5)/.1;frames.append(z)
  f=z.groupby(['definition','group']).agg(restaurants=('gmap_id','size'),counties=('county_fips','nunique'),precincts=('precinct_id','nunique')).reset_index();f['event']=event;f['level']=level;flow.append(f)
d=pd.concat(frames,ignore_index=True);assert not d.duplicated(['definition','event','level','gmap_id']).any();d.to_csv(O/'restaurant_changes_by_dictionary.csv',index=False);pd.concat(flow,ignore_index=True).to_csv(O/'sample_sizes.csv',index=False)
# Ensure the current full-raw core row exactly preserves the latest full sample.
reference=pd.read_csv(S/'correlational_full_sample/restaurant_changes.csv')
for key,z in d[d.definition.eq('full_core_pre')].groupby(['event','level']):
 ref=reference[reference.event.eq(key[0])&reference.level.eq(key[1])];assert set(z.gmap_id)==set(ref.gmap_id);a=z[['gmap_id','group','change','vote_share']].merge(ref[['gmap_id','group','change','vote_share']],on='gmap_id',validate='one_to_one',suffixes=('_new','_old'));assert a.group_new.eq(a.group_old).all() and np.allclose(a.change_new,a.change_old) and np.allclose(a.vote_share_new,a.vote_share_old)
sources=[H/'county_fe_regressions/inputs/expanded_group_assignments.csv',S/'all_group_assignments.csv',S/'restaurant_precinct_assignments.csv']+[I/f'periods_{ev}_4w.csv' for ev in ['election','ban']]
(O/'input_checksums.json').write_text(json.dumps({p.relative_to(H.parent).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2));print(d.groupby(['event','level','definition']).size().to_string())
