"""Independent NumPy verification and a local report of precinct moderation."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;core_only='--core' in sys.argv;O=H/('precinct_core' if core_only else 'precinct_analysis')
r=pd.read_csv(O/'precinct_interaction_results.csv')
d=pd.read_csv(O/'model_verification_designs.csv',dtype={'fixed_effect':str,'county_fips':str,'county_group':str},low_memory=False)
errors=[]
for row in r.itertuples():
    z=d[d.model_id==row.id].copy();cols=row.variables.split(';')
    v=z[cols+['change']];v=v-v.groupby(z.fixed_effect).transform('mean')
    x=v[cols].to_numpy();y=v.change.to_numpy();inv=np.linalg.pinv(x.T@x)
    b=inv@x.T@y;res=y-x@b
    scores=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy()
    n=len(z);g=z.county_fips.nunique()
    cov=inv@scores.T@scores@inv*(g/(g-1)*(n-1)/(n-row.df_K));j=cols.index('ME_share')
    errors.extend([abs(b[j]-row.estimate),abs(np.sqrt(cov[j,j])-row.se)])
assert max(errors)<1e-8,max(errors)
audit={'independent_models_verified':len(r),'maximum_coefficient_or_se_error':max(errors),'weighting':'Equal restaurant weights','inference':'County-clustered CR1 with fixest nonnested FE correction, two-sided t counties-1'}
(O/'model_verification.json').write_text(json.dumps(audit,indent=2))

counts=[];sharecounts=[];ranges=[]
for event in ['Election','Ban']:
    q=pd.read_csv(O/f'model_sample_{event.lower()}.csv')
    q['precinct_majority']=np.where(q.precinct_share>.5,'Trump >50%','Trump <=50%')
    q['county_type']=np.where(q.trump==1,'Trump county','Non-Trump county')
    q['share_bin']=pd.cut(q.precinct_share,[0,.25,.5,.75,1],include_lowest=True)
    c=q.groupby(['county_type','precinct_majority','group'],observed=True).size().reset_index(name='restaurants');c['shock']=event;counts.append(c)
    c=q.groupby(['share_bin','group'],observed=True).size().reset_index(name='restaurants');c['shock']=event;sharecounts.append(c)
    ranges.append(q.groupby('group').precinct_share.agg(['min','median','max']).reset_index().assign(shock=event))
pd.concat(counts).to_csv(O/'county_precinct_cross_classification.csv',index=False)
pd.concat(sharecounts).to_csv(O/'precinct_share_sample_sizes.csv',index=False)
pd.concat(ranges).to_csv(O/'precinct_share_ranges.csv',index=False)

def display(x):
    x=x.copy();x['Gradient (SE)']=x.apply(lambda z:f'{z.estimate:+.4f}{z.symbol if isinstance(z.symbol,str) else ""} ({z.se:.4f})',axis=1)
    x['95% CI']=x.apply(lambda z:f'[{z.low:+.4f}, {z.high:+.4f}]',axis=1)
    x['Raw p']=x.p.map(lambda v:f'{v:.4f}')
    return x
r=display(r)
main=r[(r.model=='Precinct share + county FE')&(r['sample']=='Main matched sample')]
primary=main[main.stratum=='All counties']
cols=['shock','stratum','Gradient (SE)','95% CI','Raw p','p_holm_six_main','restaurants','ME','WPME','counties','precincts']
fullcols=['shock','stratum','model','sample','exposure','Gradient (SE)','95% CI','Raw p','restaurants','counties']
tab=lambda x:x.to_html(index=False,border=0)
coverage=pd.read_csv(O/'population_coverage.csv')
link=json.loads((O/'precinct_linkage_audit.json').read_text())
placebo=r[r.model.isin(['Event gradient on placebo subset','Pre-event placebo gradient'])]
html='''<!doctype html><html><head><meta charset="utf-8"><title>2016 precinct voting and ME–WPME differences</title><style>
body{font:16px/1.5 system-ui;max-width:1300px;margin:36px auto;padding:0 24px;color:#243343}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3f6;position:sticky;top:0}td:nth-child(-n+3){text-align:left}.scroll{overflow:auto;max-height:650px}.note{padding:18px;background:#edf3f6}img{width:100%}code{white-space:normal}
</style></head><body><h1>Do ME–WPME differences vary with neighborhood Trump support?</h1>
<p>Four complete weeks on either side of the election and ban; frozen broad pre-election dish dictionary; primary cuisine categories; equal restaurant weights; county-clustered inference.</p>
<div class="note"><b>Interpretation:</b> The reported gradient is the change in ME-minus-WPME relative rating changes associated with a <b>10 percentage-point increase</b> in precinct Trump vote share. A <b>negative</b> gradient supports ME losing more ground in more pro-Trump neighborhoods. A positive gradient points in the opposite direction.</div>
<h2>Main results</h2>'''+tab(main[cols])+'''
<p>The pooled election and ban gradients are not statistically clear. The main ban gradient within non-Trump counties is positive, opposite the proposed ME-loss hypothesis. That subgroup association should be assessed alongside the stricter models and exploratory multiplicity, rather than selected because its raw p-value is small. Coefficients measure heterogeneity in rating changes, not a causal effect of neighbors voting for Trump.</p>
<img src="precinct_gradient.png" alt="ME-minus-WPME change across local Trump support, election and ban">
<p>Lines show model-implied ME-minus-WPME changes and pointwise 95% confidence intervals from the pooled county-FE model. To avoid extrapolating to sparsely represented neighborhoods, plots stop at the intersection of each group’s 5th–95th percentile precinct-share ranges.</p>
<h2>Model and comparability</h2><p><code>RatingChange = county FE + ME + precinctShare10 + ME × precinctShare10 + error</code>, where <code>precinctShare10 = (TrumpShare − .50)/.10</code>. Each restaurant contributes one observation. Ratings within a restaurant-period aggregate reviews using their counts. Reviews are required in both periods; missing ratings are never zero-filled. County FE in changes correspond to county-by-period controls in a restaurant-FE panel. Trump county continues to mean county Trump share above 50% using the existing county source.</p>
<p>The <b>county share benchmark</b> uses continuous county Trump share on exactly the precinct-matched sample. The <b>county gradient</b> sensitivity adds ME × county Trump share, separating the local political gradient from a county-level cuisine gradient. <b>County-by-group FE</b> allows each county a separate average change for each cuisine group; the interaction then compares within-county political gradients for ME and WPME. It requires at least two restaurants of each group in retained counties, so uses a smaller sample. <b>Baseline adjustment</b> adds the pre-period rating and log(1+pre-period reviews); this changes the conditional identifying assumption and can absorb mean reversion.</p>
<p>Other sensitivities exclude precincts with fewer than 100 votes, exclude locations within approximately 50 meters of a precinct boundary, or use Trump/(Trump+Clinton). County clustering stays fixed throughout. The boundary-distance filter can be severe for restaurants located along roads that form precinct boundaries; it is a sensitivity, not the preferred sample.</p>
<h2>Pre-event placebo</h2>'''+tab(placebo[fullcols])+'''
<p>The placebo compares election baseline October 10–November 6 with September 12–October 9, 2016; for the ban it compares December 26–January 22 with November 28–December 25. It uses the subset observed in the additional earlier four-week block. The event gradient is reestimated on that same subset. A non-significant placebo is not proof of parallel trends; this is one coarse pre-event difference and can miss nonlinear trends.</p>
<h2>Coverage and provenance</h2><p>Precinct boundaries and presidential returns are from the <a href="https://github.com/noahdasanaike/sage">SAGE archive</a>, which documents VEST and other sources for earlier US elections. The original <a href="https://doi.org/10.7910/DVN/NH5S2I">VEST 2016 archive</a> describes state precinct shapes joined with election results. Harvard’s automated download returned HTTP 403; the openly published SAGE files were used instead. Geometry was verified against the provider’s published MD5 hash. We project restaurant coordinates into the archive’s CRS (EPSG:3857), then perform point-in-polygon joins within state. Ambiguous or unmatched locations are excluded; no nearest-precinct substitution is used. County FIPS is cross-checked where the source has explicit county FIPS; NAME2 can instead represent municipalities or local IDs in other states.</p>
<p>Vote share is Trump votes divided by the source’s published total across all candidates. All precinct totals agree with summed candidate votes. Zero-total precincts are excluded. Source polygons can represent harmonized precincts and votes can include allocated absentee/provisional ballots. No independent reconstruction of original state-level VEST files was possible in this run. Restaurant location measures resident political context, not reviewer residence or individual ideology.</p>'''+tab(coverage)+'''
<p>The table above counts the source population with valid county geography, before requiring reviews on both sides of an event. Event-specific sample sizes appear in the main table. Full linkage counts are saved separately.</p>
<h2>All 40 specifications</h2><p>Raw two-sided p-value symbols: + &lt;.10; * &lt;.05; ** &lt;.01; *** &lt;.001. Holm-adjusted p-values for the two pooled primary event tests are saved separately in the CSV. Subgroups and sensitivities are exploratory. No definition or window was changed in response to these results.</p><div class="scroll">'''+tab(r[fullcols])+'''</div>
<p>All 40 coefficient and standard-error calculations were independently reproduced in NumPy. <a href="precinct_interaction_results.csv">Results</a> · <a href="model_verification.json">Verification</a> · <a href="precinct_linkage_audit.json">Linkage audit</a> · <a href="county_precinct_cross_classification.csv">County/precinct cross-classification</a> · <a href="precinct_share_sample_sizes.csv">Sample by local vote share</a> · <a href="../prepare_precincts.py">Geography code</a> · <a href="../precinct_models.R">Regression code</a></p></body></html>'''
if core_only:
    html=html.replace('frozen broad pre-election dish dictionary','frozen core-only pre-election dish dictionary (27 tags; all 10 shared tags removed)')
    previous='<p>The pooled election and ban gradients are not statistically clear. The main ban gradient within non-Trump counties is positive, opposite the proposed ME-loss hypothesis. That subgroup association should be assessed alongside the stricter models and exploratory multiplicity, rather than selected because its raw p-value is small. Coefficients measure heterogeneity in rating changes, not a causal effect of neighbors voting for Trump.</p>'
    summaries=' '.join(f'{x.shock}: gradient {x.estimate:+.4f} stars per +10 percentage points, raw p={x.p:.4f}.' for x in primary.itertuples())
    html=html.replace(previous,'<p>'+summaries+' Negative gradients indicate ME losing more ground as local Trump support rises. These are exploratory dictionary sensitivities, not established causal effects.</p>')
    html=html.replace('No definition or window was changed in response to these results.','The user requested this core-only definition after seeing the broad-dictionary results. Windows and model specifications are unchanged; this is an exploratory sensitivity.')
    cross=pd.read_csv(O/'classification_changes.csv')
    broad=pd.read_csv(H/'precinct_analysis/precinct_interaction_results.csv')
    comparison=pd.concat([broad.assign(dictionary='Broad (37 tags)'),pd.read_csv(O/'precinct_interaction_results.csv').assign(dictionary='Core only (27 tags)')],ignore_index=True)
    comparison.to_csv(O/'broad_core_model_comparison.csv',index=False)
    c=display(comparison[(comparison.model=='Precinct share + county FE')&(comparison['sample']=='Main matched sample')])
    section='<h2>What changed when shared tags were removed?</h2><p>Removed: hummus, falafel, tabbouleh, labneh, zaatar, kebab, kofta, dolma, shakshuka, baklava. WPME now requires a core dish mention. Restaurants with only shared-dish tags move to MED. ME classifications and geographic assignments are unchanged. ME sample counts can nevertheless fall when fewer counties contain both ME and WPME. MED means no detected core tag, rather than a verified cuisine identity.</p>'+tab(cross)+'<h2>Broad versus core-only: main models</h2>'+tab(c[['dictionary']+cols])
    html=html.replace('<h2>Main results</h2>',section+'<h2>Core-only main results</h2>')
    html=html.replace('<a href="../prepare_precincts.py">Geography code</a>','<a href="../prepare_precinct_core.py">Core-only preparation code</a>')
(O/'precinct_report.html').write_text(html,encoding='utf-8')
print(json.dumps(audit));print(main[cols].to_string(index=False));print(r[(r.stratum=='All counties')&(r['sample']=='Main matched sample')][fullcols].to_string(index=False))
