"""Remove shared dish tags; reuse verified geometry without relinking coordinates."""
from pathlib import Path
import pandas as pd
import json,hashlib,shutil
H=Path(__file__).resolve().parent;O=H/'precinct_core';O.mkdir(exist_ok=True)
old=pd.read_csv(H/'precinct_analysis/restaurant_precinct_assignments.csv',dtype={'county_fips':str,'NAME2':str})
labels=pd.read_csv(H/'county_fe_regressions/inputs/expanded_group_assignments.csv',dtype={'county_fips':str})
labels=labels[labels.definition.eq('expanded_core_pre')].copy()
assert set(labels.gmap_id)==set(old.gmap_id)
assert not labels.gmap_id.duplicated().any()
new=old.drop(columns=['definition','group']).merge(labels[['gmap_id','definition','group']],on='gmap_id',validate='one_to_one')
cross=old[['gmap_id','group']].merge(labels[['gmap_id','group']],on='gmap_id',suffixes=('_broad','_core'),validate='one_to_one')
assert cross.loc[cross.group_broad.eq('ME'),'group_core'].eq('ME').all()
assert cross.loc[cross.group_core.eq('WPME'),'group_broad'].eq('WPME').all()
assert cross.loc[cross.group_broad.eq('MED'),'group_core'].eq('MED').all()
cross.groupby(['group_broad','group_core']).size().reset_index(name='restaurants').to_csv(O/'classification_changes.csv',index=False)
new.to_csv(O/'restaurant_precinct_assignments.csv',index=False)
new.groupby(['group','trump'],dropna=False).agg(population=('gmap_id','size'),spatial_matches=('precinct_id','count'),eligible=('eligible_precinct','sum')).reset_index().to_csv(O/'population_coverage.csv',index=False)
d=json.loads((H/'expanded_dish_dictionary.json').read_text());removed=list(d['shared_sensitivity']);d['shared_sensitivity']={};d['main_definition']='expanded_core_pre'
d['comparison_note']='Core-only rerun requested by user; earlier broad dictionary results preserved.'
(O/'core_dictionary.json').write_text(json.dumps(d,indent=2))
audit=json.loads((H/'precinct_analysis/precinct_linkage_audit.json').read_text());audit.update({'definition':'expanded_core_pre','core_tags':list(d['core']),'removed_shared_tags':removed,'classification_source':'county_fe_regressions/inputs/expanded_group_assignments.csv; expanded_core_pre','geometry_reused_from':'precinct_analysis/restaurant_precinct_assignments.csv','geography_source_sha256':hashlib.sha256((H/'precinct_analysis/restaurant_precinct_assignments.csv').read_bytes()).hexdigest(),'all_business_ids_and_geography_unchanged':True,'eligible_restaurants':int(new.eligible_precinct.sum())})
(O/'precinct_linkage_audit.json').write_text(json.dumps(audit,indent=2))
print(cross.groupby(['group_broad','group_core']).size().to_string())
