from pathlib import Path
import json
import pandas as pd
import numpy as np
H=Path(__file__).resolve().parent;O=H/'county_continuous'
r=pd.read_csv(O/'county_continuous_results.csv');d=pd.read_csv(O/'verification_designs.csv',dtype={'county_fips':str,'fixed_effect':str})
errors=[]
for row in r.itertuples():
 z=d[d.model_id.eq(row.id)].copy();cols=row.variables.split(';');v=z[cols+['change']];v=v-v.groupby(z.fixed_effect).transform('mean')
 x=v[cols].to_numpy();y=v.change.to_numpy();inv=np.linalg.pinv(x.T@x);b=inv@x.T@y;res=y-x@b
 scores=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
 cov=inv@scores.T@scores@inv*g/(g-1)*(n-1)/(n-row.df_K);j=cols.index('ME_county');errors.extend([abs(b[j]-row.estimate),abs(np.sqrt(cov[j,j])-row.se)])
assert max(errors)<1e-8
(O/'verification.json').write_text(json.dumps({'models_independently_verified':len(r),'max_coefficient_or_se_error':max(errors)},indent=2))
r['Estimate (SE)']=r.apply(lambda q:f'{q.estimate:+.4f} ({q.se:.4f})',axis=1);r['95% CI']=r.apply(lambda q:f'[{q.low:+.4f}, {q.high:+.4f}]',axis=1)
r['p']=r.p.map(lambda v:f'{v:.4f}')
table=r[['shock','model','Estimate (SE)','95% CI','p','restaurants','ME','WPME','counties']].to_html(index=False,border=0)
html='''<!doctype html><html><head><meta charset="utf-8"><title>Continuous county Trump support</title><style>body{font:16px/1.5 system-ui;color:#243343;max-width:1250px;margin:36px auto;padding:0 24px}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:14px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:right}td:nth-child(-n+2){text-align:left}img{width:100%}.note{padding:18px;background:#edf3f6}</style></head><body><h1>Continuous county Trump support</h1><p>ME versus WPME; frozen pre-election broad dictionary; four complete weeks each side of the election or ban; equal restaurant weights.</p><div class="note">The estimate is the change in <b>ME-minus-WPME relative rating changes</b> associated with a <b>10 percentage-point increase in county Trump vote share</b>. Negative values support ME losing more ground in more pro-Trump counties. Main estimates are close to zero and uncertain for both shocks.</div><h2>Results</h2>'''+table+'''
<img src="county_continuous.png" alt="ME-minus-WPME changes across continuous county Trump support">
<h2>Specification</h2><p><code>Change = county FE + ME + ME × [(county Trump share − .50)/.10] + error.</code> The county Trump share main effect is absorbed by county fixed effects. This asks whether the within-county ME–WPME gap in changes varies across counties with different voting shares. It replaces the earlier above/below-50% split with a linear gradient. It does not compare changes in a county's voting behavior over time.</p>
<p>County shares use the same source and all-candidate denominator as the earlier analyses. The full county-linked restaurant sample is used, without requiring a precinct match. Only counties containing both groups in the event window are retained. County-clustered CR1 standard errors use t reference degrees of freedom equal to counties minus one. Review counts weight reviews within restaurant-periods; each restaurant has unit regression weight.</p>
<p>Election: October 10–November 6 versus November 14–December 11, 2016. Ban: December 26, 2016–January 22, 2017 versus January 30–February 26, 2017. Mixed event weeks are excluded. Baseline sensitivity adds the pre-period rating and log(1+pre-period reviews); it permits mean reversion and changes the identifying assumption. It is not chosen by p-value.</p>
<p>The binary and continuous models impose different functional forms: a threshold difference can coexist with a weak linear gradient. These results do not establish a causal election/ban effect or prove that there is no heterogeneity. A county-by-cuisine fixed effect in changes would absorb this county-level interaction, so it cannot identify the same slope.</p>
<p>All four coefficients and standard errors were independently reproduced in NumPy. Raw p-value symbols would be + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001; none applies to the main results. Holm corrections for the two events are saved separately.</p>
<p><a href="county_continuous_results.csv">Results CSV</a> · <a href="verification.json">Verification</a> · <a href="../county_continuous.R">R code</a> · <a href="../precinct_analysis/precinct_report.html">Precinct comparisons</a></p></body></html>'''
(O/'county_continuous_report.html').write_text(html,encoding='utf-8')
print(r[['shock','model','Estimate (SE)','95% CI','p','restaurants','ME','WPME','counties']].to_string(index=False));print('Maximum verification error',max(errors))
