# Frozen definitions/windows; equal restaurant weights; county-clustered inference.
args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
core_only<-'--core'%in%commandArgs(TRUE)
out<-file.path(here,if(core_only)'precinct_core' else 'precinct_analysis');src<-file.path(here,'county_fe_regressions','inputs')
a<-fread(file=file.path(out,'restaurant_precinct_assignments.csv'),colClasses=c(county_fips='character'))
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
rows<-list();designs<-list();preds<-list();sizes<-list();models<-list()
w<-fread(file=file.path(src,'expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
fit_one<-function(d,event,stratum,label,variables,fe='county_fips',exposure='Precinct',sample='Main matched sample'){
  if(fe=='county_group'){
    d<-d[county_group %chin% d[,.N,by=county_group][N>1]$county_group]
    d<-d[county_fips %chin% d[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips]
  }
  id<-length(rows)+1L
  fit<-feols(as.formula(paste('change ~',paste(variables,collapse='+'),'|',fe)),data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
  stopifnot(nobs(fit)==nrow(d),'ME_share'%in%names(coef(fit)))
  ct<-coeftable(fit)['ME_share',];ci<-as.matrix(confint(fit))['ME_share',];G<-uniqueN(d$county_fips)
  stopifnot(abs(ct[4]-2*pt(abs(ct[3]),G-1,lower.tail=FALSE))<1e-9)
  rows[[id]]<<-data.table(id,shock=event,stratum,model=label,sample,exposure,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),ME=sum(d$ME),WPME=sum(1-d$ME),counties=G,precincts=uniqueN(d$precinct_id),df_K=attr(vcov(fit,attr=TRUE),'df.K'),variables=paste(names(coef(fit)),collapse=';'))
  z<-copy(d[,unique(c('gmap_id','change','county_fips',fe,names(coef(fit)))),with=FALSE]);z[,fixed_effect:=as.character(get(fe))];z[,model_id:=id];designs[[id]]<<-z
  models[[paste(event,stratum,label,sample,sep='__')]]<<-fit
  if(label=='Precinct share + county FE' & stratum=='All counties' & sample=='Main matched sample'){
    b<-coef(fit);V<-vcov(fit)
    lo<-max(quantile(d[ME==1]$precinct_share,.05),quantile(d[ME==0]$precinct_share,.05));hi<-min(quantile(d[ME==1]$precinct_share,.95),quantile(d[ME==0]$precinct_share,.95))
    pp<-data.table(shock=event,share=seq(lo,hi,length.out=101));s<-(pp$share-.5)/.1
    pp[,estimate:=b['ME']+s*b['ME_share']]
    se<-sqrt(V['ME','ME']+s^2*V['ME_share','ME_share']+2*s*V['ME','ME_share'])
    pp[,`:=`(low=estimate-qt(.975,G-1)*se,high=estimate+qt(.975,G-1)*se)];preds[[length(preds)+1L]]<<-pp
  }
}
for(event in c('Election','Ban')){
  p<-fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv')))
  q<-merge(p,a[group %chin% c('ME','WPME')],by='gmap_id')
  zsize<-q[,.(restaurants=.N,matched=sum(eligible_precinct)),by=.(group,trump)];zsize[,shock:=event];sizes[[length(sizes)+1L]]<-zsize
  q<-q[eligible_precinct==TRUE];q[,ME:=as.integer(group=='ME')]
  shared<-q[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips;q<-q[county_fips %chin% shared]
  q[,`:=`(share10=(precinct_share-.5)/.1,county10=(gop_share-.5)/.1,log_pre_reviews=log1p(reviews_pre),county_group=paste(county_fips,ME,sep='_'))]
  q[,`:=`(ME_share=ME*share10,ME_county10=ME*county10)]
  for(stratum in c('All counties','Trump counties','Non-Trump counties')){
    d<-copy(if(stratum=='All counties')q else if(stratum=='Trump counties')q[trump==1] else q[trump==0])
    d[,ME_share:=ME*county10]
    fit_one(d,event,stratum,'County share benchmark',c('ME','ME_share'),exposure='County')
    d[,ME_share:=ME*share10]
    fit_one(d,event,stratum,'Precinct share + county FE',c('ME','share10','ME_share'))
    fit_one(d,event,stratum,'Precinct share + county gradient',c('ME','share10','ME_share','ME_county10'))
    fit_one(d,event,stratum,'Precinct share + county-by-group FE',c('share10','ME_share'),fe='county_group')
    fit_one(d,event,stratum,'Precinct share + baseline adjustment',c('ME','share10','ME_share','rating_pre','log_pre_reviews'))
  }
  for(sens in c('At least 100 precinct votes','At least 50 m from precinct boundary','Two-party vote share')){
    d<-copy(if(sens=='At least 100 precinct votes')q[total_max>=100] else if(sens=='At least 50 m from precinct boundary')q[boundary_distance_m_approx>=50] else q)
    if(sens=='Two-party vote share')d[,share10:=(precinct_share_2party-.5)/.1]
    d[,ME_share:=ME*share10]
    shared<-d[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips;d<-d[county_fips %chin% shared]
    fit_one(d,event,'All counties','Precinct share + county FE',c('ME','share10','ME_share'),sample=sens)
  }
  dates<-if(event=='Election')c('2016-09-12','2016-10-03') else c('2016-11-28','2016-12-19')
  prior<-w[week>=as.IDate(dates[1]) & week<=as.IDate(dates[2]) & reviews>0 & !is.na(rating),.(prior_rating=sum(rating*reviews)/sum(reviews)),by=gmap_id]
  d<-merge(q,prior,by='gmap_id');shared<-d[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips;d<-d[county_fips %chin% shared]
  fit_one(d,event,'All counties','Event gradient on placebo subset',c('ME','share10','ME_share'),sample='Observed prior four-week block')
  d[,change:=rating_pre-prior_rating]
  fit_one(d,event,'All counties','Pre-event placebo gradient',c('ME','share10','ME_share'),sample='Observed prior four-week block')
  q[,shock:=event];fwrite(q,file.path(out,paste0('model_sample_',tolower(event),'.csv')))
}
r<-rbindlist(rows);r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
r[,p_holm_primary_two_events:=NA_real_];ii<-which(r$model=='Precinct share + county FE' & r$stratum=='All counties' & r$sample=='Main matched sample');r[ii,p_holm_primary_two_events:=p.adjust(p,'holm')]
r[,p_holm_six_main:=NA_real_];ii<-which(r$model=='Precinct share + county FE' & r$sample=='Main matched sample');r[ii,p_holm_six_main:=p.adjust(p,'holm')]
r[,p_holm_all_forty:=p.adjust(p,'holm')]
fwrite(r,file.path(out,'precinct_interaction_results.csv'));fwrite(rbindlist(sizes),file.path(out,'event_linkage_counts.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'model_verification_designs.csv'))
pp<-rbindlist(preds);fwrite(pp,file.path(out,'predicted_ME_WPME_difference.csv'));saveRDS(models,file.path(out,'precinct_models.rds'))
png(file.path(out,'precinct_gradient.png'),width=2100,height=1100,res=180);par(mfrow=c(1,2),mar=c(5,5,4,2),oma=c(4,0,1,0))
for(event in c('Election','Ban')){
 z<-pp[shock==event];plot(z$share*100,z$estimate,type='n',ylim=range(z$low,z$high,0),xlab='2016 precinct Trump vote share (%)',ylab='ME minus WPME change (rating stars)',main=event)
 polygon(c(z$share,rev(z$share))*100,c(z$low,rev(z$high)),col='#dceaf1',border=NA);abline(h=0,lty=2,col='grey');lines(z$share*100,z$estimate,col='#185b7a',lwd=2)
 rr<-r[shock==event & model=='Precinct share + county FE' & stratum=='All counties' & sample=='Main matched sample']
 mtext(sprintf('Gradient per +10 pp: %+.3f; p=%.3f; N=%s',rr$estimate,rr$p,format(rr$restaurants,big.mark=',')),side=3,line=.3,cex=.8)
}
mtext('County fixed effects; equal restaurant weights; 95% county-clustered intervals.',outer=TRUE,side=1,line=.3,cex=.7)
mtext('Shown over overlapping 5th-95th percentile precinct-share support.',outer=TRUE,side=1,line=1.4,cex=.7);dev.off()
writeLines(capture.output(sessionInfo()),file.path(out,'R_session.txt'))
print(r[,.(shock,stratum,model,sample,estimate,se,p,restaurants,counties)])
