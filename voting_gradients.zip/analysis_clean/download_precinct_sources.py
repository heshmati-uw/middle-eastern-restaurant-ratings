"""Download openly published SAGE 2016 precinct files; raw files stay local."""
from pathlib import Path
import urllib.request,urllib.parse,json,hashlib,base64
O=Path(__file__).resolve().parent/'precinct_analysis';O.mkdir(exist_ok=True)
def get_json(url,path):
    j=json.load(urllib.request.urlopen(url,timeout=45));path.write_text(json.dumps(j));return j
def download(url,path,size=None,md5=None):
    if not path.exists() or (size and path.stat().st_size!=size):
        with urllib.request.urlopen(url,timeout=90) as src,path.open('wb') as dst:
            while b:=src.read(4*1024*1024):dst.write(b)
    if size:assert path.stat().st_size==size
    if md5:
        h=hashlib.md5()
        with path.open('rb') as f:
            while b:=f.read(4*1024*1024):h.update(b)
        assert base64.b64encode(h.digest()).decode()==md5
manifest=O/'polygons_index.json'
j=json.loads(manifest.read_text()) if manifest.exists() else get_json('https://storage.googleapis.com/storage/v1/b/sage-archive/o?prefix=polygons/United&maxResults=100',manifest)
x=next(x for x in j['items'] if 'United States' in x['name'] and '2016' in x['name'])
download(x['mediaLink'],O/'usa_2016_precinct_polygons.parquet',int(x['size']),x['md5Hash'])
download('https://storage.googleapis.com/sage-archive/parquet/_index.csv',O/'parquet_index.csv')
import csv
with (O/'parquet_index.csv').open(newline='') as f:row=next(x for x in csv.DictReader(f) if x['country']=='United States of America' and x['year']=='2016')
download('https://storage.googleapis.com/sage-archive/parquet/'+urllib.parse.quote(row['path'],safe='/='),O/'usa_2016_votes.parquet',int(row['bytes']))
print('2016 precinct source files ready. Cite SAGE and its documented upstream sources.')
