"""Link frozen restaurant groups to actual 2016 SAGE/VEST precinct polygons.

Raw archive files stay local; no nearest-precinct imputation or name-only join.
"""
from pathlib import Path
import sys,json,hashlib,base64,gc
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'precinct_analysis';O.mkdir(exist_ok=True)
sys.path.insert(0,str(H.parent/'.analysis-python'))
import pyarrow.parquet as pq
import pyarrow.compute as pc
import shapely
from shapely.strtree import STRtree
from pyproj import CRS,Transformer

def digest(p,algo='sha256'):
    h=hashlib.new(algo)
    with p.open('rb') as f:
        while b:=f.read(4*1024*1024):h.update(b)
    return h.hexdigest()

manifest=json.loads((O/'polygons_index.json').read_text())
obj=next(x for x in manifest['items'] if 'United States' in x['name'] and '2016' in x['name'])
polyfile=O/'usa_2016_precinct_polygons.parquet'
assert polyfile.stat().st_size==int(obj['size'])
assert base64.b64encode(bytes.fromhex(digest(polyfile,'md5'))).decode()==obj['md5Hash']
v=pq.read_table(O/'usa_2016_votes.parquet').to_pandas()
assert v.election_type.eq('Presidential').all()
keys=[c for c in v if c.startswith('NAME')]+['geometry_type','geometry_type_b','geometry_level']
for k in keys:v[k]=v[k].fillna('').astype(str)
assert not v.duplicated(keys+['party']).any()
v['trump_votes']=v.votes.where(v.party.eq('TRUMP, Donald'),0)
v['clinton_votes']=v.votes.where(v.party.eq('CLINTON, Hillary'),0)
pv=v.groupby(keys,dropna=False).agg(votes_sum=('votes','sum'),trump_votes=('trump_votes','sum'),clinton_votes=('clinton_votes','sum'),total_min=('total_votes','min'),total_max=('total_votes','max')).reset_index()
assert np.allclose(pv.total_min,pv.total_max)
# Total votes counts all candidates; export sum-vs-published discrepancies for audit.
pv['denominator_discrepancy']=pv.votes_sum-pv.total_max
pv['precinct_share']=pv.trump_votes/pv.total_max.replace(0,np.nan)
pv['precinct_share_2party']=pv.trump_votes/(pv.trump_votes+pv.clinton_votes).replace(0,np.nan)
assert pv.precinct_share.dropna().between(0,1).all()
pv.loc[pv.denominator_discrepancy.abs()>.001].to_csv(O/'vote_denominator_audit.csv',index=False)
pv.to_csv(O/'precinct_votes_audited.csv',index=False)
v.groupby('party').votes.sum().to_csv(O/'national_candidate_totals.csv')
del v;gc.collect()

a=pd.read_csv(H/'county_fe_regressions/inputs/expanded_group_assignments.csv',dtype={'county_fips':str})
a=a[a.definition.eq('expanded_broad_pre') & a.group.isin(['ME','WPME','MED'])].copy()
coord=O/'focal_coordinates.csv'
if not coord.exists():coord=H/'expanded_positioning/metadata_with_geography.csv'
meta=pd.read_csv(coord,usecols=['gmap_id','latitude','longitude'])
a=a.merge(meta,on='gmap_id',validate='one_to_one').reset_index(drop=True)
states='AL:01 AK:02 AZ:04 AR:05 CA:06 CO:08 CT:09 DE:10 DC:11 FL:12 GA:13 HI:15 ID:16 IL:17 IN:18 IA:19 KS:20 KY:21 LA:22 ME:23 MD:24 MA:25 MI:26 MN:27 MS:28 MO:29 MT:30 NE:31 NV:32 NH:33 NJ:34 NM:35 NY:36 NC:37 ND:38 OH:39 OK:40 OR:41 PA:42 RI:44 SC:45 SD:46 TN:47 TX:48 UT:49 VT:50 VA:51 WA:53 WV:54 WI:55 WY:56'
fips_to_ab={x.split(':')[1]:x.split(':')[0] for x in states.split()}
a['state']=a.county_fips.str[:2].map(fips_to_ab)
pf=pq.ParquetFile(polyfile);crs=CRS.from_user_input(json.loads(pf.schema_arrow.metadata[b'geo'])['columns']['geometry']['crs'])
tf=Transformer.from_crs(4326,crs,always_xy=True)
table=pf.read();assignments=[];audits=[]
for state,rs in a.groupby('state'):
    tab=table.filter(pc.equal(table['NAME1_b'],state));g=tab.to_pandas()
    for k in keys:g[k]=g[k].fillna('').astype(str)
    assert not g.duplicated(keys).any()
    g=g.merge(pv,on=keys,how='left',validate='one_to_one')
    assert g.trump_votes.notna().all()
    polygons=shapely.from_wkb(g.geometry.to_numpy());invalid=~shapely.is_valid(polygons)
    polygons[invalid]=shapely.make_valid(polygons[invalid])
    x,y=tf.transform(rs.longitude.to_numpy(),rs.latitude.to_numpy());points=shapely.points(x,y)
    ix=STRtree(polygons).query(points,predicate='intersects')
    hit=pd.DataFrame({'point':ix[0],'poly':ix[1]})
    ambiguous=int(hit.loc[hit.duplicated('point',False),'point'].nunique())
    unique=hit[~hit.duplicated('point',False)]
    z=rs.iloc[unique.point].copy();matched=g.iloc[unique.poly].copy()
    z['precinct_id']=[hashlib.sha256(json.dumps([row[k] for k in keys]).encode()).hexdigest()[:24] for _,row in matched.iterrows()]
    for c in ['precinct_share','precinct_share_2party','trump_votes','clinton_votes','total_max','NAME1','NAME2','NAME3','NAME3_b','denominator_discrepancy']:z[c]=matched[c].to_numpy()
    # Distance in Web Mercator, corrected locally for latitude; diagnostic only.
    z['boundary_distance_m_approx']=shapely.distance(points[unique.point.to_numpy()],shapely.boundary(polygons[unique.poly.to_numpy()]))*np.cos(np.radians(z.latitude.to_numpy()))
    # NAME2 is not uniformly a county: some states use municipality or local IDs.
    # Validate explicit FIPS fields only in states where NAME2 carries FIPS.
    coded_states=set('AL AR CA CT ID IL IN KS KY LA MO MS ND NE NH NV OH PA RI SC SD TN TX VT WV WY'.split())
    if state in coded_states:
        reported=matched.NAME2.str.strip().str.replace(r'\.0$','',regex=True)
        expected=z.county_fips if state=='CA' else z.county_fips.str[2:]
        reported=reported.str.zfill(5 if state=='CA' else 3)
        z['precinct_county_matches']=pd.array(reported.to_numpy()==expected.to_numpy(),dtype='boolean')
    else:z['precinct_county_matches']=pd.array([pd.NA]*len(z),dtype='boolean')
    assignments.append(z)
    audits.append({'state':state,'restaurants':len(rs),'unique_spatial_matches':len(z),'ambiguous_matches':ambiguous,'unmatched':len(rs)-len(z)-ambiguous,'precinct_polygons':len(g),'invalid_geometries_repaired':int(invalid.sum()),'county_code_disagreements':int((~z.precinct_county_matches).sum())})
    print(state,len(rs),len(z),flush=True)
    del g,polygons,tab;gc.collect()
z=pd.concat(assignments,ignore_index=True)
a=a.merge(z[['gmap_id','precinct_id','precinct_share','precinct_share_2party','trump_votes','clinton_votes','total_max','NAME1','NAME2','NAME3','NAME3_b','denominator_discrepancy','boundary_distance_m_approx','precinct_county_matches']],on='gmap_id',how='left',validate='one_to_one')
a['eligible_precinct']=a.precinct_share.notna() & a.precinct_county_matches.fillna(True) & a.denominator_discrepancy.abs().lt(.001)
a.to_csv(O/'restaurant_precinct_assignments.csv',index=False)
pd.DataFrame(audits).to_csv(O/'geography_audit_by_state.csv',index=False)
a.groupby(['group','trump'],dropna=False).agg(population=('gmap_id','size'),spatial_matches=('precinct_id','count'),eligible=('eligible_precinct','sum')).reset_index().to_csv(O/'population_coverage.csv',index=False)
audit={'source':'SAGE, 2016 US precincts; upstream VEST and other sources documented by SAGE','source_url':'https://github.com/noahdasanaike/sage','geometry_object':obj,'geometry_sha256':digest(polyfile),'votes_sha256':digest(O/'usa_2016_votes.parquet'),'crs':crs.to_string(),'join_keys':keys,'unique_precincts':len(pv),'restaurant_population':len(a),'eligible_restaurants':int(a.eligible_precinct.sum()),'denominator':'Trump / published total votes across all candidates','nonzero_denominator_discrepancies':int(pv.denominator_discrepancy.abs().gt(.001).sum()),'source_limitations':'Precinct results may include allocated absentee/provisional votes. Local resident voting is not reviewer ideology. SAGE includes sources beyond VEST; exact upstream state provenance requires original documentation.'}
(O/'precinct_linkage_audit.json').write_text(json.dumps(audit,indent=2))
print(a.groupby('group').eligible_precinct.agg(['size','sum']).to_string())
