args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
out<-file.path(here,'county_continuous');dir.create(out,showWarnings=FALSE)
src<-file.path(here,'county_fe_regressions','inputs')
a<-fread(file=file.path(src,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))[definition=='expanded_broad_pre' & group %chin% c('ME','WPME') & !is.na(gop_share)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');rows<-list();designs<-list();preds<-list()
for(event in c('Election','Ban')){
 q<-merge(fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv'))),a,by='gmap_id')
 q[,ME:=as.integer(group=='ME')];ids<-q[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips;q<-q[county_fips %chin% ids]
 q[,`:=`(county10=(gop_share-.5)/.1,log_pre_reviews=log1p(reviews_pre))];q[,ME_county:=ME*county10]
 for(spec in c('County FE','County FE + baseline adjustment')){
  vars<-c('ME','ME_county',if(spec!='County FE')c('rating_pre','log_pre_reviews'))
  fit<-feols(as.formula(paste('change ~',paste(vars,collapse='+'),'|county_fips')),data=q,vcov=~county_fips,ssc=ss,notes=FALSE)
  ct<-coeftable(fit)['ME_county',];ci<-as.matrix(confint(fit))['ME_county',];G<-uniqueN(q$county_fips);id<-length(rows)+1L
  stopifnot(nobs(fit)==nrow(q),abs(ct[4]-2*pt(abs(ct[3]),G-1,lower.tail=FALSE))<1e-10)
  rows[[id]]<-data.table(id,shock=event,model=spec,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(q),ME=sum(q$ME),WPME=sum(1-q$ME),counties=G,df_K=attr(vcov(fit,attr=TRUE),'df.K'),variables=paste(vars,collapse=';'))
  d<-copy(q[,c('gmap_id','county_fips','change',vars),with=FALSE]);d[,`:=`(fixed_effect=county_fips,model_id=id)];designs[[id]]<-d
  if(spec=='County FE'){
   lo<-max(quantile(q[ME==1]$gop_share,.05),quantile(q[ME==0]$gop_share,.05));hi<-min(quantile(q[ME==1]$gop_share,.95),quantile(q[ME==0]$gop_share,.95))
   z<-data.table(shock=event,share=seq(lo,hi,length.out=100));s<-(z$share-.5)/.1;b<-coef(fit);V<-vcov(fit)
   z[,estimate:=b['ME']+s*b['ME_county']];se<-sqrt(V['ME','ME']+s^2*V['ME_county','ME_county']+2*s*V['ME','ME_county'])
   z[,`:=`(low=estimate-qt(.975,G-1)*se,high=estimate+qt(.975,G-1)*se)];preds[[length(preds)+1L]]<-z
  }
 }
 fwrite(q,file.path(out,paste0('sample_',tolower(event),'.csv')))
}
r<-rbindlist(rows);r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')];r[,p_holm_two_events:=p.adjust(p,'holm'),by=model]
fwrite(r,file.path(out,'county_continuous_results.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'verification_designs.csv'));pp<-rbindlist(preds);fwrite(pp,file.path(out,'predicted_differences.csv'))
png(file.path(out,'county_continuous.png'),width=2100,height=1100,res=180);par(mfrow=c(1,2),mar=c(5,5,4,2),oma=c(4,0,1,0))
for(event in c('Election','Ban')){
 z<-pp[shock==event];plot(z$share*100,z$estimate,type='n',ylim=range(z$low,z$high,0),xlab='2016 county Trump vote share (%)',ylab='ME minus WPME change (rating stars)',main=event)
 polygon(c(z$share,rev(z$share))*100,c(z$low,rev(z$high)),col='#dceaf1',border=NA);abline(h=0,lty=2,col='grey');lines(z$share*100,z$estimate,col='#185b7a',lwd=2)
 rr<-r[shock==event&model=='County FE'];mtext(sprintf('Per +10 pp: %+.3f; p=%.3f; N=%s',rr$estimate,rr$p,format(rr$restaurants,big.mark=',')),side=3,line=.3,cex=.8)
}
mtext('County fixed effects; equal restaurant weights; 95% county-clustered intervals.',outer=TRUE,side=1,line=.3,cex=.7)
mtext('Shown over overlapping 5th-95th percentile county-share support.',outer=TRUE,side=1,line=1.4,cex=.7);dev.off();print(r)
