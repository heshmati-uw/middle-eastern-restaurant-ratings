# Election diagnostics plus combined election/holiday-excluded-ban event-study plots.
args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(here,'full_pre_election_core');out<-file.path(s,'event_holiday_trends');dir.create(out,showWarnings=FALSE)
w<-fread(file=file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');tests<-list();leads<-list();inputs<-list();means<-list();designs<-list();window_tests<-list();window_leads<-list();window_inputs<-list()
fit_mean<-function(d,pair,window,variant){
 for(t in c(2,1,0))for(spec in c('County FE','County FE + baseline')){
  z<-copy(if(t==2)d else d[trump==t]);z[,log_pre_reviews:=log1p(reviews_pre)]
  fit<-feols(if(spec=='County FE')change~first|county_fips else change~first+rating_pre+log_pre_reviews|county_fips,data=z,vcov=~county_fips,ssc=ss,notes=FALSE)
  ct<-coeftable(fit)['first',];ci<-as.matrix(confint(fit))['first',];id<-length(means)+1L;vars<-names(coef(fit));stopifnot(nobs(fit)==nrow(z))
  means[[id]]<<-data.table(id,pair,window,variant,trump=t,spec,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(z),first_N=sum(z$first),second_N=sum(1-z$first),counties=uniqueN(z$county_fips),df_K=attr(vcov(fit,attr=TRUE),'df.K'),variables=paste(vars,collapse=';'))
  zz<-z[,unique(c('gmap_id','county_fips','change',vars)),with=FALSE];zz[,model_id:=id];designs[[id]]<<-zz
 }
}
for(pair in c('ME_WPME','ME_MED','WPME_MED')){
 members<-strsplit(pair,'_',fixed=TRUE)[[1]];q<-fread(file=file.path(s,'regressions',paste0('sample_',pair,'_election.csv')),colClasses=c(county_fips='character'));q[,first:=as.integer(group==members[1])]
 z<-merge(w[week>=as.IDate('2016-08-29')&week<=as.IDate('2016-12-05')&week!=as.IDate('2016-11-07')&reviews>0&!is.na(rating)],q[,.(gmap_id,group,trump,county_fips,first)],by='gmap_id')
 for(t in c(1,0)){
  d<-copy(z[trump==t]);np<-d[week<as.IDate('2016-11-07'),.N,by=gmap_id];d<-d[gmap_id %chin% np[N>=2]$gmap_id]
  d[,nweeks:=.N,by=gmap_id];d[,weight:=1/nweeks];d[,event_week:=as.integer((week-as.IDate('2016-11-07'))/7)]
  fit<-feols(rating~i(event_week,first,ref=-1)|gmap_id+county_fips^week,data=d,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  b<-coef(fit);V<-vcov(fit);ci<-as.matrix(confint(fit));ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);stopifnot(qr(V[ii,ii,drop=FALSE])$rank==length(ii))
  F<-as.numeric(t(b[ii])%*%solve(V[ii,ii,drop=FALSE],b[ii])/length(ii));G<-uniqueN(d$county_fips);id<-length(tests)+1L
  tests[[id]]<-data.table(id,pair,trump=t,restaurants=uniqueN(d$gmap_id),first_N=uniqueN(d[first==1]$gmap_id),second_N=uniqueN(d[first==0]$gmap_id),counties=G,observations=nrow(d),df_K=attr(vcov(fit,attr=TRUE),'df.K'),joint_F=F,joint_p=pf(F,length(ii),G-1,lower.tail=FALSE),pre_restrictions=length(ii))
  leads[[id]]<-rbind(data.table(model_id=id,event_week=ev,estimate=unname(b),se=sqrt(diag(V)),low=ci[,1],high=ci[,2]),data.table(model_id=id,event_week=-1,estimate=0,se=0,low=0,high=0));d[,model_id:=id];inputs[[id]]<-d
 }
 for(nw in c(4,3,2)){
  if(nw==4){fit_mean(q,pair,'4-week','Window ratings');next}
  pre<-w[week>=as.IDate('2016-11-07')-7*nw&week<=as.IDate('2016-10-31')&reviews>0&!is.na(rating),.(pre_new=sum(rating*reviews)/sum(reviews),reviews_new=sum(reviews)),by=gmap_id]
  post<-w[week>=as.IDate('2016-11-14')&week<=as.IDate('2016-11-14')+7*(nw-1)&reviews>0&!is.na(rating),.(post_new=sum(rating*reviews)/sum(reviews)),by=gmap_id]
  d<-merge(merge(q,pre,by='gmap_id'),post,by='gmap_id');d<-d[county_fips %chin% d[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips]
  fit_mean(q[gmap_id %chin% d$gmap_id],pair,paste0(nw,'-week'),'Original four-week ratings on retained sample')
  d[,`:=`(rating_pre=pre_new,reviews_pre=reviews_new,rating_post=post_new,change=post_new-pre_new)];fit_mean(d,pair,paste0(nw,'-week'),'Window ratings')
 }
}
tt<-rbindlist(tests);ee<-rbindlist(leads);fwrite(tt,file.path(out,'election_weekly_pretests.csv'));fwrite(ee,file.path(out,'election_weekly_coefficients.csv'));fwrite(rbindlist(inputs),file.path(out,'election_weekly_inputs.csv'))
mm<-rbindlist(means);mm[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')];fwrite(mm,file.path(out,'election_window_results.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'election_mean_designs.csv'))
for(event in c('Election','Ban'))for(pair in c('ME_WPME','ME_MED','WPME_MED')){
 members<-strsplit(pair,'_',fixed=TRUE)[[1]];mixed<-as.IDate(if(event=='Election')'2016-11-07' else '2017-01-23')
 q<-fread(file=file.path(s,'regressions',paste0('sample_',pair,'_',tolower(event),'.csv')),colClasses=c(county_fips='character'));q[,first:=as.integer(group==members[1])]
 zz<-merge(w[reviews>0&!is.na(rating)],q[,.(gmap_id,group,trump,county_fips,first)],by='gmap_id')
 for(nw in c(4,3,2))for(t in c(1,0)){
  d<-copy(zz[trump==t&week>=mixed-7*nw&week<=mixed+7*nw&week!=mixed])
  if(event=='Ban')d<-d[!week %in% as.IDate(c('2016-12-19','2016-12-26'))]
  np<-d[week<mixed,.N,by=gmap_id];keep<-intersect(np[N>=2]$gmap_id,d[week>mixed]$gmap_id);d<-d[gmap_id %chin% keep]
  d[,nweeks:=.N,by=gmap_id];d[,weight:=1/nweeks];d[,event_week:=as.integer((week-mixed)/7)]
  fit<-feols(rating~i(event_week,first,ref=-1)|gmap_id+county_fips^week,data=d,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  b<-coef(fit);V<-vcov(fit);ci<-as.matrix(confint(fit));ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);stopifnot(qr(V[ii,ii,drop=FALSE])$rank==length(ii))
  F<-as.numeric(t(b[ii])%*%solve(V[ii,ii,drop=FALSE],b[ii])/length(ii));G<-uniqueN(d$county_fips);id<-length(window_tests)+1L
  window_tests[[id]]<-data.table(id,event,pair,window=nw,trump=t,restaurants=uniqueN(d$gmap_id),first_N=uniqueN(d[first==1]$gmap_id),second_N=uniqueN(d[first==0]$gmap_id),counties=G,observations=nrow(d),df_K=attr(vcov(fit,attr=TRUE),'df.K'),pre_restrictions=length(ii),joint_F=F,joint_p=pf(F,length(ii),G-1,lower.tail=FALSE))
  window_leads[[id]]<-rbind(data.table(model_id=id,event_week=ev,estimate=unname(b),se=sqrt(diag(V)),low=ci[,1],high=ci[,2]),data.table(model_id=id,event_week=-1,estimate=0,se=0,low=0,high=0));d[,model_id:=id];window_inputs[[id]]<-d
 }
}
fwrite(rbindlist(window_tests),file.path(out,'short_window_pretests.csv'));fwrite(rbindlist(window_leads),file.path(out,'short_window_coefficients.csv'));fwrite(rbindlist(window_inputs),file.path(out,'short_window_inputs.csv'))
for(pair_code in c('ME_WPME','ME_MED','WPME_MED')){
 h<-file.path(s,'ban_holiday_sensitivity',if(pair_code=='ME_WPME')'' else pair_code);bt<-fread(file=file.path(h,'weekly_pretests.csv'));be<-fread(file=file.path(h,'weekly_coefficients.csv'))
 bsel<-bt[mask=='Calendar'&comparison=='Holiday-excluded weekly ratings, fixed retained sample'];esel<-tt[pair==pair_code]
 for(ext in c('png','svg')){
  if(ext=='png')png(file.path(out,paste0(pair_code,'_election_ban_trends.png')),width=2100,height=1550,res=180) else svg(file.path(out,paste0(pair_code,'_election_ban_trends.svg')),width=2100/180,height=1550/180)
  par(mfrow=c(2,2),mar=c(4.8,5,3.5,1),oma=c(3,0,1,0));yr<-range(ee[model_id %in% esel$id]$low,ee[model_id %in% esel$id]$high,be[model_id %in% bsel$id]$low,be[model_id %in% bsel$id]$high)
  for(event in c('Election','Ban'))for(t in c(1,0)){
   test<-if(event=='Election')esel[trump==t] else bsel[trump==t];a<-if(event=='Election')ee[model_id==test$id] else be[model_id==test$id];a<-a[order(event_week)]
   plot(c(-10,4),yr,type='n',xlab='Weeks from omitted event week',ylab=paste(gsub('_','-',pair_code),'gap relative to last pre-week'),main=paste(event,if(t==1)'| Trump counties' else '| Non-Trump counties'))
   abline(h=0,lty=3,col='grey50');abline(v=0,lty=2,col='grey50');segments(a$event_week,a$low,a$event_week,a$high,col='#185b7a');points(a$event_week,a$estimate,pch=19,col=ifelse(a$event_week<0,'#185b7a','#c45a3c'))
   n1<-if(event=='Election')test$first_N else test$ME;n2<-if(event=='Election')test$second_N else test$WPME
   p_label<-if(test$joint_p<.001)'<.001' else sprintf('=%.3f',test$joint_p)
   mtext(sprintf('Joint pre p%s; N first/second=%s/%s',p_label,n1,n2),side=3,line=.3,cex=.7)
  }
  mtext('Election: original weeks. Ban: Dec 19 and Dec 26 weeks removed. Equal total restaurant weights; county-clustered 95% intervals.',outer=TRUE,side=1,line=.7,cex=.65);dev.off()
 }
}
print(tt);print(mm[trump==1&spec=='County FE'&variant=='Window ratings',.(pair,window,estimate,p,first_N,second_N)])
