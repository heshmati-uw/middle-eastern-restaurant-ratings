# Calendar-defined exclusions; no selection by estimated effect or pretest p-value.
args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
src<-file.path(here,'full_pre_election_core')
pair_arg<-commandArgs(TRUE);pair_arg<-pair_arg[grepl('^--pair=',pair_arg)];pair_code<-if(length(pair_arg))sub('^--pair=','',pair_arg[1]) else 'ME_WPME'
members<-strsplit(pair_code,'_',fixed=TRUE)[[1]];stopifnot(length(members)==2,pair_code %in% c('ME_WPME','ME_MED','WPME_MED'))
out<-file.path(src,'ban_holiday_sensitivity',if(pair_code=='ME_WPME')'' else pair_code);dir.create(out,showWarnings=FALSE,recursive=TRUE)
q<-fread(file=file.path(src,'regressions',paste0('sample_',pair_code,'_ban.csv')),colClasses=c(county_fips='character'))
# ME is the legacy internal indicator for the first member of each selected pair.
q[,ME:=as.integer(group==members[1])]
w<-fread(file=file.path(src,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
w<-merge(w[week>=as.IDate('2016-11-14')&week<=as.IDate('2017-02-20')&week!=as.IDate('2017-01-23')&reviews>0&!is.na(rating)],q[,.(gmap_id,group,trump,county_fips,ME)],by='gmap_id')
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
masks<-list(Calendar=c('2016-12-19','2016-12-26'),Observed=c('2016-12-19','2016-12-26','2017-01-02'))
means<-list();designs<-list();models<-list();weektests<-list();weekest<-list();weekinputs<-list();blocks<-list();samples<-list()
shared_counties<-function(d)d[county_fips %chin% d[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips]
fit_means<-function(d,mask,comparison){
 for(t in c(2,1,0)){
  z<-copy(if(t==2)d else d[trump==t]);z[,log_pre_reviews:=log1p(reviews_pre)]
  mm<-z[,.(restaurants=.N,pre=mean(rating_pre),post=mean(rating_post),change=mean(change)),by=group];mm[,`:=`(mask=mask,comparison=comparison,trump=t)];means[[length(means)+1L]]<<-mm
  for(spec in c('Raw','County FE','County FE + baseline')){
   form<-if(spec=='Raw')change~ME else if(spec=='County FE')change~ME|county_fips else change~ME+rating_pre+log_pre_reviews|county_fips
   fit<-feols(form,data=z,vcov=~county_fips,ssc=ss,notes=FALSE);ct<-coeftable(fit)['ME',];ci<-as.matrix(confint(fit))['ME',];id<-length(models)+1L
   stopifnot(nobs(fit)==nrow(z))
   vars<-setdiff(names(coef(fit)),'(Intercept)');G<-uniqueN(z$county_fips)
   models[[id]]<<-data.table(id,mask,comparison,trump=t,spec,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(z),ME=sum(z$ME),WPME=sum(1-z$ME),counties=G,df_K=attr(vcov(fit,attr=TRUE),'df.K'),variables=paste(vars,collapse=';'))
   zz<-z[,unique(c('gmap_id','county_fips','change',vars)),with=FALSE];zz[,`:=`(model_id=id,fixed_effect=if(spec=='Raw')'all' else county_fips)];designs[[length(designs)+1L]]<<-zz
  }
 }
}
fit_weekly<-function(d,mask,comparison,omit){
 for(t in c(1,0)){
  z<-copy(d[trump==t]);z[,nweeks:=.N,by=gmap_id];z[,weight:=1/nweeks];z[,event_week:=as.integer((week-as.IDate('2017-01-23'))/7)]
  stopifnot(max(abs(z[,sum(weight),by=gmap_id]$V1-1))<1e-10)
  fit<-feols(rating~i(event_week,ME,ref=-1)|gmap_id+county_fips^week,data=z,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  beta<-coef(fit);V<-vcov(fit);ct<-coeftable(fit);ci<-as.matrix(confint(fit));ev<-as.integer(sub(':ME$','',sub('^event_week::','',names(beta))))
  lead<-which(ev< -1);clean<-which(ev< -1 & !(ev %in% as.integer((as.IDate(omit)-as.IDate('2017-01-23'))/7)))
  joint<-function(ii){stopifnot(qr(V[ii,ii,drop=FALSE])$rank==length(ii));F<-as.numeric(t(beta[ii])%*%solve(V[ii,ii,drop=FALSE],beta[ii])/length(ii));c(F=F,p=pf(F,length(ii),uniqueN(z$county_fips)-1,lower.tail=FALSE))}
  j<-joint(lead);jc<-joint(clean);id<-length(weektests)+1L
  weektests[[id]]<<-data.table(id,mask,comparison,trump=t,restaurants=uniqueN(z$gmap_id),ME=uniqueN(z[ME==1]$gmap_id),WPME=uniqueN(z[ME==0]$gmap_id),observations=nrow(z),counties=uniqueN(z$county_fips),df_K=attr(vcov(fit,attr=TRUE),'df.K'),pre_restrictions=length(lead),joint_F=j[1],joint_p=j[2],nonholiday_restrictions=length(clean),nonholiday_joint_F=jc[1],nonholiday_joint_p=jc[2])
  weekest[[id]]<<-rbind(data.table(model_id=id,event_week=ev,estimate=unname(beta),se=sqrt(diag(V)),low=ci[,1],high=ci[,2]),data.table(model_id=id,event_week=-1,estimate=0,se=0,low=0,high=0))
  z[,model_id:=id];weekinputs[[id]]<<-z
 }
}
fit_means(q,'None','Original full sample')
npre<-w[week<as.IDate('2017-01-23'),.N,by=gmap_id];wo<-w[gmap_id %chin% npre[N>=2]$gmap_id]
fit_weekly(wo,'None','Original full weekly sample',masks$Calendar)
for(mask in names(masks)){
 omit<-masks[[mask]];nonhol<-w[!week %in% as.IDate(omit)]
 pre<-nonhol[week>=as.IDate('2016-12-26')&week<=as.IDate('2017-01-16'),.(rating_pre_new=sum(rating*reviews)/sum(reviews),reviews_pre_new=sum(reviews)),by=gmap_id]
 d<-merge(q,pre,by='gmap_id');d<-shared_counties(d)
 old<-q[gmap_id %chin% d$gmap_id];fit_means(old,mask,'Original ratings, fixed retained sample')
 d[,`:=`(rating_pre=rating_pre_new,reviews_pre=reviews_pre_new,change=rating_post-rating_pre_new)]
 fit_means(d,mask,'Holiday-excluded ratings, fixed retained sample')
 s<-d[,.(gmap_id,group,trump,county_fips,rating_pre,rating_post,reviews_pre,change)];s[,mask:=mask];samples[[length(samples)+1L]]<-s
 nn<-nonhol[week<as.IDate('2017-01-23'),.N,by=gmap_id];eligible<-intersect(wo$gmap_id,nn[N>=2]$gmap_id)
 fit_weekly(wo[gmap_id %chin% eligible],mask,'Original weekly ratings, fixed retained sample',omit)
 fit_weekly(nonhol[gmap_id %chin% eligible],mask,'Holiday-excluded weekly ratings, fixed retained sample',omit)
 # Identical restaurants in all three periods, for original vs exclusion plots.
 earlier<-nonhol[week>=as.IDate('2016-11-28')&week<=as.IDate('2016-12-19'),.(earlier_new=sum(rating*reviews)/sum(reviews)),by=gmap_id]
 origearlier<-w[week>=as.IDate('2016-11-28')&week<=as.IDate('2016-12-19'),.(earlier=sum(rating*reviews)/sum(reviews)),by=gmap_id]
 bb<-shared_counties(merge(merge(d,earlier,by='gmap_id'),origearlier,by='gmap_id'))
 for(kind in c('Original','Holiday-excluded')){
  b<-bb[,.(gmap_id,group,trump,county_fips,earlier=if(kind=='Original')earlier else earlier_new,rating_pre=if(kind=='Original')q$rating_pre[match(gmap_id,q$gmap_id)] else rating_pre,rating_post)]
  bl<-melt(b,id.vars=c('gmap_id','group','trump','county_fips'),variable.name='block',value.name='rating');bl[,`:=`(mask=mask,kind=kind)];blocks[[length(blocks)+1L]]<-bl
 }
}
# Clean calendar alternatives requested after inspecting the holiday diagnostic.
# All are retained as exploratory sensitivity checks, never selected by p-value.
for(nw in c(2,3)){
 prestart<-as.IDate('2017-01-23')-7*nw;postend<-as.IDate('2017-01-30')+7*(nw-1)
 use<-w[!week %in% as.IDate(masks$Calendar)]
 pp<-use[week>=prestart&week<=as.IDate('2017-01-16'),.(rating_pre_new=sum(rating*reviews)/sum(reviews),reviews_pre_new=sum(reviews)),by=gmap_id]
 po<-use[week>=as.IDate('2017-01-30')&week<=postend,.(rating_post_new=sum(rating*reviews)/sum(reviews)),by=gmap_id]
 dd<-shared_counties(merge(merge(q,pp,by='gmap_id'),po,by='gmap_id'))
 label<-paste0(nw,'-week matched window');orig<-q[gmap_id %chin% dd$gmap_id];fit_means(orig,label,'Original four-week ratings, fixed shorter-window sample')
 dd[,`:=`(rating_pre=rating_pre_new,reviews_pre=reviews_pre_new,rating_post=rating_post_new,change=rating_post_new-rating_pre_new)]
 fit_means(dd,label,'Shorter clean-window ratings')
}
rr<-rbindlist(models);rr[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(rr,file.path(out,'mean_change_results.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'mean_model_designs.csv'));fwrite(rbindlist(means),file.path(out,'group_means.csv'));fwrite(rbindlist(samples),file.path(out,'retained_restaurant_periods.csv'))
tt<-rbindlist(weektests);ee<-rbindlist(weekest);fwrite(tt,file.path(out,'weekly_pretests.csv'));fwrite(ee,file.path(out,'weekly_coefficients.csv'));fwrite(rbindlist(weekinputs),file.path(out,'weekly_model_inputs.csv'))
bl<-rbindlist(blocks);fwrite(bl,file.path(out,'balanced_block_ratings.csv'));bm<-bl[,.(mean_rating=mean(rating),restaurants=.N),by=.(mask,kind,trump,group,block)];fwrite(bm,file.path(out,'balanced_block_means.csv'))
cols<-setNames(c('#185b7a','#c45a3c'),members);xs<-as.numeric(as.Date(c('2016-12-11','2017-01-08','2017-02-12')));bs<-c('earlier','rating_pre','rating_post')
for(ext in c('png','svg')){
 if(ext=='png')png(file.path(out,'calendar_holiday_group_paths.png'),width=2100,height=1550,res=180) else svg(file.path(out,'calendar_holiday_group_paths.svg'),width=2100/180,height=1550/180)
 par(mfrow=c(2,2),mar=c(4.5,5,3,1),oma=c(3,0,1,0));yr<-range(bm[mask=='Calendar']$mean_rating)+c(-.07,.07)
 for(view_kind in c('Original','Holiday-excluded'))for(t in c(1,0)){
  plot(range(xs)+c(-12,12),yr,type='n',xaxt='n',xlab='',ylab='Mean restaurant rating',main=paste(view_kind,if(t==1)'| Trump counties' else '| Non-Trump counties'));abline(v=as.numeric(as.Date('2017-01-27')),lty=2,col='grey40')
  axis(1,xs,c('Nov 28-Dec 25','Dec 26-Jan 22','Jan 30-Feb 26'),cex.axis=.65)
  for(g in members){a<-bm[mask=='Calendar'&kind==view_kind&trump==t&group==g];a<-a[match(bs,block)];lines(xs,a$mean_rating,type='b',col=cols[g],lwd=2,pch=19)}
  ns<-bm[mask=='Calendar'&kind==view_kind&trump==t&block=='earlier'];legend('bottomleft',legend=paste0(members,' N=',ns$restaurants[match(members,ns$group)]),col=cols,lty=1,pch=19,bty='n',cex=.7)
 }
 mtext('Same restaurants across all periods and rows within each column; equal restaurant weights. Dec 19 and Dec 26 weeks excluded below.',side=1,outer=TRUE,line=.6,cex=.65);dev.off()
 if(ext=='png')png(file.path(out,'calendar_holiday_weekly_event_study.png'),width=2100,height=1550,res=180) else svg(file.path(out,'calendar_holiday_weekly_event_study.svg'),width=2100/180,height=1550/180)
 par(mfrow=c(2,2),mar=c(4.5,5,3.5,1),oma=c(3,0,1,0));ids<-tt[mask=='Calendar']$id;yr<-range(ee[model_id %in% ids]$low,ee[model_id %in% ids]$high)
 for(comp in c('Original weekly ratings, fixed retained sample','Holiday-excluded weekly ratings, fixed retained sample'))for(t in c(1,0)){
  test<-tt[mask=='Calendar'&comparison==comp&trump==t];a<-ee[model_id==test$id][order(event_week)];lab<-if(startsWith(comp,'Original'))'Original weeks' else 'Exclude holiday weeks'
  plot(c(-10,4),yr,type='n',xlab='Weeks from omitted Jan 23 event week',ylab=paste(paste(members,collapse='-'),'gap relative to Jan 16 week'),main=paste(lab,if(t==1)'| Trump' else '| Non-Trump'))
  abline(h=0,lty=3,col='grey50');abline(v=0,lty=2,col='grey50');segments(a$event_week,a$low,a$event_week,a$high,col='#185b7a');points(a$event_week,a$estimate,pch=19,col=ifelse(a$event_week<0,'#185b7a','#c45a3c'))
  mtext(sprintf('Joint pre p=%.3f; N ME/WPME=%s/%s',test$joint_p,test$ME,test$WPME),side=3,line=.3,cex=.7)
 }
 mtext('Same restaurants within each column; equal total restaurant weights; restaurant and county-by-week FE; county-clustered 95% intervals.',side=1,outer=TRUE,line=.6,cex=.65);dev.off()
}
print(rr[spec=='County FE'&trump!=2,.(mask,comparison,trump,estimate,p,ME,WPME,counties)]);print(tt)
