"""Verify all holiday/window models and combine both events and all three pairs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'event_holiday_trends'
def read(p,**kwargs):
 d=pd.read_csv(p,**kwargs)
 if 'mask'in d:d['mask']=d['mask'].fillna('None')
 return d
def verify_means(r,d,groupcol='fixed_effect',term='ME'):
 errors=[]
 for row in r.itertuples():
  z=d[d.model_id.eq(row.id)].copy();cols=row.variables.split(';');v=z[cols+['change']];v=v-v.groupby(z[groupcol]).transform('mean')
  x=v[cols].to_numpy();y=v.change.to_numpy();A=np.linalg.pinv(x.T@x);b=A@x.T@y;res=y-x@b
  U=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
  V=A@U.T@U@A*g/(g-1)*(n-1)/(n-row.df_K);j=cols.index(term);errors.extend([abs(b[j]-row.estimate),abs(np.sqrt(V[j,j])-row.se)])
 assert max(errors)<1e-8
 return {'models':len(r),'max_error':max(errors)}
def verify_weekly(tests,coef,data,indicator='ME'):
 checks=[]
 for row in tests.itertuples():
  z=data[data.model_id.eq(row.id)].copy();ww=z.weight.to_numpy();weeks=sorted(set(z.event_week)-{-1});x=np.column_stack([z[indicator].to_numpy()*(z.event_week.to_numpy()==v) for v in weeks])
  aa=np.column_stack([z.rating.to_numpy(),x]);groups=[pd.factorize(z.gmap_id)[0],pd.factorize(z.county_fips+'_'+z.week)[0]]
  for it in range(3000):
   before=aa.copy()
   for codes in groups:
    sums=np.bincount(codes,weights=ww)
    for j in range(aa.shape[1]):aa[:,j]-=(np.bincount(codes,weights=ww*aa[:,j])/sums)[codes]
   if np.max(np.abs(aa-before))<1e-12:break
  else:raise AssertionError('FE convergence failure')
  y=aa[:,0];x=aa[:,1:];A=np.linalg.inv(x.T@(ww[:,None]*x));b=A@x.T@(ww*y);res=y-x@b
  U=pd.DataFrame(x*(ww*res)[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
  V=A@U.T@U@A*g/(g-1)*(n-1)/(n-row.df_K);old=coef[coef.model_id.eq(row.id)&coef.event_week.ne(-1)].set_index('event_week').loc[weeks]
  error=max(float(np.max(np.abs(b-old.estimate))),float(np.max(np.abs(np.sqrt(np.diag(V))-old.se))))
  ii=np.flatnonzero(np.array(weeks)< -1);f=float(b[ii]@np.linalg.solve(V[np.ix_(ii,ii)],b[ii])/len(ii))
  assert error<1e-7 and abs(f-row.joint_F)<1e-6,(error,f,row.joint_F)
  assert np.max(np.abs(z.groupby('gmap_id').weight.sum()-1))<1e-10
  if hasattr(row,'nonholiday_joint_F'):
   omit={-5,-4,-3} if row.mask=='Observed' else {-5,-4};ix=np.array([j for j,v in enumerate(weeks) if v< -1 and v not in omit]);ff=float(b[ix]@np.linalg.solve(V[np.ix_(ix,ix)],b[ix])/len(ix));assert abs(ff-row.nonholiday_joint_F)<1e-6
  checks.append({'id':int(row.id),'max_coefficient_or_se_error':error,'F_error':abs(f-row.joint_F),'iterations':it+1})
 return checks
audits={};means=[];weekly=[]
for pair in ['ME_WPME','ME_MED','WPME_MED']:
 p=S/'ban_holiday_sensitivity' if pair=='ME_WPME' else S/'ban_holiday_sensitivity'/pair
 r=read(p/'mean_change_results.csv');d=read(p/'mean_model_designs.csv',dtype={'county_fips':str,'fixed_effect':str});audits[pair+'_means']=verify_means(r,d)
 t=read(p/'weekly_pretests.csv');c=read(p/'weekly_coefficients.csv');z=read(p/'weekly_model_inputs.csv',dtype={'county_fips':str});audits[pair+'_weekly']=verify_weekly(t,c,z)
 r['pair']=pair;t['pair']=pair;means.append(r);weekly.append(t)
 print('Verified ban',pair,flush=True)
er=read(O/'election_window_results.csv');ed=read(O/'election_mean_designs.csv',dtype={'county_fips':str});audits['Election_means']=verify_means(er,ed,groupcol='county_fips',term='first')
et=read(O/'election_weekly_pretests.csv');ec=read(O/'election_weekly_coefficients.csv');ez=read(O/'election_weekly_inputs.csv',dtype={'county_fips':str});audits['Election_weekly']=verify_weekly(et,ec,ez,'first')
st=read(O/'short_window_pretests.csv');sc=read(O/'short_window_coefficients.csv');sz=read(O/'short_window_inputs.csv',dtype={'county_fips':str});audits['Short_window_weekly']=verify_weekly(st,sc,sz,'first')
(O/'verification.json').write_text(json.dumps(audits,indent=2))
bm=pd.concat(means,ignore_index=True);bt=pd.concat(weekly,ignore_index=True);bm.to_csv(O/'all_ban_holiday_mean_results.csv',index=False);bt.to_csv(O/'all_ban_holiday_weekly_tests.csv',index=False)
# Directly reproduce the already reported original ME-WPME results/pretests.
old=read(S/'ME_WPME_focus/direct_comparisons.csv');old=old[old.shock.eq('Ban')&old.model.eq('County FE difference in changes')]
for row in old.itertuples():
 t=2 if row.stratum=='All counties' else 1 if row.stratum=='Trump counties' else 0
 r=bm[bm.pair.eq('ME_WPME')&bm['mask'].eq('None')&bm.spec.eq('County FE')&bm.trump.eq(t)].iloc[0];assert abs(r.estimate-row.estimate)<1e-10 and abs(r.p-row.p)<1e-10
pre=bt[bt['mask'].eq('Calendar')&bt.comparison.eq('Holiday-excluded weekly ratings, fixed retained sample')].copy();pre['event']='Ban, holiday-excluded';pre['first_N']=pre.ME;pre['second_N']=pre.WPME
e=et.copy();e['event']='Election, original weeks'
summary=pd.concat([e,pre],ignore_index=True);summary['Counties']=summary.trump.map({1:'Trump',0:'Non-Trump'})
summary.to_csv(O/'main_event_pretrend_summary.csv',index=False)
shown_summary=summary.copy();shown_summary['joint_p']=shown_summary.joint_p.map(lambda x:f'{x:.2g}' if x<.001 else f'{x:.4f}')
def display(r):
 r=r.copy();r['Counties']=r.trump.map({2:'All',1:'Trump',0:'Non-Trump'});r['Estimate (SE)']=r.apply(lambda x:f'{x.estimate:+.3f}{x.symbol if hasattr(x,"symbol") and isinstance(x.symbol,str) else ""} ({x.se:.3f})',axis=1);r['Raw p']=r.p.map(lambda x:f'{x:.4f}');r['N first / second']=r.apply(lambda x:f'{int(x.ME if "ME"in r else x.first_N):,} / {int(x.WPME if "WPME"in r else x.second_N):,}',axis=1);return r
effect=bm[bm.spec.eq('County FE')&bm['mask'].isin(['None','Calendar','Observed'])&bm.comparison.isin(['Original full sample','Original ratings, fixed retained sample','Holiday-excluded ratings, fixed retained sample'])]
cols=['pair','Counties','mask','comparison','Estimate (SE)','Raw p','N first / second','counties']
win=er[er.variant.eq('Window ratings')&~er.trump.eq(2)].copy();win['event']='Election';win=win.rename(columns={'first_N':'ME','second_N':'WPME','window':'mask'})
bwin=bm[(bm.comparison.eq('Shorter clean-window ratings')|((bm['mask']=='Calendar')&bm.comparison.eq('Holiday-excluded ratings, fixed retained sample')))&~bm.trump.eq(2)].copy();bwin['event']='Ban';win=pd.concat([win,bwin],ignore_index=True)
win.to_csv(O/'all_window_mean_results.csv',index=False)
table=lambda q:q.to_html(index=False,border=0,float_format=lambda x:f'{x:.4f}')
html='''<!doctype html><html><head><meta charset="utf-8"><title>Election and ban trends: holiday and window sensitivities</title><style>body{font:16px/1.5 system-ui;max-width:1450px;margin:36px auto;padding:0 24px;color:#243343}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:right}td:nth-child(-n+3){text-align:left}th{background:#edf3f6;position:sticky;top:0}img{width:100%}.note{background:#edf3f6;padding:18px}.scroll{overflow:auto;max-height:650px}</style></head><body><h1>Election and ban: all three pairwise trends</h1>
<p>Full pre-election core tags; unchanged primary categories; unit restaurant weights for period changes and unit total restaurant weights for weekly regressions. Mediterranean is observed pre-election text without a core-dish mention; shared-food mentions remain allowed.</p>
<div class="note"><b>Holiday evidence:</b> For ME–WPME in Trump counties, the full weekly pretest rejects (p=.0011). On the holiday-eligible fixed sample it rejects with all weeks (p=.0020), but not after removing Christmas/New Year weeks (p=.2245). On that same retained weekly sample, testing only nonholiday leads while retaining all data gives p=.2714. The holidays account for much of the original test rejection; this does not establish the untestable post-event parallel-trends assumption.</div>
<h2>How dates and outcomes are defined</h2><p>Trump took office <a href="https://www.govinfo.gov/app/details/DCPD-201700058">January 20, 2017</a>; the first ban order is dated <a href="https://www.govinfo.gov/app/details/DCPD-201700076">January 27</a>. January 9 precedes both. The screenshot previously discussed showed restaurants with reviews that week, not ratings. Changes in that count are changes in outcome availability, not evidence of an event's effect on ratings.</p>
<p>Calendar holiday exclusions: week starting Dec 19 (Christmas Dec 25) and week starting Dec 26 (New Year Jan 1). A wider Observed sensitivity also excludes Jan 2–8, covering observed New Year's Day. The mixed ban week Jan 23–29 remains omitted. The election event week Nov 7–13 is omitted; its post-window ends Dec 11 and contains neither Christmas nor New Year, so those exclusions do not alter election data. Thanksgiving remains included in the election post-window.</p>
<h2>Joint pre-trend tests for the plotted models</h2>'''+table(shown_summary[['event','pair','Counties','joint_p','first_N','second_N','counties','pre_restrictions']])+'''
<p>Each test jointly examines earlier-week first-group interactions against the last complete pre-event week, after restaurant and county-by-week fixed effects. Election reference is Oct 31; ban reference is Jan 16, which includes inauguration on Jan 20. Pre-history begins Aug 29 for election and Nov 14 for ban. The plots use the earlier ten-week calendar frame, with holiday weeks removed for the ban. At least two observed pre-weeks are required. Post-event observations cover the original four complete weeks. Intervals and F tests cluster by county; sparse Trump-county samples have limited precision and finite-cluster inference is approximate.</p>
<h2>ME versus WPME</h2><img src="ME_WPME_election_ban_trends.png" alt="Election and holiday-excluded ban trends for ME minus WPME, Trump and non-Trump counties">
<h2>ME versus Mediterranean</h2><img src="ME_MED_election_ban_trends.png" alt="Election and holiday-excluded ban trends for ME minus Mediterranean">
<h2>WPME versus Mediterranean</h2><img src="WPME_MED_election_ban_trends.png" alt="Election and holiday-excluded ban trends for WPME minus Mediterranean">
<p>Blue points are pre-event and orange points post-event. Each coefficient is a difference in the first-minus-second rating gap relative to that event's reference week. Zero denotes the omitted mixed event week; the point at −1 is normalized to zero. Vertical bars are pointwise county-clustered 95% intervals. Holiday exclusion creates missing pre-week points for the ban. Each restaurant's observed weekly weights sum to one. Pairwise and diagnostic samples differ; Ns cannot be added across panels.</p>
<h2>Does the average ME–WPME ban result survive?</h2><p>Yes as a raw association in the calendar exclusion: county-FE ME–WPME difference is −.3607 stars (p=.0441; 66 ME/57 WPME in 22 Trump counties), versus −.4509 (p=.0143) using original ratings on those same restaurants. Original full-sample result was −.4334 (p=.0191; 72/62). This isolates attenuation from changing ratings rather than restaurant IDs. Baseline adjustment gives −.2180 (p=.0315). These are average changes, distinct from weekly coefficients or political-share gradients.</p>
<p>The holiday-excluded baseline uses Jan 2–22 (three weeks); post remains Jan 30–Feb 26 (four weeks). A wider exclusion leaves Jan 9–22 as the baseline and gives −.4458 (p=.0301), with fewer restaurants. These are sensitivity checks with unequal numbers of pre/post weeks, not replacements selected for significance. No pooled holiday-excluded pair comparison reaches p&lt;.05.</p>
<h2>All pairs: original versus holiday-excluded average changes</h2><div class="scroll">'''+table(display(effect[~effect.trump.eq(2)])[cols])+'''
</div><h2>Matched two-, three- and four-week calendar windows</h2><p>Election: two-week Oct 24–Nov 6 vs Nov 14–27; three-week Oct 17–Nov 6 vs Nov 14–Dec 4; four-week Oct 10–Nov 6 vs Nov 14–Dec 11. Ban: two-week Jan 9–22 vs Jan 30–Feb 12; three-week Jan 2–22 vs Jan 30–Feb 19; four-week calendar frame Dec 26–Jan 22 vs Jan 30–Feb 26, with holiday weeks removed. The last ban frame consequently contains three pre-weeks and four post-weeks.</p><div class="scroll">'''+table(display(win)[['event','pair','Counties','mask','spec','Estimate (SE)','Raw p','N first / second','counties']])+'''
</div><p>ME–WPME Trump-county ban estimates remain negative but are less precise in matched shorter windows: two-week −.4427 (p=.0961; 49/36), three-week −.3653 (p=.0674; 60/53). Other pairs vary across windows, including one isolated p&lt;.05 ME–MED result in the two-week ban window. All variants are retained, rather than choosing the strongest result. County FE and baseline-adjusted specifications are both shown. Each restaurant has unit weight; missing ratings are not zero-filled. Common-county support is recomputed.</p>
<h2>Short-window weekly pretests</h2>'''+table(st[['event','pair','window','trump','joint_p','first_N','second_N','counties','pre_restrictions']])+'''
<p>These local diagnostics use only each displayed short calendar window, at least two observed pre-weeks, and at least one post-week. Their samples are smaller than the average-change samples (which require only one observed pre-week). For ME–WPME in Trump counties, election joint pre-p values are .309 (four-week), .164 (three-week), and .0034 (two-week), versus .0000085 in the longer history. A narrower window does not systematically solve the problem. Ban holiday-excluded local pretests do not reject, but some samples are very small.</p>
<h2>What a passing pretest means</h2><p>Non-rejection does not prove parallel trends; dropping weeks reduces both the set of restrictions and often the sample size. These exclusions/windows were explored after seeing the data, so their estimates remain exploratory. <a href="https://pubs.aeaweb.org/doi/10.1257/aeri.20210236">Roth (2022)</a> explains why selecting estimates after a pretest can distort inference. We should retain a calendar-motivated primary design, show the full sensitivity grid, assess substantive changes, and consider sensitivity to remaining trend violations. A changing reviewer mix or inauguration response can remain even if holidays are excluded. The weekly timing cannot cleanly separate inauguration from the ban, one week later.</p>
<p>Original and holiday-excluded figures for each ban pair are saved in the sibling ban_holiday_sensitivity directory. All mean-model coefficients, weekly coefficients, clustered standard errors and joint F statistics were independently verified in NumPy. Raw p symbols: + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001. The large exploratory test family is not a set of confirmatory discoveries. <a href="verification.json">Verification</a> · <a href="main_event_pretrend_summary.csv">Plotted pretests</a> · <a href="all_ban_holiday_mean_results.csv">All ban holiday/window estimates</a> · <a href="election_window_results.csv">All election window estimates</a> · <a href="all_ban_holiday_weekly_tests.csv">All ban weekly tests</a></p></body></html>'''
extra='''<h2>Holiday exclusion does not erase the visible pre-ban movement</h2><img src="../ban_holiday_sensitivity/calendar_holiday_group_paths.png" alt="Same-restaurant ME and WPME block means before and after holiday exclusions"><p>Within each column, the same restaurants appear in all periods and both rows. A WPME pre-ban dip remains visible in Trump counties even after the exclusions. A non-rejected weekly fixed-effects test does not mean that these descriptive paths are flat or demonstrably parallel. The block-mean and weekly-FE diagnostics also use different observation requirements and controls. This is why the holiday sensitivity improves a diagnostic without establishing causal identification.</p>'''
html=html.replace('<h2>Does the average ME–WPME ban result survive?</h2>',extra+'<h2>Does the average ME–WPME ban result survive?</h2>')
cal=bm[bm['mask'].eq('Calendar')&bm.comparison.eq('Holiday-excluded ratings, fixed retained sample')&bm.spec.eq('County FE')&~bm.trump.eq(2)].copy()
ix=np.argsort(cal.p.to_numpy());pv=cal.p.to_numpy()[ix];adj=np.empty(len(pv));adj[ix]=np.minimum(1,np.maximum.accumulate(pv*(len(pv)-np.arange(len(pv)))));cal['p_holm_six_calendar_tests']=adj;cal.to_csv(O/'calendar_primary_comparisons.csv',index=False)
html=html.replace('<h2>Matched two-, three- and four-week calendar windows</h2>','<p>The raw ME–WPME Trump p=.0441 becomes .2649 under Holm across the six calendar-excluded pair-by-county-stratum tests. All window and holiday comparisons are exploratory; these raw p-values should not be interpreted as a set of isolated confirmatory tests.</p><h2>Matched two-, three- and four-week calendar windows</h2>')
(O/'event_holiday_report.html').write_text(html,encoding='utf-8')
print('Verified mean models',sum(v['models'] for k,v in audits.items() if k.endswith('_means')),'weekly models',sum(len(v) for k,v in audits.items() if k.endswith('_weekly')))
print(summary[['event','pair','Counties','joint_p','first_N','second_N']].to_string(index=False))
