args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages(library(data.table));out<-file.path(here,'county_fe_regressions')
raw<-fread(file=file.path(out,'county_fe_pretrend_inputs.csv'),colClasses=c(county_fips='character'))
columns<-c('gmap_id','group','county_fips','trump','-3','-2','-1','1','shock')
raw<-unique(raw[,..columns]);rows<-list();inputs<-list()
contrasts<-list('WPME vs ME'=c(1,0),'WPME vs MED'=c(1,-1),'ME vs MED'=c(0,-1))
for(event in c('Election','Ban')){
  z<-raw[shock==event];shared<-z[,.(groups=uniqueN(group)),by=county_fips][groups==3]$county_fips
  z<-z[county_fips %chin% shared];z[,`:=`(wp=as.integer(group=='WPME'),med=as.integer(group=='MED'))]
  inputs[[length(inputs)+1L]]<-z
  for(tt in 0:2){
    d<-if(tt==2)copy(z) else copy(z[trump==tt]);code<-as.integer(factor(d$county_fips));den<-tabulate(code)
    X<-if(tt==2)cbind(d$wp,d$med,d$wp*d$trump,d$med*d$trump) else cbind(d$wp,d$med)
    earlier<-if(event=='Election')c('-3','-2') else '-2'
    Y<-sapply(earlier,function(b)d[[b]]-d[['-1']]);Y<-matrix(Y,nrow=nrow(d))
    Xm<-X-(rowsum(X,code)/den)[code,,drop=FALSE];Ym<-Y-(rowsum(Y,code)/den)[code,,drop=FALSE]
    A<-solve(crossprod(Xm));B<-A%*%crossprod(Xm,Ym);E<-Ym-Xm%*%B;G<-length(den);N<-nrow(d);K<-ncol(Xm)+1
    for(pair in names(contrasts)){
      c<-if(tt==2)c(0,0,contrasts[[pair]]) else contrasts[[pair]]
      h<-as.vector(Xm%*%A%*%c);U<-rowsum(E*h,code);V<-crossprod(U)*G/(G-1)*(N-1)/(N-K)
      b<-as.numeric(c%*%B);q<-length(b);F<-as.numeric(t(b)%*%solve(V,b)/q)
      rows[[length(rows)+1L]]<-data.table(shock=event,trump=tt,comparison=pair,p=pf(F,q,G-1,lower.tail=FALSE),
        F=F,restrictions=q,restaurants=N,counties=G,df_K=K,
        ME_restaurants=sum(d$group=='ME'),WPME_restaurants=sum(d$group=='WPME'),MED_restaurants=sum(d$group=='MED'))
    }
  }
}
r<-rbindlist(rows);r[,p_holm_all_eighteen:=p.adjust(p,'holm')]
fwrite(r,file.path(out,'joint_three_group_pretrend_tests.csv'))
fwrite(rbindlist(inputs,fill=TRUE),file.path(out,'joint_three_group_pretrend_inputs.csv'))
print(r)
