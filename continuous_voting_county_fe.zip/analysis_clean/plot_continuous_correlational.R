args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
o<-file.path(h,'full_pre_election_core','correlational_full_sample','continuous_vote_share')
p<-read.csv(file.path(o,'fitted_changes.csv'));bins<-read.csv(file.path(o,'binned_changes.csv'));slopes<-read.csv(file.path(o,'group_slopes.csv'))
cols<-c('#185b7a','#c45a3c','#6b7d35');gn<-c('ME','WPME','MED')
for(en in c('Election','Ban')){
 png(file.path(o,paste0(en,'_continuous_shares.png')),width=2100,height=1650,res=180);par(mfrow=c(2,2),mar=c(4.5,5,4,1),oma=c(3,0,1,0))
 yr<-range(c(p$low[p$event==en],p$high[p$event==en],0))
 for(lev in c('County','Precinct')){
  a<-p[p$event==en&p$level==lev,];bb<-bins[bins$event==en&bins$level==lev,]
  plot(c(0,100),yr,type='n',xlab=paste(lev,'Trump vote share (%)'),ylab='Post-minus-pre rating change (stars)',main=paste(en,'|',lev,'vote share'),xaxt='n');axis(1,at=seq(0,100,20));abline(h=0,lty=3,col='grey55')
  for(k in 1:3){z<-a[a$group==gn[k],];polygon(c(z$vote_share*100,rev(z$vote_share*100)),c(z$low,rev(z$high)),col=adjustcolor(cols[k],alpha.f=.12),border=NA)}
  for(k in 1:3){z<-a[a$group==gn[k],];lines(z$vote_share*100,z$estimate,col=cols[k],lwd=2)}
  legend('topleft',legend=c('ME','WPME','Mediterranean'),col=cols,lty=1,pch=c(16,17,15),lwd=2,bty='n',cex=.8)
  counts<-slopes[slopes$event==en&slopes$level==lev,];mtext(paste(sprintf('%s N=%s',counts$group,format(counts$restaurants,big.mark=',')),collapse=' | '),side=3,line=.3,cex=.68)
 }
 for(lev in c('County','Precinct')){
  a<-p[p$event==en&p$level==lev,];bb<-bins[bins$event==en&bins$level==lev,]
  rawyr<-range(c(bins$rating_change[bins$event==en],0));plot(c(0,100),rawyr,type='n',xlab=paste(lev,'Trump vote share (%)'),ylab='Observed mean rating change',main=paste(lev,'| Raw 10pp-bin means'),xaxt='n');axis(1,at=seq(0,100,20));abline(h=0,lty=3,col='grey55')
  for(k in 1:3){zz<-bb[bb$group==gn[k],];points(zz$vote_share*100,zz$rating_change,col=adjustcolor(cols[k],alpha.f=.75),pch=c(16,17,15)[k],cex=.45+1.1*sqrt(zz$restaurants/max(bb$restaurants)))}
  mtext('All bins shown; dot size reflects restaurant count; sparse extremes can be noisy.',side=3,line=.3,cex=.65)
 }
 mtext('Equal restaurant weights; county-clustered pointwise 95% bands; holidays included; no majority split.',side=1,outer=TRUE,line=.5,cex=.75)
 mtext('Top: linear fits over cuisine-specific central 90% of shares. Bottom: raw bin means, with a wider y scale.',side=1,outer=TRUE,line=1.7,cex=.72);dev.off()
}
