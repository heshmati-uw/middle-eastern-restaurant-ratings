# Diagnostics for the new county-adjusted model on history-balanced subsets.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(jsonlite)})
out<-file.path(here,'county_fe_regressions')
src<-if(dir.exists(file.path(out,'inputs')))file.path(out,'inputs') else file.path(here,'expanded_positioning')
a<-fread(file=file.path(src,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))
a<-a[definition=='expanded_broad_pre'&!is.na(gop_share)&group %chin% c('ME','WPME','MED')]
w<-fread(file=file.path(src,'expanded_common_weekly.csv'));w[,score:=rating*reviews]
cfg<-fromJSON(file.path(here,'pretrend_specifications.json'),simplifyVector=FALSE)
rows<-list();inputs<-list()
for(spec in cfg$shocks){
  event<-spec$shock;p<-fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv')))
  cohort<-merge(p,a,by='gmap_id');bins<-list()
  for(bl in spec$blocks){
    z<-w[gmap_id %chin% cohort$gmap_id & week>=bl$start & week<=bl$end]
    b<-z[,.(rating=sum(score)/sum(reviews)),by=gmap_id];b[,block:=bl$block];bins[[length(bins)+1L]]<-b
  }
  b<-rbindlist(bins);complete<-b[,.(n=.N),by=gmap_id][n==length(spec$blocks)]$gmap_id
  b<-b[gmap_id %chin% complete];wide<-dcast(b,gmap_id~block,value.var='rating')
  wide<-merge(wide,cohort[,.(gmap_id,group,county_fips,trump)],by='gmap_id')
  earlier<-sort(sapply(spec$blocks,function(x)x$block));earlier<-earlier[earlier< -1]
  for(pair in c('WPME vs ME','WPME vs MED','ME vs MED')){
    members<-strsplit(pair,' vs ',fixed=TRUE)[[1]];d0<-copy(wide[group %chin% members]);d0[,treated:=as.integer(group==members[1])]
    shared<-d0[,.(sides=uniqueN(treated)),by=county_fips][sides==2]$county_fips;d0<-d0[county_fips %chin% shared]
    for(t in 0:2){
      d<-if(t==2)copy(d0) else copy(d0[trump==t])
      X<-if(t==2)cbind(d$treated,d$treated*d$trump) else matrix(d$treated,ncol=1)
      Y<-sapply(earlier,function(bl)d[[as.character(bl)]]-d[['-1']]);Y<-matrix(Y,nrow=nrow(d))
      # County demeaning reproduces the fixed-effects estimator.
      code<-as.integer(factor(d$county_fips));den<-tabulate(code)
      Xm<-X-(rowsum(X,code)/den)[code,,drop=FALSE]
      Ym<-Y-(rowsum(Y,code)/den)[code,,drop=FALSE]
      A<-solve(crossprod(Xm));B<-A%*%crossprod(Xm,Ym);E<-Ym-Xm%*%B
      h<-as.vector(Xm%*%A[,ncol(Xm)]);U<-rowsum(E*h,code)
      G<-nrow(U);N<-nrow(d);K<-ncol(Xm)+1
      V<-crossprod(U)*G/(G-1)*(N-1)/(N-K);beta<-as.numeric(B[nrow(B),]);q<-length(beta)
      F<-as.numeric(t(beta)%*%solve(V,beta)/q)
      rows[[length(rows)+1L]]<-data.table(shock=event,trump=t,comparison=pair,
        p=pf(F,q,G-1,lower.tail=FALSE),F=F,restrictions=q,restaurants=N,counties=G,
        focal_restaurants=sum(d$treated),control_restaurants=sum(1-d$treated),df=G-1)
    }
    # Export the small balanced input so the diagnostic can be checked independently.
    d0[,`:=`(shock=event,comparison=pair)];inputs[[length(inputs)+1L]]<-d0
  }
}
r<-rbindlist(rows);r[,p_holm_all_eighteen:=p.adjust(p,'holm')]
fwrite(r,file.path(out,'county_fe_pretrend_tests.csv'))
fwrite(rbindlist(inputs,fill=TRUE),file.path(out,'county_fe_pretrend_inputs.csv'))
print(r)
