args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
s<-file.path(h,'full_pre_election_core','correlational_full_sample');o<-file.path(s,'continuous_county_fe');dir.create(o,showWarnings=FALSE)
d<-fread(file.path(s,'restaurant_changes.csv'),colClasses=c(county_fips='character'));ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
results<-list();individual<-list();info<-list();coefficients<-list();covariances<-list();inputs<-list();predictions<-list();joint<-list();support<-list();mid<-0L
for(en in c('Election','Ban'))for(lev in c('County','Precinct')){
 x<-d[event==en&level==lev];x[,`:=`(isME=as.integer(group=='ME'),isWP=as.integer(group=='WPME'),share10=(vote_share-.5)/.1)];x[,`:=`(sME=isME*share10,sWP=isWP*share10)]
 if(lev=='County'){
  stopifnot(x[,max(vote_share)-min(vote_share),by=county_fips][,max(V1)]<1e-10)
  fit<-feols(change~isME+isWP+sME+sWP|county_fips,x,vcov=~county_fips,ssc=ss,fixef.rm='none')
 }else fit<-feols(change~isME+isWP+share10+sME+sWP|county_fips,x,vcov=~county_fips,ssc=ss,fixef.rm='none')
 mid<-mid+1L;B<-coef(fit);V<-vcov(fit);G<-uniqueN(x$county_fips);K<-attr(vcov(fit,attr=TRUE),'df.K');stopifnot(nobs(fit)==nrow(x))
 mixed<-x[,.(groups=uniqueN(group),n=.N,share_variation=max(vote_share)-min(vote_share)),by=county_fips]
 info[[mid]]<-data.table(model_id=mid,event=en,level=lev,restaurants=nrow(x),ME_N=x[group=='ME',.N],WPME_N=x[group=='WPME',.N],MED_N=x[group=='MED',.N],counties=G,df_K=K,mixed_cuisine_counties=mixed[groups>1,.N],mixed_cuisine_restaurants=mixed[groups>1,sum(n)],within_county_vote_variation_counties=mixed[share_variation>1e-10,.N])
 coefficients[[mid]]<-data.table(model_id=mid,term=names(B),estimate=unname(B),se=sqrt(diag(V)))
 vv<-as.data.table(as.table(V));setnames(vv,c('term1','term2','value'));vv[,model_id:=mid];covariances[[mid]]<-vv
 ip<-data.table(model_id=mid,gmap_id=x$gmap_id,county_fips=x$county_fips,y=x$change)
 for(n in names(B))ip[[n]]<-x[[n]]
 inputs[[mid]]<-ip
 calc<-function(L){b<-sum(L*B);se<-sqrt(as.numeric(t(L)%*%V%*%L));p<-2*pt(-abs(b/se),G-1);list(estimate=b,se=se,p=p,low=b-qt(.975,G-1)*se,high=b+qt(.975,G-1)*se)}
 for(pair in c('ME_WPME','ME_MED','WPME_MED')){
  L<-setNames(rep(0,length(B)),names(B))
  if(pair %in% c('ME_WPME','ME_MED'))L['sME']<-1
  if(pair=='ME_WPME')L['sWP']<- -1
  if(pair=='WPME_MED')L['sWP']<-1
  a<-calc(L);results[[length(results)+1L]]<-cbind(data.table(model_id=mid,event=en,level=lev,pair,restaurants=nrow(x),counties=G),as.data.table(a))
  members<-strsplit(pair,'_')[[1]];st<-x[group %chin% members,.(n=uniqueN(group)),by=county_fips];support[[length(support)+1L]]<-data.table(event=en,level=lev,pair,counties_with_both_members=st[n==2,.N])
  # Relative rating-change curves: county FE cancel in cuisine contrasts.
  lo<-max(x[group==members[1],quantile(vote_share,.05)],x[group==members[2],quantile(vote_share,.05)])
  hi<-min(x[group==members[1],quantile(vote_share,.95)],x[group==members[2],quantile(vote_share,.95)])
  for(v in seq(lo,hi,length.out=121)){
   A<-L*((v-.5)/.1)
   if(pair %in% c('ME_WPME','ME_MED'))A['isME']<-1
   if(pair=='ME_WPME')A['isWP']<- -1
   if(pair=='WPME_MED')A['isWP']<-1
   predictions[[length(predictions)+1L]]<-cbind(data.table(model_id=mid,event=en,level=lev,pair,vote_share=v),as.data.table(calc(A)))
  }
 }
 # Precinct slopes are identifiable because vote share varies within county.
 if(lev=='Precinct')for(g in c('ME','WPME','MED')){
  L<-setNames(rep(0,length(B)),names(B));L['share10']<-1;if(g=='ME')L['sME']<-1;if(g=='WPME')L['sWP']<-1
  individual[[length(individual)+1L]]<-cbind(data.table(model_id=mid,event=en,level=lev,group=g,restaurants=x[group==g,.N],counties=G),as.data.table(calc(L)))
 }
 ii<-match(c('sME','sWP'),names(B));F<-as.numeric(t(B[ii])%*%solve(V[ii,ii],B[ii])/2);joint[[mid]]<-data.table(model_id=mid,event=en,level=lev,F,df1=2,df2=G-1,p=pf(F,2,G-1,lower.tail=FALSE))
}
savecsv<-function(rows,name,adjust=FALSE){z<-rbindlist(rows,fill=TRUE);if('p'%in%names(z)){z[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')];if(adjust)z[,p_holm:=p.adjust(p,'holm')]};fwrite(z,file.path(o,name));invisible(z)}
savecsv(results,'cuisine_slope_differences.csv',TRUE);savecsv(individual,'precinct_group_slopes.csv',TRUE);savecsv(info,'model_info.csv');savecsv(coefficients,'model_coefficients.csv');savecsv(covariances,'model_covariances.csv');savecsv(inputs,'model_verification_inputs.csv');savecsv(predictions,'fitted_cuisine_gaps.csv');savecsv(joint,'joint_interaction_tests.csv',TRUE);savecsv(support,'pairwise_county_support.csv')
cols<-c('#185b7a','#c45a3c','#6b7d35');rr<-rbindlist(predictions)
for(en in c('Election','Ban')){
 png(file.path(o,paste0(en,'_continuous_county_fe.png')),width=2100,height=1150,res=180);par(mfrow=c(1,2),mar=c(5,5,4,1),oma=c(3,0,1,0));yr<-range(c(rr[event==en&pair!='ME_WPME']$low,rr[event==en&pair!='ME_WPME']$high,0))
 for(lev in c('County','Precinct')){
  a<-rr[event==en&level==lev&pair!='ME_WPME'];mi<-rbindlist(info)[event==en&level==lev]
  plot(c(0,100),yr,type='n',xaxt='n',xlab=paste(lev,'Trump vote share (%)'),ylab='Rating-change gap versus Mediterranean',main=paste(en,'|',lev,'vote share | County FE'));axis(1,at=seq(0,100,20));abline(h=0,lty=3,col='grey55')
  for(k in 1:2){z<-a[pair==c('ME_MED','WPME_MED')[k]];polygon(c(z$vote_share*100,rev(z$vote_share*100)),c(z$low,rev(z$high)),col=adjustcolor(cols[k],alpha.f=.12),border=NA);lines(z$vote_share*100,z$estimate,col=cols[k],lwd=2)}
  legend('topleft',legend=c('ME relative to Mediterranean','WPME relative to Mediterranean'),col=cols,lty=1,lwd=2,bty='n',cex=.75)
  mtext(sprintf('ME N=%s | WPME N=%s | MED N=%s | %s counties',mi$ME_N,mi$WPME_N,mi$MED_N,mi$counties),side=3,line=.4,cex=.65)
 }
 mtext('Equal restaurant weights; county-clustered pointwise 95% bands; holidays included; continuous shares.',side=1,outer=TRUE,line=.5,cex=.73)
 mtext('Cuisine gaps are conditional associations. Fits shown over pairwise common central 90% share support.',side=1,outer=TRUE,line=1.6,cex=.7);dev.off()
}
print(rbindlist(results));print(rbindlist(info));print(rbindlist(joint))
