# All three groups in one county-FE regression, on counties containing all three.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
out<-file.path(here,'county_fe_regressions')
src<-if(dir.exists(file.path(out,'inputs')))file.path(out,'inputs') else file.path(here,'expanded_positioning')
a<-fread(file=file.path(src,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))
a<-a[!is.na(gop_share)&group %chin% c('ME','WPME','MED')];a[,trump:=as.integer(trump)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
rows<-list();directs<-list();joint<-list();models<-list()
contrasts<-list('WPME vs ME'=c(1,0),'WPME vs MED'=c(1,-1),'ME vs MED'=c(0,-1))
emit<-function(fit,d,def,event,t,direct=FALSE){
  terms<-if(direct)c('wp_trump','med_trump') else c('wp','med')
  b<-coef(fit)[terms];VV<-vcov(fit,attr=TRUE);V<-VV[terms,terms,drop=FALSE];G<-uniqueN(d$county_fips)
  ans<-list()
  for(pair in names(contrasts)){
    c<-contrasts[[pair]];beta<-sum(c*b);se<-sqrt(as.numeric(t(c)%*%V%*%c));stat<-beta/se
    ci<-beta+c(-1,1)*qt(.975,G-1)*se
    ans[[length(ans)+1L]]<-data.table(definition=def,shock=event,trump=t,comparison=pair,
      estimate=beta,se=se,p=2*pt(abs(stat),G-1,lower.tail=FALSE),low=ci[1],high=ci[2],
      restaurants=nrow(d),counties=G,df=G-1,df_K=attr(VV,'df.K'),
      ME_restaurants=sum(d$group=='ME'),WPME_restaurants=sum(d$group=='WPME'),MED_restaurants=sum(d$group=='MED'))
  }
  F<-as.numeric(t(b)%*%solve(V,b)/2)
  list(rows=rbindlist(ans),joint=data.table(definition=def,shock=event,trump=t,joint_F=F,
       joint_F_p=pf(F,2,G-1,lower.tail=FALSE),restaurants=nrow(d),counties=G))
}
for(event in c('Election','Ban')){
  p<-fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv')))
  for(def in unique(a$definition)){
    all<-merge(p,a[definition==def],by='gmap_id')
    shared<-all[,.(groups=uniqueN(group)),by=county_fips][groups==3]$county_fips
    all<-all[county_fips %chin% shared]
    all[,`:=`(wp=as.integer(group=='WPME'),med=as.integer(group=='MED'))]
    all[,`:=`(wp_trump=wp*trump,med_trump=med*trump)]
    for(tt in 0:1){
      d<-all[trump==tt];stopifnot(uniqueN(d$county_fips)>=2)
      fit<-feols(change~wp+med|county_fips,data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
      x<-emit(fit,d,def,event,tt);rows[[length(rows)+1L]]<-x$rows;joint[[length(joint)+1L]]<-x$joint
      if(def=='expanded_broad_pre')models[[paste(event,tt,sep='__')]]<-fit
    }
    fit<-feols(change~wp+med+wp_trump+med_trump|county_fips,data=all,vcov=~county_fips,ssc=ss,notes=FALSE)
    x<-emit(fit,all,def,event,2,TRUE);directs[[length(directs)+1L]]<-x$rows;joint[[length(joint)+1L]]<-x$joint
    if(def=='expanded_broad_pre')models[[paste(event,'direct',sep='__')]]<-fit
  }
}
r<-rbindlist(rows);di<-rbindlist(directs)
r[,p_holm_three_pairs:=p.adjust(p,'holm'),by=.(definition,shock,trump)]
di[,p_holm_three_pairs:=p.adjust(p,'holm'),by=.(definition,shock)]
r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
di[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(r,file.path(out,'joint_three_group_results.csv'))
fwrite(di,file.path(out,'joint_three_group_county_differences.csv'))
fwrite(rbindlist(joint),file.path(out,'joint_three_group_F_tests.csv'))
saveRDS(models,file.path(out,'main_joint_three_group_models.rds'))
print(r[definition=='expanded_broad_pre'])
