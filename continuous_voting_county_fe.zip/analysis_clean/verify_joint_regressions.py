from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'expanded_positioning';O=H/'county_fe_regressions'
if (O/'inputs').exists():S=O/'inputs'
CON={'WPME vs ME':np.array([1.,0.]),'WPME vs MED':np.array([1.,-1.]),'ME vs MED':np.array([0.,-1.])}
def demean(M,code):
    den=np.bincount(code);total=np.zeros((len(den),M.shape[1]));np.add.at(total,code,M)
    return M-(total/den[:,None])[code]
def fit(d,Y,joint,direct):
    if joint:
        wp=d.group.eq('WPME').to_numpy(dtype=float);med=d.group.eq('MED').to_numpy(dtype=float)
        X=np.column_stack([wp,med,wp*d.trump,med*d.trump] if direct else [wp,med])
    else:
        t=d.treated.to_numpy(dtype=float);X=np.column_stack([t,t*d.trump] if direct else [t])
    code=pd.factorize(d.county_fips)[0];G=code.max()+1
    Xm=demean(X,code);Ym=demean(Y,code);A=np.linalg.inv(Xm.T@Xm)
    B=A@Xm.T@Ym;E=Ym-Xm@B
    return Xm,A,B,E,code,G
def cov_contrast(d,Y,c,joint,direct):
    X,A,B,E,code,G=fit(d,Y,joint,direct);h=X@A@c;U=np.zeros((G,Y.shape[1]));np.add.at(U,code,E*h[:,None])
    V=U.T@U*G/(G-1)*(len(d)-1)/(len(d)-X.shape[1]-1)
    return c@B,V,G
def main():
    a=pd.read_csv(S/'expanded_group_assignments.csv',dtype={'county_fips':str})
    r=pd.read_csv(O/'joint_three_group_results.csv');di=pd.read_csv(O/'joint_three_group_county_differences.csv')
    errors=[];n=0
    for event in ['Election','Ban']:
        p=pd.read_csv(S/f'periods_{event.lower()}_4w.csv')
        for definition in r.definition.unique():
            d=p.merge(a[a.definition.eq(definition)&a.group.isin(['ME','WPME','MED'])&a.gop_share.notna()],on='gmap_id')
            counts=d.groupby('county_fips').group.nunique();d=d[d.county_fips.isin(counts[counts.eq(3)].index)]
            for direct,tab in [(False,r),(True,di)]:
                for row in tab[tab.definition.eq(definition)&tab.shock.eq(event)].itertuples():
                    z=d if direct else d[d.trump.eq(row.trump)];c=CON[row.comparison]
                    if direct:c=np.r_[0.,0.,c]
                    b,V,G=cov_contrast(z,z.change.to_numpy()[:,None],c,True,direct)
                    err=max(abs(b[0]-row.estimate),abs(np.sqrt(V[0,0])-row.se));assert err<1e-10
                    assert len(z)==row.restaurants and G==row.counties
                    errors.append(err);n+=1
    for joint,tabname,inputname in [(False,'county_fe_pretrend_tests','county_fe_pretrend_inputs'),(True,'joint_three_group_pretrend_tests','joint_three_group_pretrend_inputs')]:
        tab=pd.read_csv(O/(tabname+'.csv'));inp=pd.read_csv(O/(inputname+'.csv'),dtype={'county_fips':str})
        for row in tab.itertuples():
            d=inp[inp.shock.eq(row.shock)]
            if not joint:d=d[d.comparison.eq(row.comparison)]
            if row.trump!=2:d=d[d.trump.eq(row.trump)]
            earlier=['-3','-2'] if row.shock=='Election' else ['-2']
            Y=np.column_stack([d[b]-d['-1'] for b in earlier])
            if joint:c=CON[row.comparison];c=np.r_[0.,0.,c] if row.trump==2 else c
            else:c=np.array([0.,1.]) if row.trump==2 else np.array([1.])
            b,V,G=cov_contrast(d,Y,c,joint,row.trump==2);F=float(b@np.linalg.solve(V,b)/len(b))
            err=abs(F-row.F);assert err<1e-9 and len(d)==row.restaurants
            errors.append(err)
    ans={'joint_group_contrasts_verified':len(r),'joint_direct_contrasts_verified':len(di),
         'pair_and_joint_pretrend_tests_verified':36,'max_error':max(errors)}
    (O/'joint_independent_verification.json').write_text(json.dumps(ans,indent=2));print(json.dumps(ans,indent=2))
if __name__=='__main__':main()
