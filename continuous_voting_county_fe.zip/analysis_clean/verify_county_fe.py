"""Independent NumPy OLS and within-county covariance checks for all regression tables."""
from pathlib import Path
import json
import pandas as pd
import numpy as np
H=Path(__file__).resolve().parent;S=H/'expanded_positioning';O=H/'county_fe_regressions'
if (O/'inputs').exists():S=O/'inputs'
def calc(d,county_fe,direct,df_K):
    t=d.treated.to_numpy(dtype=float);tr=d.trump.to_numpy(dtype=float)
    if county_fe:
        X=np.column_stack([t,t*tr] if direct else [t]);M=np.column_stack([d.change.to_numpy(),X])
        code=pd.factorize(d.county_fips)[0];den=np.bincount(code)
        total=np.zeros((len(den),M.shape[1]));np.add.at(total,code,M)
        M-= (total/den[:,None])[code];y=M[:,0];X=M[:,1:]
        assert df_K==X.shape[1]+1
    else:
        X=np.column_stack([np.ones(len(d)),t,tr,t*tr] if direct else [np.ones(len(d)),t]);y=d.change.to_numpy()
        assert df_K==X.shape[1]
    A=np.linalg.inv(X.T@X);beta=A@X.T@y;res=y-X@beta
    codes=pd.factorize(d.county_fips)[0];G=codes.max()+1;U=np.zeros((G,X.shape[1]))
    np.add.at(U,codes,X*res[:,None]);V=A@U.T@U@A*G/(G-1)*(len(d)-1)/(len(d)-df_K)
    return beta[-1],np.sqrt(V[-1,-1]),G
def main():
    a=pd.read_csv(S/'expanded_group_assignments.csv',dtype={'county_fips':str})
    r=pd.read_csv(O/'four_week_county_fe_results.csv');di=pd.read_csv(O/'four_week_county_fe_direct_tests.csv')
    errors=[];n=0
    for event in ['Election','Ban']:
        p=pd.read_csv(S/f'periods_{event.lower()}_4w.csv')
        for definition in r.definition.unique():
            z=p.merge(a[a.definition.eq(definition)&a.gop_share.notna()&a.group.isin(['ME','WPME','MED'])],on='gmap_id',validate='one_to_one')
            for pair in ['WPME vs ME','WPME vs MED','ME vs MED']:
                first,second=pair.split(' vs ');full=z[z.group.isin([first,second])].copy();full['treated']=full.group.eq(first).astype(int)
                sides=full.groupby('county_fips').treated.nunique();shared=set(sides[sides.eq(2)].index)
                for row in r[r.shock.eq(event)&r.definition.eq(definition)&r.comparison.eq(pair)].itertuples():
                    d=full[full.trump.eq(row.trump)]
                    if row.specification!='Original raw change':d=d[d.county_fips.isin(shared)]
                    county_fe=row.specification=='County FE, shared counties'
                    b,se,G=calc(d,county_fe,False,row.df_K)
                    err=max(abs(b-row.estimate),abs(se-row.se));assert err<1e-10
                    assert len(d)==row.restaurants and d.treated.sum()==row.focal_restaurants and G==row.counties
                    errors.append(err);n+=1
                d=full[full.county_fips.isin(shared)]
                for row in di[di.shock.eq(event)&di.definition.eq(definition)&di.comparison.eq(pair)].itertuples():
                    county_fe=row.specification=='County FE, shared counties';b,se,G=calc(d,county_fe,True,row.df_K)
                    err=max(abs(b-row.estimate),abs(se-row.se));assert err<1e-10
                    assert len(d)==row.restaurants and G==row.counties;errors.append(err);n+=1
                    if county_fe:
                        s=r[r.shock.eq(event)&r.definition.eq(definition)&r.comparison.eq(pair)&r.specification.eq(row.specification)].set_index('trump')
                        assert abs(s.loc[1,'estimate']-s.loc[0,'estimate']-b)<1e-10
    ans={'subgroup_regressions_verified':len(r),'direct_regressions_verified':len(di),'total_verified':n,
         'within_county_transformation_verified':True,'county_CR1_covariance_verified':True,'max_error':max(errors)}
    (O/'regression_independent_verification.json').write_text(json.dumps(ans,indent=2));print(json.dumps(ans,indent=2))
if __name__=='__main__':main()
