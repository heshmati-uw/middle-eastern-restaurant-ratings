# Restaurant-level change regressions; equal restaurant weights and county clustering.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
out<-file.path(here,'county_fe_regressions');dir.create(out,showWarnings=FALSE)
src<-if(dir.exists(file.path(out,'inputs')))file.path(out,'inputs') else file.path(here,'expanded_positioning')
a<-fread(file=file.path(src,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))
a<-a[!is.na(gop_share)&group %chin% c('ME','WPME','MED')];a[,trump:=as.integer(trump)]
raw<-fread(file=file.path(here,'dictionary_focus','four_week_dictionary_comparisons.csv'))
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
pairs<-c('WPME vs ME','WPME vs MED','ME vs MED')
rows<-list();directs<-list();saved_models<-list();support_rows<-list();panel_errors<-numeric()
export_fit<-function(fit,d,term,definition,event,pair,spec,direct=FALSE){
  ct<-coeftable(fit)[term,];ci<-as.matrix(confint(fit))[term,];G<-uniqueN(d$county_fips)
  V<-vcov(fit,attr=TRUE);K<-attr(V,'df.K');N<-nrow(d)
  stopifnot(abs(ct[4]-2*pt(abs(ct[3]),df=G-1,lower.tail=FALSE))<1e-10)
  stopifnot(max(abs(ci-(ct[1]+c(-1,1)*qt(.975,G-1)*ct[2])))<1e-10)
  data.table(definition=definition,shock=event,comparison=pair,specification=spec,
    trump=if(direct)2L else unique(d$trump),estimate=unname(ct[1]),se=unname(ct[2]),
    statistic=unname(ct[3]),p=unname(ct[4]),low=unname(ci[1]),high=unname(ci[2]),
    restaurants=N,focal_restaurants=sum(d$treated),control_restaurants=sum(1-d$treated),
    counties=G,df=G-1,df_K=K,cr1_correction=G/(G-1)*(N-1)/(N-K))
}
for(event in c('Election','Ban')){
  p<-fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv')))
  for(def in unique(a$definition)){
    all<-merge(p,a[definition==def],by='gmap_id')
    for(pair in pairs){
      members<-strsplit(pair,' vs ',fixed=TRUE)[[1]]
      q<-copy(all[group %chin% members]);q[,treated:=as.integer(group==members[1])]
      shared<-q[,.(sides=uniqueN(treated)),by=county_fips][sides==2]$county_fips
      d0<-q[county_fips %chin% shared]
      for(t in 0:1){
        full<-q[trump==t];d<-d0[trump==t]
        stopifnot(uniqueN(d$county_fips)>=2,uniqueN(d$treated)==2)
        f0<-feols(change~treated,data=full,vcov=~county_fips,ssc=ss,notes=FALSE)
        rr<-export_fit(f0,full,'treated',def,event,pair,'Original raw change')
        old<-raw[definition==def & shock==event & comparison==pair & trump==t]
        stopifnot(abs(rr$estimate-old$estimate)<1e-10,abs(rr$p-old$p)<1e-10)
        rows[[length(rows)+1L]]<-rr
        f1<-feols(change~treated,data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
        rows[[length(rows)+1L]]<-export_fit(f1,d,'treated',def,event,pair,'Raw change, shared counties')
        f2<-feols(change~treated|county_fips,data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
        rows[[length(rows)+1L]]<-export_fit(f2,d,'treated',def,event,pair,'County FE, shared counties')
        if(def=='expanded_broad_pre'){
          saved_models[[paste(event,t,pair,sep='__')]]<-f2
          # Check equivalent two-period panel point estimate directly.
          panel<-melt(d,id.vars=c('gmap_id','county_fips','treated'),measure.vars=c('rating_pre','rating_post'),
            variable.name='period',value.name='rating');panel[,post:=as.integer(period=='rating_post')]
          fp<-feols(rating~treated:post|gmap_id+county_fips^post,data=panel,vcov=~county_fips,ssc=ss,notes=FALSE)
          err<-abs(unname(coef(fp)['treated:post'])-unname(coef(f2)['treated']))
          stopifnot(err<1e-8);panel_errors<-c(panel_errors,err)
        }
        support_rows[[length(support_rows)+1L]]<-data.table(definition=def,shock=event,comparison=pair,trump=t,
          original_restaurants=nrow(full),shared_county_restaurants=nrow(d),original_counties=uniqueN(full$county_fips),
          shared_counties=uniqueN(d$county_fips),focal_original=sum(full$treated),focal_shared=sum(d$treated),
          control_original=sum(1-full$treated),control_shared=sum(1-d$treated))
      }
      # The county-level Trump main effect is absorbed by county FE.
      direct_raw<-feols(change~treated*trump,data=d0,vcov=~county_fips,ssc=ss,notes=FALSE)
      directs[[length(directs)+1L]]<-export_fit(direct_raw,d0,'treated:trump',def,event,pair,'Raw change, shared counties',TRUE)
      direct_fe<-feols(change~treated+treated:trump|county_fips,data=d0,vcov=~county_fips,ssc=ss,notes=FALSE)
      directs[[length(directs)+1L]]<-export_fit(direct_fe,d0,'treated:trump',def,event,pair,'County FE, shared counties',TRUE)
      if(def=='expanded_broad_pre')saved_models[[paste(event,'direct',pair,sep='__')]]<-direct_fe
    }
  }
}
r<-rbindlist(rows);di<-rbindlist(directs)
r[,p_holm_three_pairs:=p.adjust(p,'holm'),by=.(definition,shock,trump,specification)]
di[,p_holm_three_pairs:=p.adjust(p,'holm'),by=.(definition,shock,specification)]
r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
di[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(r,file.path(out,'four_week_county_fe_results.csv'))
fwrite(di,file.path(out,'four_week_county_fe_direct_tests.csv'))
fwrite(rbindlist(support_rows),file.path(out,'county_common_support.csv'))
saveRDS(saved_models,file.path(out,'main_county_fe_models.rds'))
write_json(list(raw_models_reproduced=60,pvalues_checked_with_t_distribution=TRUE,
  main_panel_equivalence_checks=length(panel_errors),maximum_panel_coefficient_error=max(panel_errors),
  inference='First-difference regressions; county-clustered CR1; fixest nonnested FE degrees-of-freedom correction; t df = counties - 1',
  weighting='One observation and unit regression weight per restaurant'),
  file.path(out,'regression_R_checks.json'),pretty=TRUE,auto_unbox=TRUE)
writeLines(capture.output(sessionInfo()),file.path(out,'regression_R_session.txt'))
print(r[definition=='expanded_broad_pre'&specification=='County FE, shared counties',
  .(shock,trump,comparison,estimate,se,p,symbol,restaurants,counties,focal_restaurants,control_restaurants,df_K)])
