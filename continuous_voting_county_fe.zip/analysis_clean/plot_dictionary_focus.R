args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages(library(data.table))
settings<-commandArgs(trailingOnly=TRUE);mode<-if(length(settings))settings[1] else 'raw'
out<-if(mode=='raw')file.path(here,'dictionary_focus') else file.path(here,'county_fe_regressions')
if(mode=='raw')r<-fread(file=file.path(out,'four_week_dictionary_comparisons.csv'))
if(mode=='county_fe')r<-fread(file=file.path(out,'four_week_county_fe_results.csv'))[specification=='County FE, shared counties']
if(mode=='joint_fe'){
  r<-fread(file=file.path(out,'joint_three_group_results.csv'))
  r[,focal_restaurants:=ifelse(startsWith(comparison,'WPME'),WPME_restaurants,ME_restaurants)]
  r[,control_restaurants:=ifelse(comparison=='WPME vs ME',ME_restaurants,MED_restaurants)]
}
defs<-c('legacy_baba','pre_baba','expanded_core_pre','expanded_broad_pre','expanded_broad_all_saved')
labels<-c('Legacy baba flag','Pre-election baba','Pre-election core','Pre-election broad','All-saved broad')
pairs<-c('WPME vs ME','WPME vs MED','ME vs MED')
names_out<-c('dictionary_WPME_ME','dictionary_WPME_MED','dictionary_ME_MED')
if(mode!='raw')names_out<-sub('dictionary_',paste0(mode,'_'),names_out)
for(j in seq_along(pairs)){
  pair<-pairs[j];dall<-r[comparison==pair]
  bounds<-range(c(dall$low,dall$high,0));span<-diff(bounds);left<-bounds[1]-.06*span;right<-bounds[2]+.08*span
  pcol<-right+.10*span;far<-right+.45*span
  draw<-function(){
    par(mfrow=c(2,2),mar=c(4.4,8.8,4,1),oma=c(3,0,3,0),family='sans',las=1)
    for(event in c('Election','Ban'))for(t in c(1,0)){
      d<-r[comparison==pair & shock==event & trump==t];d<-d[match(defs,definition)]
      yy<-5:1;post<-d$definition %chin% c('legacy_baba','expanded_broad_all_saved')
      col<-ifelse(post,'#8B969D',ifelse(d$definition=='expanded_broad_pre','#B64B40','#376B92'))
      plot(c(left,far),c(.5,5.8),type='n',xaxt='n',yaxt='n',xlab='',ylab='',bty='l')
      ticks<-pretty(c(left,right),n=5);ticks<-ticks[ticks>=left & ticks<=right]
      axis(1,at=ticks,labels=ticks,cex.axis=.85)
      abline(v=0,lty=2,col='#929BA1');segments(left,yy,right,yy,col='#E5EAED',lwd=.7)
      axis(2,at=yy,labels=paste0(labels,'\nn=',format(d$focal_restaurants,big.mark=',',trim=TRUE),' / ',format(d$control_restaurants,big.mark=',',trim=TRUE)),tick=FALSE,cex.axis=.77)
      arrows(d$low,yy,d$high,yy,angle=90,code=3,length=.04,col=col,lwd=1.6)
      points(d$estimate,yy,pch=ifelse(post,1,16),cex=ifelse(d$definition=='expanded_broad_pre',1.4,1.1),col=col)
      pv<-ifelse(d$p<.001,'<.001',formatC(d$p,format='f',digits=4))
      text(pcol,yy,paste0(pv,d$symbol),adj=0,cex=.82,col=col)
      text(pcol,5.65,'Raw p',adj=0,font=2,cex=.8)
      title(main=paste(event,if(t==1)'| Trump counties' else '| Non-Trump counties'),cex.main=1.08)
      mtext('First-group change minus second-group change (rating stars)',side=1,line=2.6,cex=.8)
    }
    title_mode<-switch(mode,raw='Four weeks before and four weeks after',county_fe='County fixed effects | Four-week windows',joint_fe='Joint three-group county FE | Four-week windows')
    mtext(paste(pair,'|',title_mode),outer=TRUE,side=3,line=1,font=2,cex=1.1)
    caption<-switch(mode,raw='Pointwise 95% county-clustered intervals; equal restaurant weights; N = first / second group. Red = main broad pre-election tags.',county_fe='Pairwise common counties; equal restaurant weights; 95% county-clustered intervals. N = first / second group; red = main dictionary.',joint_fe='Counties containing all three groups; 95% county-clustered intervals. N = first / second group; the third group also enters the model.')
    mtext(caption,outer=TRUE,side=1,line=1.4,cex=.8)
    mtext('Grey definitions can use post-event tag information. Symbols use raw p: + <.10, * <.05, ** <.01, *** <.001.',outer=TRUE,side=1,line=.2,cex=.82)
  }
  png(file.path(out,paste0(names_out[j],'.png')),width=2300,height=1600,res=160,type='cairo');draw();dev.off()
  svg(file.path(out,paste0(names_out[j],'.svg')),width=2300/160,height=1600/160);draw();dev.off()
}
