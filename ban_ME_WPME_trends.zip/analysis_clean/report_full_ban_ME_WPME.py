from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'ban_ME_WPME_trends'
d=pd.read_csv(O/'weekly_event_study_inputs.csv',dtype={'county_fips':str});r=pd.read_csv(O/'weekly_event_study_estimates.csv');tests=pd.read_csv(O/'weekly_event_study_pretests.csv');checks=[]
for row in tests.itertuples():
 z=d[d.trump.eq(row.trump)].copy();ww=z.weight.to_numpy();weeks=sorted(set(z.event_week)-{-1});x=np.column_stack([z.ME.to_numpy()*(z.event_week.to_numpy()==t) for t in weeks]);y=z.rating.to_numpy()
 groups=[pd.factorize(z.gmap_id)[0],pd.factorize(z.county_fips+'_'+z.week)[0]]
 a=np.column_stack([y,x])
 for it in range(3000):
  before=a.copy()
  for codes in groups:
   sums=np.bincount(codes,weights=ww)
   for j in range(a.shape[1]):
    mu=np.bincount(codes,weights=ww*a[:,j])/sums;a[:,j]-=mu[codes]
  if np.max(np.abs(a-before))<1e-12:break
 else:raise AssertionError('Weighted FE residualization did not converge')
 yr=a[:,0];xr=a[:,1:];bread=np.linalg.inv(xr.T@(ww[:,None]*xr));b=bread@xr.T@(ww*yr);e=yr-xr@b
 scores=pd.DataFrame(xr*(ww*e)[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
 v=bread@scores.T@scores@bread*g/(g-1)*(n-1)/(n-row.df_K)
 old=r[r.trump.eq(row.trump)&r.event_week.ne(-1)].set_index('event_week').loc[weeks]
 err=max(float(np.max(np.abs(b-old.estimate.to_numpy()))),float(np.max(np.abs(np.sqrt(np.diag(v))-old.se.to_numpy()))))
 ii=np.array([i for i,t in enumerate(weeks) if t< -1]);f=float(b[ii]@np.linalg.solve(v[np.ix_(ii,ii)],b[ii])/len(ii))
 assert err<1e-7 and abs(f-row.joint_pre_F)<1e-6,(err,f,row.joint_pre_F)
 assert np.max(np.abs(z.groupby('gmap_id').weight.sum()-1))<1e-10
 checks.append({'trump':int(row.trump),'max_coefficient_or_se_error':err,'joint_F_error':abs(f-row.joint_pre_F),'FE_iterations':it+1})
blocks=pd.read_csv(O/'balanced_block_restaurant_ratings.csv');bm=pd.read_csv(O/'balanced_block_means.csv')
for row in bm.itertuples():
 q=blocks[blocks.trump.eq(row.trump)&blocks.group.eq(row.group)&blocks.block.eq(row.block)];assert len(q)==row.restaurants and abs(q.rating.mean()-row.mean_rating)<1e-10
for _,q in blocks.groupby('trump'):
 ids=[set(q[q.block.eq(b)].gmap_id) for b in ['earlier','rating_pre','rating_post']];assert ids[0]==ids[1]==ids[2]
(O/'verification.json').write_text(json.dumps({'weekly_models_independently_verified':checks,'fixed_cohort_block_means_verified':len(bm),'equal_restaurant_weights_verified':True},indent=2))
display=tests[['trump','original_restaurants','restaurants','ME','WPME','counties','pre_restrictions','joint_pre_p']].copy();display['trump']=display.trump.map({1:'Trump counties',0:'Non-Trump counties'})
table=lambda q:q.to_html(index=False,border=0,float_format=lambda x:f'{x:.4f}')
html='''<!doctype html><html><head><meta charset="utf-8"><title>ME-WPME ban parallel-trends diagnostics</title><style>body{font:16px/1.5 system-ui;max-width:1350px;margin:36px auto;padding:0 24px;color:#243343}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:14px;width:100%}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3f6}td:first-child{text-align:left}img{width:100%}.note{padding:18px;background:#edf3f6}</style></head><body><h1>ME versus WPME around the January 27, 2017 ban</h1><p>Full raw pre-election core tags; primary categories; equal restaurant weights; Trump and non-Trump counties shown separately.</p><div class="note"><b>Finding:</b> Trump-county ratings do not show convincing parallel pre-trends. In the fixed-cohort plot, WPME falls before the ban and rebounds afterward, while ME moves in the opposite direction. A weekly fixed-effects joint pre-lead test rejects equal pre-trends (p=.0011). Non-Trump counties show less evidence of divergence (p=.2368); non-rejection is not proof of parallel trends.</div>
<h2>Same restaurants, equally weighted, in every four-week period</h2><img src="balanced_four_week_paths.png" alt="Fixed-cohort ME and WPME rating paths around the ban in Trump and non-Trump counties">
<p>These are descriptive mean ratings for an identical set of restaurants at every point: Trump counties 63 ME and 54 WPME (117 total); non-Trump counties 938 ME and 746 WPME (1,684 total). Each restaurant has one unit of weight in each period; reviews are aggregated within restaurant-periods using review counts. The sample requires reviews in all three blocks and both cuisines in each retained county. It is smaller than the main ban samples of 134 and 1,952 restaurants. No missing rating is filled with zero.</p>
<p>Blocks are November 28–December 25, December 26–January 22, and January 30–February 26. The January 23–29 mixed week is excluded; dashed line marks January 27. Earlier coarse county-adjusted pre-period change-gap tests were p=.0757 (Trump) and p=.3127 (non-Trump); these differ from the weekly joint tests below because the hypotheses, time resolution, weighting and samples differ.</p>
<h2>Weekly relative paths with restaurant and county-by-week fixed effects</h2><img src="weekly_relative_event_study.png" alt="Weekly ME-minus-WPME relative gaps with county-clustered confidence intervals">
'''+table(display)+'''
<p>Each point is the ME-minus-WPME rating gap relative to the January 16 week, after restaurant and county-by-week fixed effects. Zero is the omitted January 23 event week; no outcome from that week enters. Blue points are pre-ban and orange points post-ban. Vertical bars are pointwise 95% county-clustered intervals.</p>
<p>The observed weekly panel runs November 14–February 26, entirely after the election week. Restaurants need at least two pre-ban observed weeks. Each restaurant receives total weight one across all its observed weeks, via 1/(number of observed weeks); weights are not review counts. This retains 130 of 134 Trump-county restaurants and 1,873 of 1,952 non-Trump restaurants. Unbalanced observation timing remains, but restaurant FE adjust stable level differences. The nine earlier-week ME interactions are jointly tested against the January 16 reference using a county-clustered F test, with reference degrees of freedom equal to counties minus one. Trump results use 23 counties; these are finite-cluster approximations, not exact tests.</p>
<p>The significant Trump pretest undermines interpreting the post-ban ME–WPME gap as a clean causal ban effect. It does not identify why trends differ; changing reviewer composition, seasonality or mean reversion could contribute. The non-Trump non-rejection is insufficient to establish causality. No restaurant is selected according to a desired pretest result.</p>
<h2>Observed weekly group means and sample sizes</h2><img src="weekly_observed_paths.png" alt="Observed weekly ME and WPME means with restaurant counts">
<p>Every observed restaurant has equal weight within a week, but the observed set changes over time. The count panels expose that variation; these raw weekly paths alone cannot establish parallel trends. A fully observed fourteen-week panel would retain only 3 ME/5 WPME restaurants in Trump counties and 65 ME/47 WPME in non-Trump counties, so it is not used as the main diagnostic.</p>
<h2>Mediterranean definition confirmed</h2><p>As requested, Mediterranean requires eligible pre-election review text and no core-dish hit. Shared-food mentions remain allowed. The completed full raw scan already implements this; no reclassification is needed. Mediterranean businesses are absent from every ME–WPME plot/model on this page.</p>
<p>Block means and weekly model coefficients, clustered standard errors and joint F statistics were independently reproduced in NumPy. <a href="verification.json">Verification</a> · <a href="weekly_event_study_pretests.csv">Weekly joint tests</a> · <a href="balanced_block_means.csv">Fixed-cohort means</a> · <a href="observed_weekly_means_and_N.csv">Weekly means and counts</a> · <a href="../ME_WPME_focus/focus_report.html">Direct before/after comparisons</a> · <a href="../../plot_full_ban_ME_WPME.R">R code</a></p></body></html>'''
(O/'ban_trends_report.html').write_text(html,encoding='utf-8');print(json.dumps(checks));print(display.to_string(index=False))
