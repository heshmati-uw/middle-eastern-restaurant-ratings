args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
src<-file.path(here,'full_pre_election_core');out<-file.path(src,'ban_ME_WPME_trends');dir.create(out,showWarnings=FALSE)
q<-fread(file=file.path(src,'regressions','sample_ME_WPME_ban.csv'),colClasses=c(county_fips='character'))
w<-fread(file=file.path(src,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
q<-q[,.(gmap_id,group,trump,county_fips,rating_pre,rating_post)];q[,ME:=as.integer(group=='ME')]
pre<-w[week>=as.IDate('2016-11-28')&week<=as.IDate('2016-12-19')&reviews>0&!is.na(rating),.(earlier=sum(rating*reviews)/sum(reviews)),by=gmap_id]
b<-merge(q,pre,by='gmap_id');shared<-b[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips;b<-b[county_fips %chin% shared]
bl<-melt(b,id.vars=c('gmap_id','group','trump','county_fips','ME'),measure.vars=c('earlier','rating_pre','rating_post'),variable.name='block',value.name='rating')
bm<-bl[,.(mean_rating=mean(rating),restaurants=.N),by=.(trump,group,block)]
fwrite(bl,file.path(out,'balanced_block_restaurant_ratings.csv'));fwrite(bm,file.path(out,'balanced_block_means.csv'))
z<-merge(w[week>=as.IDate('2016-11-14')&week<=as.IDate('2017-02-20')&week!=as.IDate('2017-01-23')&reviews>0&!is.na(rating)],q[,.(gmap_id,group,trump,county_fips,ME)],by='gmap_id')
wm<-z[,.(mean_rating=mean(rating),restaurants=.N),by=.(trump,group,week)];fwrite(wm,file.path(out,'observed_weekly_means_and_N.csv'))
fwrite(z,file.path(out,'weekly_restaurant_ratings.csv'))
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');tests<-list();leads<-list();designs<-list()
for(t in c(1,0)){
 d<-copy(z[trump==t]);npre<-d[week<as.IDate('2017-01-23'),.N,by=gmap_id];d<-d[gmap_id %chin% npre[N>=2]$gmap_id]
 d[,nweeks:=.N,by=gmap_id];d[,weight:=1/nweeks];d[,event_week:=as.integer((week-as.IDate('2017-01-23'))/7)]
 stopifnot(max(abs(d[,sum(weight),by=gmap_id]$V1-1))<1e-10)
 fit<-feols(rating~i(event_week,ME,ref=-1)|gmap_id+county_fips^week,data=d,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
 beta<-coef(fit);V<-vcov(fit);ct<-coeftable(fit);ci<-as.matrix(confint(fit));G<-uniqueN(d$county_fips)
 ev<-as.integer(sub(':ME$','',sub('^event_week::','',names(beta))));ix<-which(ev< -1)
 rank<-qr(V[ix,ix,drop=FALSE])$rank;stopifnot(rank==length(ix))
 Fstat<-as.numeric(t(beta[ix])%*%solve(V[ix,ix,drop=FALSE],beta[ix])/length(ix));p<-pf(Fstat,length(ix),G-1,lower.tail=FALSE)
 tests[[length(tests)+1L]]<-data.table(trump=t,original_restaurants=uniqueN(z[trump==t]$gmap_id),restaurants=uniqueN(d$gmap_id),ME=uniqueN(d[ME==1]$gmap_id),WPME=uniqueN(d[ME==0]$gmap_id),observations=nrow(d),counties=G,df_K=attr(vcov(fit,attr=TRUE),'df.K'),pre_restrictions=length(ix),joint_pre_F=Fstat,joint_pre_p=p,reference_week='2017-01-16',weighting='Each restaurant total observed-panel weight = 1')
 leads[[length(leads)+1L]]<-rbind(data.table(trump=t,event_week=ev,estimate=unname(beta),se=sqrt(diag(V)),p=ct[,4],low=ci[,1],high=ci[,2]),data.table(trump=t,event_week=-1,estimate=0,se=0,p=NA_real_,low=0,high=0))
 designs[[length(designs)+1L]]<-d
}
tt<-rbindlist(tests);ev<-rbindlist(leads);fwrite(tt,file.path(out,'weekly_event_study_pretests.csv'));fwrite(ev,file.path(out,'weekly_event_study_estimates.csv'));fwrite(rbindlist(designs),file.path(out,'weekly_event_study_inputs.csv'))
col<-c(ME='#185b7a',WPME='#c45a3c');blocks<-c('earlier','rating_pre','rating_post');xs<-as.numeric(as.Date(c('2016-12-11','2017-01-08','2017-02-12')))
for(ext in c('png','svg')){
 open_device<-function(name,width=2100,height=1100){if(ext=='png')png(file.path(out,paste0(name,'.png')),width=width,height=height,res=180) else svg(file.path(out,paste0(name,'.svg')),width=width/180,height=height/180)}
 open_device('balanced_four_week_paths');par(mfrow=c(1,2),mar=c(5.5,5,4,1),oma=c(3,0,1,0))
 ylim<-range(bm$mean_rating)+c(-.08,.08)
 for(t in c(1,0)){
  plot(range(xs)+c(-12,12),ylim,type='n',xaxt='n',xlab='',ylab='Mean restaurant rating',main=if(t==1)'Trump counties' else 'Non-Trump counties');abline(v=as.numeric(as.Date('2017-01-27')),lty=2,col='grey40')
  axis(1,at=xs,labels=c('Nov 28-Dec 25','Dec 26-Jan 22','Jan 30-Feb 26'),cex.axis=.72)
  for(g in c('ME','WPME')){u<-bm[trump==t&group==g];u<-u[match(blocks,block)];lines(xs,u$mean_rating,type='b',pch=19,lwd=2,col=col[g])}
  ns<-bm[trump==t&block=='earlier'];legend('bottomleft',legend=paste0(c('ME','WPME'),' (N=',ns$restaurants[match(c('ME','WPME'),ns$group)],')'),col=col,lty=1,pch=19,bty='n',cex=.8)
  mtext('Four-week period; dashed line marks Jan 27 ban',side=1,line=3.5,cex=.7)
 }
 mtext('Same restaurants in every period; each restaurant receives equal weight. History-observed subset of the main sample.',side=1,outer=TRUE,line=.8,cex=.7);dev.off()
 open_device('weekly_observed_paths',2100,1450);par(mfrow=c(2,2),mar=c(4.5,5,3,1),oma=c(3,0,1,0))
 xlim<-as.numeric(as.Date(c('2016-11-14','2017-02-27')));ticks<-as.numeric(seq(as.Date('2016-11-14'),as.Date('2017-02-20'),by='2 weeks'))
 for(t in c(1,0)){
  plot(xlim,range(wm$mean_rating)+c(-.05,.05),type='n',xaxt='n',xlab='',ylab='Mean restaurant rating',main=if(t==1)'Trump counties' else 'Non-Trump counties')
  rect(as.numeric(as.Date('2017-01-23')),par('usr')[3],as.numeric(as.Date('2017-01-30')),par('usr')[4],col='#ededed',border=NA);abline(v=as.numeric(as.Date('2017-01-27')),lty=2,col='grey40')
  for(g in c('ME','WPME')){u<-wm[trump==t&group==g][order(week)];for(phase in 0:1){v<-u[(week<as.IDate('2017-01-23'))==(phase==0)];lines(as.numeric(v$week),v$mean_rating,type='b',pch=19,lwd=1.7,col=col[g])}}
  axis(1,ticks,format(as.Date(ticks,origin='1970-01-01'),'%b %d'),cex.axis=.75);legend('bottomleft',legend=c('ME','WPME'),col=col,lty=1,pch=19,bty='n',cex=.75)
 }
 for(t in c(1,0)){
  plot(xlim,c(0,max(wm[trump==t]$restaurants)*1.1),type='n',xaxt='n',xlab='Week starting',ylab='Restaurants observed that week')
  abline(v=as.numeric(as.Date('2017-01-27')),lty=2,col='grey40')
  for(g in c('ME','WPME')){u<-wm[trump==t&group==g][order(week)];lines(as.numeric(u$week),u$restaurants,type='b',pch=19,col=col[g])};axis(1,ticks,format(as.Date(ticks,origin='1970-01-01'),'%b %d'),cex.axis=.75)
 }
 mtext('Equal weight among observed restaurants within each week; composition changes. Grey week excluded; no zero-filling.',side=1,outer=TRUE,line=.8,cex=.7);dev.off()
 open_device('weekly_relative_event_study');par(mfrow=c(1,2),mar=c(5,5,4,1),oma=c(3,0,1,0));yl<-range(ev$low,ev$high)
 for(t in c(1,0)){
  u<-ev[trump==t][order(event_week)];test<-tt[trump==t]
  plot(range(u$event_week),yl,type='n',xlab='Weeks from omitted Jan 23 event week',ylab='ME-WPME gap relative to Jan 16 week',main=if(t==1)'Trump counties' else 'Non-Trump counties')
  abline(v=0,lty=2,col='grey40');abline(h=0,lty=3,col='grey40');segments(u$event_week,u$low,u$event_week,u$high,col='#185b7a');points(u$event_week,u$estimate,pch=19,col=ifelse(u$event_week<0,'#185b7a','#c45a3c'))
  mtext(sprintf('Joint pre-lead p=%.3f; N ME/WPME=%s/%s',test$joint_pre_p,test$ME,test$WPME),side=3,line=.3,cex=.72)
 }
 mtext('Restaurant and county-by-week fixed effects; equal total restaurant weights; 95% county-clustered intervals.',side=1,outer=TRUE,line=.8,cex=.7);dev.off()
}
print(tt);print(bm)
