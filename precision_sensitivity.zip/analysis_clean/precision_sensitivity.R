# Exploratory precision diagnostics: all planned specifications, no p-value selection.
args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
out<-file.path(here,'precision_sensitivity');dir.create(out,showWarnings=FALSE)
src<-file.path(here,'county_fe_regressions','inputs')
a<-fread(file=file.path(src,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))[definition=='expanded_broad_pre' & group %chin% c('WPME','ME','MED') & !is.na(trump)]
geo_path<-file.path(out,'focal_coordinates.csv')
if(!file.exists(geo_path))geo_path<-file.path(here,'expanded_positioning','metadata_with_geography.csv')
geo<-fread(file=geo_path,select=c('gmap_id','latitude','longitude'))
a<-merge(a,geo,by='gmap_id');stopifnot(!anyDuplicated(a$gmap_id))
# Spherical Albers equal-area projection, kilometres; approximate cells, not census units.
rad<-pi/180;n<-(sin(29.5*rad)+sin(45.5*rad))/2;C<-cos(29.5*rad)^2+2*n*sin(29.5*rad)
rho<-6371.0088*sqrt(C-2*n*sin(a$latitude*rad))/n
rho0<-6371.0088*sqrt(C-2*n*sin(23*rad))/n;theta<-n*(a$longitude+96)*rad
a[,`:=`(x=rho*sin(theta),y=rho0-rho*cos(theta))]
for(km in c(5,10,20)) a[,(paste0('cell',km)):=paste(county_fips,floor(x/km),floor(y/km),sep='_')]
w<-fread(file=file.path(src,'expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');rows<-list();designs<-list()
fit_export<-function(d,event,t,pair,model,fe,covs='',support='County overlap'){
  f<-as.formula(paste('change ~ treated',covs,'|',fe))
  fit<-feols(f,data=d,vcov=~county_fips,ssc=ss,notes=FALSE,warn=FALSE)
  ct<-coeftable(fit)['treated',];ci<-as.matrix(confint(fit))['treated',];G<-uniqueN(d$county_fips)
  stopifnot(nobs(fit)==nrow(d),abs(ct[4]-2*pt(abs(ct[3]),G-1,lower.tail=FALSE))<1e-9)
  K<-attr(vcov(fit,attr=TRUE),'df.K')
  id<-length(rows)+1L
  rows[[id]]<<-data.table(id,shock=event,trump=t,comparison=pair,model,support,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),focal=sum(d$treated),control=sum(1-d$treated),counties=G,fe_units=uniqueN(d[[fe]]),df_K=K,history_missing=sum(d$history_missing))
  vars<-c('gmap_id','change','treated','county_fips',fe,if(nchar(covs))trimws(strsplit(sub('^ *\\+','',covs),'\\+')[[1]]) else character())
  vars<-unique(vars);z<-unique(copy(d[,..vars]),by='gmap_id');setnames(z,fe,'fixed_effect',skip_absent=TRUE)
  if(fe=='county_fips')z[,county_fips:=fixed_effect]
  z[,model_id:=id];designs[[id]]<<-z
}
for(event in c('Election','Ban')){
  dates<-if(event=='Election')c('2016-07-04','2016-10-03') else c('2016-11-14','2016-12-19')
  h<-w[week>=as.IDate(dates[1]) & week<=as.IDate(dates[2]) & reviews>0 & !is.na(rating),.(history_rating=sum(rating*reviews)/sum(reviews),history_reviews=sum(reviews)),by=gmap_id]
  p<-fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv')))
  all<-merge(merge(p,a,by='gmap_id'),h,by='gmap_id',all.x=TRUE)
  for(pair in c('WPME vs ME','WPME vs MED','ME vs MED'))for(t in 0:1){
    members<-strsplit(pair,' vs ',fixed=TRUE)[[1]];q<-copy(all[group %chin% members & trump==t]);q[,treated:=as.integer(group==members[1])]
    ids<-q[,.(sides=uniqueN(treated)),by=county_fips][sides==2]$county_fips;d<-q[county_fips %chin% ids]
    d[,history_missing:=as.integer(is.na(history_rating))];mu<-mean(d$history_rating,na.rm=TRUE)
    d[is.na(history_rating),history_rating:=mu];d[is.na(history_reviews),history_reviews:=0]
    d[,`:=`(log_history_reviews=log1p(history_reviews),log_pre_reviews=log1p(reviews_pre))]
    history<-'+ history_rating + log_history_reviews + history_missing'
    baseline<-paste(history,'+ rating_pre + log_pre_reviews')
    fit_export(d,event,t,pair,'County FE','county_fips')
    fit_export(d,event,t,pair,'County FE + earlier history','county_fips',history)
    fit_export(d,event,t,pair,'County FE + history + baseline','county_fips',baseline)
    for(km in c(5,10,20)){
      fe<-paste0('cell',km);ids<-d[is.finite(x)&is.finite(y),.(sides=uniqueN(treated)),by=c(fe)][sides==2][[fe]]
      z<-d[get(fe) %chin% ids];support<-paste0(km,' km cell overlap')
      if(uniqueN(z$county_fips)<3)next
      fit_export(z,event,t,pair,paste0('County FE on ',km,' km sample'),'county_fips',support=support)
      fit_export(z,event,t,pair,paste0(km,' km cell FE'),fe,support=support)
      fit_export(z,event,t,pair,paste0(km,' km cell FE + history'),fe,history,support)
    }
  }
}
r<-rbindlist(rows);r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
r[,p_holm_all_models:=p.adjust(p,'holm')]
fwrite(r,file.path(out,'precision_results.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'verification_designs.csv'))
base<-r[model=='County FE',.(shock,trump,comparison,base_se=se,base_n=restaurants)]
r<-merge(r,base,by=c('shock','trump','comparison'));r[,`:=`(se_change_pct=100*(se/base_se-1),retained_pct=100*restaurants/base_n)]
fwrite(r,file.path(out,'precision_results.csv'))
png(file.path(out,'precision_WPME_ME.png'),width=2100,height=1500,res=180)
par(mfrow=c(2,2),mar=c(4,11,3,2),oma=c(2,0,2,0))
models<-c('County FE','County FE + earlier history','County FE + history + baseline','County FE on 10 km sample','10 km cell FE','10 km cell FE + history')
for(event in c('Election','Ban'))for(t in c(1,0)){
  z<-r[shock==event & trump==t & comparison=='WPME vs ME'];z<-z[match(models,model)]
  yy<-rev(seq_len(nrow(z)));lim<-range(c(z$low,z$high,0))
  plot(z$estimate,yy,xlim=lim,ylim=c(.5,6.5),yaxt='n',ylab='',xlab='WPME change minus ME change (rating stars)',pch=19,col='#225a7b',main=paste(event,if(t==1)'Trump counties' else 'Non-Trump counties',sep=' | '))
  abline(v=0,lty=2,col='grey');segments(z$low,yy,z$high,yy,col='#225a7b',lwd=2)
  axis(2,at=yy,labels=paste0(models,'\nN=',z$restaurants,', SE=',sprintf('%.3f',z$se)),las=1,cex.axis=.67,tick=FALSE)
}
mtext('Precision diagnostics | Fixed pre-election broad dictionary | Four weeks each side',outer=TRUE,side=3,line=0,cex=1.05)
mtext('Equal restaurant weights; 95% county-clustered intervals. Baseline adjustment changes the identifying assumption.',outer=TRUE,side=1,cex=.8)
dev.off()
print(r[comparison=='WPME vs ME' & model %chin% models,.(shock,trump,model,estimate,se,p,restaurants,counties,se_change_pct)])
