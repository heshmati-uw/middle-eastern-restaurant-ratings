from pathlib import Path
import json
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parent
out=root/'precision_sensitivity'
r=pd.read_csv(out/'precision_results.csv')
d=pd.read_csv(out/'verification_designs.csv',dtype={'county_fips':str,'fixed_effect':str})
errors=[]
for row in r.itertuples():
    z=d[d.model_id==row.id].copy()
    cols=['treated']
    if 'history' in row.model:
        cols+=['history_rating','log_history_reviews','history_missing']
    if 'baseline' in row.model:
        cols+=['rating_pre','log_pre_reviews']
    v=z[cols+['change']]
    v=v-v.groupby(z.fixed_effect).transform('mean')
    x=v[cols].to_numpy();y=v.change.to_numpy()
    inv=np.linalg.pinv(x.T@x);b=inv@x.T@y;res=y-x@b
    scores=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy()
    n=len(z);g=z.county_fips.nunique()
    cov=inv@scores.T@scores@inv*(g/(g-1)*(n-1)/(n-row.df_K))
    errors.extend([abs(b[0]-row.estimate),abs(np.sqrt(cov[0,0])-row.se)])
assert max(errors)<1e-8,max(errors)
old=pd.read_csv(root/'county_fe_regressions/four_week_county_fe_results.csv')
old=old[(old.definition=='expanded_broad_pre')&(old.specification=='County FE, shared counties')]
check=r[r.model=='County FE'].merge(old,on=['shock','trump','comparison'],suffixes=('','_old'))
assert len(check)==12
assert (check.estimate-check.estimate_old).abs().max()<1e-10
audit={'models_independently_verified':len(r),'max_coefficient_or_se_error':max(errors),'original_models_reproduced':12,'weighting':'One unit weight per restaurant','inference':'County-clustered CR1, t df=counties-1'}
(out/'verification.json').write_text(json.dumps(audit,indent=2))

r['County type']=r.trump.map({0:'Non-Trump',1:'Trump'})
r['Estimate (SE)']=r.apply(lambda q:f'{q.estimate:+.3f}{q.symbol if isinstance(q.symbol,str) else ""} ({q.se:.3f})',axis=1)
r['95% CI']=r.apply(lambda q:f'[{q.low:+.3f}, {q.high:+.3f}]',axis=1)
r['p']=r.p.map(lambda x:f'{x:.4f}')
r['SE change vs full county model']=r.se_change_pct.map(lambda x:f'{x:+.1f}%')
cols=['shock','County type','comparison','model','Estimate (SE)','95% CI','p','restaurants','counties','focal','control','SE change vs full county model','retained_pct']
table=r[cols].to_html(index=False,border=0,float_format=lambda x:f'{x:.1f}')
main=r[(r.comparison=='WPME vs ME')&(r.trump==0)&r.model.isin(['County FE','County FE + earlier history','County FE + history + baseline','10 km cell FE'])]
small=main[['shock','model','Estimate (SE)','p','restaurants','counties']].to_html(index=False,border=0)
html='''<!doctype html><html><head><meta charset="utf-8"><title>Restaurant precision diagnostics</title><style>
body{font:16px/1.5 system-ui;max-width:1300px;margin:36px auto;padding:0 24px;color:#203043}h1,h2{color:#174e69}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:right}th{background:#eef3f5;position:sticky;top:0}td:nth-child(-n+4){text-align:left}img{width:100%}.scroll{overflow:auto;max-height:650px}.note{background:#eef3f5;padding:18px}
</style></head><body><h1>Can we improve precision?</h1>
<p>We tested finer spatial controls and predetermined restaurant characteristics while holding the four-week windows, pre-election broad dictionary, equal restaurant weights, and county clustering fixed. All 144 exploratory specifications are shown; none was selected by statistical significance.</p>
<div class="note"><b>Finding:</b> Finer geography reduces overlap and generally increases uncertainty in the WPME–ME comparisons. Earlier history contributes little precision. Baseline rating/activity adjustment narrows intervals, but also moves estimates toward zero; it requires a different identifying assumption.</div>
<h2>Non-Trump counties: WPME versus ME</h2>'''+small+'''
<p>Positive estimates mean WPME ratings improved relative to ME ratings. Negative estimates mean WPME lost ground relative to ME. N counts restaurants, not reviews.</p>
<img src="precision_WPME_ME.png" alt="WPME versus ME precision comparisons for election and ban in both county types">
<h2>What each refinement means</h2>
<p><b>Earlier history:</b> Mean rating weighted by review counts, log(1+review count), and a missing-history indicator, measured July 4–October 9, 2016 for the election and November 14–December 25, 2016 for the ban. Missing history rating is imputed using the pooled mean within the comparison sample; no restaurants are dropped. Ban history is before the ban but after the election, so it can absorb election-related differences.</p>
<p><b>Baseline adjustment:</b> Adds the main four-week pre-period rating and log(1+pre-period review count). A regression of change with baseline rating included is algebraically an ANCOVA regression of post rating. This permits mean reversion and can improve precision, but conditional post-level comparability replaces the simple parallel-change assumption. No causal claim follows from the smaller standard error. Earlier-history controls are included in this specification too.</p>
<p><b>Finer location:</b> Approximate 5, 10, and 20 km equal-area grid cells nested in county, constructed from coordinates using a spherical Albers projection (29.5°/45.5° standard parallels). These are not ZIP codes, census tracts, or precise distance matches; grid boundaries are arbitrary. A cell is retained only if both groups are present. Each spatial model has a county-FE comparator on exactly the same restaurants, isolating the effect of spatial controls from sample restriction. Clustering stays at county.</p>
<h2>Practical next steps</h2><p>Keep county-FE changes as the primary benchmark. Treat baseline adjustment as a reported sensitivity, rather than choosing it for a smaller p-value. For more comparable samples, obtain predetermined price tier, chain status, restaurant age, and neighborhood demographics; audit their availability before adding controls. More pre-election review history and raw-text tagging can improve measurement without redefining groups using outcomes. Precinct-level voting would measure local political exposure more accurately than county majorities, but needs historical precinct boundaries/results and a new estimand. Restaurant location is not reviewer residence.</p>
<h2>All specifications, including Mediterranean comparisons</h2><p>Raw two-sided p-values: + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001. Exploratory multiplicity-adjusted p-values for all 144 models are also saved in the CSV. These diagnostics do not establish parallel trends.</p><div class="scroll">'''+table+'''</div>
<p>Independent NumPy verification reproduced all 144 coefficients and county-clustered standard errors; all 12 county benchmarks reproduce the prior report. <a href="precision_results.csv">Results CSV</a> · <a href="verification.json">Verification</a> · <a href="../precision_sensitivity.R">R code</a> · <a href="../report_precision.py">Verification/report code</a></p>
<p>Method references: <a href="https://blogs.worldbank.org/en/impactevaluations/experimental-design-and-ancova-when-everyone-has-same-baseline-outcome-value">McKenzie on baseline adjustment</a>; <a href="https://www.nber.org/papers/w24003">Abadie et al. on clustering</a>. Experimental precision results motivate diagnostics here, not observational identification.</p></body></html>'''
(out/'precision_report.html').write_text(html,encoding='utf-8')
print(json.dumps(audit))
print(r[(r.comparison=='WPME vs ME')&r.model.str.contains('km cell FE')][['shock','County type','model','restaurants','se','SE change vs full county model']].to_string(index=False))
