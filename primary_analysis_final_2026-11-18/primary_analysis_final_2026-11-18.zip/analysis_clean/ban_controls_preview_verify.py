from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
from scipy.stats import t as td
BASE=H/'original_primary_county_fe';O=BASE/'controls_preview'
d=pd.read_csv(O/'analysis_data.csv',dtype={'county_fips':str});r=pd.read_csv(O/'results.csv');coef=pd.read_csv(O/'coefficients.csv');design=json.loads((O/'design.json').read_text())
def within(a,c):
 a=np.asarray(a,float);one=a.ndim==1
 if one:a=a[:,None]
 n=np.bincount(c);s=np.zeros((len(n),a.shape[1]));np.add.at(s,c,a);ans=a-s[c]/n[c,None]
 return ans[:,0] if one else ans
checks=[]
for row in r.itertuples(index=False):
 v=pd.read_csv(O/f'verify_{row.id}.csv.gz',dtype={'county':str});first,second=row.pair.split(' versus ')
 q=d[d.group_hummus_or_baba.isin([first,second])];shared=q.groupby('county_fips').group_hummus_or_baba.nunique().eq(2);q=q[q.county_fips.isin(shared[shared].index)]
 if row.stratum!='direct':q=q[q.trump.eq(int(row.stratum=='Trump'))]
 assert set(v.id)==set(q.gmap_id) and v.id.is_unique
 z=q.set_index('gmap_id').loc[v.id];np.testing.assert_allclose(v.y,z.change,atol=1e-12)
 np.testing.assert_array_equal(v.treated,z.group_hummus_or_baba.eq(first).astype(int))
 for col in design['specifications'][row.specification]:
  np.testing.assert_allclose(v[col],z[col],atol=1e-12)
  if row.stratum=='direct':np.testing.assert_allclose(v[col+'_T'],z[col].to_numpy()*z.trump.to_numpy(),atol=1e-12)
 if row.stratum=='direct':np.testing.assert_allclose(v.interaction,v.treated*z.trump.to_numpy(),atol=1e-12)
 names=list(v.columns[3:]);county=pd.factorize(v.county)[0];G=county.max()+1
 full=within(v[names].to_numpy(),county);y=within(v.y.to_numpy(),county)
 kept=coef[coef.id.eq(row.id)].term.tolist();X=full[:,[names.index(k) for k in kept]]
 B=np.linalg.lstsq(X,y,rcond=None)[0];reference=coef[coef.id.eq(row.id)].set_index('term').loc[kept,'estimate'].to_numpy();np.testing.assert_allclose(B,reference,atol=1e-8,rtol=1e-7)
 u=y-X@B;A=np.linalg.inv(X.T@X);S=np.zeros((G,len(B)));np.add.at(S,county,X*u[:,None]);K=len(B)+1;V=A@(S.T@S)@A*G/(G-1)*(len(v)-1)/(len(v)-K)
 RV=pd.read_csv(O/f'cov_{row.id}.csv',index_col=0).loc[kept,kept].to_numpy();np.testing.assert_allclose(V,RV,atol=1e-8,rtol=1e-6)
 assert K==row.df_K and len(v)==row.restaurants and G==row.counties
 target='interaction' if row.stratum=='direct' else 'treated';k=kept.index(target);se=np.sqrt(V[k,k]);p=2*td.sf(abs(B[k]/se),G-1)
 np.testing.assert_allclose([B[k],se,p],[row.estimate,row.se,row.p],atol=1e-8,rtol=1e-6)
 checks.append(dict(id=row.id,passed=True,max_beta_error=float(np.max(abs(B-reference)))))
for (pair,stratum),q in r.groupby(['pair','stratum']):assert q.restaurants.nunique()==1 and q.counties.nunique()==1
for (pair,spec),q in r.groupby(['pair','specification']):
 q=q.set_index('stratum');np.testing.assert_allclose(q.loc['Trump','estimate']-q.loc['nonTrump','estimate'],q.loc['direct','estimate'],atol=1e-8)
old=pd.read_csv(BASE/'pairwise_results.csv');old=old[(old.source=='raw')&(old.definition=='hummus_or_baba')&(old.event=='Ban')]
for row in r[r.specification.eq('baseline')].itertuples(index=False):
 q=old[old.pair.eq(row.pair)&old.stratum.eq(row.stratum)].iloc[0];np.testing.assert_allclose([row.estimate,row.se,row.p],[q.estimate,q.se,q.p],atol=1e-10)
raw=pd.read_csv(BASE/'individual_reviews.csv');early=raw[(raw.event=='Election')&(raw.period=='pre')].groupby('gmap_id').rating.agg(['mean','size'])
expected=d.gmap_id.map(early['mean']);assert np.array_equal(expected.isna().astype(int),d.rating_missing)
np.testing.assert_allclose(d.rating_control,expected.fillna(expected.median()),atol=1e-12)
np.testing.assert_allclose(d.log_earlier_reviews,np.log1p(d.gmap_id.map(early['size']).fillna(0)),atol=1e-12)
numerical_only='--numerical-only' in sys.argv
if not numerical_only:
 protected=json.loads((O/'protected_document_hashes.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in protected.items())
out=dict(all_passed=True,fits_checked=len(checks),checks=checks,sample_fixed_across_specifications=True,direct_equals_adjusted_subgroup_difference=True,baseline_matches_existing_results=True,earlier_controls_reconstructed_from_raw=True,existing_reports_and_tables_unchanged=None if numerical_only else True)
(O/('checkpoint_verification.json' if numerical_only else 'verification.json')).write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
