args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()));suppressPackageStartupMessages(library(fixest));setFixest_nthreads(1)
o<-file.path(h,'original_primary_county_fe');raw<-read.csv(file.path(o,'restaurant_changes.csv'),colClasses=c(county_fips='character'));archive<-read.csv(file.path(o,'archived_restaurant_changes.csv'),colClasses=c(county_fips='character'))
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
results<-list();support<-list();inputs<-list();joint<-list();infos<-list();continuous_pairs<-list()
stars<-function(p)ifelse(is.na(p),'',ifelse(p<.001,'***',ifelse(p<.01,'**',ifelse(p<.05,'*',ifelse(p<.10,'+','')))))
save_design<-function(d,id,cols){
 con<-gzfile(file.path(o,paste0('verify_',id,'.csv.gz')),'wt');write.csv(data.frame(id=d$gmap_id,county=d$county_fips,y=d$change,d[,cols,drop=FALSE],check.names=FALSE),con,row.names=FALSE);close(con)
}
for(source in c('raw','archive')){
 base<-if(source=='raw')raw else archive
 defs<-if(source=='raw')c('hummus_or_baba','baba_only','legacy_baba') else 'legacy_baba'
 for(definition in defs)for(event in c('Election','Ban')){
  all<-base[base$event==event,];all$position<-all[[paste0('group_',definition)]];all<-all[all$position%in%c('ME','WPME','MED'),]
  for(pair in c('WPME versus ME','WPME versus MED','ME versus MED')){
   members<-strsplit(pair,' versus ',fixed=TRUE)[[1]]
   q<-all[all$position%in%members,];q$treated<-as.integer(q$position==members[1]);q$interaction<-q$treated*q$trump
   sides<-tapply(q$treated,q$county_fips,function(x)length(unique(x)))
   shared<-names(sides)[sides==2];d0<-q[q$county_fips%in%shared,]
   if(source=='raw'){
    dc<-d0;dc$vote_interaction<-dc$treated*dc$vote10
    fc<-feols(change~treated+vote_interaction|county_fips,data=dc,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
    ct<-coeftable(fc)['vote_interaction',];ci<-as.matrix(confint(fc))['vote_interaction',];Vc<-vcov(fc,attr=TRUE)
    idc<-paste('continuous_pair',definition,event,gsub(' ','_',pair),sep='__')
    continuous_pairs[[length(continuous_pairs)+1]]<-data.frame(id=idc,definition=definition,event=event,pair=pair,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(dc),first_restaurants=sum(dc$treated),second_restaurants=sum(1-dc$treated),counties=length(unique(dc$county_fips)),df_K=attr(Vc,'df.K'))
    save_design(dc,idc,c('treated','vote_interaction'))
   }
   support[[length(support)+1]]<-data.frame(source=source,definition=definition,event=event,pair=pair,all_pair_restaurants=nrow(q),shared_county_restaurants=nrow(d0),all_pair_counties=length(unique(q$county_fips)),shared_counties=length(shared))
   for(stratum in c('nonTrump','Trump','direct')){
    d<-if(stratum=='direct')d0 else d0[d0$trump==as.integer(stratum=='Trump'),]
    cols<-if(stratum=='direct')c('treated','interaction') else 'treated'
    term<-if(stratum=='direct')'interaction' else 'treated'
    fit<-feols(as.formula(paste('change~',paste(cols,collapse='+'),'|county_fips')),data=d,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
    ct<-coeftable(fit)[term,];ci<-as.matrix(confint(fit))[term,];V<-vcov(fit,attr=TRUE);G<-length(unique(d$county_fips));K<-attr(V,'df.K')
    id<-paste(source,definition,event,gsub(' ','_',pair),stratum,sep='__')
    results[[length(results)+1]]<-data.frame(id=id,source=source,definition=definition,event=event,pair=pair,stratum=stratum,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),first_restaurants=sum(d$treated),second_restaurants=sum(1-d$treated),counties=G,df_K=K,source_reviews_pre=sum(d$reviews_pre),source_reviews_post=sum(d$reviews_post))
    save_design(d,id,cols)
   }
  }
  if(source=='raw'){
   d<-all;d$ME<-as.integer(d$position=='ME');d$WPME<-as.integer(d$position=='WPME');d$ME_vote<-d$ME*d$vote10;d$WPME_vote<-d$WPME*d$vote10
   cols<-c('ME','WPME','ME_vote','WPME_vote')
   fit<-feols(change~ME+WPME+ME_vote+WPME_vote|county_fips,data=d,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
   B<-coef(fit);V<-vcov(fit,attr=TRUE);G<-length(unique(d$county_fips));id<-paste('joint',definition,event,sep='__')
   X<-demean(as.matrix(d[,cols]),f=list(factor(d$county_fips)),tol=1e-12,nthreads=1)
   active<-length(unique(d$county_fips[rowSums(abs(X))>1e-8]))
   infos[[length(infos)+1]]<-data.frame(id=id,definition=definition,event=event,restaurants=nrow(d),counties=G,informative_counties=active,df_K=attr(V,'df.K'),omitted=paste(setdiff(cols,names(B)),collapse='; '))
   contrasts<-list('WPME versus ME'=c(ME_vote=-1,WPME_vote=1),'WPME versus MED'=c(WPME_vote=1),'ME versus MED'=c(ME_vote=1))
   for(pair in names(contrasts)){
    L<-setNames(rep(0,length(B)),names(B));L[names(contrasts[[pair]])]<-contrasts[[pair]];b<-sum(L*B);se<-sqrt(as.numeric(t(L)%*%V%*%L))
    joint[[length(joint)+1]]<-data.frame(id=id,definition=definition,event=event,pair=pair,estimate=b,se=se,p=2*pt(-abs(b/se),G-1),low=b-qt(.975,G-1)*se,high=b+qt(.975,G-1)*se,restaurants=nrow(d),counties=G,df_K=attr(V,'df.K'))
   }
   save_design(d,id,cols);write.csv(V,file.path(o,paste0('cov_',id,'.csv')));write.csv(data.frame(term=names(B),estimate=B),file.path(o,paste0('coef_',id,'.csv')),row.names=FALSE)
  }
  cat(source,definition,event,'completed\n')
 }
}
r<-do.call(rbind,results);r$symbol<-stars(r$p);j<-do.call(rbind,joint);j$symbol<-stars(j$p)
write.csv(r,file.path(o,'pairwise_results.csv'),row.names=FALSE);write.csv(j,file.path(o,'continuous_joint_results.csv'),row.names=FALSE)
write.csv(do.call(rbind,support),file.path(o,'county_support.csv'),row.names=FALSE);write.csv(do.call(rbind,infos),file.path(o,'joint_model_info.csv'),row.names=FALSE)
cp<-do.call(rbind,continuous_pairs);cp$symbol<-stars(cp$p);write.csv(cp,file.path(o,'continuous_pairwise_results.csv'),row.names=FALSE)
old<-read.csv(file.path(h,'county_fe_regressions/four_week_county_fe_results.csv'))
di<-read.csv(file.path(h,'county_fe_regressions/four_week_county_fe_direct_tests.csv'))
for(i in seq_len(nrow(r))){
 row<-r[i,];if(row$source!='archive')next
 pair<-gsub(' versus ',' vs ',row$pair,fixed=TRUE)
 target<-if(row$stratum=='direct')di[di$definition=='legacy_baba'&di$shock==row$event&di$comparison==pair&di$specification=='County FE, shared counties',] else old[old$definition=='legacy_baba'&old$shock==row$event&old$comparison==pair&old$specification=='County FE, shared counties'&old$trump==as.integer(row$stratum=='Trump'),]
 stopifnot(nrow(target)==1,max(abs(c(row$estimate-target$estimate,row$se-target$se,row$p-target$p)))<1e-8)
}
cat('All 18 archived fits reproduce the saved estimates and p values\n')
