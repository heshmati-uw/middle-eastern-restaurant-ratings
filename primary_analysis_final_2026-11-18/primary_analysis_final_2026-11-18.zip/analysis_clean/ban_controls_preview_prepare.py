"""Separate controls preview. Never writes to the existing report/tables."""
from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
H=Path(__file__).resolve().parent;BASE=H/'original_primary_county_fe';O=BASE/'controls_preview';O.mkdir(exist_ok=True)
protected=[BASE/'regression_tables.html',BASE/'analysis_report.html',H.parent/'restaurant_project_review.html']
fingerprints={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
(O/'protected_document_hashes.json').write_text(json.dumps(fingerprints,indent=2))
d=pd.read_csv(BASE/'restaurant_changes.csv',dtype={'county_fips':str});d=d[(d.event=='Ban')&d.group_hummus_or_baba.isin(['ME','WPME','MED'])].copy()
reviews=pd.read_csv(BASE/'individual_reviews.csv');early=reviews[(reviews.event=='Election')&(reviews.period=='pre')].groupby('gmap_id').rating.agg(earlier_rating='mean',earlier_reviews='size')
d=d.merge(early,on='gmap_id',how='left',validate='one_to_one')
d['rating_missing']=d.earlier_rating.isna().astype(int);median=float(d.earlier_rating.median());d['rating_control']=d.earlier_rating.fillna(median)
d['earlier_reviews']=d.earlier_reviews.fillna(0).astype(int);d['log_earlier_reviews']=np.log1p(d.earlier_reviews)
a=pd.read_csv(H/'full_pre_election_core/attribute_matching/restaurant_attributes.csv')
attrs=['price_tier','dine_in','takeout','delivery','alcohol','service_recorded','offerings_recorded']
d=d.merge(a[['gmap_id']+attrs],on='gmap_id',how='left',validate='one_to_one')
d['price_unknown']=d.price_tier.isna().astype(int);d['price_two']=d.price_tier.eq(2).astype(int);d['price_high']=d.price_tier.ge(3).astype(int)
d['service_unknown']=~d.service_recorded.eq(1);d['alcohol_unknown']=~d.offerings_recorded.eq(1)
for label in ['dine_in','takeout','delivery']:d[label+'_listed']=(d[label].eq(1)&~d.service_unknown).astype(int)
d['alcohol_listed']=(d.alcohol.eq(1)&~d.alcohol_unknown).astype(int)
d['service_unknown']=d.service_unknown.astype(int);d['alcohol_unknown']=d.alcohol_unknown.astype(int)
history=['rating_control','rating_missing','log_earlier_reviews']
snapshot=['price_two','price_high','price_unknown','dine_in_listed','takeout_listed','delivery_listed','service_unknown','alcohol_listed','alcohol_unknown']
assert d[history+snapshot].notna().all().all()
d.to_csv(O/'analysis_data.csv',index=False)
coverage=[]
for pair in ['WPME versus ME','WPME versus MED','ME versus MED']:
 first,second=pair.split(' versus ');q=d[d.group_hummus_or_baba.isin([first,second])];shared=q.groupby('county_fips').group_hummus_or_baba.nunique().eq(2);q=q[q.county_fips.isin(shared[shared].index)]
 for t,g in q.groupby('trump'):
  coverage.append(dict(pair=pair,trump=int(t),restaurants=len(g),earlier_rating_observed=int(g.earlier_rating.notna().sum()),price_observed=int(g.price_tier.notna().sum()),service_unknown=int(g.service_unknown.sum()),alcohol_unknown=int(g.alcohol_unknown.sum()),counties=g.county_fips.nunique()))
pd.DataFrame(coverage).to_csv(O/'coverage.csv',index=False)
design=dict(status='Preview only; existing report and tables unchanged',event='Ban',dictionary='hummus_or_baba',primary_category_rules='Original original_primary_county_fe frame',outcome='Restaurant post mean minus pre mean',weights='One per restaurant',county_FE=True,
 specifications={'baseline':[],'history':history,'full_snapshot':history+snapshot},
 earlier_baseline_UTC='2016-10-10 inclusive through 2016-11-07 exclusive (before election)',
 earlier_review_count='Observed rated reviews in the same earlier four-week window, not lifetime count',
 missing_earlier_rating='Fill with pooled paired-sample median plus missing indicator; no rows dropped',earlier_rating_imputation_median=median,
 price='Categorical: $ reference; $$; $$$/$$$$ combined; Unknown. Only four $$$$ records in full paired cohort, collapsed before estimation.',
 service='Dine-in, takeout and delivery listed flags with a common service-record-unknown indicator; not-listed is not verified absence',
 alcohol='Listed alcohol/beer/wine/cocktails flag and offerings-record-unknown indicator',
 timing='Price/service/alcohol are undated metadata snapshots; full model is sensitivity, not confirmed pre-ban covariates.',
 sample='Same original paired shared-county sample for every specification; missingness indicators preserve all restaurants',
 direct_test='Pooled group x Trump interaction. Added control slopes also interact with Trump, so the direct coefficient equals the difference between the two separately adjusted subgroup contrasts.',
 inference='Original county-clustered CR1/nonnested correction; t df=counties-1; raw p')
(O/'design.json').write_text(json.dumps(design,indent=2));print(pd.DataFrame(coverage).to_string(index=False));print('Earlier rating pooled median:',median)
