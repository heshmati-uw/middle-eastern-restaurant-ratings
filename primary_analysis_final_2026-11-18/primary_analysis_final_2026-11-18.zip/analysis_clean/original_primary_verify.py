from pathlib import Path
import sys,json
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
from scipy.stats import t as td
O=H/'original_primary_county_fe';raw=pd.read_csv(O/'individual_reviews.csv');meta=pd.read_csv(O/'restaurants.csv',dtype={'county_fips':str})
assert raw.review_hash.is_unique and raw.rating.isin([1,2,3,4,5]).all()
wide=raw.groupby(['event','gmap_id','period']).rating.agg(['mean','size']).unstack('period');wide.columns=[('rating_' if a=='mean' else 'reviews_')+b for a,b in wide.columns];wide=wide.reset_index().merge(meta,on='gmap_id',validate='many_to_one')
wide=wide[wide.rating_pre.notna()&wide.rating_post.notna()&wide.county_fips.notna()&wide.gop_share.notna()].copy();wide['change']=wide.rating_post-wide.rating_pre;wide['vote10']=(wide.gop_share-.5)/.1
archive=pd.read_csv(O/'archived_restaurant_changes.csv',dtype={'county_fips':str})
r=pd.read_csv(O/'pairwise_results.csv');cp=pd.read_csv(O/'continuous_pairwise_results.csv');joint=pd.read_csv(O/'continuous_joint_results.csv')
def within(a,code):
 a=np.asarray(a,float);one=a.ndim==1
 if one:a=a[:,None]
 n=np.bincount(code);s=np.zeros((len(n),a.shape[1]));np.add.at(s,code,a);ans=a-s[code]/n[code,None]
 return ans[:,0] if one else ans
def estimate(v):
 names=list(v.columns[3:]);code=pd.factorize(v.county)[0];G=code.max()+1;X=within(v[names].to_numpy(),code);y=within(v.y.to_numpy(),code)
 B=np.linalg.lstsq(X,y,rcond=None)[0];u=y-X@B;bread=np.linalg.inv(X.T@X);S=np.zeros((G,len(B)));np.add.at(S,code,X*u[:,None]);K=len(B)+1
 V=bread@(S.T@S)@bread*G/(G-1)*(len(v)-1)/(len(v)-K)
 return B,V,G,K
checks=[]
for table,continuous in [(r,False),(cp,True)]:
 for row in table.itertuples(index=False):
  source=wide if continuous or row.source=='raw' else archive
  d=source[source.event.eq(row.event)].copy();d['position']=d['group_'+row.definition]
  first,second=row.pair.split(' versus ');d=d[d.position.isin([first,second])];sides=d.groupby('county_fips').position.nunique();d=d[d.county_fips.isin(sides[sides.eq(2)].index)]
  if not continuous and row.stratum!='direct':d=d[d.trump.eq(int(row.stratum=='Trump'))]
  v=pd.read_csv(O/f'verify_{row.id}.csv.gz',dtype={'county':str});assert v.id.is_unique and set(v.id)==set(d.gmap_id)
  z=d.set_index('gmap_id').loc[v.id];np.testing.assert_allclose(v.y,z.change,atol=1e-12);assert np.array_equal(v.county,z.county_fips)
  np.testing.assert_array_equal(v.treated,z.position.eq(first).astype(int))
  if continuous:np.testing.assert_allclose(v.vote_interaction,v.treated*z.vote10.to_numpy(),atol=1e-12)
  elif row.stratum=='direct':np.testing.assert_allclose(v.interaction,v.treated*z.trump.to_numpy(),atol=1e-12)
  B,V,G,K=estimate(v);assert len(v)==row.restaurants and G==row.counties and K==row.df_K
  beta=B[-1];se=np.sqrt(V[-1,-1]);p=2*td.sf(abs(beta/se),G-1);ci=beta+np.array([-1,1])*td.ppf(.975,G-1)*se
  np.testing.assert_allclose([beta,se,p,*ci],[row.estimate,row.se,row.p,row.low,row.high],atol=1e-9,rtol=1e-7)
  checks.append(dict(id=row.id,passed=True))
for mid,q in joint.groupby('id'):
 first=q.iloc[0];v=pd.read_csv(O/f'verify_{mid}.csv.gz',dtype={'county':str});d=wide[wide.event.eq(first.event)&wide['group_'+first.definition].isin(['ME','WPME','MED'])].set_index('gmap_id').loc[v.id]
 assert set(v.id)==set(d.index) and v.id.is_unique
 np.testing.assert_allclose(v.y,d.change,atol=1e-12)
 B,V,G,K=estimate(v);names=list(v.columns[3:]);R=pd.read_csv(O/f'coef_{mid}.csv').set_index('term').loc[names,'estimate'].to_numpy();RV=pd.read_csv(O/f'cov_{mid}.csv',index_col=0).loc[names,names].to_numpy()
 np.testing.assert_allclose(B,R,atol=1e-9);np.testing.assert_allclose(V,RV,atol=1e-9)
 for row in q.itertuples(index=False):
  terms={'WPME versus ME':{'WPME_vote':1,'ME_vote':-1},'WPME versus MED':{'WPME_vote':1},'ME versus MED':{'ME_vote':1}}[row.pair];L=np.array([terms.get(c,0) for c in names]);b=float(L@B);se=float(np.sqrt(L@V@L));p=float(2*td.sf(abs(b/se),G-1));np.testing.assert_allclose([b,se,p],[row.estimate,row.se,row.p],atol=1e-9)
 checks.append(dict(id=mid,passed=True))
for (source,definition,event,pair),q in r.groupby(['source','definition','event','pair']):
 q=q.set_index('stratum');assert abs(q.loc['Trump','estimate']-q.loc['nonTrump','estimate']-q.loc['direct','estimate'])<1e-9
old=pd.read_csv(H/'county_fe_regressions/four_week_county_fe_results.csv');direct=pd.read_csv(H/'county_fe_regressions/four_week_county_fe_direct_tests.csv')
for row in r[r.source.eq('archive')].itertuples(index=False):
 pair=row.pair.replace(' versus ',' vs ')
 if row.stratum=='direct':z=direct[(direct.definition=='legacy_baba')&(direct.shock==row.event)&(direct.comparison==pair)&direct.specification.eq('County FE, shared counties')]
 else:z=old[(old.definition=='legacy_baba')&(old.shock==row.event)&(old.comparison==pair)&old.specification.eq('County FE, shared counties')&old.trump.eq(int(row.stratum=='Trump'))]
 assert len(z)==1;np.testing.assert_allclose([row.estimate,row.se,row.p],z[['estimate','se','p']].iloc[0],atol=1e-9)
design=json.loads((O/'design.json').read_text())
for event,periods in design['windows_utc_end_exclusive'].items():
 for period,(a,b) in periods.items():
  z=raw[raw.event.eq(event)&raw.period.eq(period)];aa=pd.Timestamp(a,tz='UTC').timestamp()*1000;bb=pd.Timestamp(b,tz='UTC').timestamp()*1000;assert z.time.ge(aa).all() and z.time.lt(bb).all()
prev=pd.read_csv(H/'hummus_baba_restore/individual_reviews.csv');target=set(meta.gmap_id);priorids=set(pd.read_csv(H/'hummus_baba_restore/restaurants.csv').gmap_id)
assert set(prev.loc[prev.gmap_id.isin(target),'review_hash'])==set(raw.loc[raw.gmap_id.isin(priorids),'review_hash'])
out=dict(all_passed=True,fits_checked=len(checks),checks=checks,archived_fits_exactly_reproduced=18,raw_period_means_reconstructed=True,county_CR1_nonnested_correction_verified=True,direct_coefficients_equal_split_difference=True,source_overlap_review_hashes_match=True,outcome_windows_verified=True,method='Independent NumPy within-county OLS and cluster covariance; SciPy t tests')
(O/'verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
