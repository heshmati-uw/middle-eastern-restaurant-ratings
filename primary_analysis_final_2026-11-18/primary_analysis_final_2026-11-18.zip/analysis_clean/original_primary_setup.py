"""Restore the exact original primary-category frame and restaurant-level estimator."""
from pathlib import Path
import csv,json,hashlib
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'original_primary_county_fe';O.mkdir(exist_ok=True)
cfg=json.loads((H/'config.json').read_text());cats=set(cfg['me_categories']);records=[]
with (H/'positioning_restart/metadata_food_businesses.csv').open(newline='',encoding='utf-8') as f:
 for r in csv.DictReader(f):
  if r['primary_category'] in cats or r['primary_category']=='Mediterranean restaurant':records.append(r)
b=pd.DataFrame(records)
archived=pd.read_csv(H/'expanded_positioning/metadata_with_geography.csv',dtype={'county_fips':str})
frame=archived[archived.primary_category.isin(cats|{'Mediterranean restaurant'})]
assert len(b)==8669 and set(b.gmap_id)==set(frame.gmap_id)
cmp=b[['gmap_id','primary_category']].merge(frame[['gmap_id','primary_category']],on='gmap_id',suffixes=('_new','_old'),validate='one_to_one')
assert cmp.primary_category_new.eq(cmp.primary_category_old).all()
f=pd.read_csv(H/'hummus_baba_restore/pre_election_food_flags.csv')
b=b.merge(f,on='gmap_id',how='left',validate='one_to_one')
for col in ['pre_searchable_text','baba','hummus','pre_text']:b[col]=b[col].fillna(False).astype(bool)
me=b.primary_category.isin(cats)
for definition,tag in [('hummus_or_baba',b.baba|b.hummus),('baba_only',b.baba)]:
 b['group_'+definition]='Unknown';b.loc[me,'group_'+definition]='ME';eligible=~me&b.pre_searchable_text
 b.loc[eligible&tag,'group_'+definition]='WPME';b.loc[eligible&~tag,'group_'+definition]='MED'
assign=pd.read_csv(H/'expanded_positioning/expanded_group_assignments.csv',dtype={'county_fips':str})
legacy=assign[assign.definition.eq('legacy_baba')][['gmap_id','group']].rename(columns={'group':'group_legacy_baba'})
b=b.merge(legacy,on='gmap_id',how='left',validate='one_to_one');assert b.group_legacy_baba.notna().all()
b['latitude']=pd.to_numeric(b.latitude,errors='coerce');b['longitude']=pd.to_numeric(b.longitude,errors='coerce')
ns={'__file__':str(H/'prepare_expanded_positioning.py')}
exec(compile((H/'prepare_expanded_positioning.py').read_text().split('def tags(meta):')[0],str(H/'prepare_expanded_positioning.py'),'exec'),ns)
b=ns['geography'](b.reset_index(drop=True));b.to_csv(O/'restaurants.csv',index=False)
population=[]
for definition in ['hummus_or_baba','baba_only','legacy_baba']:
 for group,g in b.groupby('group_'+definition):population.append(dict(definition=definition,group=group,restaurants=len(g),county_linked=int(g.gop_share.notna().sum())))
pd.DataFrame(population).to_csv(O/'population_counts.csv',index=False)
windows=json.loads((H/'hummus_baba_restore/design.json').read_text())['windows_utc_end_exclusive']
design=dict(primary_dictionary='hummus_or_baba',sensitivity='baba_only',legacy_diagnostic='legacy_baba: exact archived group assignments; can use post-event tags, not a predetermined definition',
 primary_categories=cfg['me_categories'],ME='Primary category is in the original 20-category ME list, including Halal/Kebab/Shawarma. Ignore names and secondary categories.',
 Mediterranean='Primary category exactly Mediterranean restaurant; secondary ME categories and names do not override it.',
 WPME='Primary Mediterranean plus pre-election food tag',MED='Primary Mediterranean, searchable pre-election text, no matching tag',Unknown='No searchable pre-election text; excluded from predetermined analyses',
 population='Original primary-category restaurant frame: 3227 ME + 5442 Mediterranean; IDs and categories checked against archived metadata.',
 unit='One restaurant, with one pre and one post mean formed from all rated raw reviews. Equal restaurant weight; both observed means required to form a change.',
 estimator='Restaurant mean rating change regressed on group indicators with county FE. Historical pairwise analyses use shared counties; joint continuous-share analyses use one common three-group sample.',
 inference='County-clustered CR1; original fixest nonnested FE correction: K=number of non-FE coefficients+1, because county FE are nested in county clusters; t df=counties-1.',
 windows_utc_end_exclusive=windows,cutoff_exclusive_utc='2016-11-08T00:00:00Z',matching=False,
 rating_aggregation='All valid review ratings, regardless of text/food mention; no weighting across restaurants by review count.',
 historical_replication='Also re-estimate archived legacy tags with archived period summaries to verify old result. Fresh raw-source summaries remain the main outcome source.')
(O/'design.json').write_text(json.dumps(design,indent=2))
s=(H/'restore_hummus_baba_scan.py').read_text().replace("BASE=H/'hummus_baba_restore'","BASE=H/'original_primary_county_fe'")
(H/'original_primary_scan.py').write_text(s)
# Preserve source mismatch audit; do not treat older aggregates as raw-equivalent.
r=pd.read_csv(H/'hummus_baba_restore/individual_reviews.csv');audit=[]
for event in ['Election','Ban']:
 z=r[r.event.eq(event)].groupby(['gmap_id','period']).rating.agg(['mean','size']).unstack()
 old=pd.read_csv(H/f'full_pre_election_core/inputs/periods_{event.lower()}_4w.csv').set_index('gmap_id');shared=z.index.intersection(old.index)
 for period in ['pre','post']:
  err=(z.loc[shared,('mean',period)]-old.loc[shared,'rating_'+period]).abs();count=z.loc[shared,('size',period)]-old.loc[shared,'reviews_'+period]
  audit.append(dict(event=event,period=period,overlapping_restaurants=len(shared),mean_mismatches=int(err.gt(1e-10).sum()),review_count_mismatches=int(count.fillna(0).ne(0).sum()),max_mean_difference=err.max()))
pd.DataFrame(audit).to_csv(O/'old_vs_raw_outcome_audit.csv',index=False)
(O/'frame_verification.json').write_text(json.dumps(dict(original_frame_IDs_exact_match=True,original_primary_categories_exact_match=True,primary_ME=int(me.sum()),primary_MED=int((~me).sum()),source='Fresh raw metadata restaurant census checked against original archived frame'),indent=2))
print(pd.DataFrame(population).to_string(index=False))
