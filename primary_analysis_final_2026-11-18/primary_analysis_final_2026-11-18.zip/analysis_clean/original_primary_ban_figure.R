args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'original_primary_county_fe')
means<-read.csv(file.path(o,'descriptive_pre_post_means.csv'));means<-means[means$event=='Ban'&means$pair=='WPME versus ME',]
r<-read.csv(file.path(o,'pairwise_results.csv'));r<-r[r$source=='raw'&r$definition=='hummus_or_baba'&r$event=='Ban'&r$pair=='WPME versus ME',]
write.csv(means,file.path(o,'ban_figure_data.csv'),row.names=FALSE)
draw<-function(){
 par(mfrow=c(1,2),mar=c(5,5,5,1.3),oma=c(6.5,0,4,0),family='sans',las=1)
 colors<-c(ME='#B44E43',WPME='#176F91')
 for(trump in c(1,0)){
  z<-means[means$trump==trump,];q<-r[r$stratum==ifelse(trump==1,'Trump','nonTrump'),]
  plot(c(.8,2.2),c(4.26,4.65),type='n',axes=FALSE,xlab='',ylab='',main=ifelse(trump==1,'Trump-majority counties','Non-Trump-majority counties'),cex.main=1.2)
  abline(h=seq(4.3,4.6,.1),col='#E4E9EC',lwd=1)
  axis(2,at=seq(4.3,4.6,.1),cex.axis=.95,col='#8C999F',col.axis='#34454C')
  axis(1,at=1:2,labels=c('Before ban','After ban'),tick=FALSE,line=.3,cex.axis=1.05)
  mtext('Mean restaurant rating (stars)',side=2,line=3.5,las=0,cex=.95)
  box(bty='l',col='#8C999F')
  leg<-c()
  for(j in 1:2){
   group<-c('ME','WPME')[j];a<-z[z$group==group,];other<-z[z$group!=group,]
   y<-c(a$mean_pre,a$mean_post);other_y<-c(other$mean_pre,other$mean_post)
   lines(1:2,y,type='o',col=colors[group],lwd=3.3,pch=c(15,16)[j],cex=1.2,lty=c(1,2)[j])
   text(1:2,y,sprintf('%.3f',y),pos=ifelse(y>=other_y,3,1),offset=.6,cex=.94,col=colors[group])
   leg<-c(leg,sprintf('%s: %s restaurants | %s / %s reviews',group,format(a$restaurants,big.mark=','),format(a$reviews_pre,big.mark=','),format(a$reviews_post,big.mark=',')))
  }
  legend('topleft',legend=leg,col=colors,lty=c(1,2),pch=c(15,16),lwd=2.4,bty='n',cex=.76,inset=c(.01,.01))
  mtext(sprintf('County-FE WPME-ME change: %+.3f%s | p=%.3f',q$estimate,ifelse(is.na(q$symbol),'',q$symbol),q$p),side=3,line=.35,cex=.91,col='#34454C')
 }
 direct<-r[r$stratum=='direct',]
 mtext('Ratings around the January 2017 travel ban',side=3,outer=TRUE,line=2,font=2,cex=1.35)
 mtext('Original primary-category rules | Pre-election hummus OR baba tags | Equal restaurant weights',side=3,outer=TRUE,line=.5,cex=.95,col='#52656F')
 mtext(sprintf('Direct difference between county types: %+.3f stars*  |  p=%.3f',direct$estimate,direct$p),side=1,outer=TRUE,line=1,font=2,cex=1.04,col='#1F454F')
 mtext('Lines show unadjusted means for the same paired restaurants. Tests compare county-FE-adjusted changes; they do not test each line separately.',side=1,outer=TRUE,line=2.7,cex=.77,col='#52656F')
 mtext('Before: Dec 26-Jan 22. After: Jan 30-Feb 26. Pair-specific shared counties; all rated reviews form each restaurant-period mean.',side=1,outer=TRUE,line=4,cex=.8,col='#52656F')
 mtext('* p<.05, county-clustered. Descriptive associations, not causal effects. WPME = primary Mediterranean plus a pre-election food mention.',side=1,outer=TRUE,line=5.3,cex=.76,col='#52656F')
}
png(file.path(o,'ban_ME_WPME_figure.png'),width=1900,height=1050,res=175);draw();dev.off()
pdf(file.path(o,'ban_ME_WPME_figure.pdf'),width=11,height=6.2,useDingbats=FALSE);draw();dev.off()
