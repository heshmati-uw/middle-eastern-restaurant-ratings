from pathlib import Path
import pandas as pd,json
H=Path(__file__).resolve().parent;O=H/'original_primary_county_fe'
r=pd.read_csv(O/'individual_reviews.csv');b=pd.read_csv(O/'restaurants.csv',dtype={'county_fips':str})
assert r.review_hash.is_unique and r.rating.isin([1,2,3,4,5]).all()
p=r.groupby(['event','gmap_id','period']).rating.agg(['mean','size']).unstack('period')
p.columns=[('rating_' if stat=='mean' else 'reviews_')+period for stat,period in p.columns]
p=p.reset_index().merge(b,on='gmap_id',validate='many_to_one')
p['paired']=p.rating_pre.notna()&p.rating_post.notna();p['county_valid']=p.county_fips.notna()&p.gop_share.notna()
p['change']=p.rating_post-p.rating_pre;p['trump']=p.gop_share.gt(.5).astype(int);p['vote10']=(p.gop_share-.5)/.1
p.to_csv(O/'all_restaurant_periods.csv',index=False)
d=p[p.paired&p.county_valid].copy();d.to_csv(O/'restaurant_changes.csv',index=False)
rows=[]
for definition in ['hummus_or_baba','baba_only','legacy_baba']:
 for (event,group),g in d.groupby(['event','group_'+definition]):
  if group not in ['ME','WPME','MED']:continue
  rows.append(dict(definition=definition,event=event,group=group,restaurants=len(g),reviews_pre=int(g.reviews_pre.sum()),reviews_post=int(g.reviews_post.sum()),counties=g.county_fips.nunique(),mean_pre=g.rating_pre.mean(),mean_post=g.rating_post.mean(),mean_change=g.change.mean()))
pd.DataFrame(rows).to_csv(O/'paired_sample_counts.csv',index=False)
# Exact archive replication uses the same saved inputs as the original R script.
S=H/'county_fe_regressions/inputs'
if not S.exists():S=H/'expanded_positioning'
a=pd.read_csv(S/'expanded_group_assignments.csv',dtype={'county_fips':str});a=a[a.definition.eq('legacy_baba')&a.group.isin(['ME','WPME','MED'])&a.gop_share.notna()]
out=[]
for event in ['Election','Ban']:
 old=pd.read_csv(S/f'periods_{event.lower()}_4w.csv').merge(a,on='gmap_id',validate='one_to_one')
 old['event']=event;old['group_legacy_baba']=old.group;out.append(old)
pd.concat(out,ignore_index=True).to_csv(O/'archived_restaurant_changes.csv',index=False)
(O/'sample_audit.json').write_text(json.dumps(dict(raw_outcome_reviews=len(r),outcome_restaurants=r.gmap_id.nunique(),restaurant_event_rows=len(p),paired_county_linked_rows=len(d),one_period_rows=int((~p.paired).sum()),missing_geography_rows=int((~p.county_valid).sum()),unit='One paired restaurant per event, unit weight',before_after_pair_required=True,matching=False,outcome_text_filter=False,archived_input_directory=str(S)),indent=2))
print(pd.DataFrame(rows).to_string(index=False))
