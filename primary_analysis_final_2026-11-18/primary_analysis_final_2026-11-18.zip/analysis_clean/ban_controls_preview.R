args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()));suppressPackageStartupMessages(library(fixest));setFixest_nthreads(1)
o<-file.path(h,'original_primary_county_fe/controls_preview');all<-read.csv(file.path(o,'analysis_data.csv'),colClasses=c(county_fips='character'))
history<-c('rating_control','rating_missing','log_earlier_reviews')
snapshot<-c('price_two','price_high','price_unknown','dine_in_listed','takeout_listed','delivery_listed','service_unknown','alcohol_listed','alcohol_unknown')
specs<-list(baseline=character(),history=history,full_snapshot=c(history,snapshot));ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
results<-list();coefficients<-list()
for(pair in c('WPME versus ME','WPME versus MED','ME versus MED')){
 members<-strsplit(pair,' versus ',fixed=TRUE)[[1]];q<-all[all$group_hummus_or_baba%in%members,];q$treated<-as.integer(q$group_hummus_or_baba==members[1]);sides<-tapply(q$treated,q$county_fips,function(x)length(unique(x)));shared<-names(sides)[sides==2];q<-q[q$county_fips%in%shared,]
 for(stratum in c('nonTrump','Trump','direct'))for(spec in names(specs)){
  d<-if(stratum=='direct')q else q[q$trump==as.integer(stratum=='Trump'),]
  covs<-specs[[spec]];terms<-c('treated',covs);target<-'treated'
  if(stratum=='direct'){
   d$interaction<-d$treated*d$trump;target<-'interaction'
   for(cov in covs)d[[paste0(cov,'_T')]]<-d[[cov]]*d$trump
   terms<-c('treated','interaction',covs,paste0(covs,'_T'))
  }
  # paste0(character(), suffix) can create a suffix-only string in R.
  if(stratum=='direct'&&!length(covs))terms<-c('treated','interaction')
  fit<-feols(as.formula(paste('change~',paste(terms,collapse='+'),'|county_fips')),data=d,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  stopifnot(nobs(fit)==nrow(d));B<-coef(fit);V<-vcov(fit,attr=TRUE);G<-length(unique(d$county_fips));K<-attr(V,'df.K')
  rawX<-as.matrix(d[,terms,drop=FALSE]);fullX<-demean(rawX,f=list(factor(d$county_fips)),tol=1e-12,nthreads=1);colnames(fullX)<-terms
  keep<-names(B);omitted<-setdiff(terms,keep);estimable<-target%in%keep
  if(estimable&&length(omitted)){
   X<-fullX[,keep,drop=FALSE];A<-solve(crossprod(X),crossprod(X,fullX[,omitted,drop=FALSE]));L<-setNames(rep(0,length(B)),keep);L[target]<-1
   estimable<-max(abs(as.numeric(t(L)%*%A)))<1e-7
  }
  ct<-if(estimable)coeftable(fit)[target,] else rep(NA_real_,4);ci<-if(estimable)as.matrix(confint(fit))[target,] else c(NA,NA)
  id<-paste(gsub(' ','_',pair),stratum,spec,sep='__')
  results[[length(results)+1]]<-data.frame(id=id,pair=pair,stratum=stratum,specification=spec,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),first_restaurants=sum(d$treated),second_restaurants=sum(1-d$treated),counties=G,df_K=K,estimable=estimable,omitted=paste(omitted,collapse='; '))
  for(term in names(B))coefficients[[length(coefficients)+1]]<-data.frame(id=id,term=term,estimate=B[term],se=sqrt(V[term,term]))
  con<-gzfile(file.path(o,paste0('verify_',id,'.csv.gz')),'wt');write.csv(data.frame(id=d$gmap_id,county=d$county_fips,y=d$change,rawX,check.names=FALSE),con,row.names=FALSE);close(con)
  write.csv(V,file.path(o,paste0('cov_',id,'.csv')))
 }
}
r<-do.call(rbind,results);r$symbol<-ifelse(is.na(r$p),'',ifelse(r$p<.001,'***',ifelse(r$p<.01,'**',ifelse(r$p<.05,'*',ifelse(r$p<.1,'+','')))))
write.csv(r,file.path(o,'results.csv'),row.names=FALSE);write.csv(do.call(rbind,coefficients),file.path(o,'coefficients.csv'),row.names=FALSE)
print(r[r$pair=='WPME versus ME',])
