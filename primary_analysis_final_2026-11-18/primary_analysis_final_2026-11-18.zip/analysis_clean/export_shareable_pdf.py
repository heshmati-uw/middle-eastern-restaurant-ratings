from pathlib import Path
from html.parser import HTMLParser
from html import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
O=ROOT/'analysis_clean/original_primary_county_fe'
class Node:
 def __init__(self,tag='',attrs=()): self.tag=tag;self.attrs=dict(attrs);self.children=[]
 def all(self,tag):
  return [x for c in self.children if isinstance(c,Node) for x in ([c] if c.tag==tag else [])+c.all(tag)]
 def text(self):return ''.join(c.text() if isinstance(c,Node) else c for c in self.children)
 def rich(self):
  t=''.join(c.rich() if isinstance(c,Node) else escape(c.replace('–','-').replace('—','-').replace('−','-')) for c in self.children)
  return '<b>'+t+'</b>' if self.tag=='strong' else '<br/>' if self.tag=='br' else t
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.root=Node();self.stack=[self.root]
 def handle_starttag(self,t,a):
  n=Node(t,a);self.stack[-1].children.append(n)
  if t not in ['meta','img','br','link','hr','input']:self.stack.append(n)
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==t:self.stack=self.stack[:i];break
 def handle_data(self,d):self.stack[-1].children.append(d)
p=Parser();p.feed((O/'regression_tables.html').read_text(encoding='utf-8'));root=p.root
for font,file in [('Arial','arial.ttf'),('Arial-Bold','arialbd.ttf')]:pdfmetrics.registerFont(TTFont(font,'C:/Windows/Fonts/'+file))
pdfmetrics.registerFontFamily('Arial',normal='Arial',bold='Arial-Bold',italic='Arial',boldItalic='Arial-Bold')
st=getSampleStyleSheet()
st.add(ParagraphStyle(name='BodyCustom',fontName='Arial',fontSize=9.2,leading=12.4,spaceAfter=7,textColor=colors.HexColor('#23343c')))
st.add(ParagraphStyle(name='TitleCustom',parent=st['BodyCustom'],fontName='Arial-Bold',fontSize=21,leading=26,spaceAfter=15))
st.add(ParagraphStyle(name='HeadingCustom',parent=st['BodyCustom'],fontName='Arial-Bold',fontSize=14,leading=18,spaceAfter=12))
st.add(ParagraphStyle(name='NoteCustom',parent=st['BodyCustom'],fontSize=8,leading=10.6,spaceAfter=6))
st.add(ParagraphStyle(name='CellCustom',parent=st['BodyCustom'],fontSize=8.3,leading=10.7,spaceAfter=0,alignment=TA_CENTER))
st.add(ParagraphStyle(name='LeftCell',parent=st['CellCustom'],alignment=0))
P=lambda t,style='BodyCustom':Paragraph(t,st[style])
story=[P('Restaurant positioning and ratings around the travel ban','TitleCustom'),P('Restaurant-level analysis | County fixed effects | November 18, 2026'),P('Original primary-category rules; pre-election hummus OR baba classification. Main regressions include all controls. This document reports correlational associations.'),Spacer(1,15),Image(str(O/'ban_ME_WPME_observed_all_controls_figure.png'),width=504,height=504*1050/1900),Spacer(1,15),P('<b>How to read the figure.</b> Lines show observed rating means for the same paired restaurants, with equal restaurant weights. The estimates and p values printed above the plots are all-controls, county-FE-adjusted relative changes. They do not test each group\'s change separately; plotted raw differences need not match adjusted contrasts.'),P('<b>Timing limitation.</b> Price and service attributes are undated metadata and are not confirmed to precede the ban. Earlier rating and activity controls are measured before the election.'),PageBreak(),P('Methods and sample','HeadingCustom')]
uls=root.all('ul')
for li in uls[0].all('li'):story.append(P(li.rich()))
notes=[x for x in root.all('p') if x.text().startswith('Interpretation:') or x.text().startswith('Inference:')]
tables=root.all('table');heads=[n.text() for n in root.all('h2') if n.text().startswith(('Panel ','Control checks.'))]
assert len(tables)==len(heads)==6

def add_table(n):
 rows=[]
 for tr in n.all('tr'):
  cells=[x for x in tr.children if isinstance(x,Node) and x.tag in ('th','td')]
  rows.append([P(c.rich(),'LeftCell' if i==0 else 'CellCustom') for i,c in enumerate(cells)])
 t=Table(rows,colWidths=[180,108,108,108],repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eef4f5')),('LINEBELOW',(0,0),(-1,0),.8,colors.HexColor('#a7babc')),('LINEBELOW',(0,1),(-1,-1),.4,colors.HexColor('#d9e2e4')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
 story.append(t)
for i in range(3):
 story.extend([PageBreak(),P(heads[i],'HeadingCustom'),P('Main specification: all controls included. Outcome: after-minus-before mean rating, in stars.','NoteCustom')]);add_table(tables[i]);story.append(Spacer(1,10))
 story.append(P('County-clustered standard errors in parentheses; raw two-sided p values below coefficients. + p&lt;.10, * p&lt;.05, ** p&lt;.01, *** p&lt;.001. Each restaurant receives equal weight.','NoteCustom'))
 story.append(P('Pooled column: the positioning indicator is the non-Trump contrast; its interaction with Trump-majority status is the direct difference between county types. All added control slopes also interact with Trump-majority status. The Trump-majority main effect is absorbed by county fixed effects.','NoteCustom'))
story.extend([PageBreak(),P('Control checks: specifications and interpretation','HeadingCustom')])
for li in uls[1].all('li'):story.append(P(li.rich()))
for n in root.all('p'):
 if n.text().startswith('What changes with controls?'):story.append(P(n.rich()))
for i in range(3,6):
 story.extend([PageBreak(),P(heads[i],'HeadingCustom'),P('Same restaurant sample across the no-controls, earlier-controls, and all-controls specifications.','NoteCustom')]);add_table(tables[i]);story.append(Spacer(1,10));story.append(P('Cells show estimates in rating stars, county-clustered standard errors, and raw p values. + p&lt;.10, * p&lt;.05, ** p&lt;.01, *** p&lt;.001. A positive contrast means the first group improved relative to the second. These are correlational comparisons.','NoteCustom'))
path=ROOT/'output/pdf/restaurant_positioning_ban_results.pdf'
def footer(canvas,doc):
 canvas.saveState();canvas.setFont('Arial',8);canvas.setFillColor(colors.HexColor('#60727a'));canvas.drawString(54,28,'Restaurant positioning | Ban-period results | November 18, 2026');canvas.drawRightString(558,28,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(path),pagesize=(612,792),rightMargin=54,leftMargin=54,topMargin=43,bottomMargin=48,title='Restaurant positioning: ban-period results',author='Restaurant positioning project')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
r=PdfReader(str(path));print('Pages:',len(r.pages))
for i,page in enumerate(r.pages):print(i+1,len(page.extract_text()),page.extract_text()[:80].replace('\n',' | '))
assert len(r.pages)==9,len(r.pages)
assert all(x in ''.join(pg.extract_text() for pg in r.pages) for x in ['0.0256','0.0090','Missing-data indicators','Controls × Trump-majority'])
