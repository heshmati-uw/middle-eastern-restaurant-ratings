# Original primary categories, equal restaurant weights, county FE

The user requested the original primary-category rules and restaurant-level county-FE estimator. This branch supersedes the preceding any-explicit-label/review-weighted analysis as the current requested specification; previous branches are preserved.

ME uses the original 20 primary-category list in `design.json`, including Halal/Kebab/Shawarma. Primary Mediterranean remains Mediterranean regardless of names or secondary categories. The 8,669-ID frame and every primary-category value exactly match the archived frame: 3,227 ME + 5,442 Mediterranean.

Main WPME rule: pre-election hummus OR baba mention. Baba-only is a sensitivity. MED requires searchable pre-election text and no matching tag; missing text is unknown. Legacy baba tags are an archival diagnostic and may use post-event information. Food flags are proxies for offerings, not verified nationality/authenticity.

All rated raw outcome reviews form the period means, regardless of text or food words. Each restaurant contributes one observed pre/post mean change with weight one. Restaurants missing one period cannot form a change and remain in `all_restaurant_periods.csv` for attrition audit. There is no matching or review-count threshold.

Original split model: restaurant change = county FE + first-group indicator. Pooled direct model adds first-group × Trump-majority; the county-type main effect is absorbed by county FE. Each pair uses shared counties containing both groups, as the original archived analysis did. These supports differ across pairs. Continuous-share pairwise tests use exactly the same shared-county cohort. Joint continuous models put all three groups into one common classified paired sample.

The original CR1 inference convention is retained: county FE nested in county clusters are not counted again in the small-sample correction. K is the number of non-FE coefficients plus one; t df=counties−1. This differs from the full-FE correction used in the preceding review-level branch. Restaurant intercepts are removed by differencing; separate restaurant FE dummies are not estimated in the one-row-per-business model. Additional price/service/baseline-rating controls are not included.

Timing: election Oct10–Nov6 vs Nov14–Dec11, 2016; ban Dec26–Jan22 vs Jan30–Feb26, 2017 (UTC). Mixed event weeks omitted, no further holiday exclusions.

## Reproduce from the project root

1. `analysis_clean/original_primary_setup.py`: build/check original frame and group assignments; retain exact archive mapping for diagnostic.
2. `analysis_clean/original_primary_scan.py`: resumable extraction from all 52 raw review archives for all 8,669 IDs and both events.
3. `analysis_clean/original_primary_prepare.py`: create period means, paired changes and exact archived-input replication data.
4. `analysis_clean/original_primary_models.R`: pairwise split/direct tests, same-support continuous tests, and common-sample continuous models; reproduce 18 archived fits exactly.
5. `analysis_clean/original_primary_verify.py`: independently reconstruct raw means and verify all 96 fits using NumPy/SciPy within-county OLS and clustered covariance.
6. `analysis_clean/original_primary_tables.py`: regression tables with all coefficients, SEs, p values, FE/controls rows, weights, sample criteria and counts.
7. `analysis_clean/original_primary_plots.R`: equal-restaurant descriptive before/after figures on each pair's exact shared cohort.
8. `analysis_clean/original_primary_report.py`: analysis report and current project-document update.

Use the installed R workspace library `.r-library`. Set `OPENBLAS_NUM_THREADS=1` and `OMP_NUM_THREADS=1` for Python numeric steps; supplementary packages are in `.analysis-python`.

The requested main ban/Trump shared-county gap is +0.281, p=.029 (124 WPME / 90 ME restaurants; 36 counties); the direct difference is +0.337, p=.011. Its same-cohort linear continuous-share gradient remains unclear (p=.535). These are different functional-form tests, and the split result does not establish a monotonic political gradient or a causal effect. All raw/archived and dictionary sensitivities are preserved.
