"""Publication-style tables of the already estimated original-specification models."""
from pathlib import Path
import sys,json
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
from scipy.stats import t as td
O=H/'original_primary_county_fe';r=pd.read_csv(O/'pairwise_results.csv');cr=pd.read_csv(O/'controls_preview/results.csv');jinfo=pd.read_csv(O/'joint_model_info.csv')
assert json.loads((O/'verification.json').read_text())['all_passed']
def stars(p):return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else '+' if p<.1 else ''
def pv(p):return '&lt;.001' if p<.001 else f'{p:.4f}'
def fit(mid):
 folder=O/"controls_preview"
 v=pd.read_csv(folder/f'verify_{mid}.csv.gz',dtype={'county':str});names=pd.read_csv(folder/'coefficients.csv').query('id == @mid').term.tolist();code=pd.factorize(v.county)[0];G=code.max()+1;n=len(v)
 M=np.column_stack([v.y,v[names]]).astype(float);s=np.zeros((G,M.shape[1]));np.add.at(s,code,M);M-=s[code]/np.bincount(code)[code,None]
 y=M[:,0];X=M[:,1:];B=np.linalg.lstsq(X,y,rcond=None)[0];u=y-X@B;A=np.linalg.inv(X.T@X);S=np.zeros((G,len(B)));np.add.at(S,code,X*u[:,None]);V=A@(S.T@S)@A*G/(G-1)*(n-1)/(n-len(B)-1)
 p=2*td.sf(abs(B/np.sqrt(np.diag(V))),G-1)
 return names,B,V,p,1-float(u@u)/float(y@y)
def cell(b,se,p):return f'<strong>{b:+.3f}{stars(p)}</strong><br>({se:.3f})<br><small>p={pv(p)}</small>'
def table(header,rows):return '<table><thead><tr>'+''.join(f'<th>{x}</th>' for x in header)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table>'
cols=[('Ban','nonTrump'),('Ban','Trump'),('Ban','direct')]
labels=['(1)<br>Ban<br>Non-Trump','(2)<br>Ban<br>Trump','(3)<br>Ban<br>Pooled']
style='body{font:16px/1.5 system-ui,sans-serif;color:#23343c;max-width:1350px;margin:30px auto;padding:0 24px}h1,h2{color:#19484c}table{border-collapse:collapse;width:100%;table-layout:fixed;margin:20px 0;font-size:13px}th,td{padding:10px 7px;border-bottom:1px solid #dae2e4;text-align:center;vertical-align:top}th:first-child,td:first-child{text-align:left;width:225px}th{background:#eef4f5}small{color:#52636c}h2{margin-top:40px}.note{background:#f0f6f5;padding:16px}a{color:#12647c}@media print{body{font-size:10px;max-width:none}table{font-size:9px}h2{break-before:page}}'
parts=[f'<!doctype html><html lang="en"><meta charset="utf-8"><title>Ban-only restaurant-level county-FE regression tables</title><style>{style}.methods{{max-width:1150px;padding-left:25px}}.methods li{{margin:11px 0}}</style><body><h1>Ban-only restaurant-level regressions: original primary-category rules</h1><p>November 18, 2026 · All-controls primary specification · Hummus OR baba, strictly pre-election tags · <a href="analysis_report.html">Archived full analysis and figures</a></p>']
if (O/'ban_ME_WPME_observed_all_controls_figure.png').exists():
 parts.append('<img style="width:100%;height:auto" src="ban_ME_WPME_observed_all_controls_figure.png" alt="Separate ME and WPME before-after lines in Trump and non-Trump counties"><p><a href="ban_ME_WPME_observed_all_controls_figure.pdf">Download figure as PDF</a> · <a href="ban_observed_all_controls_figure_data.csv">Plotted restaurant means and counts</a></p>')
parts.append('''<h2>Methods</h2><ul class="methods">
<li><strong>Data:</strong> Google reviews from all 52 raw state archives. All valid rated reviews in the outcome windows are used, including reviews without text or food mentions.</li>
<li><strong>Groups:</strong> ME = primary category in the <a href="design.json">original 20-category ME list</a>. WPME = primary Mediterranean with a pre-election hummus or baba-ghanoush mention. MED = primary Mediterranean with searchable pre-election review text but no such mention. Names and secondary categories do not override the primary category. Restaurants without searchable pre-election text are excluded from the Mediterranean comparison frame; no observed mention does not prove the food is absent.</li>
<li><strong>Classification cutoff:</strong> food tags use reviews strictly before November 8, 2016 (UTC). This cutoff applies to classification only; ratings after the election and ban remain eligible outcomes.</li>
<li><strong>Ban windows:</strong> before = December 26, 2016–January 22, 2017; after = January 30–February 26, 2017 (UTC). Each window is four weeks. The mixed ban week is omitted, with no additional holiday exclusions.</li>
<li><strong>Outcome and weighting:</strong> first average all ratings within each restaurant-period, then subtract the before mean from the after mean. Each restaurant contributes one change observation and receives weight one, regardless of review volume.</li>
<li><strong>Eligible sample:</strong> restaurants must have rated reviews in both periods and usable county/vote data. Each pairwise regression uses counties containing both comparison groups. Samples therefore differ across Panels A–C. No restaurant or distance matching is used.</li>
<li><strong>Political context:</strong> Trump-majority counties have more than 50% of all-candidate 2016 presidential votes for Trump. Models are run separately by county type; pooled models add a group-by-Trump-majority interaction to test the difference between county types directly.</li>
<li><strong>Fixed effects and controls:</strong> all models include county fixed effects, absorbing common county-level rating changes. Stable restaurant intercepts are removed by differencing; separate restaurant FE dummies are not estimated. Panels A–C control for the earlier mean rating and log(1 + review count), price-tier indicators, and indicators for listed dine-in, takeout, delivery, and alcohol service. Missing-data indicators retain restaurants with incomplete records; an unlisted service is not a verified absence. In pooled models, all controls also interact with Trump-majority status. Earlier ratings/activity use October 10–November 6, 2016. Price and service attributes come from undated metadata and are not confirmed to precede the ban. The control checks compare no controls, earlier controls, and all controls on identical samples. The county-level Trump main effect is absorbed by county FE.</li>
<li><strong>Inference:</strong> county-clustered CR1 standard errors use the original nonnested-FE correction and t degrees of freedom equal to counties minus one. Parentheses show clustered SEs; p values are raw and two-sided. Symbols: + p&lt;.10, * p&lt;.05, ** p&lt;.01, *** p&lt;.001.</li>
<li><strong>Reading the figure:</strong> lines show observed pre/post rating means, with equal restaurant weights and the same paired restaurants in both periods. The printed estimates and p values come from the all-controls county-FE models and test relative changes, not each line separately. The observed gaps between lines need not equal the adjusted regression contrasts. The results are correlational associations.</li>
</ul>''')
flat=[];main_html='';appendix=[]
for k,pair in enumerate(['WPME versus ME','WPME versus MED','ME versus MED']):
 first,second=pair.split(' versus ');selected=[]
 for event,stratum in cols:
  row=r[(r.source=='raw')&(r.definition=='hummus_or_baba')&(r.event==event)&(r.pair==pair)&(r.stratum==stratum)].iloc[0]
  mid=cr[(cr.pair==pair)&(cr.stratum==stratum)&(cr.specification=='full_snapshot')].iloc[0].id
  names,B,V,P,R2=fit(mid);selected.append((row,names,B,V,P,R2))
  for z,name in enumerate(names):flat.append(dict(panel=pair,event=event,stratum=stratum,term=name,estimate=B[z],se=np.sqrt(V[z,z]),p=P[z],restaurants=int(row.restaurants),counties=int(row.counties),within_R2=R2,county_FE=True,restaurant_FE_dummies=False,stable_restaurant_effects='Differenced out',additional_covariates='Earlier ratings/activity + price/service/alcohol',weights='Equal restaurant'))
 rows=[]
 term_labels={'treated':f'{first} indicator (reference: {second})','interaction':f'{first} × Trump-majority','rating_control':'Earlier mean rating','rating_missing':'Earlier rating missing','log_earlier_reviews':'log(1 + earlier review count)','price_two':'Price: $$ (reference: $)','price_high':'Price: $$$ / $$$$','price_unknown':'Price unknown','dine_in_listed':'Dine-in listed','takeout_listed':'Takeout listed','delivery_listed':'Delivery listed','service_unknown':'Service record unknown','alcohol_listed':'Alcohol listed','alcohol_unknown':'Alcohol record unknown'}
 all_terms=list(term_labels)+[x+'_T' for x in list(term_labels)[2:]]
 for term in all_terms:
  label=term_labels.get(term,term_labels.get(term.removesuffix('_T'),term)+' × Trump-majority')
  values=[]
  for row,names,B,V,P,R2 in selected:
   if term in names:
    z=names.index(term); values.append(cell(B[z],np.sqrt(V[z,z]),P[z]))
   elif term=='interaction' or term.endswith('_T'): values.append('—' if row.stratum!='direct' else 'Omitted: collinear')
   else: values.append('Omitted: collinear')
  rows.append([label]+values)
 rows += [['County fixed effects']+['Yes']*3,
 ['Stable restaurant effects']+['Differenced out']*3,
 ['Controls']+['All listed controls']*3,
 ['Restaurant weights']+['Equal (1 each)']*3,
 ['Shared counties within pair']+['Yes']*3,
 ['Restaurants']+[f'{int(row.restaurants):,}' for row,*_ in selected],
 [f'{first} / {second} restaurants']+[f'{int(row.first_restaurants):,} / {int(row.second_restaurants):,}' for row,*_ in selected],
 ['County clusters']+[str(int(row.counties)) for row,*_ in selected],
 ['Underlying review records']+[f'{int(row.source_reviews_pre+row.source_reviews_post):,}' for row,*_ in selected],
 ['Within R²']+[f'{R2:.4f}' for row,names,B,V,P,R2 in selected]]
 appendix.append(f'<h2>Panel {chr(65+k)}. {pair}: complete coefficients</h2>'+table(['Regressor / specification']+labels,rows))
 compact=rows[:2]+[
 ['Earlier rating and review activity controls']+['Yes']*3,
 ['Price-tier controls']+['Yes']*3,
 ['Service and alcohol controls']+['Yes']*3,
 ['Controls × Trump-majority','—','—','Yes'],
 ['County fixed effects']+['Yes']*3,
 ['Restaurant weights']+['Equal']*3,
 ['Restaurants']+[f'{int(row.restaurants):,}' for row,*_ in selected],
 [f'{first} / {second} restaurants']+[f'{int(row.first_restaurants):,} / {int(row.second_restaurants):,}' for row,*_ in selected],
 ['County clusters']+[str(int(row.counties)) for row,*_ in selected],
 ['Within R²']+[f'{R2:.4f}' for row,names,B,V,P,R2 in selected]]
 fragment=f'<h2>Panel {chr(65+k)}. {pair}</h2>'+table(['Regressor / specification']+labels,compact)
 parts.append(fragment)
 if k==0:main_html=fragment
parts.append('<p><strong>Interpretation:</strong> in pooled column (3), the group-indicator coefficient is the non-Trump-county contrast. Adding the interaction yields the Trump-county contrast. The interaction itself tests whether those contrasts differ between county types. The county-level Trump main effect is absorbed by county FE.</p><p><strong>Controls in Panels A–C:</strong> all control blocks are included; their individual coefficients and interactions are reported in the <a href="regression_tables_full_coefficients.html">full-coefficient appendix</a>. In pooled models, control slopes also interact with Trump-majority status. Omitted nuisance terms are collinear after county FE; the main contrasts remain estimable. County FE account for common county-level rating changes. Stable restaurant intercepts are removed by differencing; separate restaurant dummy coefficients are not estimated with one observation per restaurant. Period changes are embodied in the outcome, so no separate post dummy is included.</p><p><strong>Inference:</strong> original fixest nonnested small-sample correction: county FE are nested in county clusters and are not counted again in the CR1 parameter correction; t degrees of freedom equal counties minus one. This matches the archived estimator. Each pair uses its own shared-county sample; cross-panel coefficients are not contrasts from one common three-group regression.</p>')
from ban_controls_tables import render_controls
parts.append(render_controls(O,table,cell))
parts.append('<p>Ban windows: Dec26–Jan22 versus Jan30–Feb26, 2017, all UTC. Mixed event weeks omitted; no additional holiday exclusions. All rated reviews form each restaurant-period mean, regardless of text or food mentions.</p><p><a href="formatted_table_coefficients.csv">Table coefficients as CSV</a> · <a href="pairwise_results.csv">All split/direct estimates and confidence intervals</a> · <a href="verification.json">Independent numerical verification</a></p></body></html>')
pd.DataFrame(flat).to_csv(O/'formatted_table_coefficients.csv',index=False)
(O/'regression_tables.html').write_text(''.join(parts),encoding='utf-8')
(O/'main_table_fragment.html').write_text(main_html,encoding='utf-8')
(O/'regression_tables_full_coefficients.html').write_text(f'<!doctype html><html lang="en"><meta charset="utf-8"><title>Full-coefficient appendix</title><style>{style}</style><body><h1>All-controls models: complete coefficients</h1><p><a href="regression_tables.html">Return to main tables and methods</a>. Coefficients, county-clustered SEs and raw p values. Collinear nuisance terms are marked as omitted; main contrasts remain estimable.</p>'+''.join(appendix)+'</body></html>',encoding='utf-8')
print(pd.DataFrame(flat).query('panel == "WPME versus ME"').to_string(index=False))
