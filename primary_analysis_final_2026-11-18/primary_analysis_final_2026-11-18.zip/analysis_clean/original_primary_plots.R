args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'original_primary_county_fe')
all<-read.csv(file.path(o,'restaurant_changes.csv'),colClasses=c(county_fips='character'));r<-read.csv(file.path(o,'pairwise_results.csv'))
cols<-c(ME='#b35442',WPME='#25718b',MED='#718064');means<-list();pf<-function(p)if(p<.001)'<.001' else sprintf('%.3f',p)
for(pair in c('WPME versus ME','WPME versus MED','ME versus MED')){
 members<-strsplit(pair,' versus ',fixed=TRUE)[[1]];frames<-list()
 for(event in c('Election','Ban')){
  d<-all[all$event==event&all$group_hummus_or_baba%in%members,];d$position<-d$group_hummus_or_baba
  shared<-names(which(tapply(d$position,d$county_fips,function(x)length(unique(x)))==2));frames[[event]]<-d[d$county_fips%in%shared,]
 }
 lim<-range(unlist(lapply(frames,function(d)c(tapply(d$rating_pre,list(d$position,d$trump),mean),tapply(d$rating_post,list(d$position,d$trump),mean)))),na.rm=TRUE)+c(-.12,.23)
 name<-paste0(gsub(' versus ','_',pair,fixed=TRUE),'_pre_post.png')
 png(file.path(o,name),width=1800,height=1300,res=170)
 par(mfrow=c(2,2),mar=c(4,5,4.5,1),oma=c(5.5,0,3,0))
 for(event in c('Election','Ban'))for(trump in c(0,1)){
  d<-frames[[event]];d<-d[d$trump==trump,]
  q<-r[r$source=='raw'&r$definition=='hummus_or_baba'&r$event==event&r$pair==pair&r$stratum==ifelse(trump==1,'Trump','nonTrump'),]
  plot(c(.85,2.15),lim,type='n',xaxt='n',xlab='',ylab='Mean restaurant rating (stars)',main=paste0(event,' | ',ifelse(trump==1,'Trump-majority','Non-Trump-majority')),cex.main=1)
  axis(1,1:2,c('Before','After'));leg<-c();rawgap<-c()
  for(j in seq_along(members)){
   group<-members[j];z<-d[d$position==group,];y<-c(mean(z$rating_pre),mean(z$rating_post));rawgap<-c(rawgap,y[2]-y[1])
   other<-d[d$position==members[3-j],];other_y<-c(mean(other$rating_pre),mean(other$rating_post))
   lines(1:2,y,type='o',lwd=2.7,pch=15+j,col=cols[group]);text(1:2,y,sprintf('%.3f',y),pos=ifelse(y>=other_y,3,1),col=cols[group],cex=.8)
   leg<-c(leg,sprintf('%s: %d restaurants; reviews %s / %s',group,nrow(z),format(sum(z$reviews_pre),big.mark=','),format(sum(z$reviews_post),big.mark=',')))
   means[[length(means)+1]]<-data.frame(pair=pair,event=event,trump=trump,group=group,restaurants=nrow(z),reviews_pre=sum(z$reviews_pre),reviews_post=sum(z$reviews_post),mean_pre=y[1],mean_post=y[2],raw_change=y[2]-y[1])
  }
  legend('topleft',legend=leg,col=cols[members],lwd=2,pch=16:17,bty='n',cex=.69)
  mtext(sprintf('County-FE gap %+.3f%s (p%s%s); raw gap %+.3f',q$estimate,ifelse(is.na(q$symbol),'',q$symbol),ifelse(q$p<.001,'','='),pf(q$p),rawgap[1]-rawgap[2]),side=3,line=.2,cex=.75)
 }
 mtext(paste0(pair,' | Original primary categories | Equal restaurant weights | Pre-election hummus OR baba'),side=3,outer=TRUE,line=1,font=2,cex=.9)
 mtext('Each restaurant contributes the same weight before and after; all rated reviews form its period mean. Pair-specific shared counties; observed pairs only.',side=1,outer=TRUE,line=1,cex=.75)
 mtext('Lines show descriptive means. Printed county-FE gaps are adjusted differences in changes and need not equal the raw line gaps.',side=1,outer=TRUE,line=2.5,cex=.8)
 mtext('County-clustered raw p: + <.10, * <.05, ** <.01, *** <.001. Conditional associations, not causal effects.',side=1,outer=TRUE,line=4,cex=.8)
 dev.off()
}
write.csv(do.call(rbind,means),file.path(o,'descriptive_pre_post_means.csv'),row.names=FALSE)
