"""Render verified, fixed-sample control checks for the ban regression tables."""
import json
import pandas as pd


def render_controls(output, table, cell):
    folder = output / 'controls_preview'
    assert json.loads((folder / 'verification.json').read_text())['all_passed']
    data = pd.read_csv(folder / 'results.csv')
    specs = ['baseline', 'history', 'full_snapshot']
    parts = ['''<h2 id="controls">Additional controls: same-sample robustness checks</h2>
<p>These models extend Panels A–C without changing their restaurant samples, county fixed effects, equal restaurant weights, or county-clustered inference. Every cell reports the contrast in rating-star changes, clustered standard error in parentheses, and raw two-sided p value.</p>
<ul class="methods">
<li><strong>Earlier ratings/activity:</strong> mean rating and log(1 + review count) from October 10–November 6, 2016 (UTC), a separate pre-election four-week window. Missing earlier ratings are filled with the pooled paired-sample median (4.6), with a missing-rating indicator. No earlier observed reviews means count zero.</li>
<li><strong>Price/service/alcohol:</strong> adds price tier ($ reference; $$; $$$/$$$$; unknown), dine-in, takeout, delivery and alcohol listing indicators, plus service-record and alcohol-record missingness indicators. Listed/not-listed does not establish verified presence/absence.</li>
<li><strong>Timing caveat:</strong> price and service metadata are undated snapshots and may reflect information after the ban. Treat the final column as a sensitivity check; the earlier-ratings/activity specification has clearer temporal ordering.</li>
<li><strong>Sample and direct tests:</strong> missingness indicators retain all restaurants. Pooled tests also interact added control slopes with Trump-majority status, so the direct interaction equals the difference between the separately adjusted county-type contrasts. County FE absorb the Trump-majority main effect. Collinear nuisance terms are omitted where necessary.</li>
</ul>''']
    for pair in ['WPME versus ME', 'WPME versus MED', 'ME versus MED']:
        first, second = pair.split(' versus ')
        rows = []
        for stratum, label in [('nonTrump', 'Non-Trump counties'), ('Trump', 'Trump counties'), ('direct', 'Trump minus non-Trump: direct interaction')]:
            subset = data[(data.pair == pair) & (data.stratum == stratum)]
            assert len(subset) == 3
            assert subset.restaurants.nunique() == subset.counties.nunique() == 1
            entries = [subset[subset.specification == spec].iloc[0] for spec in specs]
            base = entries[0]
            rows.append([label] + [cell(x.estimate, x.se, x.p) for x in entries])
            rows.append([f'{first} / {second} restaurants'] + [f'{int(x.first_restaurants):,} / {int(x.second_restaurants):,}' for x in entries])
            rows.append(['Total restaurants / county clusters'] + [f'{int(x.restaurants):,} / {int(x.counties):,}' for x in entries])
        rows += [
            ['County fixed effects', 'Yes', 'Yes', 'Yes'],
            ['Stable restaurant effects', 'Differenced out', 'Differenced out', 'Differenced out'],
            ['Earlier rating and activity controls', 'No', 'Yes', 'Yes'],
            ['Price/service/alcohol controls', 'No', 'No', 'Yes'],
            ['Restaurant weights', 'Equal', 'Equal', 'Equal'],
            ['Standard errors', 'County-clustered', 'County-clustered', 'County-clustered'],
        ]
        parts.append(f'<h2>Control checks. {pair}</h2>' + table(['Contrast / specification', 'No controls', '+ Earlier ratings/activity', 'All controls (primary)'], rows))
    parts.append('''<p class="note"><strong>What changes with controls?</strong> For WPME versus ME in Trump counties, p changes from .029 to .030 with earlier controls and .026 with snapshot controls. The direct county-type interaction remains significant (.011, .012, .009). The ME-versus-MED contrast in Trump counties becomes clearer (.090, .046, .027); its direct county-type interaction is .123, .070, .042. No non-Trump contrast or WPME-versus-MED contrast reaches p&lt;.10. These are exploratory, correlational estimates with unadjusted p values; smaller p values alone do not establish a better model.</p>
<p>Symbols: + p&lt;.10, * p&lt;.05, ** p&lt;.01, *** p&lt;.001. Positive contrasts mean the first group improved relative to the second, not necessarily that its own ratings increased.</p>
<p><a href="controls_preview/results.csv">Control-check estimates, confidence intervals and sample sizes (CSV)</a> · <a href="controls_preview/coefficients.csv">All estimated coefficients and standard errors (CSV)</a> · <a href="controls_preview/design.json">Control definitions and model design</a> · <a href="controls_preview/verification.json">Independent verification of 27 fits</a></p>''')
    return ''.join(parts)
