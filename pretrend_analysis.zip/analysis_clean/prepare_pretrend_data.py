"""Use verified cached source arrays to add prehistory; original inputs stay unchanged."""
from pathlib import Path
import ast, hashlib, json
import pandas as pd
HERE=Path(__file__).resolve().parent; OUT=HERE/'outputs'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def main():
    meta=json.loads((OUT/'both_county_cache_metadata.json').read_text())
    cache=OUT/'both_county_source_records.pkl'
    assert sha(cache)==meta['record_sha256']
    cand=pd.read_csv(OUT/'both_county_candidates.csv',dtype={'county_fips':'string'})
    assert sha(OUT/'both_county_candidates.csv')==meta['fingerprint']['candidate_sha256']
    rec=pd.read_pickle(cache); rows=[]
    for ident,days,ratings,counts in rec.itertuples(index=False,name=None):
        ds,rs,ns=map(ast.literal_eval,[days,ratings,counts])
        assert len(ds)==len(rs)==len(ns)
        rows.extend((ident,d,float(r),float(n)) for d,r,n in zip(ds,rs,ns) if '2016-07-04'<=d<='2017-04-03')
    w=pd.DataFrame(rows,columns=['gmap_id','week','rating','reviews']).drop_duplicates()
    assert not w.duplicated(['gmap_id','week']).any()
    w=w[w.rating.between(1,5)&w.reviews.gt(0)].merge(cand,on='gmap_id',validate='many_to_one')
    assert pd.to_datetime(w.week).dt.dayofweek.eq(0).all()
    old=pd.read_csv(OUT/'both_county_shock_weekly.csv',dtype={'county_fips':'string'})
    compare=w[w.week.between('2016-10-10','2017-02-20')].sort_values(['gmap_id','week']).reset_index(drop=True)
    pd.testing.assert_frame_equal(compare[old.columns],old.sort_values(['gmap_id','week']).reset_index(drop=True),check_dtype=False)
    w.to_csv(OUT/'pretrend_history_weekly.csv',index=False)
    cfg=json.loads((HERE/'pretrend_specifications.json').read_text())
    cohort=pd.read_csv(OUT/'county_four_week_restaurant_changes.csv',dtype={'county_fips':'string'})
    blockrows=[]; attr=[]
    for s in cfg['shocks']:
        current=cohort[cohort.shock.eq(s['shock'])]
        for b in s['blocks']:
            z=w[w.week.between(b['start'],b['end'])&w.gmap_id.isin(current.gmap_id)].copy()
            z['score']=z.rating*z.reviews
            g=z.groupby(['gmap_id','group','county_fips','trump']).agg(score=('score','sum'),reviews=('reviews','sum'),weeks=('week','size')).reset_index()
            g['rating']=g.score/g.reviews;g['shock']=s['shock'];g['block']=b['block']
            blockrows.append(g.drop(columns='score'))
        # Availability from the entire existing candidate pool, before four-week selection.
        pre=set(w.loc[w.week.between(s['pre_start'],s['pre_end']),'gmap_id'])
        post=set(w.loc[w.week.between(s['post_start'],s['post_end']),'gmap_id'])
        x=cand.copy();x['pre']=x.gmap_id.isin(pre);x['post']=x.gmap_id.isin(post)
        x['status']=x.apply(lambda r:'Both' if r.pre and r.post else 'Pre only' if r.pre else 'Post only' if r.post else 'Neither',axis=1)
        g=x.groupby(['trump','group','status']).size().reset_index(name='restaurants');g['shock']=s['shock'];attr.append(g)
    pd.concat(blockrows,ignore_index=True).to_csv(OUT/'pretrend_restaurant_blocks.csv',index=False)
    pd.concat(attr,ignore_index=True).to_csv(OUT/'four_week_sample_availability.csv',index=False)
    # Report sample sizes at all existing windows in both county strata, without estimating new effects.
    windows=json.loads((HERE/'shock_specifications.json').read_text());sizes=[]
    for s in windows['main_windows']+windows['sensitivity_windows']:
        pre=set(w.loc[w.week.between(s['pre_start'],s['pre_end']),'gmap_id'])
        post=set(w.loc[w.week.between(s['post_start'],s['post_end']),'gmap_id'])
        g=cand[cand.gmap_id.isin(pre&post)].groupby(['trump','group']).size().reset_index(name='restaurants')
        g['shock']=s['shock'];g['weeks']=s['weeks'];sizes.append(g)
    pd.concat(sizes,ignore_index=True).to_csv(OUT/'sample_size_by_window.csv',index=False)
    audit={'cache_sha256':sha(cache),'weekly_rows':len(w),'businesses':w.gmap_id.nunique(),'original_weekly_input_reproduced':True,
           'cohort_sha256':sha(OUT/'county_four_week_restaurant_changes.csv'),'specification_sha256':sha(HERE/'pretrend_specifications.json')}
    (OUT/'pretrend_data_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
