param([string]$Python='python',[string]$Rscript='Rscript',[switch]$RebuildInputs)
$ErrorActionPreference='Stop'
if($RebuildInputs){
  & $Python "$PSScriptRoot/prepare_pretrend_data.py"
  if($LASTEXITCODE -ne 0){throw 'History preparation failed'}
  & $Python "$PSScriptRoot/audit_sample_expansion.py"
  if($LASTEXITCODE -ne 0){throw 'Master audit failed'}
}
& $Rscript --vanilla "$PSScriptRoot/test_four_week_pretrends.R"
if($LASTEXITCODE -ne 0){throw 'Pretrend models failed'}
& $Python "$PSScriptRoot/verify_pretrends.py"
if($LASTEXITCODE -ne 0){throw 'Independent verification failed'}
& $Rscript --vanilla "$PSScriptRoot/plot_pretrends.R"
if($LASTEXITCODE -ne 0){throw 'Plot generation failed'}
& $Python "$PSScriptRoot/report_pretrends.py"
if($LASTEXITCODE -ne 0){throw 'Report generation failed'}
