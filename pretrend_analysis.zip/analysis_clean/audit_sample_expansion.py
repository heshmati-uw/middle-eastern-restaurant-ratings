"""Audit saved-master expansion potential without changing sample definitions."""
from pathlib import Path
import hashlib,json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'outputs'
def main():
    cfg=json.loads((H/'config.json').read_text())
    folder=Path(cfg['source_root'])/'analysis/2025-08-18-rohan/categorized output'
    allpath=folder/'all-states.csv';filteredpath=folder/'all-states-filtered.csv'
    a=pd.read_csv(allpath,low_memory=False);f=pd.read_csv(filteredpath,low_memory=False)
    c=pd.read_csv(O/'both_county_candidates.csv');r=pd.read_csv(O/'reviews_clean.csv',usecols=['gmap_id'])
    extra=a[a.category.isin(cfg['me_categories'])&~a.gmap_id.isin(c.gmap_id)]
    result={'all_states_restaurants':a.gmap_id.nunique(),'filtered_master_restaurants':f.gmap_id.nunique(),
      'all_states_primary_ME':a.loc[a.category.isin(cfg['me_categories']),'gmap_id'].nunique(),
      'primary_ME_not_current_pool':extra.gmap_id.nunique(),
      'all_states_ME_any_category':a.loc[a.me_pos_any.eq(1),'gmap_id'].nunique(),
      'all_states_primary_Mediterranean':a.loc[a.med_pos_first.eq(1),'gmap_id'].nunique(),
      'extra_primary_ME_with_saved_2016_2017_reviews':int(extra.gmap_id.isin(r.gmap_id).sum()),
      'extra_primary_ME_without_saved_2016_2017_reviews':int((~extra.gmap_id.isin(r.gmap_id)).sum()),
      'source_files':{str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [allpath,filteredpath]}}
    (O/'sample_expansion_master_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
