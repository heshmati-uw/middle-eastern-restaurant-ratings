"""Independent NumPy checks of all history and weighted FE pretrend statistics."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent; O=H/'outputs'
def multi(d,Y,direct):
    tr=d.treated.to_numpy();tt=d.trump.to_numpy()
    X=np.column_stack([np.ones(len(d)),tr,tt,tr*tt] if direct else [np.ones(len(d)),tr])
    A=np.linalg.inv(X.T@X);B=A@X.T@Y;E=Y-X@B
    h=X@A[:,-1];codes=pd.factorize(d.county_fips)[0];G=codes.max()+1
    U=np.zeros((G,Y.shape[1]));np.add.at(U,codes,E*h[:,None])
    V=U.T@U*G/(G-1)*(len(d)-1)/(len(d)-X.shape[1])
    return B[-1],V,float(B[-1]@np.linalg.solve(V,B[-1])/Y.shape[1])
def within(M,weight,codes):
    a=M.copy()
    for n in range(2000):
        old=a.copy()
        for code in codes:
            denom=np.bincount(code,weights=weight)
            total=np.zeros((len(denom),a.shape[1]));np.add.at(total,code,a*weight[:,None])
            a-= (total/denom[:,None])[code]
        if np.abs(a-old).max()<1e-12:return a
    raise AssertionError('Demeaning did not converge')
def main():
    cfg=json.loads((H/'pretrend_specifications.json').read_text())
    blocks=pd.read_csv(O/'pretrend_restaurant_blocks.csv',dtype={'county_fips':str})
    hist=pd.read_csv(O/'four_week_history_pretrend_tests.csv')
    events=pd.read_csv(O/'four_week_history_event_contrasts.csv')
    w=pd.read_csv(O/'pretrend_history_weekly.csv',dtype={'county_fips':str})
    cohort=pd.read_csv(O/'county_four_week_restaurant_changes.csv',dtype={'county_fips':str})
    tests=pd.read_csv(O/'four_week_weekly_pretrend_tests.csv')
    leads=pd.read_csv(O/'four_week_weekly_pretrend_leads.csv')
    errors=[]
    for row in hist.itertuples():
        s=next(x for x in cfg['shocks'] if x['shock']==row.shock)
        b=blocks[blocks.shock.eq(row.shock)];counts=b.groupby('gmap_id').size()
        complete=set(counts[counts.eq(len(s['blocks']))].index)
        a,c=row.comparison.split(' vs ')
        d=b[b.gmap_id.isin(complete)&b.group.isin([a,c])]
        d=d.pivot(index=['gmap_id','group','county_fips','trump'],columns='block',values='rating').reset_index()
        if row.trump!=2:d=d[d.trump.eq(row.trump)]
        d['treated']=d.group.eq(a).astype(int)
        earlier=sorted(x for x in d.columns if isinstance(x,int) and x<-1)
        Y=np.column_stack([d[x]-d[-1] for x in earlier])
        beta,V,F=multi(d,Y,row.trump==2)
        assert len(d)==row.restaurants and d.treated.sum()==row.treated_restaurants
        errors.append(abs(F-row.joint_F));assert abs(F-row.joint_F)<1e-9
        e=events[(events.shock.eq(row.shock))&(events.trump.eq(row.trump))&events.comparison.eq(row.comparison)]
        for j,block in enumerate(earlier):
            saved=e[e.block.eq(block)].iloc[0]
            assert abs(beta[j]-saved.estimate)<1e-10
            assert abs(np.sqrt(V[j,j])-saved.se)<1e-10
        po,PV,_=multi(d,(d[1]-d[-1]).to_numpy()[:,None],row.trump==2)
        assert abs(po[0]-row.post_estimate)<1e-10 and abs(np.sqrt(PV[0,0])-row.post_se)<1e-10
    for row in tests.itertuples():
        s=next(x for x in cfg['shocks'] if x['shock']==row.shock);a,c=row.comparison.split(' vs ')
        ids=set(cohort.loc[cohort.shock.eq(row.shock),'gmap_id'])
        z=w[w.gmap_id.isin(ids)&w.week.between(s['pre_start'],s['pre_end'])&w.trump.eq(row.trump)&w.group.isin([a,c])].copy()
        z['n']=z.groupby('gmap_id').week.transform('size');z=z[z.n.ge(2)]
        z['treated']=z.group.eq(a).astype(int)
        week=((pd.to_datetime(z.week)-pd.Timestamp(s['pre_start'])).dt.days//7).to_numpy()
        weight=1/z.n.to_numpy();X=np.column_stack([(week==j)*z.treated for j in range(3)])
        M=within(np.column_stack([z.rating.to_numpy(),X]),weight,
                 [pd.factorize(z.gmap_id)[0],pd.factorize(z.week)[0]])
        y=M[:,0];x=M[:,1:];A=np.linalg.inv(x.T@(x*weight[:,None]));beta=A@x.T@(weight*y)
        residual=y-x@beta;codes=pd.factorize(z.county_fips)[0];G=codes.max()+1
        U=np.zeros((G,3));np.add.at(U,codes,x*(weight*residual)[:,None])
        V=A@U.T@U@A*G/(G-1)*(len(z)-1)/(len(z)-row.df_K)
        F=float(beta@np.linalg.solve(V,beta)/3)
        assert len(z)==row.observations and z.gmap_id.nunique()==row.informative_restaurants
        e=leads[leads.shock.eq(row.shock)&leads.trump.eq(row.trump)&leads.comparison.eq(row.comparison)]
        e=e.assign(index=e.term.str.extract(r'::(\d+):')[0].astype(int)).sort_values('index')
        err=max(np.abs(beta-e.estimate.to_numpy()).max(),np.abs(np.sqrt(np.diag(V))-e.se.to_numpy()).max(),abs(F-row.joint_F))
        assert err<1e-6,(row.shock,row.trump,row.comparison,err)
        errors.append(err)
    result={'history_joint_tests_verified':len(hist),'weekly_fixed_effect_joint_tests_verified':len(tests),
            'history_post_contrasts_verified':len(hist),'max_numerical_error':max(errors),
            'independent_county_sandwich_and_weighted_within_transform':True}
    (O/'pretrend_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
