"""Generate a local report from verified pretrend diagnostics and sample audits."""
from pathlib import Path
from html import escape
from html.parser import HTMLParser
import json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'outputs'
def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+escape(str(x))+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def pstar(p):return f'{p:.3f}'+('***' if p<.01 else '**' if p<.05 else '*' if p<.1 else '')
def main():
    weekly=pd.read_csv(O/'four_week_weekly_pretrend_tests.csv')
    hist=pd.read_csv(O/'four_week_history_pretrend_tests.csv')
    counts=pd.read_csv(O/'four_week_history_balanced_sizes.csv')
    original=pd.read_csv(O/'county_four_week_descriptives.csv')
    avail=pd.read_csv(O/'four_week_sample_availability.csv')
    windows=pd.read_csv(O/'sample_size_by_window.csv')
    master=json.loads((O/'sample_expansion_master_audit.json').read_text())
    verified=json.loads((O/'pretrend_verification.json').read_text())
    assert verified['history_joint_tests_verified']==18 and verified['weekly_fixed_effect_joint_tests_verified']==12
    body='''<h1>Pre-trends in the four-week restaurant samples</h1>
    <p class="lead">The current evidence is not sufficient for a credible causal election claim. Tests confined to the four baseline weeks do not reject, but their confidence intervals are wide. Longer pre-election history shows the ME–American gap evolving differently across county types (unadjusted joint p = 0.029). The Trump ME mean peaks immediately before the election and then partially falls back. This is a warning about pre-existing dynamics and possible mean reversion, not proof that the election had no effect.</p>
    <p>All diagnostics start with the exact restaurant IDs in the existing four-week comparisons. The original estimates are retained. Observations from the mixed election and ban weeks are excluded from all plotted periods. Trump means 2016 Republican share &gt; 50%; non-Trump means share ≤ 50%.</p>
    <h2>Rating paths: fixed restaurants, equal weight</h2>
    <p>To avoid attributing changing restaurant composition to a trend, these paths use a fixed subset with reviews in every plotted four-week block. Within a restaurant/block, ratings are weighted by review counts; across restaurants, every restaurant has equal weight. Levels are descriptive; confidence intervals for differences appear below.</p>
    <img src="four_week_group_paths.png" alt="Group rating paths in Trump and non-Trump counties for election and ban">
    <h2>What exactly was tested?</h2>
    <p><strong>Weekly check:</strong> Only the four baseline weeks, using restaurant and week fixed effects and group-by-week interactions (last week is the reference). Each informative restaurant has total pre-period weight one: an observed week has weight 1/(number of that restaurant’s observed pre-weeks). A restaurant with only one observed baseline week provides no within-restaurant pre-trend information and is omitted. Weekly rating means are not review-volume weighted across restaurants. Three pre-week coefficients are jointly tested using county-clustered covariance and F(3,G−1) inference. This diagnostic is not the original before/after estimator.</p>
    <p><strong>Longer-history check:</strong> Election has three four-week pre-blocks (Aug 15–Sep 11, Sep 12–Oct 9, Oct 10–Nov 6, 2016), plus the original Nov 14–Dec 11 post-block. Ban has two entirely post-election pre-blocks (Nov 28–Dec 25 and Dec 26–Jan 22), plus Jan 30–Feb 26. Each requires reviews in every block. For each earlier block, regress restaurant earlier-minus-last-pre rating on the group indicator. Joint tests use the cross-equation county sandwich covariance, correction G/(G−1) × (N−1)/(N−2), and F(q,G−1). Direct county-type tests add treated, Trump, and treated×Trump; their correction uses K=4. The null is that every earlier relative group gap equals its last-pre value.</p>'''
    body+='<h2>Joint pre-trend p-values</h2><p>Stars here flag evidence <em>against</em> parallel pre-trends: * p&lt;.10; ** p&lt;.05; *** p&lt;.01. Raw two-sided/joint p-values are shown. Non-rejection does not establish equivalence or prove parallel trends.</p>'
    pairs=['ME vs American','WPME vs American','WPME vs ME']
    rows=[]
    for shock in ['Election','Ban']:
        for t in [1,0]:
            vals=[]
            for pair in pairs:
                w=weekly[weekly.shock.eq(shock)&weekly.trump.eq(t)&weekly.comparison.eq(pair)].iloc[0]
                h=hist[hist.shock.eq(shock)&hist.trump.eq(t)&hist.comparison.eq(pair)].iloc[0]
                vals.extend([pstar(w.p),pstar(h.p)])
            rows.append([shock,'Trump' if t else 'Non-Trump']+vals)
    body+=table(['Event','County','ME–American: weekly','ME–American: history','WPME–American: weekly','WPME–American: history','WPME–ME: weekly','WPME–ME: history'],rows)
    body+='<h3>Were the relative gaps already changing differently across county types?</h3>'
    direct=hist[hist.trump.eq(2)]
    body+=table(['Event','Comparison','History joint pre-trend p','Holm p across 18 history tests'],[[r.shock,r.comparison,pstar(r.p),f'{r.p_holm_eighteen:.3f}'] for r in direct.itertuples()])
    body+='<p>The election ME–American direct pre-trend p = 0.029 becomes 0.523 after adjusting across all 18 history diagnostics. The Trump ban WPME–ME p = 0.042 becomes 0.713. Neither survives this broad adjustment; neither should be selectively used as definitive evidence of a violation. The visual dynamics and imprecision still do not justify declaring the design validated. All 12 weekly joint tests have p &gt; 0.16.</p>'
    for name,title in [('four_week_election_relative_paths','Election: all pairwise gaps'),('four_week_ban_relative_paths','Ban: all pairwise gaps'),('four_week_county_gap_paths','Direct differences across county types'),('four_week_election_weekly_pretrends','Election: four baseline weeks'),('four_week_ban_weekly_pretrends','Ban: four baseline weeks')]:
        body+=f'<h2>{title}</h2><img src="{name}.png" alt="{title}">'
    body+='<h2>How much of the original cohort supports each check?</h2>'
    rows=[]
    for shock in ['Election','Ban']:
        for t in [1,0]:
            for group in ['ME','American','WPME']:
                orig=original[original.shock.eq(shock)&original.trump.eq(t)&original.group.eq(group)].iloc[0].restaurants
                bal=counts[counts.shock.eq(shock)&counts.trump.eq(t)&counts.group.eq(group)].iloc[0].restaurants
                pair='WPME vs American' if group=='WPME' else 'ME vs American'
                ww=weekly[weekly.shock.eq(shock)&weekly.trump.eq(t)&weekly.comparison.eq(pair)].iloc[0]
                info=ww.informative_control if group=='American' else ww.informative_treated
                rows.append([shock,'Trump' if t else 'Non-Trump',group,f'{orig:,}',f'{info:,}',f'{bal:,}'])
    body+=table(['Event','County','Group','Original four-week N','Weekly informative N','History-balanced N'],rows)
    body+='<p>For election ME–American in Trump counties, requiring the full plotted history changes the post contrast from −0.249 (p = 0.008; 92 ME) to −0.162 (p = 0.103; 71 ME). The direct county difference changes from −0.217 (p = 0.031) to −0.128 (p = 0.230). These are different cohorts: attenuation is a sample-sensitivity finding, not an estimated correction for pre-trends.</p>'
    body+='<h2>Power and causal interpretation</h2><p>The history-based Trump ME–American pre-slope is estimated at +0.020 stars per week for the election. Projecting a linear drift across the five-week separation between the pre/post block midpoints gives +0.099 stars, with a 95% interval [−0.044,+0.242]. Its approximate 80%-power minimum detectable five-week drift is 0.204 stars (normal-power approximation using the observed standard error). The four-baseline-week slope is much less precise. Thus a nonsignificant pre-test does not exclude substantively meaningful departures from parallel trends.</p>'
    body+='''<p>A stronger design would use a cuisine universe defined independently of food mentions or post-event reviews, pre-event classifications, more pre-election history, and a prespecified window. Then estimate restaurant fixed effects with county×time effects and cuisine×time effects, identifying the ME×Trump×post contrast, and inspect its leads. Match or reweight on pre-event levels/trends, review activity and location using pre-event information; assess common support and sensitivity to remaining trend violations. Matching does not itself establish identification. American restaurants may also respond to the election, so any causal estimand would be relative to that comparison group. Reviewer selection, restaurant survival, contemporary category measurement and local shocks remain concerns. Election anticipation during the campaign also limits a sharp, unanticipated-shock interpretation.</p>
    <p>For the ban, the short post-election prehistory includes holidays and only two four-week blocks. It cannot establish a stable long pre-trend separate from election and seasonal dynamics. The original ban estimates are not statistically clear.</p>
    <h2>Expanding the sample</h2>'''
    rows=[]
    for shock in ['Election','Ban']:
        for t in [1,0]:
            z=windows[windows.shock.eq(shock)&windows.trump.eq(t)&windows.group.eq('ME')]
            rows.append([shock,'Trump' if t else 'Non-Trump']+[int(z[z.weeks.eq(k)].iloc[0].restaurants) for k in [4,6,10]])
    body+=table(['Event','County','ME: 4 weeks','ME: 6 weeks','ME: 10 weeks'],rows)
    body+='<p><strong>Immediate limit:</strong> The existing candidate universe has 165 ME businesses in Trump counties and 1,355 in non-Trump counties. Of the 165 Trump ME candidates around the election, 92 have reviews both sides, 12 pre only, 31 post only, and 30 neither. The existing pipeline already uses the larger combined outcome source, recovering many businesses excluded by the old weekly panel. Reusing that same source again will not automatically create more eligible four-week observations.</p>'
    body+=f'<p><strong>Rebuild eligibility from full metadata:</strong> Upstream code first selects restaurants with hummus/baba-ghanoush mentions. The current broader saved master has {master["all_states_primary_ME"]:,} primary-ME businesses versus 1,520 current geocoded focal candidates, but of the {master["primary_ME_not_current_pool"]:,} extra IDs only {master["extra_primary_ME_with_saved_2016_2017_reviews"]} appear in the saved July 2016–June 2017 review panel; the other {master["extra_primary_ME_without_saved_2016_2017_reviews"]} have no saved review in that period. These counts do not demonstrate 593 usable additions. The highest-value audit is the original full metadata and historical outcomes, selecting ME categories without conditioning on food mentions, then checking dates and geography. The actual gain is not yet known.</p>'
    body+='''<p><strong>Other options:</strong> Broader cuisine/category definitions (e.g., secondary-category ME) may add businesses but change the population and require a mutually exclusive, prespecified classification. Exact review dates could recover event-adjacent days currently discarded as mixed weeks, but need individual review data consistently for all groups. Longer windows add usable restaurants but change timing, cohort and seasonal exposure; six/ten-week Trump results already weaken the original election result. One-sided observations can enter repeated-cross-section or unbalanced-panel analyses under additional composition assumptions; they do not recover the missing restaurant-level change. No-review weeks must not be coded as zero-star ratings. Review counts are a separate outcome and cannot be read as sales. More American controls alone will have limited value compared with more ME restaurants and more ME counties.</p>'''
    body+='<h2>Sources and reproducibility</h2><p>The original cached weekly source arrays were hash-checked; the prior 139,864-row input was reproduced exactly. Independent NumPy implementations verify all 18 history joint tests, 18 history post contrasts, and 12 weighted weekly fixed-effect tests. Maximum numerical discrepancy is '+f'{verified["max_numerical_error"]:.2g}'+'.</p>'
    body+='<p>Methodological references: <a href="https://pubs.aeaweb.org/doi/10.1257/aeri.20210236">Roth, Pretest with Caution</a>; <a href="https://bcallaway11.github.io/files/Callaway-Chapter-2022/main.pdf">Callaway, Difference-in-Differences</a>. Failing to reject a pre-trend test is not proof of identification.</p>'
    links=['four_week_weekly_pretrend_tests.csv','four_week_weekly_pretrend_leads.csv','four_week_weekly_pretrend_slopes.csv','four_week_history_pretrend_tests.csv','four_week_history_event_contrasts.csv','four_week_history_balanced_sizes.csv','four_week_sample_availability.csv','sample_size_by_window.csv','sample_expansion_master_audit.json','pretrend_data_audit.json','pretrend_verification.json','pretrend_history_weekly.csv','pretrend_restaurant_blocks.csv','../pretrend_specifications.json','../prepare_pretrend_data.py','../test_four_week_pretrends.R','../verify_pretrends.py','../plot_pretrends.R','../report_pretrends.py']
    body+='<ul>'+''.join(f'<li><a href="{x}">{escape(x)}</a></li>' for x in links)+'</ul>'
    style='body{font:16px/1.6 system-ui;max-width:1350px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2{color:#173f46}img{width:100%;height:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:9px;border-bottom:1px solid #d8e2e5}th{background:#edf4f5}.scroll{overflow-x:auto}.lead{font-size:19px}a{color:#14637d}'
    path=O/'four_week_pretrend_report.html';path.write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Four-week sample pre-trends</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    class Links(HTMLParser):
        def handle_starttag(self,tag,attrs):
            a=dict(attrs);url=a.get('href',a.get('src',''))
            if url and not url.startswith(('http','#')):assert (O/url).exists(),url
    Links().feed(path.read_text(encoding='utf-8'))
    print(path)
if __name__=='__main__':main()
