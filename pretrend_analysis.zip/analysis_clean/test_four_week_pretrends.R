# Diagnostics for the exact four-week cohorts; sparse-history restrictions are explicit.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
out<-file.path(here,'outputs')
cfg<-fromJSON(file.path(here,'pretrend_specifications.json'),simplifyVector=FALSE)
w<-fread(file.path(out,'pretrend_history_weekly.csv'),colClasses=c(county_fips='character'))
cohort<-fread(file.path(out,'county_four_week_restaurant_changes.csv'),colClasses=c(county_fips='character'))
blocks<-fread(file.path(out,'pretrend_restaurant_blocks.csv'),colClasses=c(county_fips='character'))
pairs<-list(c('ME','American'),c('WPME','American'),c('WPME','ME'))
ssc_rule<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
weekly<-list();leads<-list();history<-list();events<-list();slopes<-list();sizes<-list();models<-list()
wald_joint<-function(beta,V,G){
  stopifnot(qr(V)$rank==length(beta))
  F<-as.numeric(t(beta)%*%solve(V,beta)/length(beta))
  list(F=F,p=pf(F,length(beta),G-1,lower.tail=FALSE))
}
# A multivariate extension of change~treated (or treated*trump) regressions.
# One row per restaurant, one outcome per earlier/reference block contrast.
multi<-function(d,ys,direct=FALSE){
  X<-if(direct)cbind(1,d$treated,d$trump,d$treated*d$trump) else cbind(1,d$treated)
  Y<-as.matrix(d[,..ys]); N<-nrow(X);K<-ncol(X); ix<-K
  A<-solve(crossprod(X));B<-A%*%crossprod(X,Y);E<-Y-X%*%B
  h<-as.vector(X%*%A[,ix]);U<-rowsum(E*h,d$county_fips);G<-nrow(U)
  V<-crossprod(U)*G/(G-1)*(N-1)/(N-K)
  beta<-as.numeric(B[ix,]);se<-sqrt(diag(V));j<-wald_joint(beta,V,G)
  list(beta=beta,se=se,V=V,p=2*pt(abs(beta/se),G-1,lower.tail=FALSE),
       low=beta-qt(.975,G-1)*se,high=beta+qt(.975,G-1)*se,G=G,N=N,joint=j)
}
for(spec in cfg$shocks){
  shock_name<-spec$shock
  c0<-cohort[shock==shock_name]
  # WEEKLY: all original-cohort restaurants with identifying pre-week variation.
  z0<-w[gmap_id %chin% c0$gmap_id & week>=spec$pre_start & week<=spec$pre_end]
  z0[,n_pre_weeks:=.N,by=gmap_id]
  z0<-z0[n_pre_weeks>=2]
  z0[,rest_weight:=1/n_pre_weeks]
  ref<-spec$pre_end
  for(pair in pairs){
    label<-paste(pair,collapse=' vs ')
    for(t in 0:1){
      z<-copy(z0[trump==t & group %chin% pair]);z[,treated:=as.integer(group==pair[1])]
      z[,week_index:=as.integer((as.IDate(week)-as.IDate(spec$pre_start))/7)]
      fit<-feols(rating~i(week_index,treated,ref=3)|gmap_id+week,data=z,weights=~rest_weight,
                 vcov=~county_fips,ssc=ssc_rule,notes=FALSE)
      beta<-coef(fit);V<-vcov(fit,attr=TRUE);G<-uniqueN(z$county_fips)
      jt<-wald_joint(beta,V,G);ct<-coeftable(fit);ci<-confint(fit)
      nm<-paste(shock_name,t,label,sep='__');models[[nm]]<-fit
      weekly[[length(weekly)+1L]]<-data.table(shock=shock_name,trump=t,comparison=label,
        original_restaurants=nrow(c0[trump==t & group %chin% pair]),
        original_treated=nrow(c0[trump==t & group==pair[1]]),
        informative_restaurants=uniqueN(z$gmap_id),informative_treated=uniqueN(z[group==pair[1]]$gmap_id),
        informative_control=uniqueN(z[group==pair[2]]$gmap_id),counties=G,observations=nrow(z),
        joint_F=jt$F,restrictions=length(beta),p=jt$p,df2=G-1,
        df_K=attr(V,'df.K'))
      for(j in seq_along(beta))leads[[length(leads)+1L]]<-data.table(shock=shock_name,trump=t,
          comparison=label,term=names(beta)[j],estimate=beta[j],se=sqrt(V[j,j]),p=ct[j,4],low=ci[j,1],high=ci[j,2])
      z[,time:=as.numeric(as.IDate(week)-as.IDate(ref))/7]
      sf<-feols(rating~treated:time|gmap_id+week,data=z,weights=~rest_weight,vcov=~county_fips,ssc=ssc_rule,notes=FALSE)
      sc<-coeftable(sf);sci<-confint(sf)
      slopes[[length(slopes)+1L]]<-data.table(shock=shock_name,trump=t,comparison=label,design='weekly',
        slope_per_week=sc[1,1],se=sc[1,2],p=sc[1,4],low=sci[1,1],high=sci[1,2],
        projected_five_week_drift=sc[1,1]*5,drift_low=sci[1,1]*5,drift_high=sci[1,2]*5)
    }
  }
  # HISTORY: same four-week cohort, restricted to complete four-week blocks.
  b<-copy(blocks[shock==shock_name]);nblocks<-length(spec$blocks)
  complete<-b[,.(n=.N),by=gmap_id][n==nblocks]$gmap_id
  b<-b[gmap_id %chin% complete]
  sizes[[length(sizes)+1L]]<-unique(b[,.(shock,trump,group,gmap_id)])[,.(restaurants=.N),by=.(shock,trump,group)]
  means<-b[,.(mean=mean(rating),restaurants=.N),by=.(shock,trump,group,block)]
  fwrite(means,file.path(out,paste0('pretrend_',tolower(shock_name),'_balanced_means.csv')))
  for(pair in pairs){
    label<-paste(pair,collapse=' vs ')
    q<-dcast(b[group %chin% pair],gmap_id+group+county_fips+trump~block,value.var='rating')
    q[,treated:=as.integer(group==pair[1])]
    earlier<-sort(as.integer(names(q)[grepl('^-?[0-9]+$',names(q))]));earlier<-earlier[earlier< -1]
    ys<-paste0('lead',seq_along(earlier))
    for(j in seq_along(earlier))q[,(ys[j]):=get(as.character(earlier[j]))-get('-1')]
    q[,post_change:=get('1')-get('-1')]
    q[,slope:= (get('-1')-get(as.character(min(earlier))))/(4*(-1-min(earlier)))]
    for(t in c(0,1,2)){
      d<-if(t==2)copy(q) else copy(q[trump==t]);direct<-t==2
      fit<-multi(d,ys,direct);po<-multi(d,'post_change',direct);sl<-multi(d,'slope',direct)
      history[[length(history)+1L]]<-data.table(shock=shock_name,trump=t,comparison=label,
        restaurants=fit$N,treated_restaurants=sum(d$treated),control_restaurants=sum(1-d$treated),
        counties=fit$G,joint_F=fit$joint$F,restrictions=length(ys),p=fit$joint$p,
        post_estimate=po$beta,post_se=po$se,post_p=po$p,
        slope_per_week=sl$beta,slope_se=sl$se,slope_p=sl$p,
        projected_five_week_drift=sl$beta*5,drift_low=sl$low*5,drift_high=sl$high*5,
        approximate_80pct_MDE_five_week_drift=(qt(.975,sl$G-1)+qnorm(.8))*sl$se*5)
      for(j in seq_along(ys))events[[length(events)+1L]]<-data.table(shock=shock_name,trump=t,
        comparison=label,block=earlier[j],estimate=fit$beta[j],se=fit$se[j],p=fit$p[j],low=fit$low[j],high=fit$high[j])
      events[[length(events)+1L]]<-data.table(shock=shock_name,trump=t,comparison=label,block=-1,
        estimate=0,se=0,p=NA_real_,low=0,high=0)
      events[[length(events)+1L]]<-data.table(shock=shock_name,trump=t,comparison=label,block=1,
        estimate=po$beta,se=po$se,p=po$p,low=po$low,high=po$high)
    }
  }
}
ww<-rbindlist(weekly);hh<-rbindlist(history)
ww[,p_holm_twelve:=p.adjust(p,'holm')]
hh[,p_holm_eighteen:=p.adjust(p,'holm')]
fwrite(ww,file.path(out,'four_week_weekly_pretrend_tests.csv'))
fwrite(rbindlist(leads),file.path(out,'four_week_weekly_pretrend_leads.csv'))
fwrite(rbindlist(slopes),file.path(out,'four_week_weekly_pretrend_slopes.csv'))
fwrite(hh,file.path(out,'four_week_history_pretrend_tests.csv'))
fwrite(rbindlist(events),file.path(out,'four_week_history_event_contrasts.csv'))
fwrite(rbindlist(sizes),file.path(out,'four_week_history_balanced_sizes.csv'))
saveRDS(models,file.path(out,'four_week_weekly_pretrend_models.rds'))
writeLines(capture.output(sessionInfo()),file.path(out,'pretrend_R_session.txt'))
print(ww);print(hh)
