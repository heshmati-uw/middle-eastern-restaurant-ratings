# Static, exportable scientific figures. PNG and SVG outputs use identical content.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(jsonlite)})
out<-file.path(here,'outputs');cfg<-fromJSON(file.path(here,'pretrend_specifications.json'),simplifyVector=FALSE)
ev<-fread(file.path(out,'four_week_history_event_contrasts.csv'))
ht<-fread(file.path(out,'four_week_history_pretrend_tests.csv'))
wt<-fread(file.path(out,'four_week_weekly_pretrend_tests.csv'))
wl<-fread(file.path(out,'four_week_weekly_pretrend_leads.csv'))
cols<-c(ME='#B64B40',American='#376B92',WPME='#42866A')
pairs<-c('ME vs American','WPME vs American','WPME vs ME')
draw<-function(name,width,height,f){
  png(file.path(out,paste0(name,'.png')),width=width,height=height,res=160,type='cairo');f();dev.off()
  svg(file.path(out,paste0(name,'.svg')),width=width/160,height=height/160);f();dev.off()
}
draw('four_week_group_paths',1900,1450,function(){
  par(mfrow=c(2,2),mar=c(5.5,4.5,4.2,1),oma=c(2,0,3,0),family='sans',las=1,cex=.95)
  for(spec in cfg$shocks){
    d<-fread(file.path(out,paste0('pretrend_',tolower(spec$shock),'_balanced_means.csv')))
    for(t in c(1,0)){
      z<-d[trump==t];bs<-sort(unique(z$block))
      x<-sapply(spec$blocks,function(b)as.numeric(as.Date(b$start))+13.5)
      event<-as.numeric(as.Date(spec$event))
      plot(range(x),c(4.05,4.7),type='n',xaxt='n',xlab='',ylab='Mean restaurant rating',bty='l',col.axis='#44515C')
      abline(h=seq(4.1,4.7,.1),col='#E5E9EC',lwd=.7);abline(v=event,lty=2,col='#727A81')
      axis(1,at=x,labels=sapply(spec$blocks,function(b)format(as.Date(b$start),'%b %d')),cex.axis=.85)
      mtext('Four-week period starting',side=1,line=3.2,cex=.85)
      for(g in c('ME','American','WPME')){
        a<-z[group==g][order(block)];lines(x,a$mean,type='b',pch=16,col=cols[g],lwd=2.3,cex=1.1)
      }
      title(main=paste(spec$shock,if(t==1)'| Trump counties' else '| Non-Trump counties'),cex.main=1.05)
      ns<-z[block== -1];legend('topleft',legend=paste0(c('ME','American','WPME'),' (n=',ns$restaurants[match(c('ME','American','WPME'),ns$group)],')'),
          col=cols,lty=1,pch=16,bty='n',cex=.82,horiz=TRUE,inset=c(0,-.005))
    }
  }
  mtext('Rating paths in the history-balanced subset of each original four-week sample',outer=TRUE,side=3,line=1,cex=1.1,font=2)
  mtext('Same restaurants in every plotted block; equal restaurant weights. Dashed line marks the event; mixed event weeks omitted.',outer=TRUE,side=1,line=.4,cex=.82)
})
for(spec in cfg$shocks){
  draw(paste0('four_week_',tolower(spec$shock),'_relative_paths'),2100,1300,function(){
    par(mfrow=c(2,3),mar=c(5,4,4.5,1),oma=c(2,0,3,0),family='sans',las=1)
    for(t in c(1,0))for(pair in pairs){
      z<-ev[shock==spec$shock & trump==t & comparison==pair][order(block)]
      x<-sapply(spec$blocks,function(b)as.numeric(as.Date(b$start))+13.5)
      plot(range(x),c(-.8,.8),type='n',xaxt='n',xlab='',ylab='Relative rating gap (stars)',bty='l')
      abline(h=0,col='#919BA2',lty=3);abline(v=as.numeric(as.Date(spec$event)),col='#919BA2',lty=2)
      lines(x,z$estimate,col='#376B92',lwd=2);keep<-z$block!= -1
      arrows(x[keep],z$low[keep],x[keep],z$high[keep],angle=90,code=3,length=.04,col='#376B92',lwd=1.4)
      points(x,z$estimate,pch=16,col=ifelse(z$block<0,'#376B92','#B64B40'),cex=1.2)
      axis(1,at=x,labels=sapply(spec$blocks,function(b)format(as.Date(b$start),'%b %d')),cex.axis=.8)
      test<-ht[shock==spec$shock & trump==t & comparison==pair]
      title(main=paste(pair,if(t==1)'| Trump' else '| Non-Trump'),cex.main=.95,
            sub=paste0('Joint pre-trend p = ',formatC(test$p,digits=3,format='f')),cex.sub=.85)
    }
    mtext(paste(spec$shock,': differences in group gaps, relative to the last pre-event block'),outer=TRUE,side=3,line=1,font=2,cex=1.1)
    mtext('History-balanced subset; equal restaurant weights; pointwise 95% county-clustered intervals. Zero reference is normalized, not estimated.',outer=TRUE,side=1,line=.3,cex=.8)
  })
}
draw('four_week_county_gap_paths',2100,1300,function(){
  par(mfrow=c(2,3),mar=c(5,4,4.5,1),oma=c(2,0,3,0),family='sans',las=1)
  for(spec in cfg$shocks)for(pair in pairs){
    z<-ev[shock==spec$shock & trump==2 & comparison==pair][order(block)]
    x<-sapply(spec$blocks,function(b)as.numeric(as.Date(b$start))+13.5)
    plot(range(x),c(-.8,.8),type='n',xaxt='n',xlab='',ylab='Trump minus non-Trump gap',bty='l')
    abline(h=0,col='#919BA2',lty=3);abline(v=as.numeric(as.Date(spec$event)),col='#919BA2',lty=2)
    lines(x,z$estimate,col='#376B92',lwd=2);keep<-z$block!= -1
    arrows(x[keep],z$low[keep],x[keep],z$high[keep],angle=90,code=3,length=.04,col='#376B92',lwd=1.4)
    points(x,z$estimate,pch=16,col=ifelse(z$block<0,'#376B92','#B64B40'),cex=1.2)
    axis(1,at=x,labels=sapply(spec$blocks,function(b)format(as.Date(b$start),'%b %d')),cex.axis=.8)
    test<-ht[shock==spec$shock & trump==2 & comparison==pair]
    title(main=paste(spec$shock,'|',pair),cex.main=.95,
          sub=paste0('Joint pre-trend p = ',formatC(test$p,digits=3,format='f')),cex.sub=.85)
  }
  mtext('Were relative group gaps already changing differently across county types?',outer=TRUE,side=3,line=1,font=2,cex=1.1)
  mtext('History-balanced subset; relative to the last pre-event block; pointwise 95% county-clustered intervals.',outer=TRUE,side=1,line=.3,cex=.85)
})
for(spec in cfg$shocks){
  draw(paste0('four_week_',tolower(spec$shock),'_weekly_pretrends'),2100,1300,function(){
    par(mfrow=c(2,3),mar=c(5,4,4.5,1),oma=c(2,0,3,0),family='sans',las=1)
    for(t in c(1,0))for(pair in pairs){
      z<-wl[shock==spec$shock & trump==t & comparison==pair];z[,index:=as.integer(sub('.*::([0-9]+):.*','\\1',term))]
      z<-rbind(z[,.(index,estimate,low,high)],data.table(index=3,estimate=0,low=0,high=0))[order(index)]
      plot(0:3,c(0,0,0,0),type='n',ylim=c(-1.35,1.35),xaxt='n',xlab='',ylab='Relative pre-event gap',bty='l')
      abline(h=0,lty=3,col='#919BA2');lines(z$index,z$estimate,col='#376B92',lwd=2)
      keep<-z$index!=3
      arrows(z$index[keep],z$low[keep],z$index[keep],z$high[keep],angle=90,code=3,length=.04,col='#376B92');points(z$index,z$estimate,pch=16,col='#376B92')
      axis(1,at=0:3,labels=format(as.Date(spec$pre_start)+7*(0:3),'%b %d'),cex.axis=.8)
      test<-wt[shock==spec$shock & trump==t & comparison==pair]
      title(main=paste(pair,if(t==1)'| Trump' else '| Non-Trump'),cex.main=.95,
            sub=paste0('Joint p = ',formatC(test$p,digits=3,format='f'),'; n = ',test$informative_restaurants),cex.sub=.85)
    }
    mtext(paste(spec$shock,': trends within the four baseline weeks'),outer=TRUE,side=3,line=1,font=2,cex=1.1)
    mtext('Restaurant/week fixed effects; equal total pre-period weight per informative restaurant; 95% county-clustered intervals.',outer=TRUE,side=1,line=.3,cex=.85)
  })
}
