args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(h,'full_pre_election_core');extra<-'--dine-alcohol' %in% args;o<-file.path(s,'attribute_matching',if(extra)'ME_WPME_price_dine_alcohol' else 'ME_WPME_price_only');d<-fread(file.path(o,'matched_restaurants.csv'),colClasses=c(county_fips='character',match_stratum='character'));w<-fread(file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');means<-list();tests<-list();coefs<-list();inputs<-list();meaninputs<-list();levels<-list()
for(en in c('Election','Ban'))for(t in c(1,0)){
 a<-d[event==en&trump==t];mf<-feols(change~first|match_stratum,a,vcov=~county_fips,ssc=ss);ct<-coeftable(mf)['first',];ci<-confint(mf)['first',];G<-uniqueN(a$county_fips)
 means[[length(means)+1]]<-data.table(event=en,trump=t,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],ME=sum(a$first),WPME=sum(1-a$first),counties=G,df_K=attr(vcov(mf,attr=TRUE),'df.K'))
 ap<-a[,.(gmap_id,county_fips,first,change,match_stratum)];ap[,`:=`(event=en,trump=t)];meaninputs[[length(meaninputs)+1]]<-ap
 mixed<-as.IDate(if(en=='Election')'2016-11-07' else '2017-01-23')
 dw<-merge(w[week>=mixed-70&week<=mixed+28&week!=mixed&reviews>0&!is.na(rating)],a[,.(gmap_id,county_fips,first,group,match_stratum)],by='gmap_id')
 keep<-intersect(dw[week<mixed,.N,by=gmap_id][N>=2]$gmap_id,dw[week>mixed]$gmap_id)
 eligible<-unique(dw[gmap_id %chin% keep,.(gmap_id,first,match_stratum)])
 # Rebalance the diagnostic on the exact matching strata, without arbitrary pairs.
 set.seed(20261026L+(if(en=='Ban')100L else 0L)+t)
 selected<-eligible[,{
  aa<-sort(gmap_id[first==1]);bb<-sort(gmap_id[first==0]);nn<-min(length(aa),length(bb));.(gmap_id=c(if(nn)aa[sample.int(length(aa),nn)] else character(),if(nn)bb[sample.int(length(bb),nn)] else character()))
 },by=match_stratum]$gmap_id
 dw<-dw[gmap_id %chin% selected];dw[,weight:=1/.N,by=gmap_id];dw[,event_week:=as.integer((week-mixed)/7)]
 fit<-feols(rating~i(event_week,first,ref=-1)|gmap_id+match_stratum^week,dw,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none')
 b<-coef(fit);V<-vcov(fit);ci<-confint(fit);ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);G<-uniqueN(dw$county_fips);F<-as.numeric(t(b[ii])%*%solve(V[ii,ii],b[ii])/length(ii));p<-pf(F,length(ii),G-1,lower.tail=FALSE)
 tests[[length(tests)+1]]<-data.table(event=en,trump=t,ME=uniqueN(dw[first==1]$gmap_id),WPME=uniqueN(dw[first==0]$gmap_id),counties=G,pre_restrictions=length(ii),F,p,df_K=attr(vcov(fit,attr=TRUE),'df.K'))
 z<-rbind(data.table(event_week=ev,estimate=unname(b),se=sqrt(diag(V)),low=ci[,1],high=ci[,2]),data.table(event_week=-1,estimate=0,se=0,low=0,high=0));setorder(z,event_week);z[,`:=`(event=en,trump=t)];coefs[[length(coefs)+1]]<-z;dw[,`:=`(event=en,trump=t)];inputs[[length(inputs)+1]]<-dw
 lev<-dw[,.(rating=mean(rating),restaurants=.N),by=.(group,week)];setorder(lev,group,week);lev[,`:=`(event=en,trump=t)];levels[[length(levels)+1]]<-lev
 png(file.path(o,paste0(en,'_',if(t==1)'Trump' else 'NonTrump','_price_only.png')),width=1500,height=1300,res=160);par(mfrow=c(2,1),mar=c(4.5,5,3,1),oma=c(3,0,1,0));dates<-sort(unique(lev$week));cols<-c('#185b7a','#c45a3c')
 plot(range(dates),range(lev$rating),type='n',xaxt='n',xlab='',ylab='Average rating (stars)',main=paste(en,if(t==1)'| Trump counties' else '| Non-Trump counties',if(extra)'| Price, dine-in and alcohol matching' else '| Price-only matching'))
 axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.75);abline(v=as.Date(mixed)+if(en=='Election')1 else 4,lty=2,col='grey50')
 for(k in 1:2){zz<-lev[group==c('ME','WPME')[k]];lines(zz$week,zz$rating,col=cols[k],lwd=2);points(zz$week,zz$rating,col=cols[k],pch=c(16,17)[k])};legend('bottomleft',legend=c('ME','WPME'),col=cols,lty=1,pch=c(16,17),bty='n')
 plot(as.Date(mixed)+7*z$event_week,z$estimate,type='n',ylim=range(c(z$low,z$high,0)),xaxt='n',xlab='',ylab='Adjusted ME minus WPME gap',main=sprintf('Joint pre p = %.3f | %d ME + %d WPME | %d counties',p,uniqueN(dw[first==1]$gmap_id),uniqueN(dw[first==0]$gmap_id),G))
 axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.75);abline(v=as.Date(mixed)+if(en=='Election')1 else 4,lty=2,col='grey50');abline(h=0,lty=3,col='grey50');x<-as.Date(mixed)+7*z$event_week;segments(x,z$low,x,z$high,col=cols[1]);points(x,z$estimate,col=ifelse(z$event_week<0,cols[1],cols[2]),pch=16)
 mtext('Holidays included; mixed event week omitted; no geographic matching or geographic fixed effects.',side=1,outer=TRUE,line=.6,cex=.72)
 mtext('Raw lines: equal weight among observed restaurants each week. Adjusted model: total restaurant weight one.',side=1,outer=TRUE,line=1.7,cex=.67);dev.off()
}
fwrite(rbindlist(means),file.path(o,'mean_results.csv'));fwrite(rbindlist(tests),file.path(o,'pretrend_tests.csv'));fwrite(rbindlist(coefs),file.path(o,'weekly_estimates.csv'));fwrite(rbindlist(inputs),file.path(o,'weekly_verification_inputs.csv'));fwrite(rbindlist(meaninputs),file.path(o,'mean_verification_inputs.csv'));fwrite(rbindlist(levels),file.path(o,'weekly_group_means.csv'))
print(rbindlist(means));print(rbindlist(tests))
