"""Outcome-blind, equal-weight ME/WPME samples balanced on price tier only."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';extra='--dine-alcohol' in sys.argv;O=S/'attribute_matching'/('ME_WPME_price_dine_alcohol' if extra else 'ME_WPME_price_only');O.mkdir(exist_ok=True)
attrs=pd.read_csv(S/'attribute_matching/restaurant_attributes.csv',usecols=['gmap_id','price_tier','dine_in','alcohol','service_recorded','offerings_recorded'])
strata=['price_tier']+(['dine_in','alcohol'] if extra else [])
meta=pd.read_csv(S/'restaurant_precinct_assignments.csv',dtype={'county_fips':str},usecols=['gmap_id','group','county_fips','trump','state','primary_category'])
meta=meta[meta.group.isin(['ME','WPME'])&meta.trump.isin([0,1])&meta.county_fips.notna()]
seed=20261026;rows=[];flows=[];balance=[]
design={'groups':['ME','WPME'],'exact_matching':strata,'geography_used_for_selection':False,'separate_samples':['event','Trump/non-Trump county status'],'ratio':'1:1 within each matching stratum, no replacement','selection':'Select min(ME count,WPME count) from each group within each matching stratum, using independent seeded random permutations of sorted IDs. No geographic or outcome-based tie breaking.','seed':seed,'weights':'Every selected restaurant unit weight','outcomes_used_for_matching':False,'holidays':'Included','mean_model':'Rating change ~ ME + matching-stratum fixed effects; county-clustered CR1 standard errors. No arbitrary individual pair FE.','weekly_model':'Restaurant and matching-stratum-by-week FE; total observed-panel restaurant weight one. County clustering. Diagnostic samples rebalanced within the same matching strata after individual weekly eligibility.','timing_caveat':'Metadata undated. Feature zero means not recorded, not verified absence. Rating outcomes are required to define analysis eligibility but never used to choose matches.'}
(O/'design.json').write_text(json.dumps(design,indent=2))
for event in ['Election','Ban']:
 q=pd.read_csv(S/'inputs'/f'periods_{event.lower()}_4w.csv').merge(meta,on='gmap_id',validate='one_to_one').merge(attrs,on='gmap_id',validate='one_to_one');q=q[q.rating_pre.notna()&q.rating_post.notna()&q.price_tier.notna()]
 for t in [1,0]:
  rng=np.random.default_rng(seed+(0 if event=='Election' else 100)+t);eligible=q[q.trump.eq(t)];selected=[]
  for key,z in eligible.groupby(strata,sort=True):
   key=key if isinstance(key,tuple) else (key,);stratum='|'.join(str(v) for v in key)
   a=z[z.group.eq('ME')].sort_values('gmap_id');b=z[z.group.eq('WPME')].sort_values('gmap_id');n=min(len(a),len(b))
   if n==0:continue
   for group,zz in [('ME',a),('WPME',b)]:
    pick=zz.iloc[rng.permutation(len(zz))[:n]].copy();pick['event']=event;pick['first']=(group=='ME')*1;pick['match_stratum']=stratum;selected.append(pick)
   balance.append(dict(event=event,trump=t,**dict(zip(strata,key)),eligible_ME=len(a),eligible_WPME=len(b),matched_ME=n,matched_WPME=n))
  m=pd.concat(selected,ignore_index=True);assert not m.gmap_id.duplicated().any();assert m.groupby(['match_stratum','group']).size().unstack().apply(lambda x:x.ME==x.WPME,axis=1).all();rows.append(m)
  flows.append(dict(event=event,trump=t,ME=sum(m.group.eq('ME')),WPME=sum(m.group.eq('WPME')),counties=m.county_fips.nunique(),eligible_ME=sum(eligible.group.eq('ME')),eligible_WPME=sum(eligible.group.eq('WPME'))))
pd.concat(rows,ignore_index=True).to_csv(O/'matched_restaurants.csv',index=False);pd.DataFrame(flows).to_csv(O/'sample_flow.csv',index=False);pd.DataFrame(balance).to_csv(O/'price_balance.csv',index=False)
print(pd.DataFrame(flows).to_string(index=False))
