"""Outcome-blind common ME/WPME/MED matched triplets within county and price."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'attribute_matching/common_triplets';O.mkdir(exist_ok=True)
sys.path.insert(0,str(H.parent/'.analysis-python'))
from scipy.optimize import linear_sum_assignment
attrs=pd.read_csv(S/'attribute_matching/restaurant_attributes.csv',usecols=['gmap_id','price_tier'])
groups=['ME','WPME','MED'];out=[];flows=[]
def distance(a,b):
 lat1=np.radians(a.latitude.to_numpy())[:,None];lat2=np.radians(b.latitude.to_numpy())[None,:]
 dl=np.radians(a.longitude.to_numpy())[:,None]-np.radians(b.longitude.to_numpy())[None,:]
 h=np.sin((lat1-lat2)/2)**2+np.cos(lat1)*np.cos(lat2)*np.sin(dl/2)**2
 return 6371.0088*2*np.arcsin(np.sqrt(np.clip(h,0,1)))
design={'groups':groups,'ratio':'1:1:1, no replacement','exact':['county_fips','price_tier'],'selection':'Within each county-price stratum, anchor every restaurant of the smallest group (ties ME then WPME then MED); optimally assign distinct restaurants from each other group to anchors using squared geographic distance. This is not a global minimum of all three pairwise distances.','outcomes_used_for_matching':False,'holidays':'Included','target':'Common three-group overlap; different from earlier pairwise samples','weekly_eligibility':'Retain entire triplet only if all members have at least two pre-event weeks and one post-event week.','timing_caveat':'Price metadata are undated snapshots.'}
(O/'design.json').write_text(json.dumps(design,indent=2))
for event in ['Election','Ban']:
 frames=[pd.read_csv(S/'regressions'/f'sample_{p}_{event.lower()}.csv',dtype={'county_fips':str}) for p in ['ME_WPME','ME_MED','WPME_MED']]
 q=pd.concat(frames,ignore_index=True)
 for _,z in q.groupby('gmap_id'):
  assert z.group.nunique()==1 and np.ptp(z.change.to_numpy())<1e-8
 q=q.drop_duplicates('gmap_id').merge(attrs,on='gmap_id',validate='one_to_one')
 for t in [1,0]:
  eligible=q[q.trump.eq(t)&q.price_tier.notna()].copy();matched=[];tid=0
  for key,z in eligible.groupby(['county_fips','price_tier'],sort=True):
   parts={g:z[z.group.eq(g)].sort_values('gmap_id').reset_index(drop=True) for g in groups}
   if any(len(parts[g])==0 for g in groups):continue
   anchor=min(groups,key=lambda g:len(parts[g]));a=parts[anchor];assignment={anchor:np.arange(len(a))}
   for g in groups:
    if g==anchor:continue
    rows,cols=linear_sum_assignment((distance(a,parts[g])/20)**2)
    assert np.array_equal(rows,np.arange(len(a)));assignment[g]=cols
   for j in range(len(a)):
    tid+=1;triplet=f'{event}_{t}_{tid}'
    for g in groups:
     row=parts[g].iloc[assignment[g][j]].to_dict();row.update(event=event,triplet_id=triplet,anchor_group=anchor);matched.append(row)
  m=pd.DataFrame(matched);assert m.groupby('triplet_id').group.nunique().eq(3).all() and not m.gmap_id.duplicated().any()
  assert m.groupby('triplet_id').county_fips.nunique().eq(1).all() and m.groupby('triplet_id').price_tier.nunique().eq(1).all()
  out.append(m)
  flows.append({'event':event,'trump':t,'triplets':tid,'restaurants':len(m),'counties':m.county_fips.nunique(),**{f'eligible_{g}':sum(eligible.group.eq(g)) for g in groups}})
pd.concat(out,ignore_index=True).to_csv(O/'common_matched_restaurants.csv',index=False)
pd.DataFrame(flows).to_csv(O/'sample_flow.csv',index=False)
print(pd.DataFrame(flows).to_string(index=False))
