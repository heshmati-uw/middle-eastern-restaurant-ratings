from pathlib import Path
import json,re
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'full_pre_election_core/attribute_matching/common_triplets'
m=pd.read_csv(O/'mean_results.csv');p=pd.read_csv(O/'mean_verification_inputs.csv',dtype={'county_fips':str});w=pd.read_csv(O/'weekly_verification_inputs.csv',dtype={'county_fips':str});models=json.loads((O/'weekly_model_coefficients.json').read_text());errors=[];we=[]
for (event,trump),z in p.groupby(['event','trump']):
 a=z[['isME','isWP','change']];a=a-a.groupby(z.triplet_id).transform('mean');X=a[['isME','isWP']].to_numpy();y=a.change.to_numpy();b=np.linalg.solve(X.T@X,X.T@y);res=y-X@b;bread=np.linalg.inv(X.T@X);scores=pd.DataFrame(X*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();G=z.county_fips.nunique();N=len(z);K=z.df_K.iloc[0];V=bread@scores.T@scores@bread*G/(G-1)*(N-1)/(N-K)
 for pair,L in [('ME_WPME',np.array([1,-1])),('ME_MED',np.array([1,0])),('WPME_MED',np.array([0,1]))]:
  r=m[m.event.eq(event)&m.trump.eq(trump)&m.pair.eq(pair)].iloc[0];errors.extend([abs(L@b-r.estimate),abs(np.sqrt(L@V@L)-r.se)])
for key,old in models.items():
 event,trump=key.split('_');z=w[w.event.eq(event)&w.trump.eq(int(trump))];names=old['names'];ww=z.weight.to_numpy()
 X=np.column_stack([z['isME' if n.endswith('isME') else 'isWP'].to_numpy()*(z.event_week.to_numpy()==int(re.search(r'::(-?\d+):',n)[1])) for n in names]);a=np.column_stack([z.rating.to_numpy(),X]);groups=[pd.factorize(z.gmap_id)[0],pd.factorize(z.county_fips+'_'+z.week)[0]]
 assert np.allclose(z.groupby('gmap_id').weight.sum(),1)
 for it in range(4000):
  prev=a.copy()
  for codes in groups:
   sums=np.bincount(codes,weights=ww)
   for j in range(a.shape[1]):a[:,j]-=(np.bincount(codes,weights=ww*a[:,j])/sums)[codes]
  if np.max(np.abs(a-prev))<1e-12:break
 else:raise AssertionError('Demeaning failed')
 X=a[:,1:];y=a[:,0];bread=np.linalg.inv(X.T@(ww[:,None]*X));b=bread@(X.T@(ww*y));res=y-X@b
 scores=pd.DataFrame(X*(ww*res)[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();G=z.county_fips.nunique();N=len(z);V=bread@scores.T@scores@bread*G/(G-1)*(N-1)/(N-old['df_K']);we.extend([np.max(np.abs(b-old['b'])),np.max(np.abs(V-np.array(old['V'])))])
assert max(errors)<1e-8 and max(we)<1e-7,(max(errors),max(we))
d=pd.read_csv(O/'common_matched_restaurants.csv');assert d.groupby(['event','trump','triplet_id']).group.nunique().eq(3).all();assert not d.duplicated(['event','trump','gmap_id']).any();assert d.groupby('triplet_id').county_fips.nunique().eq(1).all();assert d.groupby('triplet_id').price_tier.nunique().eq(1).all()
for event in ['Election','Ban']:
 for t in [1,0]:
  z=m[m.event.eq(event)&m.trump.eq(t)].set_index('pair');assert abs(z.loc['ME_WPME','estimate']-(z.loc['ME_MED','estimate']-z.loc['WPME_MED','estimate']))<1e-10
audit={'mean_contrasts_verified':12,'weekly_models_verified':4,'max_mean_error':max(errors),'max_weekly_coefficient_or_covariance_error':max(we),'same_restaurants_all_contrasts':True,'exact_county_price':True,'equal_total_restaurant_weight':True};(O/'verification.json').write_text(json.dumps(audit,indent=2))
def display(frame):
 z=frame.copy()
 if 'trump' in z:z['counties_type']=z.trump.map({1:'Trump',0:'Non-Trump'});z=z.drop(columns='trump')
 for col in ['estimate','se','low','high']:
  if col in z:z[col]=z[col].map(lambda x:f'{x:+.3f}')
 if 'p' in z:z['p']=z.p.map(lambda x:'Not estimable' if pd.isna(x) else (f'{x:.4g}'+('***' if x<.001 else '**' if x<.01 else '*' if x<.05 else '+' if x<.1 else '')))
 return z.to_html(index=False,escape=True)
tests=pd.read_csv(O/'pretrend_tests.csv');flow=pd.read_csv(O/'sample_flow.csv')
html='''<!doctype html><html><meta charset="utf-8"><title>Common restaurant samples</title><style>body{font:16px system-ui;max-width:1250px;margin:35px auto;padding:20px;color:#223}table{border-collapse:collapse;font-size:14px}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:right}img{max-width:100%}.scroll{overflow-x:auto}</style><h1>Common price-matched ME, WPME and Mediterranean samples</h1><p>Every matched set has one restaurant from each group in the same county and dollar-sign price tier. All three comparisons use exactly the same restaurants and the same Mediterranean pool within each event and county stratum. The election and ban samples differ: these are not the same businesses across shocks. Holidays are included.</p><p>Outcome-blind matching anchors the smallest group within each county-price stratum, then uses optimal geographic assignment without replacement for each other group. This is not a global optimal three-way distance match; there is no hard proximity threshold. Price is an undated snapshot. The target is the overlap population, not all restaurants.</p><h2>Mean changes</h2><p>Equal restaurant weights, triplet FE, county-clustered CR1 inference with county-count-minus-one t degrees of freedom. All contrasts come from one three-group model per event/stratum, so ME minus WPME equals ME minus MED minus WPME minus MED. Negative estimates indicate first-group relative losses. Election windows Oct 10-Nov 6 versus Nov 14-Dec 11, 2016. Ban windows Dec 26-Jan 22 versus Jan 30-Feb 26, 2017. Symbols use raw p: + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001.</p>'''
html+='<div class="scroll">'+display(m)+'</div><h2>Sample flow</h2>'+display(flow)
html+='''<h2>Trends and inference limits</h2><p>For weekly diagnostics, an entire triplet is retained only if every member has two or more observed pre-weeks and at least one post-week. Thus the same cohort underlies all three weekly contrasts, but businesses observed in a particular week can vary. Raw lines give equal weight to each restaurant observed that week. The adjusted joint model uses restaurant and county-by-week FE, total observed-panel restaurant weight one, and the last complete pre-week as reference.</p><p>Trump-county samples are particularly small: the election plot has only six counties, making the nine-restriction pretest unidentifiable. The ban has ten counties; nine-restriction tests are near the covariance-rank limit and can be unstable or non-estimable. Tiny reported p-values there should not be interpreted as precise evidence. Non-rejection elsewhere is not proof of parallel trends.</p>'''
html+='<div class="scroll">'+display(tests)+'</div>'
for event in ['Ban','Election']:
 for t in ['Trump','NonTrump']:html+=f'<h2>{event}: {t}</h2><img src="{event}_{t}_common.png">'
html+='''<p>Undated metadata, sparse reviews, changing weekly observation composition, and unobserved differences remain limitations. The matched cohorts are common across contrasts, not a fully observed restaurant-by-week panel. Review food labels remain frozen using full raw pre-election core tags; MED has pre-election review text without core mentions.</p><p><a href="common_matched_restaurants.csv">Common restaurant data</a> | <a href="mean_results.csv">Mean results</a> | <a href="weekly_estimates.csv">Weekly contrasts</a> | <a href="design.json">Design</a> | <a href="verification.json">Independent verification</a></p></html>'''
(O/'common_sample_report.html').write_text(html,encoding='utf-8');print(json.dumps(audit));print(m.to_string(index=False))
