args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(h,'full_pre_election_core');o<-file.path(s,'attribute_matching','mediterranean_two_lines');dir.create(o,showWarnings=FALSE)
d<-fread(file.path(s,'attribute_matching','matched_restaurant_data.csv'),colClasses=c(county_fips='character'))
w<-fread(file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');results<-list();tests<-list();means<-list()
for(pair_code in c('ME_MED','WPME_MED')){
 a<-d[event=='Ban'&pair==pair_code&trump==1&method=='Price']
 orig<-fread(file.path(s,'regressions',paste0('sample_',pair_code,'_ban.csv')));j<-match(a$gmap_id,orig$gmap_id);stopifnot(!anyNA(j));a[,change:=orig$change[j]]
 mf<-feols(change~first|match_id,a,vcov=~county_fips,ssc=ss);ct<-coeftable(mf)['first',]
 means[[pair_code]]<-data.table(pair=pair_code,estimate=ct[1],se=ct[2],p=ct[4],first_N=sum(a$first),MED_N=sum(1-a$first),counties=uniqueN(a$county_fips))
 dw<-merge(w[week>=as.IDate('2016-11-14')&week<=as.IDate('2017-02-20')&week!=as.IDate('2017-01-23')&reviews>0&!is.na(rating)],a[,.(gmap_id,county_fips,first,match_id)],by='gmap_id')
 keep<-intersect(dw[week<as.IDate('2017-01-23'),.N,by=gmap_id][N>=2]$gmap_id,dw[week>as.IDate('2017-01-23')]$gmap_id)
 dw<-dw[gmap_id %chin% keep];dw<-dw[match_id %chin% dw[,.(n=uniqueN(gmap_id)),by=match_id][n==2]$match_id]
 dw[,weight:=1/.N,by=gmap_id];dw[,event_week:=as.integer((week-as.IDate('2017-01-23'))/7)]
 fit<-feols(rating~i(event_week,first,ref=-1)|gmap_id+county_fips^week,dw,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none')
 b<-coef(fit);v<-vcov(fit);ci<-confint(fit);ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);G<-uniqueN(dw$county_fips);p<-NA_real_
 if(qr(v[ii,ii])$rank==length(ii)&&G>length(ii))p<-pf(as.numeric(t(b[ii])%*%solve(v[ii,ii],b[ii])/length(ii)),length(ii),G-1,lower.tail=FALSE)
 z<-rbind(data.table(event_week=ev,estimate=unname(b),low=ci[,1],high=ci[,2]),data.table(event_week=-1,estimate=0,low=0,high=0));setorder(z,event_week);z[,pair:=pair_code];results[[pair_code]]<-z
 tests[[pair_code]]<-data.table(pair=pair_code,first_N=uniqueN(dw[first==1]$gmap_id),MED_N=uniqueN(dw[first==0]$gmap_id),counties=G,joint_pre_p=p)
}
rr<-rbindlist(results);tt<-rbindlist(tests);mm<-rbindlist(means);fwrite(rr,file.path(o,'weekly_estimates.csv'));fwrite(tt,file.path(o,'pretrend_tests.csv'));fwrite(mm,file.path(o,'average_results.csv'))
png(file.path(o,'trump_ban_ME_WPME_relative_MED.png'),width=1600,height=1000,res=160);par(mar=c(6,5,4,1))
dates<-as.Date('2017-01-23')+7*sort(unique(rr$event_week));yr<-range(c(rr$low,rr$high,0))
plot(range(dates),yr,type='n',xaxt='n',xlab='',ylab='Change in rating gap versus Mediterranean (stars)',main='Trump counties | Ban | Price-matched comparisons to Mediterranean')
axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.8);abline(h=0,lty=3,col='grey50');abline(v=as.Date('2017-01-27'),lty=2,col='grey50')
cols<-c('#185b7a','#c45a3c');k<-0
for(pair_code in c('ME_MED','WPME_MED')){k<-k+1;z<-rr[pair==pair_code];x<-as.Date('2017-01-23')+7*z$event_week;segments(x+(k-1.5)*.6,z$low,x+(k-1.5)*.6,z$high,col=adjustcolor(cols[k],alpha.f=.45));lines(x,z$estimate,col=cols[k],lwd=2);points(x,z$estimate,col=cols[k],pch=c(16,17)[k])}
legend('topleft',legend=c('ME relative to Mediterranean','WPME relative to Mediterranean'),col=cols,lty=1,pch=c(16,17),lwd=2,bty='n',cex=.85)
mtext('Both gaps normalized to Jan 16 week; holidays included; dashed line = Jan 27 ban',side=3,line=.4,cex=.8)
mtext('Week starting (2016-2017); equal total restaurant weights; 95% county-clustered intervals',side=1,line=4.2,cex=.75)
mtext('Separate matched samples and Mediterranean comparators; lines are relative gaps, not raw ratings.',side=1,line=5.2,cex=.75);dev.off()
writeLines(c('Existing price-matched pairs retained, Trump counties, ban, holidays included.','Two separately estimated cuisine-versus-MED event studies; not a common Mediterranean sample.','Each gap normalized to Jan 16 week; Jan 23 mixed week omitted. Restaurant and county-by-week FE.','Equal total restaurant weights; county clustering. Undated matching attributes; exploratory sensitivity.','Mean windows Dec 26-Jan 22 and Jan 30-Feb 26. Weekly diagnostic Nov 14-Feb 26, with both partners meeting observation requirements.'),file.path(o,'README.txt'))
print(tt);print(mm)
