args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(h,'full_pre_election_core');o<-file.path(s,'attribute_matching','ME_WPME_two_lines');dir.create(o,showWarnings=FALSE)
d<-fread(file.path(s,'attribute_matching','matched_restaurant_data.csv'),colClasses=c(county_fips='character'))[event=='Ban'&pair=='ME_WPME'&trump==1&method=='Price']
w<-fread(file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
dw<-merge(w[week>=as.IDate('2016-11-14')&week<=as.IDate('2017-02-20')&week!=as.IDate('2017-01-23')&reviews>0&!is.na(rating)],d[,.(gmap_id,county_fips,first,group,match_id)],by='gmap_id')
keep<-intersect(dw[week<as.IDate('2017-01-23'),.N,by=gmap_id][N>=2]$gmap_id,dw[week>as.IDate('2017-01-23')]$gmap_id)
dw<-dw[gmap_id %chin% keep];dw<-dw[match_id %chin% dw[,.(n=uniqueN(gmap_id)),by=match_id][n==2]$match_id]
dw[,weight:=1/.N,by=gmap_id];dw[,event_week:=as.integer((week-as.IDate('2017-01-23'))/7)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
fit<-feols(rating~i(event_week,first,ref=-1)|gmap_id+county_fips^week,dw,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none')
b<-coef(fit);v<-vcov(fit);ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);G<-uniqueN(dw$county_fips);p<-NA_real_
if(qr(v[ii,ii])$rank==length(ii)&&G>length(ii))p<-pf(as.numeric(t(b[ii])%*%solve(v[ii,ii],b[ii])/length(ii)),length(ii),G-1,lower.tail=FALSE)
trend<-dw[,.(rating=mean(rating),restaurants=.N),by=.(group,week)];setorder(trend,group,week);fwrite(trend,file.path(o,'weekly_group_means.csv'))
test<-data.table(ME=uniqueN(dw[first==1]$gmap_id),WPME=uniqueN(dw[first==0]$gmap_id),counties=G,joint_pre_p=p);fwrite(test,file.path(o,'pretrend_test.csv'))
orig<-fread(file.path(s,'regressions','sample_ME_WPME_ban.csv'));j<-match(d$gmap_id,orig$gmap_id);d[,change:=orig$change[j]];mf<-feols(change~first|match_id,d,vcov=~county_fips,ssc=ss);ct<-coeftable(mf)['first',];mr<-data.table(estimate=ct[1],p=ct[4],ME=sum(d$first),WPME=sum(1-d$first));fwrite(mr,file.path(o,'mean_change_result.csv'))
png(file.path(o,'trump_ban_ME_WPME_two_lines.png'),width=1500,height=1000,res=160);par(mfrow=c(2,1),mar=c(3.5,5,3,1),oma=c(3,0,1,0))
dates<-sort(unique(trend$week));cols<-c('#185b7a','#c45a3c')
plot(range(dates),range(trend$rating),type='n',xaxt='n',xlab='',ylab='Average review rating (stars)',main='Trump counties | Ban | Price-matched ME and WPME')
axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=as.Date('2017-01-27'),lty=2,col='grey50')
for(k in 1:2){z<-trend[group==c('ME','WPME')[k]];lines(z$week,z$rating,col=cols[k],lwd=2);points(z$week,z$rating,col=cols[k],pch=c(16,17)[k])}
legend('bottomleft',legend=c('ME','WPME'),col=cols,lty=1,pch=c(16,17),lwd=2,bty='n')
plot(range(dates),c(0,max(trend$restaurants)+2),type='n',xaxt='n',xlab='',ylab='Restaurants observed that week',main='Weekly sample composition')
axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=as.Date('2017-01-27'),lty=2,col='grey50')
for(k in 1:2){z<-trend[group==c('ME','WPME')[k]];lines(z$week,z$restaurants,col=cols[k],lwd=2);points(z$week,z$restaurants,col=cols[k],pch=c(16,17)[k])}
mtext('Holidays included; ban week omitted; equal restaurant weight within each observed week.',side=1,outer=TRUE,line=.6,cex=.75)
mtext('Raw group averages; varying weekly composition. Regression pretest uses equal total restaurant weights.',side=1,outer=TRUE,line=1.7,cex=.7);dev.off()
writeLines(c('Fixed eligible matched-pair cohort, but observed businesses can vary by week.','Top panel is raw restaurant-week rating means with equal weight among restaurants observed that week.','Not the adjusted event-study estimate: county-by-week fixed effects identify relative group movements, not two separate absolute rating paths.','The regression pretest uses restaurant and county-by-week FE and total restaurant weight one.','Price metadata are undated; limited counties and exploratory inference.'),file.path(o,'README.txt'))
print(test);print(mr);print(trend)
