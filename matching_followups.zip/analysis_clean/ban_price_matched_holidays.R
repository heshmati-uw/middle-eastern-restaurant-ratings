args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(h,'full_pre_election_core');o<-file.path(s,'attribute_matching','holidays_restored');dir.create(o,showWarnings=FALSE)
d<-fread(file.path(s,'attribute_matching','matched_restaurant_data.csv'),colClasses=c(county_fips='character'))[event=='Ban'&pair=='ME_WPME'&trump==0&method=='Price']
original<-fread(file.path(s,'regressions','sample_ME_WPME_ban.csv'))
stopifnot(nrow(d)==930,all(d$gmap_id %in% original$gmap_id))
w<-fread(file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
means<-list();tests<-list();coefs<-list()
for(holidays in c(FALSE,TRUE)){
 a<-copy(d)
 if(holidays){j<-match(a$gmap_id,original$gmap_id);a[,`:=`(rating_pre=original$rating_pre[j],rating_post=original$rating_post[j],change=original$change[j])]}
 fit<-feols(change~first|match_id,a,vcov=~county_fips,ssc=ss)
 ct<-coeftable(fit)['first',];ci<-confint(fit)['first',]
 # Independently check pair-difference estimate and cluster standard error.
 pd<-a[,.(gap=change[first==1]-change[first==0]),by=.(match_id,county_fips)]
 b<-mean(pd$gap);G<-uniqueN(pd$county_fips);N<-nrow(a);K<-attr(vcov(fit,attr=TRUE),'df.K')
 scores<-pd[,.(score=sum(gap-b)/2),by=county_fips]$score
 se<-sqrt(sum(scores^2)/(nrow(pd)/2)^2*G/(G-1)*(N-1)/(N-K))
 stopifnot(abs(b-ct[1])<1e-10,abs(se-ct[2])<1e-10)
 means[[length(means)+1]]<-data.table(holidays_included=holidays,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],ME=sum(a$first),WPME=sum(1-a$first),counties=G)
 dw<-merge(w[week>=as.IDate('2016-11-14')&week<=as.IDate('2017-02-20')&week!=as.IDate('2017-01-23')&reviews>0&!is.na(rating)],a[,.(gmap_id,county_fips,first,match_id)],by='gmap_id')
 if(!holidays)dw<-dw[!week %in% as.IDate(c('2016-12-19','2016-12-26'))]
 keep<-intersect(dw[week<as.IDate('2017-01-23'),.N,by=gmap_id][N>=2]$gmap_id,dw[week>as.IDate('2017-01-23')]$gmap_id)
 dw<-dw[gmap_id %chin% keep];dw<-dw[match_id %chin% dw[,.(n=uniqueN(gmap_id)),by=match_id][n==2]$match_id]
 dw[,weight:=1/.N,by=gmap_id];dw[,event_week:=as.integer((week-as.IDate('2017-01-23'))/7)]
 wf<-feols(rating~i(event_week,first,ref=-1)|gmap_id+county_fips^week,dw,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none')
 b<-coef(wf);v<-vcov(wf);ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);G<-uniqueN(dw$county_fips)
 stopifnot(qr(v[ii,ii])$rank==length(ii));ff<-as.numeric(t(b[ii])%*%solve(v[ii,ii],b[ii])/length(ii));p<-pf(ff,length(ii),G-1,lower.tail=FALSE)
 ci<-confint(wf);z<-rbind(data.table(event_week=ev,estimate=unname(b),low=ci[,1],high=ci[,2]),data.table(event_week=-1,estimate=0,low=0,high=0));setorder(z,event_week);z[,holidays_included:=holidays];coefs[[length(coefs)+1]]<-z
 tests[[length(tests)+1]]<-data.table(holidays_included=holidays,ME=uniqueN(dw[first==1]$gmap_id),WPME=uniqueN(dw[first==0]$gmap_id),counties=G,pre_restrictions=length(ii),F=ff,p=p)
 if(holidays){
  dates<-as.Date('2017-01-23')+7*z$event_week
  png(file.path(o,'ban_nontrump_price_holidays.png'),width=1500,height=900,res=160);par(mar=c(6,5,4,1))
  plot(dates,z$estimate,type='n',ylim=range(c(z$low,z$high,0)),xaxt='n',xlab='',ylab='ME minus WPME gap relative to Jan 16 week',main='Ban | Non-Trump counties | Price-matched | Holidays included')
  axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.8);abline(h=0,lty=3,col='grey50');abline(v=as.Date('2017-01-27'),lty=2,col='grey50')
  segments(dates,z$low,dates,z$high,col='#185b7a');points(dates,z$estimate,pch=19,col=ifelse(z$event_week<0,'#185b7a','#c45a3c'))
  mtext(sprintf('Joint pre-trend p = %.3f | %d ME + %d WPME | %d counties',p,uniqueN(dw[first==1]$gmap_id),uniqueN(dw[first==0]$gmap_id),G),side=3,line=.4,cex=.85)
  mtext('Week starting (2016-2017); 95% county-clustered intervals',side=1,line=4.1,cex=.8)
  mtext('Same original price-matched pairs; equal total restaurant weights; ban week omitted.',side=1,line=5.1,cex=.7);dev.off()
 }
}
fwrite(rbindlist(means),file.path(o,'average_results.csv'));fwrite(rbindlist(tests),file.path(o,'pretrend_tests.csv'));fwrite(rbindlist(coefs),file.path(o,'weekly_estimates.csv'))
writeLines(c('Same 465 original price-matched pairs; no rematching.','Four-week mean windows: Dec 26-Jan 22 and Jan 30-Feb 26. Christmas week Dec 19 is outside that baseline.','Weekly trend window Nov 14-Feb 26 includes both Dec 19 and Dec 26 weeks when holidays are restored.','Weekly eligibility requires both partners to have 2+ pre weeks and 1+ post weeks; restaurant total weight one.','Metadata timing remains undated; these are exploratory descriptive sensitivities.'),file.path(o,'README.txt'))
print(rbindlist(means));print(rbindlist(tests))
