Existing price-matched pairs retained, Trump counties, ban, holidays included.
Two separately estimated cuisine-versus-MED event studies; not a common Mediterranean sample.
Each gap normalized to Jan 16 week; Jan 23 mixed week omitted. Restaurant and county-by-week FE.
Equal total restaurant weights; county clustering. Undated matching attributes; exploratory sensitivity.
Mean windows Dec 26-Jan 22 and Jan 30-Feb 26. Weekly diagnostic Nov 14-Feb 26, with both partners meeting observation requirements.
