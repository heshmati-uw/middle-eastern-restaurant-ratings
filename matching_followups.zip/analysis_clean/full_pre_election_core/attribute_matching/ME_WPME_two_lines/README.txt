Fixed eligible matched-pair cohort, but observed businesses can vary by week.
Top panel is raw restaurant-week rating means with equal weight among restaurants observed that week.
Not the adjusted event-study estimate: county-by-week fixed effects identify relative group movements, not two separate absolute rating paths.
The regression pretest uses restaurant and county-by-week FE and total restaurant weight one.
Price metadata are undated; limited counties and exploratory inference.
