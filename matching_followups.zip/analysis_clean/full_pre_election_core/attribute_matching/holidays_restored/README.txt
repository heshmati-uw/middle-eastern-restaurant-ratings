Same 465 original price-matched pairs; no rematching.
Four-week mean windows: Dec 26-Jan 22 and Jan 30-Feb 26. Christmas week Dec 19 is outside that baseline.
Weekly trend window Nov 14-Feb 26 includes both Dec 19 and Dec 26 weeks when holidays are restored.
Weekly eligibility requires both partners to have 2+ pre weeks and 1+ post weeks; restaurant total weight one.
Metadata timing remains undated; these are exploratory descriptive sensitivities.
