args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'ban_friday_event_study_2026_11_19')
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()));suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)});setFixest_nthreads(1)
old<-fread(file.path(h,'ban_controlled_event_study_2026_11_19/analysis_data.csv'),colClasses=c(county_fips='character'));new<-fread(file.path(o,'analysis_data.csv'),colClasses=c(county_fips='character'));ids<-intersect(unique(old$gmap_id),unique(new$gmap_id));fwrite(data.table(gmap_id=ids),file.path(o,'common_restaurant_ids.csv'))
full<-fromJSON(file.path(h,'original_primary_county_fe/controls_preview/design.json'))$specifications$full_snapshot;ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');out<-list()
for(kind in c('Monday-Sunday; mixed week omitted','Friday-Thursday; no omitted week'))for(tr in c(1,0)){
 z<-copy(if(startsWith(kind,'Monday'))old else new);z<-z[gmap_id%chin%ids&trump==tr];post<-if(startsWith(kind,'Monday'))7:12 else 6:11;times<-c(0:5,post)
 fit<-feols(as.formula(paste('rating~',paste(c('i(idx,treated,ref=5)',sprintf('i(idx,%s,ref=5)',full)),collapse='+'),'|gmap_id+county_fips^idx')),data=z,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
 b<-coef(fit);V<-vcov(fit);G<-uniqueN(z$county_fips);A<-matrix(0,12,length(b),dimnames=list(times,names(b)))
 for(k in times[times!=5])A[as.character(k),paste0('idx::',k,':treated')]<-1
 L<-colMeans(A[as.character(post),,drop=FALSE])-colMeans(A[as.character(0:5),,drop=FALSE]);est<-sum(L*b);se<-sqrt(as.numeric(t(L)%*%V%*%L));p<-2*pt(abs(est/se),G-1,lower.tail=FALSE)
 out[[length(out)+1]]<-data.table(week_definition=kind,trump=tr,restaurants=uniqueN(z$gmap_id),ME=uniqueN(z[group=='ME']$gmap_id),WPME=uniqueN(z[group=='WPME']$gmap_id),counties=G,average_post=est,se,p,low=est-qt(.975,G-1)*se,high=est+qt(.975,G-1)*se)
}
result<-rbindlist(out);fwrite(result,file.path(o,'common_sample_comparison.csv'));print(result)
