"""Unmatched individual-review outcome extraction for all cuisine-identified food businesses."""
from pathlib import Path
import pandas as pd,json,gzip,re,hashlib,time,threading,subprocess,shutil,concurrent.futures as cf
H=Path(__file__).resolve().parent
BASE=H/'preban_trends_2026_11_19/raw_extraction'
O=BASE;O.mkdir(exist_ok=True,parents=True)
C=O/'checkpoints';C.mkdir(exist_ok=True)
ROOT=Path(json.loads((H/'config.json').read_text())['source_root'])
SRC=ROOT/'analysis/2025-08-18-rohan/inputs'
codes=pd.read_csv(H/'preban_trends_2026_11_19/cohort.csv')
TARGET=set(codes.gmap_id)
WINDOWS=[('PreBan','pre',int(pd.Timestamp('2016-11-14',tz='UTC').timestamp()*1000),int(pd.Timestamp('2017-01-23',tz='UTC').timestamp()*1000))]
SIGNATURE=hashlib.sha256(json.dumps([sorted(TARGET),WINDOWS,'preban-tenweeks-raw-v1']).encode()).hexdigest()

def scan(p):
 done=C/(p.stem+'.done.json');dest=C/(p.stem+'.reviews.gz');tmp=dest.with_suffix('.tmp')
 if done.exists() and dest.exists():
  saved=json.loads(done.read_text())
  if saved.get('signature')==SIGNATURE and saved.get('bytes')==p.stat().st_size and saved.get('mtime_ns')==p.stat().st_mtime_ns:return saved
 stat=dict(file=p.name,signature=SIGNATURE,rows=0,selected=0,invalid_ratings=0,json_errors=0,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns)
 rg=shutil.which('rg')
 early=subprocess.Popen([rg,'--text','--no-unicode','--no-heading','--no-line-number',r'"time"\s*:\s*(?:147|148)[0-9]{10}\s*[,}]'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 select=subprocess.Popen([rg,'--text','--no-unicode','--no-heading','--no-line-number','-F','-f',str(O/'target_ids.txt')],stdin=early.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 early.stdout.close();errors=[];progress=[time.monotonic()]
 def feed():
  try:
   with p.open('rb') as raw,gzip.GzipFile(fileobj=raw) as stream:
    while True:
     chunk=stream.read(4*1024*1024)
     if not chunk:break
     stat['rows']+=chunk.count(b'\n');early.stdin.write(chunk);stat['compressed_bytes_read']=raw.tell()
     if time.monotonic()-progress[0]>20:
      (C/(p.stem+'.status.json')).write_text(json.dumps(stat));progress[0]=time.monotonic()
  except Exception as e:errors.append(repr(e))
  finally:early.stdin.close()
 writer=threading.Thread(target=feed);writer.start()
 with gzip.open(tmp,'wt',encoding='utf8') as out:
  for line in select.stdout:
   try:r=json.loads(line)
   except (ValueError,UnicodeError):stat['json_errors']+=1;continue
   if r.get('gmap_id') not in TARGET:continue
   t=r.get('time')
   if not isinstance(t,(int,float)):continue
   selected_window=next(((ev,per) for ev,per,a,b in WINDOWS if a<=t<b),None)
   if selected_window is None:continue
   event,period=selected_window
   stars=r.get('rating')
   if stars not in (1,2,3,4,5):stat['invalid_ratings']+=1;continue
   # Deduplicate exact source-review copies without saving names, text, or raw reviewer IDs.
   key=hashlib.sha256(json.dumps([r.get('gmap_id'),r.get('user_id'),t,stars,r.get('text')],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
   user=str(r.get('user_id') or '')
   out.write(json.dumps([key,r['gmap_id'],int(t),stars,event,period,hashlib.sha256(user.encode()).hexdigest() if user else ''])+'\n')
   stat['selected']+=1
 writer.join();select.stdout.close()
 e1=early.stderr.read().decode();e2=select.stderr.read().decode();rc1=early.wait();rc2=select.wait()
 if errors or rc1 not in (0,1) or rc2 not in (0,1):raise RuntimeError(str((errors,rc1,rc2,e1,e2)))
 tmp.replace(dest);stat['complete']=True;done.write_text(json.dumps(stat));return stat
def main():
 (O/'target_ids.txt').write_text('\n'.join(sorted(TARGET)),encoding='utf8')
 files=sorted(SRC.glob('review-*.json.gz'),key=lambda p:-p.stat().st_size);assert len(files)==52
 manifest=dict(signature=SIGNATURE,target_businesses=len(TARGET),windows=WINDOWS,outcome_filter='All rated reviews, regardless of star level, text availability, cuisine or dish words. No matching or pre-history criterion.',sources=[dict(file=p.name,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns) for p in files])
 (O/'manifest.json').write_text(json.dumps(manifest,indent=2))
 with cf.ProcessPoolExecutor(8) as pool:stats=list(pool.map(scan,files))
 pd.DataFrame(stats).to_csv(O/'scan_counts.csv',index=False)
 rows=[]
 for p in C.glob('*.reviews.gz'):
  rows.extend(json.loads(line) for line in gzip.open(p,'rt',encoding='utf8'))
 reviews=pd.DataFrame(rows,columns=['review_hash','gmap_id','time','rating','event','period','reviewer_hash'])
 before=len(reviews);reviews=reviews.drop_duplicates('review_hash')
 reviews.to_csv(O/'individual_reviews.csv',index=False)
 (O/'scan_audit.json').write_text(json.dumps(dict(raw_rows=sum(s['rows'] for s in stats),files=52,before_dedup=before,reviews=len(reviews),duplicate_copies=before-len(reviews),businesses=reviews.gmap_id.nunique(),json_errors=sum(s['json_errors'] for s in stats),invalid_ratings=sum(s['invalid_ratings'] for s in stats)),indent=2))
 print((O/'scan_audit.json').read_text(),flush=True)
if __name__=='__main__':main()
