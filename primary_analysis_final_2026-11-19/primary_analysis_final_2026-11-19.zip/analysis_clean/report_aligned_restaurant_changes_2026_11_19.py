from pathlib import Path
import sys,json
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import pandas as pd
from scipy.stats import t
O=H/'aligned_restaurant_changes_2026_11_19';assert json.loads((O/'verification.json').read_text())['all_passed']
r=pd.read_csv(O/'results.csv');co=pd.read_csv(O/'coefficients.csv');old=pd.read_csv(H/'original_primary_county_fe/controls_preview/results.csv')
pairs=['WPME versus ME','WPME versus MED','ME versus MED'];strata=['nonTrump','Trump','direct'];labels=['Non-Trump','Trump','Pooled']
def stars(p):return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else '+' if p<.1 else ''
def cell(b,se,p):return f'<b>{b:+.3f}{stars(p)}</b><br>({se:.3f})<br><small>p={p:.4f}</small>'
def table(headers,rows):return '<table><tr>'+''.join(f'<th>{x}</th>' for x in headers)+'</tr>'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in row)+'</tr>' for row in rows)+'</table>'
def find(pair,st,spec='full_snapshot',scope='native',window='aligned'):return r[(r.pair==pair)&(r.stratum==st)&(r.specification==spec)&(r.scope==scope)&(r.window==window)].iloc[0]
s=['''<!doctype html><html lang="en"><meta charset="utf-8"><title>Aligned four-week restaurant-change regressions</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:1300px;margin:35px auto;padding:0 25px;color:#23343c}h1,h2{color:#19484c}img{width:100%;height:auto}table{border-collapse:collapse;width:100%;font-size:14px;margin:20px 0}td,th{padding:10px;border-bottom:1px solid #d9e2e4;text-align:center;vertical-align:top}td:first-child,th:first-child{text-align:left}th,.note{background:#eef4f5}.note{padding:18px}small{color:#52636c}a{color:#12647c}</style><body><h1>Restaurant-level pre/post changes: four-week periods aligned to the ban</h1><p>November 19, 2026. Calendar-alignment update of the November 18 restaurant-change specification. Original final report, PDF and GitHub checkpoint are preserved.</p><img src="aligned_ME_WPME_observed.png" alt="Observed restaurant-level before-after means with full-controls county-FE relative change tests"><p><a href="aligned_ME_WPME_observed.pdf">Download figure as PDF</a></p><h2>Methods</h2><ul>
<li><strong>Aligned dates:</strong> pre = December 30, 2016-January 26, 2017; post = January 27-February 23, 2017. Both are 28 days in UTC, with no omitted week or gap. January 27 is the calendar-date boundary, not the precise signing/announcement instant.</li>
<li><strong>Outcome:</strong> average all valid individual raw review ratings within each restaurant-period, then subtract its pre mean from its post mean. Restaurants receive weight one regardless of review volume. Do not average weekly means without accounting for their underlying review counts. No weekly-history requirement or matching is applied.</li>
<li><strong>Groups and eligibility:</strong> original primary-category ME rules; primary-Mediterranean with pre-election hummus OR baba evidence = WPME; primary-Mediterranean with searchable pre-election review text and neither mention = MED. Both period means and usable county/vote data are required. Pairwise samples use counties containing both groups; they differ across panels.</li>
<li><strong>Regression:</strong> restaurant post-minus-pre rating change on positioning and county FE. Stable additive restaurant effects are differenced out; no separate restaurant FE dummy coefficients or county-by-week FE are fitted. Pooled models add positioning-by-Trump-majority and controls-by-Trump-majority interactions; the county-type main effect is absorbed by county FE.</li>
<li><strong>Controls:</strong> same earlier mean rating and log(1 + review count), October 10-November 6, 2016, plus price-tier and listed dine-in, takeout, delivery and alcohol indicators. Missing-data indicators retain incomplete records, with the original 4.6 missing-rating fill constant. Control values are verified unchanged for restaurants shared with November 18. Price/service snapshots are undated and not confirmed to precede the ban.</li>
<li><strong>Inference:</strong> original county-clustered CR1/nonnested FE correction; t df = county clusters minus one. Parentheses show SEs; raw two-sided p values and symbols + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001. These are exploratory correlational associations.</li>
<li><strong>Raw extraction:</strong> fill the previously omitted January 23-29 raw-review gap for the complete original candidate frame and combine it with the frozen raw outcome reviews. Overlap with the longer ME/WPME raw extraction matches exactly. Use all ratings, including textless reviews and those without food mentions.</li>
<li><strong>Comparison design:</strong> native aligned-period samples allow newly eligible restaurants and exclude those lacking either new period. Common-sample checks refit both the original and aligned dates on exactly the same restaurants and shared counties. The prior weekly event studies remain separate diagnostics.</li></ul>''']
for k,pair in enumerate(pairs):
 first,second=pair.split(' versus ');models=[find(pair,st) for st in strata]
 def coefcell(m,term):
  z=co[(co.id==m.id)&(co.term==term)]
  if z.empty:return '-'
  z=z.iloc[0];p=2*t.sf(abs(z.estimate/z.se),int(m.counties)-1);return cell(z.estimate,z.se,p)
 rows=[[f'{first} indicator (reference: {second})']+[coefcell(m,'treated') for m in models],
       [f'{first} x Trump-majority']+['-','-',coefcell(models[2],'interaction')],
       ['Earlier rating/activity controls']+['Yes']*3,['Price-tier controls']+['Yes']*3,['Service/alcohol controls']+['Yes']*3,
       ['Controls x Trump-majority','-','-','Yes'],['County FE']+['Yes']*3,['Restaurant weights']+['Equal']*3,
       ['Restaurants']+[f'{int(m.restaurants):,}' for m in models],
       [f'{first} / {second} N']+[f'{int(m.first_restaurants):,} / {int(m.second_restaurants):,}' for m in models],
       ['County clusters']+[str(int(m.counties)) for m in models],
       ['Underlying pre / post reviews']+[f'{int(m.reviews_pre):,} / {int(m.reviews_post):,}' for m in models]]
 s.append(f'<h2>Panel {chr(65+k)}. {pair}: all controls</h2>'+table(['Variable / specification']+labels,rows))
s.append('<p><strong>Pooled interpretation:</strong> the positioning coefficient is the non-Trump contrast; the interaction is the direct Trump-minus-non-Trump difference in contrasts. Their sum is the Trump contrast. The interaction tests county-type differences directly, rather than comparing separate significance levels.</p><h2>Timing comparison on common restaurants: all controls</h2>')
rows=[]
for pair in pairs:
 for st in strata:
  a=find(pair,st,scope='common',window='original');b=find(pair,st,scope='common');rows.append([pair,{'nonTrump':'Non-Trump','Trump':'Trump','direct':'Direct county-type difference'}[st],f'{int(a.restaurants):,}',cell(a.estimate,a.se,a.p),cell(b.estimate,b.se,b.p)])
s.append(table(['Comparison','County type / test','Same N','Original dates','Aligned dates'],rows))
s.append('<p>Original dates: Dec 26-Jan 22 versus Jan 30-Feb 26. Aligned dates: Dec 30-Jan 26 versus Jan 27-Feb 23. Both columns use identical restaurants and county support within each row. Controls and inference are held fixed.</p><h2>All-controls results: original native sample versus aligned native sample</h2>')
rows=[]
for pair in pairs:
 for st in strata:
  a=old[(old.pair==pair)&(old.stratum==st)&(old.specification=='full_snapshot')].iloc[0];b=find(pair,st)
  rows.append([pair,{'nonTrump':'Non-Trump','Trump':'Trump','direct':'Direct'}[st],f'{int(a.restaurants):,} / {int(b.restaurants):,}',cell(a.estimate,a.se,a.p),cell(b.estimate,b.se,b.p)])
s.append(table(['Comparison','County test','Original / aligned N','November 18 native','Aligned native'],rows))
s.append('<h2>Control checks: aligned dates, fixed sample within pair</h2>')
for pair in pairs:
 rows=[]
 for st in strata:
  rows.append([{'nonTrump':'Non-Trump','Trump':'Trump','direct':'Direct county-type difference'}[st]]+[cell(find(pair,st,spec).estimate,find(pair,st,spec).se,find(pair,st,spec).p) for spec in ['baseline','history','full_snapshot']])
 s.append(f'<h3>{pair}</h3>'+table(['Test','No added controls','Earlier controls','All controls'],rows))
s.append('<p class="note"><strong>Summary:</strong> the aligned all-controls WPME-ME contrast is +0.242 in Trump counties (p=.078), -0.075 in non-Trump counties (p=.134), and the direct difference is +0.317 (p=.023). On common restaurants, the corresponding direct difference is +0.299 (p=.029). ME-MED and WPME-MED aligned contrasts are not statistically clear. Calendar alignment does not establish parallel trends or a causal ban effect.</p><p><a href="results.csv">All 81 native/common model results</a> · <a href="coefficients.csv">Complete coefficients and SEs</a> · <a href="analysis_data.csv">Aligned restaurant-level regression data</a> · <a href="observed_period_means.csv">Observed group means</a> · <a href="common_restaurant_memberships.csv">Common-sample memberships</a> · <a href="design.json">Definitions, windows and control design</a> · <a href="verification.json">Independent verification</a> · <a href="../original_primary_county_fe/regression_tables.html">Unchanged November 18 tables</a></p></body></html>')
(O/'aligned_regression_tables.html').write_text(''.join(s),encoding='utf8');print('Aligned restaurant-change regression tables written.')
