.libPaths(c('.r-library',.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
setFixest_nthreads(1)
a <- 'analysis_clean/aligned_restaurant_changes_2026_11_19'
x <- fread(file.path(a,'analysis_data.csv'),colClasses=c(county_fips='character'))
r <- fread('analysis_clean/extended_raw_timeline_2026_11_19/raw_extraction/individual_reviews.csv',select=c('gmap_id','time','rating'),integer64='double')
d <- merge(x[group_hummus_or_baba %chin% c('ME','WPME')], unique(r[,.(gmap_id)]), by='gmap_id')
d[,treated:=as.integer(group_hummus_or_baba=='WPME')]
ms <- function(s) as.numeric(as.POSIXct(s,tz='UTC'))*1000
ratings <- function(from,to,tag) {
 z <- r[gmap_id %chin% d$gmap_id & time>=ms(from) & time<ms(to),.(avg=mean(rating),n=.N),by=gmap_id]
 setnames(z,c('avg','n'),paste0(tag,c('_rating','_reviews')))
 z
}
for (row in list(c('2016-12-30','2017-01-27','a'),c('2017-01-27','2017-02-24','b'),c('2016-12-16','2017-01-27','c'),c('2017-01-27','2017-03-10','d'))) {
 d<-merge(d,ratings(row[1],row[2],row[3]),by='gmap_id')
}
stopifnot(max(abs(d$a_rating-d$rating_pre))<1e-10, max(abs(d$b_rating-d$rating_post))<1e-10, all(d$a_reviews==d$reviews_pre), all(d$b_reviews==d$reviews_post))
hold <- d[,uniqueN(treated),by=county_fips][V1==2,county_fips]
d<-d[county_fips %chin% hold]
covs<-fromJSON(file.path(a,'design.json'))$specifications$full_snapshot
historical <- fread('analysis_clean/original_primary_county_fe/individual_reviews.csv',
                    select=c('gmap_id','event','period','rating','review_hash'))
historical <- historical[event=='Election' & period %chin% c('pre','post')]
stopifnot(!anyDuplicated(historical$review_hash))
history <- historical[, .(long_mean=mean(rating),long_count=.N), by=gmap_id]
d <- merge(d, history, by='gmap_id', all.x=TRUE)
d[, long_missing := as.integer(is.na(long_mean))]
d[long_missing==1L, `:=`(long_mean=4.6,long_count=0L)]
d[, long_log_count := log1p(long_count)]
long_covs <- c('long_mean','long_missing','long_log_count',
               setdiff(covs,c('rating_control','rating_missing','log_earlier_reviews')))
for(v in union(covs,long_covs)) d[,(paste0(v,'_T')):=get(v)*trump]
d[,interaction:=treated*trump]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
results<-list()
adjusted_lines <- list()
main_coefficients <- list()
for (weeks in c(4,6)) for (history_weeks in c(4,8)) {
 active_controls <- if(history_weeks==4) covs else long_covs
 d[,change_now:=if(weeks==4) b_rating-a_rating else d_rating-c_rating]
 for (st in c('Trump','nonTrump','direct')) {
  z<-if(st=='direct') d else d[trump==as.integer(st=='Trump')]
  terms<-if(st=='direct') c('treated','interaction',active_controls,paste0(active_controls,'_T')) else c('treated',active_controls)
  f<-feols(as.formula(paste('change_now~',paste(terms,collapse='+'),'|county_fips')),data=z,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  target<-if(st=='direct') 'interaction' else 'treated'
  ct<-coeftable(f)[target,];ci<-as.matrix(confint(f))[target,]
  stopifnot(nobs(f)==nrow(z))
  if (weeks==6 && history_weeks==8) {
   main_coefficients[[st]] <- as.data.table(coeftable(f), keep.rownames="term")
   setnames(main_coefficients[[st]], c("term","estimate","se","statistic","p"))
   main_coefficients[[st]][,stratum:=st]
  }
  if (weeks==6 && history_weeks==8 && st!='direct') {
   # Standardize both groups over the same observed covariate and county mix.
   # Changing the group indicator shifts every fitted value by its coefficient.
   beta <- unname(coef(f)['treated'])
   shared_mean <- mean(fitted(f)-beta*z$treated)
   stopifnot(abs(mean(fitted(f))-mean(z$change_now))<1e-10)
   adjusted_lines[[st]] <- data.table(stratum=st,group=c('ME','WPME'),
                                       adjusted_change=shared_mean+c(0,beta))
  }
  results[[length(results)+1]]<-data.table(weeks,history_weeks,stratum=st,N=nrow(z),counties=uniqueN(z$county_fips),reviews_pre=sum(if(weeks==4) z$a_reviews else z$c_reviews),reviews_post=sum(if(weeks==4) z$b_reviews else z$d_reviews),estimate=unname(ct[1]),se=unname(ct[2]),p=unname(ct[4]),low=unname(ci[1]),high=unname(ci[2]))
 }
}
result<-rbindlist(results)
for (w in c(4,6)) for (hw in c(4,8)) {
 stopifnot(abs(sum(result[weeks==w & history_weeks==hw,estimate]*c(1,-1,-1)))<1e-8)
}
old <- fread(file.path(a,'longer_rating_history','outcome_window_common_sample.csv'))
replicated <- result[history_weeks==4, names(old), with=FALSE]
stopifnot(isTRUE(all.equal(old,replicated,tolerance=1e-10)))
fwrite(result,file.path(a,'longer_rating_history','outcome_window_by_rating_history.csv'))
plot_means <- d[, .(mean_pre=mean(c_rating), mean_post=mean(d_rating), restaurants=.N,
                    reviews_pre=sum(c_reviews), reviews_post=sum(d_reviews)),
                by=.(trump, group=group_hummus_or_baba)]
fwrite(plot_means,file.path(a,'longer_rating_history','six_week_plot_means.csv'))
fwrite(rbindlist(adjusted_lines),file.path(a,'longer_rating_history','six_week_adjusted_lines.csv'))
fwrite(rbindlist(main_coefficients),file.path(a,'longer_rating_history','six_week_main_coefficients.csv'))
summary_columns <- c("county_fips","trump","treated","c_rating","d_rating","c_reviews","d_reviews",
                     "long_count",long_covs)
fwrite(d[,..summary_columns],file.path(a,'longer_rating_history','six_week_summary_inputs.csv'))
print(result)
