"""Build a self-contained results report for the ban-aligned ME/WPME analysis."""
from base64 import b64encode
from html import escape
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / ".analysis-python"))
import numpy as np
import pandas as pd
from scipy.stats import t

OUT = HERE / "aligned_restaurant_changes_2026_11_19" / "longer_rating_history"
WEEKLY = HERE / "ban_friday_event_study_2026_11_19"
data = pd.read_csv(OUT / "six_week_summary_inputs.csv", dtype={"county_fips":str})
data["change"] = data.d_rating - data.c_rating
models = pd.read_csv(OUT / "outcome_window_by_rating_history.csv")
main = models.query("weeks == 6 and history_weeks == 8").set_index("stratum")
coef = pd.read_csv(OUT / "six_week_main_coefficients.csv").set_index(["stratum", "term"])
means = pd.read_csv(OUT / "six_week_plot_means.csv").set_index(["trump", "group"])
weekly = pd.read_csv(WEEKLY / "model_summary.csv")
assert len(data) == main.loc["direct", "N"] == 2346
for st in main.index:
    term = "interaction" if st == "direct" else "treated"
    np.testing.assert_allclose(coef.loc[(st, term), ["estimate", "se", "p"]].astype(float),
                               main.loc[st, ["estimate", "se", "p"]].astype(float))


def table(header, rows):
    return ("<div class='table-wrap'><table><thead><tr>" +
            "".join(f"<th scope='col'>{escape(str(x))}</th>" for x in header) +
            "</tr></thead><tbody>" +
            "".join("<tr><th scope='row'>" + escape(str(row[0])) + "</th>" +
                    "".join(f"<td>{x}</td>" for x in row[1:]) + "</tr>" for row in rows) +
            "</tbody></table></div>")


def picture(path, alt, caption):
    encoded = b64encode(path.read_bytes()).decode("ascii")
    return f'<figure><img src="data:image/png;base64,{encoded}" alt="{escape(alt)}"><figcaption>{caption}</figcaption></figure>'


def result_cell(row):
    p = row.p
    stars = "***" if p < .001 else "**" if p < .01 else "*" if p < .05 else "+" if p < .10 else ""
    return f"<strong>{row.estimate:+.3f}{stars}</strong><br>({row.se:.3f})<br><small>p = {p:.3f}</small>"


parts = ['''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ME and WPME | Travel ban results</title>
<style>
:root{color-scheme:light}body{max-width:1120px;margin:36px auto;padding:0 22px;color:#203442;font:16px/1.6 system-ui,sans-serif}
h1,h2{line-height:1.2;color:#164950}h1{font-size:2.35rem}h2{margin-top:2.5em}
nav{display:flex;flex-wrap:wrap;gap:8px 20px}a{color:#076783}.lead{background:#eff6f6;border-left:4px solid #176f91;padding:15px 20px}
figure{margin:24px 0 32px}img{display:block;width:100%;height:auto}figcaption,small,.note{color:#465c69;font-size:.9rem}
.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.88rem;margin:14px 0 20px;font-variant-numeric:tabular-nums}
th,td{padding:8px 10px;border-bottom:1px solid #dce6e9;text-align:right;vertical-align:top}thead th{background:#edf5f6}
th:first-child,td:first-child{text-align:left}tbody th{font-weight:550}details{margin:14px 0}summary{cursor:pointer;font-weight:650}
@media print{body{margin:0;max-width:none;padding:0}figure,tr{break-inside:avoid}nav{display:none}}
</style></head><body>
<h1>Restaurant ratings around the travel ban</h1>
<p>ME and WPME in Trump-majority and non-Trump-majority counties</p>
<nav><a href="#figures">Figures</a><a href="#regressions">Regressions</a><a href="#descriptives">Descriptives</a><a href="#correlations">Correlations</a><a href="#methods">Methods</a></nav>
<p class="lead">In the six-week restaurant-level model with eight weeks of historical controls, WPME gained 0.213 stars relative to ME in Trump-majority counties (p = .028). The corresponding change was −0.004 stars elsewhere (p = .926). The direct county-type difference was +0.216 stars (95% CI 0.024 to 0.409, p = .028).</p>
<h2 id="figures">Pre/post ratings and weekly trends</h2>''']
parts += [
    picture(OUT / "six_week_outcome_eight_week_history.png",
            "Observed pre and post rating levels for both positioning groups",
            "<b>Figure 1. Observed rating levels.</b> Each period mean gives each restaurant equal weight. Annotations show the adjusted relative change from the regression."),
    picture(OUT / "six_week_adjusted_pre_post.png",
            "Model-adjusted changes from zero for ME and WPME",
            "<b>Figure 2. Adjusted pre/post changes.</b> Both groups start at zero. The endpoints evaluate the two groups at the same mix of counties and controls within each panel. The Trump-county endpoints differ by 0.213 stars."),
    picture(WEEKLY / "event_study_all_controls.png",
            "Friday–Thursday weekly trends with a dashed January 27 marker",
            "<b>Figure 3. Friday–Thursday weekly event study.</b> This is the attached specification. The weekly model uses restaurant and county-by-week fixed effects and its own sample and history controls. Its average post change is +0.260 stars in Trump-majority counties (p = .041) and −0.013 stars elsewhere (p = .788)."),
]
parts.append('<h2 id="regressions">Regression results</h2><h3>Six-week restaurant change with eight-week history</h3>')
columns = ["Trump", "nonTrump", "direct"]
rows = [["WPME indicator (ME reference)"] + [result_cell(coef.loc[(st, "treated")]) for st in columns],
        ["WPME × Trump-majority", "—", "—", result_cell(coef.loc[("direct", "interaction")])]]
for label, values in [
    ("Historical rating and review activity", ["Yes"] * 3),
    ("Price, service, alcohol and missing-data controls", ["Yes"] * 3),
    ("Controls × Trump-majority", ["—", "—", "Yes"]),
    ("County fixed effects", ["Yes"] * 3),
    ("Restaurants", [f"{main.loc[st, 'N']:,}" for st in columns]),
    ("County clusters", [main.loc[st, "counties"] for st in columns]),
]:
    rows.append([label, *values])
parts.append(table(["Variable", "Trump-majority", "Non-Trump-majority", "Pooled"], rows))
parts.append('<p class="note">County-clustered standard errors in parentheses and raw two-sided p values below. + p &lt; .10, * p &lt; .05, ** p &lt; .01, *** p &lt; .001. In the pooled column, the WPME indicator is the non-Trump contrast and the interaction is the direct difference between county types.</p>')
parts.append('<h3>Window and history checks on the same restaurants</h3>')
rows = []
for (weeks, history), block in models.groupby(["weeks", "history_weeks"]):
    z = block.set_index("stratum")
    rows.append([f"{weeks} weeks before and after / {history} weeks of history",
                 *[result_cell(z.loc[st]) for st in columns]])
parts.append(table(["Outcome windows / earlier controls", "Trump-majority", "Non-Trump-majority", "Direct difference"], rows))
parts.append('<h3>Weekly event study</h3>')
parts.append(table(["County type / specification", "ME / WPME N", "Avg. post change", "95% CI", "p"],
                   [[f"{'Trump' if x.trump else 'Non-Trump'} / {x.spec}", f"{x.ME:,} / {x.WPME:,}",
                     f"{x.average_post:+.3f}", f"{x.low:+.3f} to {x.high:+.3f}", f"{x.average_post_p:.3f}"]
                    for x in weekly.itertuples()]))

parts.append('<h2 id="descriptives">Descriptive statistics</h2><p>Six-week restaurant regression sample. Rating cells show mean (restaurant-level SD).</p>')
rows = []
for tr in [1, 0]:
    for treated, label in [(0, "ME"), (1, "WPME")]:
        z = data.loc[data.trump.eq(tr) & data.treated.eq(treated)]
        m = means.loc[(tr, label)]
        assert len(z) == m.restaurants
        np.testing.assert_allclose([z.c_rating.mean(),z.d_rating.mean()],[m.mean_pre,m.mean_post])
        rows.append([f"{'Trump' if tr else 'Non-Trump'} / {label}", f"{len(z):,}",
                     *[f"{z[v].mean():.3f} ({z[v].std():.3f})" for v in ["c_rating", "d_rating", "change"]],
                     f"{z.c_reviews.sum():,} / {z.d_reviews.sum():,}",
                     f"{z.long_count.median():.0f}", f"{z.long_missing.mean():.1%}"])
parts.append(table(["County type / group", "Restaurants", "Pre rating", "Post rating", "Rating change",
                    "Pre / post reviews", "Median earlier reviews", "Earlier rating missing"], rows))

core = {"treated":"WPME label", "trump":"Trump majority", "c_rating":"Pre rating",
        "d_rating":"Post rating", "change":"Rating change", "long_mean":"Earlier rating",
        "long_log_count":"Log earlier reviews"}
attributes = {"long_missing":"Earlier rating missing", "price_two":"Price $$", "price_high":"Price $$$/$$$$",
              "price_unknown":"Price missing", "dine_in_listed":"Dine-in listed", "takeout_listed":"Takeout listed",
              "delivery_listed":"Delivery listed", "service_unknown":"Service record missing",
              "alcohol_listed":"Alcohol listed", "alcohol_unknown":"Alcohol record missing"}
assert set(attributes).issubset(data.columns)
parts.append('<details><summary>Price, service and missing-data descriptives</summary>')
parts.append(table(["Characteristic", "Trump ME", "Trump WPME", "Non-Trump ME", "Non-Trump WPME"],
                   [[label, *[f"{data.loc[data.trump.eq(tr)&data.treated.eq(g), col].mean():.1%}" for tr in (1,0) for g in (0,1)]]
                    for col,label in attributes.items()]))
parts.append('</details><h2 id="correlations">Correlations</h2><p>Pearson correlations on the restaurant regression sample, before adjustment for county fixed effects. Stars use two-sided county-clustered delta-method tests with counties minus one degrees of freedom. + p &lt; .10, * p &lt; .05, ** p &lt; .01, *** p &lt; .001. Tests are unadjusted for multiple comparisons. Binary indicators are coded 0/1. Earlier rating uses 4.6 when history is missing. Rating change equals post minus pre, so its correlations with both outcomes are partly mechanical.</p>')


def correlation_matrix(frame, labels):
    cols = list(labels)
    corr = frame[cols].corr()
    n = len(frame)
    groups = frame.county_fips.nunique()
    standardized = (frame[cols] - frame[cols].mean()) / frame[cols].std(ddof=0)

    def cell(col, other):
        rho = corr.at[col, other]
        if pd.isna(rho):
            return "—"
        if col == other:
            return "1.00"
        x, y = standardized[col], standardized[other]
        # Influence function of Pearson r, allowing restaurants within counties to co-vary.
        score = (x*y - rho*(x*x + y*y)/2).groupby(frame.county_fips).sum()
        se = np.sqrt(groups / (groups - 1) * score.pow(2).sum()) / n
        p = 2*t.sf(abs(rho/se), groups-1) if se > 0 else np.nan
        stars = "***" if p < .001 else "**" if p < .01 else "*" if p < .05 else "+" if p < .10 else ""
        return f'{rho:.2f}<sup title="p = {p:.4g}">{stars}</sup>'

    rows = [[f"{i+1}. {labels[col]}", *[cell(col, other) if j <= i else ""
                                        for j, other in enumerate(cols)]]
            for i, col in enumerate(cols)]
    return table(["Variable", *range(1, len(cols)+1)], rows)


parts.append('<h3>Pooled sample (N = 2,346)</h3>')
parts.append(correlation_matrix(data, core))
for tr, label in [(1,"Trump-majority"),(0,"Non-Trump-majority")]:
    block = data[data.trump.eq(tr)]
    parts.append(f'<details><summary>{label} correlations (N = {len(block):,})</summary>')
    parts.append(correlation_matrix(block,{k:v for k,v in core.items() if k!="trump"}))
    parts.append('</details>')
parts.append('<details><summary>Full pooled matrix including price and service controls</summary>')
parts.append(correlation_matrix(data, core | attributes))
parts.append('''</details><h2 id="methods">Methods</h2><ul>
<li><b>Groups.</b> ME follows the original primary-category rules. WPME is primary Mediterranean with a hummus or baba ghanoush mention in pre-election reviews.</li>
<li><b>Restaurant model.</b> Average all rated raw reviews in each period, then regress each restaurant's post-minus-pre rating change on positioning, controls and county fixed effects. Each restaurant has equal weight. The common sample contains 2,346 ME and WPME restaurants observed under both aligned window definitions, in counties containing both groups.</li>
<li><b>Dates.</b> The main pre-period is December 16, 2016–January 26, 2017. The post-period is January 27–March 9, 2017. The four-week check uses December 30–January 26 and January 27–February 23. Both use January 27 as the calendar-date boundary in UTC.</li>
<li><b>Controls.</b> The eight-week history pools October 10–November 6 and November 14–December 11. It supplies the mean rating and log(1 + review count), with a missing-rating indicator. The four-week history uses the first block. Models add price tier, listed dine-in, takeout, delivery and alcohol, and indicators for missing records. Price and service metadata are undated.</li>
<li><b>Weekly model.</b> Friday–Thursday bins are plotted at Monday midpoints, with the January 27 marker. The plotted model uses the original four-week historical controls alongside price and service measures interacted with week. Each restaurant receives equal total weight across its observed weeks. The bars show pointwise 95% confidence intervals clustered by county. The weekly sample requires two observed pre bins and one post bin in the original paired-ban cohort.</li>
<li><b>Interpretation.</b> The restaurant and weekly estimates are correlational. Earlier pretrend diagnostics varied by window and specification.</li>
</ul></body></html>''')
target = OUT / "travel_ban_summary_results.html"
target.write_text("\n".join(parts), encoding="utf-8")
print(f"Wrote {target.name} with three embedded figures and {sum(p.count('<table>') for p in parts)} tables.")
