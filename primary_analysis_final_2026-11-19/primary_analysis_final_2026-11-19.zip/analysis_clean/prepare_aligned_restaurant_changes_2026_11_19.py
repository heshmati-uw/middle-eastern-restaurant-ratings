from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
O=H/'aligned_restaurant_changes_2026_11_19';B=H/'original_primary_county_fe'
old=pd.read_csv(B/'individual_reviews.csv');gap=pd.read_csv(O/'raw_gap_extraction/individual_reviews.csv')
extended=pd.read_csv(H/'extended_raw_timeline_2026_11_19/raw_extraction/individual_reviews.csv');ids=set(extended.gmap_id)
lo=int(pd.Timestamp('2017-01-23',tz='UTC').timestamp()*1000);hi=int(pd.Timestamp('2017-01-30',tz='UTC').timestamp()*1000)
e=extended[extended.time.between(lo,hi-1)];g=gap[gap.gmap_id.isin(ids)];assert set(e.review_hash)==set(g.review_hash)
raw=pd.concat([old,gap],ignore_index=True);assert raw.review_hash.is_unique
codes=pd.read_csv(B/'restaurants.csv',dtype={'county_fips':str});codes=codes[codes.group_hummus_or_baba.isin(['ME','WPME','MED'])&codes.county_fips.notna()&codes.gop_share.notna()].copy()
codes['trump']=codes.gop_share.gt(.5).astype(int)
windows={'pre':('2016-12-30','2017-01-27'),'post':('2017-01-27','2017-02-24')}
periods=[]
for per,(a,b) in windows.items():
 start=int(pd.Timestamp(a,tz='UTC').timestamp()*1000);end=int(pd.Timestamp(b,tz='UTC').timestamp()*1000)
 z=raw[raw.time.ge(start)&raw.time.lt(end)&raw.gmap_id.isin(codes.gmap_id)]
 p=z.groupby('gmap_id').rating.agg(**{f'rating_{per}':'mean',f'reviews_{per}':'size'});periods.append(p)
d=codes.merge(periods[0].join(periods[1],how='outer').reset_index(),on='gmap_id',how='left',validate='one_to_one');d['paired']=d.rating_pre.notna()&d.rating_post.notna();d['change']=d.rating_post-d.rating_pre
d.to_csv(O/'all_candidate_period_means.csv',index=False);d=d[d.paired].copy();d['event']='Ban'
early=old[(old.event=='Election')&(old.period=='pre')].groupby('gmap_id').rating.agg(earlier_rating='mean',earlier_reviews='size')
d=d.merge(early,on='gmap_id',how='left',validate='one_to_one');d['rating_missing']=d.earlier_rating.isna().astype(int);d['rating_control']=d.earlier_rating.fillna(4.6);d['earlier_reviews']=d.earlier_reviews.fillna(0).astype(int);d['log_earlier_reviews']=np.log1p(d.earlier_reviews)
a=pd.read_csv(H/'full_pre_election_core/attribute_matching/restaurant_attributes.csv');attrs=['price_tier','dine_in','takeout','delivery','alcohol','service_recorded','offerings_recorded']
d=d.merge(a[['gmap_id']+attrs],on='gmap_id',how='left',validate='one_to_one')
d['price_unknown']=d.price_tier.isna().astype(int);d['price_two']=d.price_tier.eq(2).astype(int);d['price_high']=d.price_tier.ge(3).astype(int)
d['service_unknown']=(~d.service_recorded.eq(1)).astype(int);d['alcohol_unknown']=(~d.offerings_recorded.eq(1)).astype(int)
for name in ['dine_in','takeout','delivery']:d[name+'_listed']=(d[name].eq(1)&d.service_unknown.eq(0)).astype(int)
d['alcohol_listed']=(d.alcohol.eq(1)&d.alcohol_unknown.eq(0)).astype(int)
design=json.loads((B/'controls_preview/design.json').read_text());cols=design['specifications']['full_snapshot'];assert d[cols].notna().all().all();d.to_csv(O/'analysis_data.csv',index=False)
base=pd.read_csv(B/'controls_preview/analysis_data.csv',dtype={'county_fips':str});joint=d.merge(base,on='gmap_id',suffixes=('_new','_old'),validate='one_to_one')
for col in cols:np.testing.assert_allclose(joint[col+'_new'],joint[col+'_old'],atol=1e-12)
protected=[B/'regression_tables.html',H.parent/'output/pdf/restaurant_positioning_ban_results.pdf'];frozen={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected};(O/'protected_hashes.json').write_text(json.dumps(frozen))
design.update(status='Separate four-week ban-aligned restaurant-change analysis; original final untouched',windows_utc_end_exclusive=windows,estimand='One overall post-minus-pre rating change per restaurant; county FE and equal restaurant weights',imputation='Original 4.6 rating imputation constant retained',new_gap_reviews=len(gap),gap_overlap_hashes_verified=len(e),candidate_restaurants=len(codes),paired_restaurants=len(d),common_control_values_unchanged=True)
(O/'design.json').write_text(json.dumps(design,indent=2));print(json.dumps({k:design[k] for k in ['candidate_restaurants','paired_restaurants','new_gap_reviews','gap_overlap_hashes_verified']},indent=2))
