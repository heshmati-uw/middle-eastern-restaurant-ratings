from pathlib import Path
import sys
sys.path.insert(0,'.analysis-python')
import pandas as pd,numpy as np
from scipy.stats import t
O=Path('analysis_clean/extended_raw_timeline_2026_11_19');w=pd.read_csv(O/'restaurant_week_ratings.csv',dtype={'county_fips':str});rows=[]
for (tr,g,week),z in w.groupby(['trump','group','week']):
 assert z.gmap_id.is_unique
 n=len(z);mu=z.rating.mean();scores=(z.rating-mu).groupby(z.county_fips).sum();G=len(scores);assert G>1
 se=float(np.sqrt(G/(G-1)*np.square(scores).sum()/n**2));crit=t.ppf(.975,G-1)
 rows.append(dict(trump=tr,group=g,week=week,mean_rating=mu,restaurants=n,reviews=z.reviews.sum(),county_clusters=G,mean_se=se,mean_low=mu-crit*se,mean_high=mu+crit*se))
a=pd.DataFrame(rows);base=pd.read_csv(O/'weekly_group_means.csv');merged=base.merge(a,on=['trump','group','week'],suffixes=('','_check'),validate='one_to_one')
np.testing.assert_allclose(merged.mean_rating,merged.mean_rating_check,atol=1e-12)
np.testing.assert_array_equal(merged.restaurants,merged.restaurants_check)
a.to_csv(O/'weekly_mean_confidence_intervals.csv',index=False)
p=Path('analysis_clean/plot_ban_zoom_2026_11_19.R');s=p.read_text(encoding='utf8');s=s.replace("'weekly_group_means.csv'","'weekly_mean_confidence_intervals.csv'")
s=s.replace('range(d$mean_rating)+c(-.08,.1)','range(c(d$mean_low,d$mean_high))+c(-.04,.08)')
needle="   lines(a$date,value,type='o'"
s=s.replace(needle,"   if(!counts)arrows(a$date,a$mean_low,a$date,a$mean_high,angle=90,code=3,length=.035,col=adjustcolor(cols[g],alpha.f=.7),lwd=1.4)\n"+needle)
s=s.replace('Same 2,430-restaurant paired ban cohort throughout; no matching, no smoothing and no controls applied to the plotted means.', 'Error bars: pointwise 95% CIs for weekly means, clustered by county; t critical values use counties minus one.')
s=s.replace('Descriptive paths are not causal estimates. This extended view does not alter the November 18 final analysis.', 'Error-bar overlap is not a test of relative pre/post changes. Descriptive means; November 18 final analysis unchanged.')
p.write_text(s,encoding='utf8')
p=Path('analysis_clean/report_extended_raw_timeline_2026_11_19.py');s=p.read_text(encoding='utf8');s=s.replace('This is a horizontal zoom of the same observed series and uses the same rating scale for both county types.', 'This is a horizontal zoom of the same observed series and uses the same rating scale for both county types. Error bars are pointwise 95% confidence intervals for each weekly equal-restaurant mean, using county-clustered intercept-only standard errors and t critical values with county clusters minus one degrees of freedom. They do not test relative pre/post changes; overlap alone is not a significance test.')
s=s.replace('Zoomed weekly means and counts</a>', 'Zoomed weekly means, confidence intervals and counts</a>')
p.write_text(s,encoding='utf8')
print('Computed county-clustered mean intervals for',len(a),'group-weeks.')
