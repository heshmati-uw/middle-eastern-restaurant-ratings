args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'extended_raw_timeline_2026_11_19')
d<-read.csv(file.path(o,'weekly_group_means.csv'));d$date<-as.Date(d$week);n<-read.csv(file.path(o,'cohort_counts.csv'))
cols<-c(ME='#B44E43',WPME='#176F91');events<-as.Date(c('2016-11-08','2017-01-27'));eventcols<-c('#333333','#665193')
draw<-function(counts=FALSE){
 par(mfrow=c(2,1),mar=c(3.8,5.1,5.3,1.5),oma=c(6.8,0,4.5,0),las=1,family='sans')
 yy<-if(counts)range(c(0,d$restaurants))*c(1,1.1) else range(d$mean_rating)+c(-.08,.1)
 ticks<-seq(as.Date('2016-07-01'),as.Date('2017-05-01'),by='month')
 for(tr in c(1,0)){
  z<-d[d$trump==tr,]
  if(counts)yy<-c(0,max(z$restaurants)*1.1)
  plot(as.Date(c('2016-07-01','2017-05-05')),yy,type='n',axes=FALSE,xlab='',ylab=if(counts)'Restaurants with rated reviews' else 'Mean restaurant rating (stars)')
  abline(h=pretty(yy),col='#E3E8EB')
  rect(as.Date('2016-11-07'),yy[1],as.Date('2016-11-14'),yy[2],col=adjustcolor('#A5B2BE',alpha.f=.15),border=NA)
  rect(as.Date('2017-01-23'),yy[1],as.Date('2017-01-30'),yy[2],col=adjustcolor('#A5B2BE',alpha.f=.15),border=NA)
  axis(2);axis.Date(1,at=ticks,format='%b %Y',cex.axis=.85);box(bty='l',col='#8C999F')
  for(g in c('ME','WPME')){
   a<-z[z$group==g,];a<-a[order(a$date),];value<-if(counts)a$restaurants else a$mean_rating
   lines(a$date,value,type='o',col=cols[g],lwd=2.4,pch=if(g=='ME')15 else 16,cex=.7,lty=if(g=='ME')1 else 2)
  }
  for(j in 1:2){abline(v=events[j],lty=2,lwd=2,col=eventcols[j]);mtext(c('Election: Nov 8, 2016','Travel ban: Jan 27, 2017')[j],side=3,at=events[j],line=.7,font=2,cex=.95,col=eventcols[j])}
  nn<-n[n$trump==tr,];cohort<-sprintf('%s: fixed cohort %s',nn$group,format(nn$cohort_restaurants,big.mark=','))
  mtext(paste(if(tr==1)'Trump-majority counties' else 'Non-Trump-majority counties',paste(cohort,collapse=' | '),sep=' | '),side=3,line=3.3,font=2,cex=1.05)
  legend('topleft',legend=c('ME','WPME'),col=cols,lty=1:2,pch=c(15,16),lwd=2,bty='n',horiz=TRUE,cex=.95,inset=c(.01,.005))
  mtext('Week starting (Monday-Sunday averages)',side=1,line=2.5,cex=.85)
 }
 mtext(if(counts)'Review activity in the fixed restaurant cohort' else 'Observed ratings before and after the election and travel ban',side=3,outer=TRUE,line=1.6,font=2,cex=1.35)
 mtext('July 4, 2016-April 30, 2017 | Original raw reviews | Final 11/18 ME/WPME definitions',side=3,outer=TRUE,line=.1,cex=.95)
 mtext('Dashed lines mark exact event dates. Shaded bands mark the weeks containing each event; these means mix pre/post reviews.',side=1,outer=TRUE,line=.8,cex=.83)
 mtext('Equal weight per observed restaurant within each week. Zero-review weeks are absent; weekly restaurant composition varies.',side=1,outer=TRUE,line=2.1,cex=.83)
 mtext('Same 2,430-restaurant paired ban cohort throughout; no matching, no smoothing and no controls applied to the plotted means.',side=1,outer=TRUE,line=3.4,cex=.83)
 mtext('Descriptive paths are not causal estimates. This extended view does not alter the November 18 final analysis.',side=1,outer=TRUE,line=4.7,cex=.83)
}
for(counts in c(FALSE,TRUE)){
 name<-if(counts)'extended_weekly_counts' else 'extended_observed_ratings'
 png(file.path(o,paste0(name,'.png')),width=2400,height=1900,res=175);draw(counts);dev.off()
 pdf(file.path(o,paste0(name,'.pdf')),width=13.7,height=10.9,useDingbats=FALSE);draw(counts);dev.off()
}
