from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
from scipy.stats import t as td
O=H/'aligned_restaurant_changes_2026_11_19';r=pd.read_csv(O/'results.csv');coef=pd.read_csv(O/'coefficients.csv');new=pd.read_csv(O/'analysis_data.csv',dtype={'county_fips':str});old=pd.read_csv(H/'original_primary_county_fe/controls_preview/analysis_data.csv',dtype={'county_fips':str});members=pd.read_csv(O/'common_restaurant_memberships.csv');specs=json.loads((O/'design.json').read_text())['specifications']
def within(a,c):
 a=np.asarray(a,float);n=np.bincount(c);s=np.zeros((len(n),a.shape[1]));np.add.at(s,c,a);return a-s[c]/n[c,None]
checks=[]
for row in r.itertuples():
 first,second=row.pair.split(' versus ');q=(new if row.window=='aligned' else old).copy();q=q[q.group_hummus_or_baba.isin([first,second])];shared=q.groupby('county_fips').group_hummus_or_baba.nunique().eq(2);q=q[q.county_fips.isin(shared[shared].index)]
 if row.scope=='common':q=q[q.gmap_id.isin(members[members.pair.eq(row.pair)].gmap_id)]
 if row.stratum!='direct':q=q[q.trump.eq(int(row.stratum=='Trump'))]
 v=pd.read_csv(O/f'verify_{row.id}.csv.gz',dtype={'county':str});assert v.gmap_id.is_unique and set(v.gmap_id)==set(q.gmap_id);z=q.set_index('gmap_id').loc[v.gmap_id]
 np.testing.assert_allclose(v.y,z.change,atol=1e-12);np.testing.assert_array_equal(v.treated,z.group_hummus_or_baba.eq(first).astype(int))
 for cov in specs[row.specification]:
  np.testing.assert_allclose(v[cov],z[cov],atol=1e-12)
  if row.stratum=='direct':np.testing.assert_allclose(v[cov+'_T'],z[cov].to_numpy()*z.trump.to_numpy())
 if row.stratum=='direct':np.testing.assert_allclose(v.interaction,v.treated*z.trump.to_numpy())
 c=pd.factorize(v.county)[0];G=c.max()+1;names=coef[coef.id.eq(row.id)].term.tolist();M=within(v[['y']+names].to_numpy(),c);y=M[:,0];X=M[:,1:];b=np.linalg.lstsq(X,y,rcond=None)[0]
 np.testing.assert_allclose(b,coef[coef.id.eq(row.id)].set_index('term').loc[names].estimate,atol=1e-8,rtol=1e-7)
 omitted=[n for n in v.columns[3:] if n not in names];target='interaction' if row.stratum=='direct' else 'treated';k=names.index(target)
 if omitted:
  projection=np.linalg.lstsq(X,within(v[omitted].to_numpy(),c),rcond=None)[0];assert np.max(abs(projection[k]))<1e-7,'Main contrast aliased with omitted nuisance terms'
 u=y-X@b;A=np.linalg.inv(X.T@X);S=np.zeros((G,len(b)));np.add.at(S,c,X*u[:,None]);K=len(b)+1;V=A@(S.T@S)@A*G/(G-1)*(len(y)-1)/(len(y)-K)
 RV=pd.read_csv(O/f'cov_{row.id}.csv',index_col=0).loc[names,names].to_numpy();np.testing.assert_allclose(V,RV,atol=1e-8,rtol=1e-6)
 se=np.sqrt(V[k,k]);p=2*td.sf(abs(b[k]/se),G-1);np.testing.assert_allclose([b[k],se,p],[row.estimate,row.se,row.p],atol=1e-8,rtol=1e-6);assert K==row.df_K and G==row.counties and len(y)==row.restaurants
 checks.append(dict(id=row.id,passed=True))
for (scope,window,pair,spec),z in r.groupby(['scope','window','pair','specification']):
 z=z.set_index('stratum');np.testing.assert_allclose(z.loc['Trump','estimate']-z.loc['nonTrump','estimate'],z.loc['direct','estimate'],atol=1e-8)
for (scope,window,pair,st),z in r.groupby(['scope','window','pair','stratum']):assert z.restaurants.nunique()==1
for (pair,st,spec),z in r[r.scope.eq('common')].groupby(['pair','stratum','specification']):assert z.restaurants.nunique()==1 and z.counties.nunique()==1
protected=json.loads((O/'protected_hashes.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in protected.items())
(O/'verification.json').write_text(json.dumps(dict(all_passed=True,fits=len(checks),checks=checks,raw_review_means=True,common_samples_verified=True,controls_fixed=True,original_final_files_unchanged=True),indent=2));print(f'Verified {len(checks)} models, coefficients, clustered covariances, main-contrast estimability, fixed controls, common samples and unchanged final files.')
