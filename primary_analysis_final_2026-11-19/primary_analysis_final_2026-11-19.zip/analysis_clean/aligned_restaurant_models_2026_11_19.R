args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'aligned_restaurant_changes_2026_11_19')
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()));suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)});setFixest_nthreads(1)
new<-fread(file.path(o,'analysis_data.csv'),colClasses=c(county_fips='character'));old<-fread(file.path(h,'original_primary_county_fe/controls_preview/analysis_data.csv'),colClasses=c(county_fips='character'));specs<-fromJSON(file.path(o,'design.json'))$specifications
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');rr<-list();cc<-list();desc<-list();memberships<-list()
shared<-function(d,m){z<-copy(d[group_hummus_or_baba%chin%m]);z[,treated:=as.integer(group_hummus_or_baba==m[1])];keep<-z[,.(sides=uniqueN(treated)),by=county_fips][sides==2]$county_fips;z[county_fips%chin%keep]}
run<-function(z,pair,scope,window){
 for(stratum in c('nonTrump','Trump','direct'))for(spec in names(specs)){
  d<-copy(if(stratum=='direct')z else z[trump==as.integer(stratum=='Trump')]);covs<-unlist(specs[[spec]],use.names=FALSE);terms<-c('treated',covs);target<-'treated'
  if(stratum=='direct'){
   d[,interaction:=treated*trump];target<-'interaction'
   for(cov in covs)d[,(paste0(cov,'_T')):=get(cov)*trump]
   terms<-if(length(covs))c('treated','interaction',covs,paste0(covs,'_T')) else c('treated','interaction')
  }
  fit<-feols(as.formula(paste('change~',paste(terms,collapse='+'),'|county_fips')),data=d,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  stopifnot(nobs(fit)==nrow(d));b<-coef(fit);V<-vcov(fit);stopifnot(target%in%names(b));ct<-coeftable(fit)[target,];ci<-as.matrix(confint(fit))[target,]
  id<-paste(scope,window,gsub(' ','_',pair),stratum,spec,sep='__')
  rr[[length(rr)+1]]<<-data.table(id,scope,window,pair,stratum,specification=spec,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),first_restaurants=sum(d$treated),second_restaurants=sum(1-d$treated),counties=uniqueN(d$county_fips),reviews_pre=sum(d$reviews_pre),reviews_post=sum(d$reviews_post),df_K=attr(V,'df.K'),within_R2=as.numeric(fitstat(fit,'wr2')),omitted=paste(setdiff(terms,names(b)),collapse=';'))
  for(term in names(b))cc[[length(cc)+1]]<<-data.table(id,term,estimate=b[term],se=sqrt(V[term,term]))
  fwrite(cbind(d[,.(gmap_id,county=county_fips,y=change)],d[,terms,with=FALSE]),file.path(o,paste0('verify_',id,'.csv.gz')));write.csv(V,file.path(o,paste0('cov_',id,'.csv')))
 }
 desc[[length(desc)+1]]<<-z[,.(mean_pre=mean(rating_pre),mean_post=mean(rating_post),mean_change=mean(change),restaurants=.N,reviews_pre=sum(reviews_pre),reviews_post=sum(reviews_post)),by=.(trump,group=group_hummus_or_baba)][,`:=`(pair=pair,scope=scope,window=window)]
}
for(pair in c('WPME versus ME','WPME versus MED','ME versus MED')){
 m<-strsplit(pair,' versus ',fixed=TRUE)[[1]];n<-shared(new,m);b<-shared(old,m);run(n,pair,'native','aligned')
 common<-intersect(n$gmap_id,b$gmap_id);n<-shared(n[gmap_id%chin%common],m);b<-shared(b[gmap_id%chin%common],m);stopifnot(setequal(n$gmap_id,b$gmap_id))
 memberships[[length(memberships)+1]]<-n[,.(pair=pair,gmap_id,county_fips,trump,group=group_hummus_or_baba)]
 run(b,pair,'common','original');run(n,pair,'common','aligned')
}
r<-rbindlist(rr);fwrite(r,file.path(o,'results.csv'));fwrite(rbindlist(cc),file.path(o,'coefficients.csv'));fwrite(rbindlist(desc),file.path(o,'observed_period_means.csv'));fwrite(rbindlist(memberships),file.path(o,'common_restaurant_memberships.csv'))
print(r[specification=='full_snapshot',.(scope,window,pair,stratum,estimate,p,restaurants,counties)])
