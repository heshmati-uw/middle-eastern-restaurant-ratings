from pathlib import Path
import sys,json
sys.path.insert(0,'.analysis-python')
import pandas as pd,numpy as np
H=Path('analysis_clean');O=H/'ban_friday_event_study_2026_11_19';O.mkdir(exist_ok=True)
r=pd.read_csv(H/'extended_raw_timeline_2026_11_19/raw_extraction/individual_reviews.csv');c=pd.read_csv(H/'preban_trends_2026_11_19/cohort.csv',dtype={'county_fips':str})
anchor=int(pd.Timestamp('2017-01-27',tz='UTC').timestamp()*1000);week_ms=7*24*60*60*1000
r['relative_week']=np.floor_divide(r.time-anchor,week_ms);r=r[r.relative_week.between(-6,5)].copy();assert r.review_hash.is_unique
r['week_start']=pd.to_datetime(anchor+r.relative_week*week_ms,unit='ms',utc=True).dt.strftime('%Y-%m-%d')
w=r.groupby(['gmap_id','week_start','relative_week']).rating.agg(rating='mean',reviews='size').reset_index();w=w.rename(columns={'week_start':'week'}).merge(c[['gmap_id','group','trump','county_fips']],on='gmap_id',validate='many_to_one');w['idx']=w.relative_week+6
assert (pd.to_datetime(w.week).dt.dayofweek==4).all();assert w.reviews.sum()==len(r)
w.to_csv(O/'restaurant_week_ratings.csv',index=False)
bins=w[['idx','relative_week','week']].drop_duplicates().sort_values('idx');bins['week_end']=(pd.to_datetime(bins.week)+pd.Timedelta(days=6)).dt.strftime('%Y-%m-%d');bins['midpoint']=(pd.to_datetime(bins.week)+pd.Timedelta(days=3)).dt.strftime('%Y-%m-%d');bins.to_csv(O/'week_definitions.csv',index=False)
audit=dict(raw_only=True,anchor_utc='2017-01-27 00:00:00',week_interval='Friday 00:00 UTC inclusive to next Friday 00:00 UTC exclusive',first_post='2017-01-27 through 2017-02-02; February 3 belongs to next week',last_pre='2017-01-20 through 2017-01-26',window='2016-12-16 inclusive to 2017-03-10 exclusive',raw_reviews=len(r),restaurant_weeks=len(w),no_gap_or_mixed_calendar_week=True,calendar_day_caveat='January 27 is the calendar-date cutoff, not the exact signing/announcement instant; some reviews that day may predate the order.',parent_cohort=2430)
(O/'binning_audit.json').write_text(json.dumps(audit,indent=2));print(bins.to_string(index=False))
s=(H/'ban_controlled_event_study_2026_11_19.R').read_text(encoding='utf8')
s=s.replace("o<-file.path(h,'ban_controlled_event_study_2026_11_19')", "o<-file.path(h,'ban_friday_event_study_2026_11_19')")
s=s.replace("file.path(h,'extended_raw_timeline_2026_11_19/restaurant_week_ratings.csv')", "file.path(o,'restaurant_week_ratings.csv')")
s=s.replace(";w<-w[date>=as.IDate('2016-12-12')&date<=as.IDate('2017-03-06')&date!=as.IDate('2017-01-23')]",'')
s=s.replace('2016-12-12','2016-12-16').replace('post=sum(idx>=7)','post=sum(idx>=6)').replace('times<-c(0:5,7:12)','times<-0:11').replace('as.character(7:12)','as.character(6:11)')
s=s.replace('Six full weeks before and after; mixed Jan 23 week excluded','Six Friday-Thursday weeks before and after Jan 27; no omitted event week; Dec 16-Mar 9 UTC')
(H/'ban_friday_event_study_2026_11_19.R').write_text(s,encoding='utf8')
