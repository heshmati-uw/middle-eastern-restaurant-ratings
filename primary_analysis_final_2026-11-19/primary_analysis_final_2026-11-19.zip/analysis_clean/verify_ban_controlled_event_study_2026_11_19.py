from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
from scipy.stats import t as td,f as fd
O=H/'ban_controlled_event_study_2026_11_19';r=pd.read_csv(O/'model_summary.csv');ee=pd.read_csv(O/'weekly_estimates.csv')
def absorb(a,codes,w):
 a=a.copy()
 for it in range(20000):
  before=a.copy()
  for c in codes:
   n=np.bincount(c,weights=w);s=np.zeros((len(n),a.shape[1]));np.add.at(s,c,a*w[:,None]);a-=s[c]/n[c,None]
  if np.max(abs(a-before))<1e-11:return a*np.sqrt(w[:,None])
 raise AssertionError('FE convergence')
checks=[];samples={}
for row in r.itertuples():
 v=pd.read_csv(O/f'verify_{row.id}.csv.gz',dtype={'county':str});coef=pd.read_csv(O/f'coef_{row.id}.csv');names=coef.term.tolist()
 codes=[pd.factorize(v.gmap_id)[0],pd.factorize(v.county+':'+v.idx.astype(str))[0]];cc=pd.factorize(v.county)[0];w=v.weight.to_numpy()
 a=absorb(v[['y']+names].to_numpy(float),codes,w);y=a[:,0];X=a[:,1:];b=np.linalg.lstsq(X,y,rcond=None)[0];np.testing.assert_allclose(b,coef.estimate,atol=3e-6,rtol=3e-5)
 u=y-X@b;A=np.linalg.inv(X.T@X);S=np.zeros((row.counties,len(b)));np.add.at(S,cc,X*u[:,None]);K=len(b)+1;V=A@(S.T@S)@A*row.counties/(row.counties-1)*(len(y)-1)/(len(y)-K)
 RV=pd.read_csv(O/f'cov_{row.id}.csv',index_col=0).loc[names,names].to_numpy();np.testing.assert_allclose(V,RV,atol=4e-6,rtol=5e-4);assert K==row.df_K
 times=[0,1,2,3,4,5,7,8,9,10,11,12];T=np.zeros((12,len(b)))
 for i,k in enumerate(times):
  if k!=5:T[i,names.index(f'idx::{k}:treated')]=1
 L=T-T[:6].mean(axis=0);est=L@b;var=L@V@L.T;se=np.sqrt(var.diagonal());q=ee[ee.id.eq(row.id)].set_index('idx').loc[times]
 np.testing.assert_allclose(est,q.estimate,atol=3e-6,rtol=3e-5);np.testing.assert_allclose(se,q.se,atol=3e-6,rtol=3e-5);assert abs(est[:6].mean())<1e-10
 def jp(C):
  z=C@b;cov=C@V@C.T;F=float(z@np.linalg.solve(cov,z)/len(z));return fd.sf(F,len(z),row.counties-1)
 np.testing.assert_allclose([jp(T[:5]),jp(L[6:])],[row.pre_joint_p,row.post_joint_p],atol=3e-6,rtol=5e-4)
 contrast=L[6:].mean(axis=0);avg=contrast@b;ase=np.sqrt(contrast@V@contrast);p=2*td.sf(abs(avg/ase),row.counties-1)
 np.testing.assert_allclose([avg,ase,p],[row.average_post,row.average_post_se,row.average_post_p],atol=3e-6,rtol=5e-4)
 np.testing.assert_allclose(v.groupby('gmap_id').weight.sum(),1)
 ids=set(v.gmap_id);samples.setdefault(row.trump,ids);assert ids==samples[row.trump]
 checks.append(dict(id=row.id,passed=True))
protected=json.loads((H/'preban_trends_2026_11_19/protected_hashes.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in protected.items())
(O/'verification.json').write_text(json.dumps(dict(all_passed=True,checks=checks,same_sample_across_specs=True,pre_average_normalized_to_zero=True,original_final_files_unchanged=True),indent=2));print('Verified six models, covariances, rebased weekly CIs, pre/post joint tests, average-post contrasts and unchanged final files.')
