from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import numpy as np,pandas as pd
from scipy.stats import t as td, f as fd
O=H/'preban_trends_2026_11_19';tests=pd.read_csv(O/'pretrend_tests.csv');checks=[]
def absorb(a,codes,w):
 a=a.copy()
 for it in range(20000):
  before=a.copy()
  for c in codes:
   n=np.bincount(c,weights=w);s=np.zeros((len(n),a.shape[1]));np.add.at(s,c,a*w[:,None]);a-=s[c]/n[c,None]
  if np.max(abs(a-before))<1e-11:return a*np.sqrt(w[:,None])
 raise AssertionError('FE absorption did not converge')
for row in tests.itertuples():
 for kind in ['event','linear']:
  v=pd.read_csv(O/f'verify_{row.id}_{kind}.csv.gz',dtype={'county':str});coef=pd.read_csv(O/f'coef_{row.id}_{kind}.csv');names=coef.term.tolist()
  ci=pd.factorize(v.county)[0];ri=pd.factorize(v.gmap_id)[0];wi=pd.factorize(v.county+':'+v.t.astype(str))[0]
  a=absorb(v[['y']+names].to_numpy(float),[ri,wi],v.weight.to_numpy());y=a[:,0];X=a[:,1:]
  b=np.linalg.lstsq(X,y,rcond=None)[0];np.testing.assert_allclose(b,coef.estimate,atol=2e-6,rtol=2e-5)
  u=y-X@b;bread=np.linalg.inv(X.T@X);S=np.zeros((row.counties,len(b)));np.add.at(S,ci,X*u[:,None]);V=bread@(S.T@S)@bread*row.counties/(row.counties-1)*(len(y)-1)/(len(y)-len(b)-1)
  rv=pd.read_csv(O/f'cov_{row.id}_{kind}.csv',index_col=0).loc[names,names].to_numpy();np.testing.assert_allclose(V,rv,atol=3e-6,rtol=3e-4)
  if kind=='event':
   ix=[i for i,n in enumerate(names) if n.startswith('t::') and n.endswith(':treated')];q=V[np.ix_(ix,ix)];F=float(b[ix]@np.linalg.solve(q,b[ix])/len(ix));p=fd.sf(F,len(ix),row.counties-1);np.testing.assert_allclose([F,p],[row.joint_F,row.joint_p],atol=2e-5,rtol=3e-4)
  else:
   k=names.index('trend_group');se=np.sqrt(V[k,k]);p=2*td.sf(abs(b[k]/se),row.counties-1);np.testing.assert_allclose([b[k],se,p],[row.slope,row.slope_se,row.slope_p],atol=2e-6,rtol=3e-4)
  weight_check=v.groupby('gmap_id').weight.sum();np.testing.assert_allclose(weight_check,1)
  checks.append(dict(id=row.id,kind=kind,passed=True))
protected=json.loads((O/'protected_hashes.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in protected.items())
design=json.loads((O/'design.json').read_text());assert design['overlap_review_hashes_match'] and not design['saved_weekly_series_used']
(O/'verification.json').write_text(json.dumps(dict(all_passed=True,checks=checks,raw_only=True,original_final_files_unchanged=True),indent=2))
print('Verified coefficients, clustered covariance, joint tests, slope tests, equal total restaurant weights and unchanged final files.')
