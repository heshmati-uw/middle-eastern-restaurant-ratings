args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'aligned_restaurant_changes_2026_11_19')
o<-file.path(o,'longer_rating_history')
means<-read.csv(file.path(o,'six_week_plot_means.csv'))
r<-read.csv(file.path(o,'outcome_window_by_rating_history.csv'))
r<-r[r$weeks==6 & r$history_weeks==8,]
stopifnot(all(sapply(c(1,0),function(t)sum(means$restaurants[means$trump==t]))==r$N[match(c('Trump','nonTrump'),r$stratum)]))
ylims<-range(c(means$mean_pre,means$mean_post))+c(-.06,.14)
ticks<-pretty(ylims)
draw<-function(){
 par(mfrow=c(1,2),mar=c(5,5,5,1.3),oma=c(6.5,0,4,0),family='sans',las=1)
 colors<-c(ME='#B44E43',WPME='#176F91')
 for(trump in c(1,0)){
  z<-means[means$trump==trump,];q<-r[r$stratum==ifelse(trump==1,'Trump','nonTrump'),]
  plot(c(.8,2.2),ylims,type='n',axes=FALSE,xlab='',ylab='',main=ifelse(trump==1,'Trump-majority counties','Non-Trump-majority counties'),cex.main=1.2)
  abline(h=ticks,col='#E4E9EC',lwd=1)
  axis(2,at=ticks,cex.axis=.95,col='#8C999F',col.axis='#34454C')
  axis(1,at=1:2,labels=c('Before ban','After ban'),tick=FALSE,line=.3,cex.axis=1.05)
  mtext('Mean restaurant rating (stars)',side=2,line=3.5,las=0,cex=.95)
  box(bty='l',col='#8C999F')
  leg<-c()
  for(j in 1:2){
   group<-c('ME','WPME')[j];a<-z[z$group==group,];other<-z[z$group!=group,]
   y<-c(a$mean_pre,a$mean_post);other_y<-c(other$mean_pre,other$mean_post)
   lines(1:2,y,type='o',col=colors[group],lwd=3.3,pch=c(15,16)[j],cex=1.2,lty=c(1,2)[j])
   text(1:2,y,sprintf('%.3f',y),pos=ifelse(y>=other_y,3,1),offset=.6,cex=.94,col=colors[group])
   leg<-c(leg,sprintf('%s: %s restaurants | %s / %s reviews',group,format(a$restaurants,big.mark=','),format(a$reviews_pre,big.mark=','),format(a$reviews_post,big.mark=',')))
  }
  legend('topleft',legend=leg,col=colors,lty=c(1,2),pch=c(15,16),lwd=2.4,bty='n',cex=.76,inset=c(.01,.01))
  mtext(sprintf('Adjusted WPME - ME change: %+.3f | p=%.3f',q$estimate,q$p),side=3,line=.35,cex=.91,col='#34454C')
 }
 direct<-r[r$stratum=='direct',]
 mtext('Restaurant ratings before and after the travel ban',side=3,outer=TRUE,line=2,font=2,cex=1.35)
 mtext('Six-week pre/post windows | Eight-week historical controls | Equal restaurant weights',side=3,outer=TRUE,line=.5,cex=.95,col='#52656F')
 mtext(sprintf('Trump minus non-Trump difference: %+.3f stars  |  p=%.3f',direct$estimate,direct$p),side=1,outer=TRUE,line=1,font=2,cex=1.04,col='#1F454F')
 mtext('Lines show observed means. Annotations test relative changes with county fixed effects, rating history, price and service controls.',side=1,outer=TRUE,line=2.7,cex=.77,col='#52656F')
 mtext('Before: Dec 16-Jan 26. After: Jan 27-Mar 9. Each legend lists pre / post review counts.',side=1,outer=TRUE,line=4,cex=.8,col='#52656F')
 mtext('County-clustered p values. Price and service metadata are undated. Estimates are correlational.',side=1,outer=TRUE,line=5.3,cex=.76,col='#52656F')
}
png(file.path(o,'six_week_outcome_eight_week_history.png'),width=1900,height=1150,res=175);draw();dev.off()
pdf(file.path(o,'six_week_outcome_eight_week_history.pdf'),width=11,height=6.6,useDingbats=FALSE);draw();dev.off()
