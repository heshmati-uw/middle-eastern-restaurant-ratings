from pathlib import Path
import sys,json
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import pandas as pd
B=H/'original_primary_county_fe';O=H/'preban_trends_2026_11_19'
d=pd.read_csv(O/'cohort.csv',dtype={'county_fips':str})
raw=pd.read_csv(O/'raw_extraction/individual_reviews.csv')
old=pd.read_csv(B/'individual_reviews.csv')
old=old[old.gmap_id.isin(d.gmap_id)&(((old.event=='Election')&(old.period=='post'))|((old.event=='Ban')&(old.period=='pre')))]
times=pd.to_datetime(raw.time,unit='ms',utc=True)
overlap=raw[~times.between('2016-12-12','2016-12-25 23:59:59.999')]
assert set(old.review_hash)==set(overlap.review_hash),'Re-extraction differs from frozen raw inputs'
assert not raw.review_hash.duplicated().any()
raw['week']=times.dt.tz_localize(None).dt.to_period('W-SUN').dt.start_time.astype(str)
w=raw.groupby(['gmap_id','week']).rating.agg(rating='mean',reviews='size').reset_index()
full=w.copy();full['source']='exact_raw_10weeks'
short=w[w.week>='2016-12-26'].copy();short['source']='exact_raw_4weeks'
out=pd.concat([full,short],ignore_index=True).merge(d,on='gmap_id',validate='many_to_one')
assert not out.duplicated(['source','gmap_id','week']).any()
out.to_csv(O/'weekly_data.csv',index=False)
means=out.groupby(['source','trump','group','week']).agg(mean_rating=('rating','mean'),restaurants=('gmap_id','nunique'),reviews=('reviews','sum')).reset_index()
means.to_csv(O/'observed_means.csv',index=False)
design=json.loads((O/'design.json').read_text())
design.update(main_source='Fresh ten-week extraction from original 52 raw archives, Nov 14-Jan 22 UTC',sensitivity_source='Exact four-week pre-ban subset from the same extraction',overlapping_frozen_reviews=len(old),overlap_review_hashes_match=True,raw_reviews=len(raw),saved_weekly_series_used=False)
design['limitations']=[x for x in design['limitations'] if not x.startswith('Saved-series')]
(O/'design.json').write_text(json.dumps(design,indent=2))
print(json.dumps({k:design[k] for k in ['raw_reviews','overlapping_frozen_reviews','overlap_review_hashes_match','saved_weekly_series_used']},indent=2))
