args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'ban_friday_event_study_2026_11_19')
e<-read.csv(file.path(o,'weekly_estimates.csv'));e$date<-as.Date(e$week)+3;write.csv(transform(e,week_midpoint=as.character(date)),file.path(o,'weekly_plot_coordinates.csv'),row.names=FALSE);r<-read.csv(file.path(o,'model_summary.csv'))
draw<-function(spec){
 par(mfrow=c(1,2),mar=c(5.5,5.3,5.8,1),oma=c(8.5,0,4.5,0),las=1,family='sans')
 yy<-range(c(0,e$low[e$spec==spec],e$high[e$spec==spec]));yy<-yy+c(-.07,.15)
 for(tr in c(1,0)){
  z<-e[e$spec==spec&e$trump==tr,];z<-z[order(z$date),];q<-r[r$spec==spec&r$trump==tr,]
  plot(as.Date(c('2016-12-14','2017-03-10')),yy,type='n',axes=FALSE,xlab='',ylab='Adjusted WPME - ME change (stars)')
  abline(h=pretty(yy),col='#E4E9EB');invisible(NULL)
  abline(h=0,col='#727C83',lty=3);abline(v=as.Date('2017-01-27'),lty=2,lwd=2,col='#665193')
  axis(2);axis.Date(1,at=seq(as.Date('2016-12-19'),as.Date('2017-03-06'),by='2 weeks'),format='%b %d',cex.axis=.85);box(bty='l')
  for(post in c(FALSE,TRUE)){
   a<-z[(z$idx>=6)==post,];col<-if(post)'#176F91' else '#64737B';arrows(a$date,a$low,a$date,a$high,angle=90,code=3,length=.035,col=col,lwd=1.4);lines(a$date,a$estimate,type='o',pch=if(post)16 else 1,col=col,lwd=2.2)
  }
  mtext(if(tr==1)'Trump-majority counties' else 'Non-Trump-majority counties',side=3,line=3.8,font=2,cex=1.1)
  mtext(sprintf('Average post change: %+.3f | p=%.3f',q$average_post,q$average_post_p),side=3,line=2.2,font=2,cex=.95)
  mtext('Travel ban: Jan 27',side=3,at=as.Date('2017-01-27'),line=.7,font=2,col='#665193',cex=.9)
  legend('topleft',legend=c('Pre-ban','Post-ban'),col=c('#64737B','#176F91'),lty=1,pch=c(1,16),bty='n',horiz=TRUE,cex=.85)
  mtext('Week midpoint (Monday)',side=1,line=1.8,cex=.8)
  mtext(sprintf('N: %d ME / %d WPME; %d county clusters',q$ME,q$WPME,q$counties),side=1,line=3,cex=.83)
 }
 mtext('Ban-aligned weekly regressions: Friday-Thursday bins',side=3,outer=TRUE,line=2.4,font=2,cex=1.3)
 mtext(paste(spec,'| Restaurant FE + county-by-week FE | Equal total weight per restaurant'),side=3,outer=TRUE,line=.7,cex=.92)
 mtext('Zero = average WPME-ME gap over six pre-ban weeks. Positive = WPME improved relative to ME versus that baseline.',side=1,outer=TRUE,line=1,cex=.8)
 mtext('Friday-Thursday weeks; estimates at Monday midpoints. Jan 27-Feb 2 is the first post week; no week omitted.',side=1,outer=TRUE,line=2.4,cex=.81)
 mtext('Added controls interact with week; their time-invariant levels are absorbed by restaurant FE. Samples are fixed across specifications.',side=1,outer=TRUE,line=3.8,cex=.77)
 mtext('Price/service metadata are undated. Weekly p values are exploratory and unadjusted; non-rejection of pretrends is not proof.',side=1,outer=TRUE,line=5.2,cex=.77)
 mtext('95% county-clustered CIs. Jan 27 is a calendar-date cutoff, not the exact signing time. Associational estimates.',side=1,outer=TRUE,line=6.6,cex=.8)
}
for(spec in c('FE only','Earlier controls','All controls')){
 name<-paste0('event_study_',gsub(' ','_',tolower(spec)))
 png(file.path(o,paste0(name,'.png')),width=2400,height=1650,res=175);draw(spec);dev.off()
 pdf(file.path(o,paste0(name,'.pdf')),width=13.7,height=9.5,useDingbats=FALSE);draw(spec);dev.off()
}
