from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'.analysis-python')
import pandas as pd
R=Path.cwd();B=R/'analysis_clean/original_primary_county_fe';O=R/'analysis_clean/preban_trends_2026_11_19';O.mkdir(exist_ok=True)
protected=[B/'regression_tables.html',R/'output/pdf/restaurant_positioning_ban_results.pdf']
(O/'protected_hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}))
d=pd.read_csv(B/'controls_preview/analysis_data.csv',dtype={'county_fips':str});d=d[d.group_hummus_or_baba.isin(['ME','WPME'])];shared=d.groupby('county_fips').group_hummus_or_baba.nunique().eq(2);d=d[d.county_fips.isin(shared[shared].index)]
d=d.rename(columns={'group_hummus_or_baba':'group'})
controls=json.loads((B/'controls_preview/design.json').read_text())['specifications']['full_snapshot']
d[['gmap_id','group','trump','county_fips']+controls].to_csv(O/'cohort.csv',index=False)
r=pd.read_csv(B/'individual_reviews.csv');r=r[(r.event=='Ban')&(r.period=='pre')&r.gmap_id.isin(d.gmap_id)]
r['week']=(pd.to_datetime(r.time,unit='ms',utc=True).dt.tz_localize(None).dt.to_period('W-SUN').dt.start_time).astype(str)
a=r.groupby(['gmap_id','week']).rating.agg(rating='mean',reviews='size').reset_index();a['source']='exact_raw_4weeks'
w=pd.read_csv(R/'analysis_clean/expanded_positioning/expanded_common_weekly.csv');w=w[w.gmap_id.isin(d.gmap_id)&w.week.between('2016-11-14','2017-01-16')&(w.reviews>0)].copy();w['source']='saved_weekly_10weeks'
full=pd.concat([a,w],ignore_index=True).merge(d[['gmap_id','group','trump','county_fips']+controls],on='gmap_id',validate='many_to_one');assert not full.duplicated(['source','gmap_id','week']).any()
full.to_csv(O/'weekly_data.csv',index=False)
means=full.groupby(['source','trump','group','week']).agg(mean_rating=('rating','mean'),restaurants=('gmap_id','nunique'),reviews=('reviews','sum')).reset_index();means.to_csv(O/'observed_means.csv',index=False)
z=a.merge(w,on=['gmap_id','week'],suffixes=('_raw','_saved'))
audit={'cohort_restaurants':len(d),'raw_pre_reviews':len(r),'raw_week_cells':len(a),'shared_cells':len(z),'same_rating_fraction':float((abs(z.rating_raw-z.rating_saved)<1e-9).mean()),'same_review_count_fraction':float((z.reviews_raw==z.reviews_saved).mean()),'mean_absolute_rating_difference':float(abs(z.rating_raw-z.rating_saved).mean()),'controls':controls,'main_source':'Exact final-analysis raw reviews: four pre-ban weeks','sensitivity_source':'Saved weekly aggregates: ten pre-ban weeks; not spliced into raw series','test_sample':'Original paired ban cohort, at least two observed pre-ban weeks per restaurant; no weekly mean imputations','weights':'Raw means: equal per observed restaurant within week. FE regressions: inverse number of observed pre-weeks, equal total weight per restaurant.','reference_week':'2017-01-16','limitations':['Pretrend tests cannot confirm parallel trends; wide CIs may hide meaningful departures.','Weekly observed means change composition; restaurant FE diagnostic addresses stable restaurant differences.','All-controls week interactions use undated price/service snapshots and do not establish pre-treatment timing.','Original paired cohort conditions on post-ban review activity.','Last fully pre-ban week includes inauguration; January 23 week omitted to avoid mixed ban exposure.','Saved-series sensitivity differs slightly in outcome construction from exact final raw reviews.']}
(O/'design.json').write_text(json.dumps(audit,indent=2));print(json.dumps({k:v for k,v in audit.items() if k not in ['controls','limitations']},indent=2))
