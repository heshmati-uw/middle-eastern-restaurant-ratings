args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'ban_controlled_event_study_2026_11_19');dir.create(o,showWarnings=FALSE)
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()));suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)});setFixest_nthreads(1)
w<-fread(file.path(h,'extended_raw_timeline_2026_11_19/restaurant_week_ratings.csv'),colClasses=c(county_fips='character'));c<-fread(file.path(h,'preban_trends_2026_11_19/cohort.csv'),colClasses=c(county_fips='character'))
history<-c('rating_control','rating_missing','log_earlier_reviews');full<-fromJSON(file.path(h,'original_primary_county_fe/controls_preview/design.json'))$specifications$full_snapshot
specs<-list('FE only'=character(),'Earlier controls'=history,'All controls'=full)
w<-merge(w,c[,c('gmap_id',full),with=FALSE],by='gmap_id',all.x=TRUE);w[,date:=as.IDate(week)];w<-w[date>=as.IDate('2016-12-12')&date<=as.IDate('2017-03-06')&date!=as.IDate('2017-01-23')]
w[,idx:=as.integer((date-as.IDate('2016-12-12'))/7)];eligible<-w[,.(pre=sum(idx<=5),post=sum(idx>=7)),by=gmap_id];w<-w[gmap_id%chin%eligible[pre>=2&post>=1]$gmap_id]
w[,nweeks:=.N,by=gmap_id];w[,weight:=1/nweeks];w[,treated:=as.integer(group=='WPME')];fwrite(w,file.path(o,'analysis_data.csv'))
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');results<-list();effects<-list();summary<-list()
for(tr in c(1,0))for(spec in names(specs)){
 z<-w[trump==tr];covs<-specs[[spec]];rhs<-paste(c('i(idx,treated,ref=5)',sprintf('i(idx,%s,ref=5)',covs)),collapse='+')
 fit<-feols(as.formula(paste('rating~',rhs,'|gmap_id+county_fips^idx')),data=z,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
 b<-coef(fit);V<-vcov(fit);G<-uniqueN(z$county_fips);stopifnot(nobs(fit)==nrow(z));times<-c(0:5,7:12);A<-matrix(0,length(times),length(b),dimnames=list(times,names(b)))
 for(k in times[times!=5]){term<-paste0('idx::',k,':treated');stopifnot(term%in%names(b));A[as.character(k),term]<-1}
 # Rebase every weekly relative gap to the equal-week average of six pre-ban gaps.
 L<-sweep(A,2,colMeans(A[as.character(0:5),,drop=FALSE]),'-');B<-as.numeric(L%*%b);CV<-L%*%V%*%t(L);se<-sqrt(pmax(0,diag(CV)));crit<-qt(.975,G-1)
 id<-paste(tr,gsub(' ','_',spec),sep='__')
 effects[[length(effects)+1]]<-data.table(id,trump=tr,spec,idx=times,week=as.character(as.IDate('2016-12-12')+7*times),estimate=B,se,low=B-crit*se,high=B+crit*se,p=2*pt(abs(B/se),G-1,lower.tail=FALSE))
 # Joint pretest: five independent deviations from the last pre-ban week.
 P<-A[as.character(0:4),,drop=FALSE];Q<-P%*%V%*%t(P);stopifnot(qr(Q)$rank==5);v<-P%*%b;Fpre<-as.numeric(t(v)%*%solve(Q,v)/5);ppre<-pf(Fpre,5,G-1,lower.tail=FALSE)
 Ppost<-L[as.character(7:12),,drop=FALSE];Qpost<-Ppost%*%V%*%t(Ppost);stopifnot(qr(Qpost)$rank==6);vpost<-Ppost%*%b;Fpost<-as.numeric(t(vpost)%*%solve(Qpost,vpost)/6);ppost<-pf(Fpost,6,G-1,lower.tail=FALSE)
 contrast<-colMeans(Ppost);est<-sum(contrast*b);cs<-sqrt(as.numeric(t(contrast)%*%V%*%contrast));pavg<-2*pt(abs(est/cs),G-1,lower.tail=FALSE)
 summary[[length(summary)+1]]<-data.table(id,trump=tr,spec,restaurants=uniqueN(z$gmap_id),ME=uniqueN(z[group=='ME']$gmap_id),WPME=uniqueN(z[group=='WPME']$gmap_id),counties=G,restaurant_weeks=nrow(z),reviews=sum(z$reviews),pre_joint_p=ppre,post_joint_p=ppost,average_post=est,average_post_se=cs,average_post_p=pavg,low=est-crit*cs,high=est+crit*cs,df_K=attr(vcov(fit,attr=TRUE),'df.K'),omitted=paste(fit$collin.var,collapse=';'))
 X<-model.matrix(fit,type='rhs')[,names(b),drop=FALSE];fwrite(cbind(z[,.(gmap_id,county=county_fips,idx,y=rating,weight)],as.data.table(X)),file.path(o,paste0('verify_',id,'.csv.gz')))
 fwrite(data.table(term=names(b),estimate=unname(b)),file.path(o,paste0('coef_',id,'.csv')));write.csv(V,file.path(o,paste0('cov_',id,'.csv')))
}
tt<-rbindlist(summary);ee<-rbindlist(effects);fwrite(tt,file.path(o,'model_summary.csv'));fwrite(ee,file.path(o,'weekly_estimates.csv'));print(tt[,!c('omitted'),with=FALSE])
writeLines(toJSON(list(outcome='Weekly restaurant mean rating',sample='Frozen original paired ban ME/WPME cohort; at least two pre-ban weeks and one post-ban week',window='Six full weeks before and after; mixed Jan 23 week excluded',normalization='Equal-week average of six pre-ban WPME-ME gaps = 0',formula='rating ~ WPME x week + controls x week | restaurant FE + county-by-week FE',weights='1 / observed weeks per restaurant: equal total restaurant weight',inference='County-clustered CR1, nonnested FE correction, county-minus-one t df; pointwise 95% CIs',timing_caveat='Price/service snapshots are undated. Earlier controls alone have cleaner temporal ordering.',interpretation='Relative associations, not a forced ban discontinuity or proof of a causal effect'),pretty=TRUE,auto_unbox=TRUE),file.path(o,'design.json'))
