from pathlib import Path
import sys,json,hashlib
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))
import pandas as pd
O=H/'extended_raw_timeline_2026_11_19';B=H/'original_primary_county_fe';P=H/'preban_trends_2026_11_19'
d=pd.read_csv(P/'cohort.csv',dtype={'county_fips':str});r=pd.read_csv(O/'raw_extraction/individual_reviews.csv')
assert not r.review_hash.duplicated().any() and r.rating.isin([1,2,3,4,5]).all()
assert set(r.gmap_id)==set(d.gmap_id)
old=pd.read_csv(B/'individual_reviews.csv');old=old[old.gmap_id.isin(d.gmap_id)]
assert set(old.review_hash).issubset(set(r.review_hash))
prior=pd.read_csv(P/'raw_extraction/individual_reviews.csv');assert set(prior.review_hash).issubset(set(r.review_hash))
stamp=pd.to_datetime(r.time,unit='ms',utc=True)
assert stamp.ge('2016-07-04').all() and stamp.lt('2017-05-01').all()
r['week']=stamp.dt.tz_localize(None).dt.to_period('W-SUN').dt.start_time.astype(str)
w=r.groupby(['gmap_id','week']).rating.agg(rating='mean',reviews='size').reset_index().merge(d[['gmap_id','group','trump','county_fips']],on='gmap_id',validate='many_to_one')
assert not w.duplicated(['gmap_id','week']).any()
w.to_csv(O/'restaurant_week_ratings.csv',index=False)
m=w.groupby(['trump','group','week']).agg(mean_rating=('rating','mean'),restaurants=('gmap_id','nunique'),reviews=('reviews','sum')).reset_index()
assert len(m)==43*4
m['week_end']=(pd.to_datetime(m.week)+pd.Timedelta(days=6)).dt.strftime('%Y-%m-%d')
m['mixed_event_week']=m.week.map({'2016-11-07':'Election','2017-01-23':'Travel ban'}).fillna('')
m.to_csv(O/'weekly_group_means.csv',index=False)
counts=d.groupby(['trump','group']).size().rename('cohort_restaurants').reset_index();counts.to_csv(O/'cohort_counts.csv',index=False)
original=pd.read_csv(B/'ban_observed_all_controls_figure_data.csv');pairs=w[w.week.between('2016-12-26','2017-01-16')].copy()
agg=pairs.groupby('gmap_id').apply(lambda x:(x.rating*x.reviews).sum()/x.reviews.sum(),include_groups=False).rename('raw_pre_mean')
assert len(agg)==2430
for row in original.itertuples():
 ids=d[(d.trump==row.trump)&(d.group==row.group)].gmap_id
 assert abs(agg.loc[ids].mean()-row.mean_pre)<1e-10
protected=json.loads((P/'protected_hashes.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in protected.items())
audit=dict(all_passed=True,start='2016-07-04',end_inclusive='2017-04-30',weeks=43,restaurants=len(d),reviews=len(r),restaurant_weeks=len(w),frozen_review_hashes_reproduced=len(old),previous_ten_week_hashes_reproduced=len(prior),original_ban_pre_means_reproduced=True,raw_only=True,equal_restaurant_weights_within_week=True,mixed_event_weeks_included=True,election_date='2016-11-08',travel_ban_date='2017-01-27',original_final_files_unchanged=True)
(O/'verification.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
