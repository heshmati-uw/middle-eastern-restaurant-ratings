args <- commandArgs(FALSE)
here <- dirname(normalizePath(sub("^--file=", "", args[grepl("^--file=", args)])))
out <- file.path(here, "aligned_restaurant_changes_2026_11_19", "longer_rating_history")
changes <- read.csv(file.path(out, "six_week_adjusted_lines.csv"))
fits <- read.csv(file.path(out, "outcome_window_by_rating_history.csv"))
fits <- subset(fits, weeks == 6 & history_weeks == 8)
draw <- function() {
  par(mfrow=c(1,2), mar=c(4.7,5,4.7,1.2), oma=c(5.5,0,4.6,0),
      family="sans", las=1)
  colors <- c(ME="#B44E43", WPME="#176F91")
  for (st in c("Trump", "nonTrump")) {
    q <- fits[fits$stratum==st, ]
    changes_here <- subset(changes, stratum==st)
    y <- setNames(changes_here$adjusted_change,changes_here$group)
    stopifnot(abs(y["WPME"] - y["ME"] - q$estimate)<1e-9)
    plot(c(.82,2.38), c(-.206,.17), type="n", axes=FALSE, xlab="", ylab="")
    abline(h=seq(-.2,.15,.05),col="#E5EBEE")
    abline(h=0,col="#74828A",lty=3)
    axis(2,at=seq(-.2,.15,.05),labels=sprintf("%.2f",seq(-.2,.15,.05)))
    axis(1,at=1:2,labels=c("Before ban (set to zero)","After ban"),tick=FALSE)
    box(bty="l",col="#91A1A9")
    mtext("Adjusted rating change (stars)",2,line=3.4,las=0)
    for (i in seq_along(colors)) {
      g <- names(colors)[i]
      lines(1:2,c(0,y[g]),type="o",lwd=2.8,col=colors[g],lty=i,pch=c(15,16)[i])
      pos <- if (y[g] >= max(y)) 3 else 1
      text(2,y[g],sprintf("%+.4f",y[g]),pos=pos,offset=.5,col=colors[g],font=2)
    }
    if (st=="Trump") {
      segments(2.14,y["ME"],2.14,y["WPME"],col="#34454C",lwd=1.5)
      segments(2.11,y,2.17,y,col="#34454C",lwd=1.5)
      text(2.16,mean(y),sprintf("%.3f stars",q$estimate),pos=4,offset=.28,cex=.85)
    }
    legend("topleft",c("ME","WPME"),col=colors,lwd=2,lty=1:2,pch=c(15,16),
           bty="n",horiz=TRUE,cex=.85)
    mtext(if (st=="Trump") "Trump-majority counties" else "Non-Trump-majority counties",
          3,line=2.7,font=2,cex=1.08)
    mtext(sprintf("WPME minus ME: %+.3f stars | p=%.3f | N=%s",
                  q$estimate,q$p,format(q$N,big.mark=",")),3,line=.85,cex=.89)
  }
  mtext("Model-adjusted rating changes around the travel ban",3,outer=TRUE,line=2.5,font=2,cex=1.35)
  mtext("Six weeks before and after | Eight weeks of rating and review history | Equal restaurant weights",
        3,outer=TRUE,line=.7,cex=.91,col="#52656F")
  direct <- fits[fits$stratum=="direct", ]
  mtext(sprintf("Direct Trump minus non-Trump comparison: %+.3f stars | p=%.3f",direct$estimate,direct$p),
        1,outer=TRUE,line=.9,font=2,cex=.96)
  mtext("Both groups are evaluated at the same mix of counties and controls within each panel. The starting points are normalized.",
        1,outer=TRUE,line=2.3,cex=.73)
  mtext("Before: Dec 16-Jan 26. After: Jan 27-Mar 9. Models include county fixed effects, price and service controls.",
        1,outer=TRUE,line=3.55,cex=.73)
  mtext("P values test the relative change using county-clustered standard errors. Estimates are correlational.",
        1,outer=TRUE,line=4.65,cex=.73)
}
stem <- file.path(out,"six_week_adjusted_pre_post")
png(paste0(stem,".png"),width=2200,height=1190,res=175)
draw()
dev.off()
pdf(paste0(stem,".pdf"),width=2200/175,height=1190/175,useDingbats=FALSE)
draw()
dev.off()
