from pathlib import Path

import json,sys

H=Path(__file__).resolve().parent;sys.path.insert(0,str(H.parent/'.analysis-python'))

import pandas as pd

O=H/'extended_raw_timeline_2026_11_19';v=json.loads((O/'verification.json').read_text());assert v['all_passed']

d=pd.read_csv(O/'weekly_group_means.csv');cohort=pd.read_csv(O/'cohort_counts.csv')

s=['''<!doctype html><html lang="en"><meta charset="utf-8"><title>Extended raw-review ratings timeline</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:1300px;margin:30px auto;padding:0 25px;color:#23343c}h1,h2{color:#19484c}img{width:100%;height:auto}table{border-collapse:collapse;width:100%}th,td{padding:10px;text-align:left;border-bottom:1px solid #d9e2e4}th,.note{background:#eef4f5}.note{padding:16px}a{color:#12647c}</style><body><h1>Ratings around the election and travel ban: extended raw-review timeline</h1><p>November 19, 2026. July 4, 2016-April 30, 2017. Original primary-category ME/WPME definitions and the fixed November 18 paired-ban restaurant cohort.</p>''']

s.append(f'<p><strong>Raw data:</strong> {v["reviews"]:,} deduplicated rated reviews, {v["restaurant_weeks"]:,} observed restaurant-weeks, and {v["restaurants"]:,} restaurants over {v["weeks"]} weeks. Re-extraction reproduces all {v["frozen_review_hashes_reproduced"]:,} frozen outcome-review hashes and all {v["previous_ten_week_hashes_reproduced"]:,} reviews from the preceding ten-week diagnostic. The original ban pre-period restaurant means also reproduce exactly.</p>')

s.append('''<ul><li><strong>Event markers:</strong> dark dashed line = election on November 8, 2016; purple dashed line = travel ban on January 27, 2017. Shaded bands identify the weeks containing each event (November 7-13 and January 23-29). These weekly means mix pre/post reviews, so the line immediately before an event date is not necessarily an entirely pre-event outcome.</li><li><strong>Means:</strong> average all valid raw ratings within each restaurant-week, then average those restaurant means with equal weights. All star ratings and reviews without text or food mentions are included. No matching, smoothing or control adjustment is applied to these descriptive lines.</li><li><strong>Cohort:</strong> retain the same 2,430 restaurants used in the November 18 ME/WPME paired-ban comparisons, with primary-category rules and pre-election hummus/baba evidence frozen. This selects on ban-period review activity; it is not an unrestricted population series. Mediterranean without food mentions (MED) is not included in this ME/WPME figure.</li><li><strong>Missing weeks:</strong> a restaurant without reviews contributes no rating that week; it is not assigned zero or carried forward. Weekly restaurant and review counts are provided below and in the CSV. The observed composition can therefore change even though the eligible cohort is fixed.</li><li><strong>Interpretation:</strong> this extends the descriptive view; it does not run new causal models or change the November 18 final analysis. The classification cutoff remains November 8, so some classification evidence postdates the early months shown here.</li></ul><h2>Travel ban: closer view</h2><p>Six complete weeks before and after the ban, plus its event week: December 12, 2016-March 12, 2017. This is a horizontal zoom of the same observed series and uses the same rating scale for both county types. Error bars are pointwise 95% confidence intervals for each weekly equal-restaurant mean, using county-clustered intercept-only standard errors and t critical values with county clusters minus one degrees of freedom. They do not test relative pre/post changes; overlap alone is not a significance test.</p><img src="ban_zoom_observed_ratings.png" alt="Six-week view before and after the travel ban, with separate ME and WPME lines and a dashed January 27 marker"><p><a href="ban_zoom_observed_ratings.pdf">Download zoomed figure as PDF</a> · <a href="ban_zoom_weekly_means.csv">Zoomed weekly means, confidence intervals and counts</a> · <a href="ban_zoom_weekly_counts.png">Zoomed restaurant activity</a></p><h2>Observed mean ratings: full horizon</h2><img src="extended_observed_ratings.png" alt="Raw weekly ME and WPME mean ratings in Trump and non-Trump counties, July 2016-April 2017, with dashed election and travel ban markers"><p><a href="extended_observed_ratings.pdf">Download ratings figure as PDF</a></p><h2>Weekly restaurant activity</h2><img src="extended_weekly_counts.png" alt="Numbers of restaurants observed in each week, with the same election and ban markers"><p><a href="extended_weekly_counts.pdf">Download activity figure as PDF</a></p><table><tr><th>County type</th><th>Group</th><th>Fixed cohort N</th><th>Weekly restaurant N range</th><th>Total reviews</th></tr>''')

for row in cohort.itertuples():

 z=d[(d.trump==row.trump)&(d.group==row.group)]

 s.append(f'<tr><td>{"Trump" if row.trump else "Non-Trump"}</td><td>{row.group}</td><td>{row.cohort_restaurants:,}</td><td>{z.restaurants.min():,}-{z.restaurants.max():,}</td><td>{z.reviews.sum():,}</td></tr>')

s.append('''</table><p class="note">These plots make the timing visible without attributing changes to either event. The separate pre-ban FE diagnostics remain in their own report; the final November 18 report, PDF and GitHub checkpoint are unchanged.</p><p><a href="weekly_group_means.csv">Weekly means, restaurant counts and review counts</a> · <a href="restaurant_week_ratings.csv">Restaurant-week data</a> · <a href="verification.json">Verification</a> · <a href="../preban_trends_2026_11_19/preban_trends_report.html">Earlier pre-ban trend diagnostics</a></p></body></html>''')

(O/'extended_timeline_report.html').write_text(''.join(s),encoding='utf8')

print('Extended raw timeline report written.')

