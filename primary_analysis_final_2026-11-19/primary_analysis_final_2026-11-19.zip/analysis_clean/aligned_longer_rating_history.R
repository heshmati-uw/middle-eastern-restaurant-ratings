args <- commandArgs(FALSE)
here <- dirname(normalizePath(sub('^--file=', '', args[grepl('^--file=', args)])))
.libPaths(c(file.path(dirname(here), '.r-library'), .libPaths()))
suppressPackageStartupMessages({library(data.table); library(fixest); library(jsonlite)})
setFixest_nthreads(1)

root <- file.path(here, 'aligned_restaurant_changes_2026_11_19')
out <- file.path(root, 'longer_rating_history')
dir.create(out, showWarnings=FALSE)
cohort <- fread(file.path(root, 'analysis_data.csv'), colClasses=c(county_fips='character'))
prior <- fread(file.path(root, 'results.csv'))[scope=='native' & window=='aligned']
design <- fromJSON(file.path(root, 'design.json'))
reviews <- fread(file.path(here, 'original_primary_county_fe/individual_reviews.csv'),
                 select=c('gmap_id','review_hash','time','rating','event','period'), integer64='double')
reviews <- reviews[event=='Election' & period %chin% c('pre','post')]
utc_ms <- function(x) as.numeric(as.POSIXct(x, tz='UTC')) * 1000
stopifnot(!anyDuplicated(reviews$review_hash),
          all(reviews[period=='pre', time >= utc_ms('2016-10-10') & time < utc_ms('2016-11-07')]),
          all(reviews[period=='post', time >= utc_ms('2016-11-14') & time < utc_ms('2016-12-12')]))
history <- reviews[, .(history_mean=mean(rating), history_count=.N,
                       pre_election_count=sum(period=='pre'),
                       pre_election_mean=if (any(period=='pre')) mean(rating[period=='pre']) else NA_real_), by=gmap_id]
cohort <- merge(cohort, history, by='gmap_id', all.x=TRUE, sort=FALSE)
cohort[is.na(history_count), `:=`(history_count=0L, pre_election_count=0L)]
stopifnot(isTRUE(all.equal(log1p(cohort$pre_election_count), cohort$log_earlier_reviews)),
          isTRUE(all.equal(ifelse(is.na(cohort$pre_election_mean), 4.6, cohort$pre_election_mean), cohort$rating_control)))
cohort[, `:=`(history_rating_missing=as.integer(is.na(history_mean)),
              history_rating=ifelse(is.na(history_mean), 4.6, history_mean),
              log_history_reviews=log1p(history_count))]
extended_terms <- c('history_rating','history_rating_missing','log_history_reviews')
attributes <- setdiff(unlist(design$specifications$full_snapshot), unlist(design$specifications$history))
specs <- list(long_history=extended_terms, long_history_snapshot=c(extended_terms, attributes))
ss <- ssc(K.adj=TRUE, K.fixef='nonnested', G.adj=TRUE, t.df='min')
results <- list()
coverage <- list()

for (pair_name in unique(prior$pair)) for (county_type in c('nonTrump','Trump','direct')) {
  saved <- prior[pair==pair_name & stratum==county_type]
  base_id <- saved[specification=='baseline', id]
  ref <- as.data.table(read.csv(file.path(root, paste0('verify_', base_id, '.csv.gz')),
                                colClasses=c(county='character')))
  d <- merge(ref, cohort, by='gmap_id', sort=FALSE)
  stopifnot(!anyDuplicated(d$gmap_id), nrow(d)==nrow(ref), all(d$county==d$county_fips),
            isTRUE(all.equal(d$y, d$change)))
  coverage[[length(coverage)+1]] <- data.table(pair=pair_name, stratum=county_type,
     restaurants=nrow(d), short_observed=sum(d$pre_election_count>0), long_observed=sum(d$history_count>0),
     short_median_reviews=median(d$pre_election_count), long_median_reviews=median(d$history_count))
  for (spec in names(specs)) {
    controls <- specs[[spec]]
    target <- if (county_type=='direct') 'interaction' else 'treated'
    terms <- c('treated', controls)
    if (county_type=='direct') {
      for (control in controls) d[, (paste0(control,'_T')) := get(control)*trump]
      terms <- c('treated','interaction',controls,paste0(controls,'_T'))
    }
    formula <- as.formula(paste('y ~', paste(terms, collapse=' + '), '| county'))
    fit <- feols(formula,
                 data=d, vcov=~county, ssc=ss, fixef.rm='none', notes=FALSE)
    ct <- coeftable(fit)[target, ]
    ci <- as.matrix(confint(fit))[target, ]
    stopifnot(nobs(fit)==nrow(ref), uniqueN(d$county)==saved[specification=='baseline',counties])
    comparison <- if (spec=='long_history') 'history' else 'full_snapshot'
    previous <- saved[specification==comparison]
    results[[length(results)+1]] <- data.table(pair=pair_name, stratum=county_type, specification=spec,
       estimate=unname(ct[1]), se=unname(ct[2]), p=unname(ct[4]), low=unname(ci[1]), high=unname(ci[2]),
       restaurants=nobs(fit), counties=uniqueN(d$county), comparison=comparison,
       previous_estimate=previous$estimate, previous_se=previous$se, previous_p=previous$p,
       se_change_pct=100*(unname(ct[2])/previous$se-1))
  }
}
results <- rbindlist(results)
for (pair_name in unique(results$pair)) for (spec in names(specs)) {
  z <- results[pair==pair_name & specification==spec]
  stopifnot(abs(z[stratum=='Trump',estimate]-z[stratum=='nonTrump',estimate]-z[stratum=='direct',estimate])<1e-8)
}
fwrite(results, file.path(out,'results.csv'))
fwrite(rbindlist(coverage), file.path(out,'coverage.csv'))
print(results[pair=='WPME versus ME'])
