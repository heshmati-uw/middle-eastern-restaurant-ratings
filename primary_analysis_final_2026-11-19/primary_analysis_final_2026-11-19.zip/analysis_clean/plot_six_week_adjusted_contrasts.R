args <- commandArgs(FALSE)
here <- dirname(normalizePath(sub("^--file=", "", args[grepl("^--file=", args)])))
out <- file.path(here, "aligned_restaurant_changes_2026_11_19", "longer_rating_history")
results <- read.csv(file.path(out, "outcome_window_by_rating_history.csv"))
results <- subset(results, weeks == 6 & history_weeks == 8)
results <- results[match(c("Trump", "nonTrump", "direct"), results$stratum), ]
stopifnot(nrow(results) == 3L, !anyNA(results$estimate),
          abs(results$estimate[1] - results$estimate[2] - results$estimate[3]) < 1e-8)

draw <- function() {
  par(mar=c(7.5, 18, 6, 2), las=1, family="sans")
  positions <- c(3.25, 2.25, .85)
  ink <- "#203442"
  colors <- c("#176F91", "#576773", "#665193")
  plot(c(-.53, 1.00), c(.28, 3.85), type="n", axes=FALSE, xlab="", ylab="")
  ticks <- seq(-.5, .75, by=.25)
  abline(v=ticks, col="#E5EBEE")
  abline(v=0, col="#71808A", lty=2)
  abline(h=1.54, col="#D5DFE3")
  axis(1, at=ticks, labels=sprintf("%.2f", ticks), col.axis=ink, col="#91A1A9")
  mtext("Adjusted rating change (stars)", 1, line=2.4, col=ink)
  mtext("Change in the WPME minus ME ratings gap after the ban", 3,
        line=3.5, adj=.5, font=2, cex=1.20, col=ink)
  mtext("Six weeks before and after  |  Eight weeks of historical rating and review activity controls",
        3, line=1.8, adj=.5, cex=.86, col="#52656F")
  labels <- c("Trump-majority counties", "Non-Trump-majority counties", "Direct county-type comparison")
  details <- c("198 restaurants", "2,148 restaurants", "Trump minus non-Trump")
  for (i in seq_along(positions)) {
    y <- positions[i]
    text(-.55, y+.10, labels[i], adj=1, xpd=NA, font=2, col=ink, cex=.94)
    text(-.55, y-.13, details[i], adj=1, xpd=NA, col="#52656F", cex=.82)
    arrows(results$low[i], y, results$high[i], y, code=3, angle=90,
           length=.045, lwd=2, col=colors[i])
    points(results$estimate[i], y, pch=c(16,16,18)[i], cex=1.35, col=colors[i])
    text(.98, y+.08, sprintf("%+.3f stars", results$estimate[i]), adj=1,
         font=2, col=colors[i], cex=.95)
    text(.98, y-.15, sprintf("p = %.3f", results$p[i]), adj=1, col=ink, cex=.82)
  }
  mtext("Positive values mean WPME gained relative to ME. Bars are 95% confidence intervals clustered by county.",
        1, line=4.3, adj=-.62, cex=.79, col="#52656F")
  mtext("Equal restaurant weights. Models include county fixed effects, price and service controls. Estimates are correlational.",
        1, line=5.55, adj=-.62, cex=.79, col="#52656F")
}

stem <- file.path(out, "six_week_adjusted_contrasts")
png(paste0(stem, ".png"), width=1900, height=970, res=175)
draw()
dev.off()
pdf(paste0(stem, ".pdf"), width=1900/175, height=970/175, useDingbats=FALSE)
draw()
dev.off()
