args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'preban_trends_2026_11_19')
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(fixest);library(data.table);library(jsonlite)})
setFixest_nthreads(1);d<-fread(file.path(o,'weekly_data.csv'),colClasses=c(county_fips='character'));design<-fromJSON(file.path(o,'design.json'));covs<-design$controls
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');tests<-list();effects<-list()
for(src in unique(d$source))for(tr in c(1,0)){
 z<-copy(d[source==src&trump==tr]);z[,nweeks:=.N,by=gmap_id];z<-z[nweeks>=2];z[,weight:=1/nweeks];z[,treated:=as.integer(group=='WPME')];z[,t:=as.integer((as.IDate(week)-min(as.IDate(week)))/7)];ref<-max(z$t);G<-uniqueN(z$county_fips)
 for(spec in c('FE only','All controls x week')){
  rhs<-sprintf('i(t,treated,ref=%d)',ref)
  if(spec!='FE only')rhs<-paste(c(rhs,sprintf('i(t,%s,ref=%d)',covs,ref)),collapse='+')
  fit<-feols(as.formula(paste('rating~',rhs,'|gmap_id+county_fips^t')),data=z,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  b<-coef(fit);V<-vcov(fit);ii<-grep('^t::[0-9]+:treated$',names(b));stopifnot(length(ii)==ref,nobs(fit)==nrow(z));Q<-V[ii,ii,drop=FALSE];stopifnot(qr(Q)$rank==length(ii))
  F<-as.numeric(t(b[ii])%*%solve(Q,b[ii])/length(ii));jp<-pf(F,length(ii),G-1,lower.tail=FALSE);ci<-as.matrix(confint(fit));id<-paste(src,tr,gsub(' ','_',spec),sep='__')
  ev<-as.integer(sub(':treated$','',sub('^t::','',names(b)[ii])))
  effects[[length(effects)+1]]<-rbind(data.table(id,source=src,trump=tr,spec,t=ev,estimate=unname(b[ii]),se=sqrt(diag(V))[ii],low=ci[ii,1],high=ci[ii,2]),data.table(id,source=src,trump=tr,spec,t=ref,estimate=0,se=0,low=0,high=0))
  z[,trend_group:=treated*t];terms<-'trend_group'
  if(spec!='FE only'){
   for(cov in covs)z[,(paste0(cov,'_slope')):=get(cov)*t]
   terms<-c(terms,paste0(covs,'_slope'))
  }
  lin<-feols(as.formula(paste('rating~',paste(terms,collapse='+'),'|gmap_id+county_fips^t')),data=z,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE)
  ct<-coeftable(lin)['trend_group',];lc<-as.matrix(confint(lin))['trend_group',]
  tests[[length(tests)+1]]<-data.table(id,source=src,trump=tr,spec,restaurants=uniqueN(z$gmap_id),ME=uniqueN(z[group=='ME']$gmap_id),WPME=uniqueN(z[group=='WPME']$gmap_id),counties=G,restaurant_weeks=nrow(z),reviews=sum(z$reviews),pre_weeks=ref+1,joint_F=F,joint_p=jp,restrictions=length(ii),slope=ct[1],slope_se=ct[2],slope_p=ct[4],slope_low=lc[1],slope_high=lc[2])
  # Export all nuisance and target coefficients for independent reconstruction.
  for(kind in c('event','linear')){
   model<-if(kind=='event')fit else lin;bn<-coef(model);vars<-names(bn)
   X<-model.matrix(model,type='rhs');X<-X[,vars,drop=FALSE]
   out<-data.table(gmap_id=z$gmap_id,county=z$county_fips,t=z$t,y=z$rating,weight=z$weight);out<-cbind(out,as.data.table(X));fwrite(out,file.path(o,paste0('verify_',id,'_',kind,'.csv.gz')))
   fwrite(data.table(term=vars,estimate=unname(bn)),file.path(o,paste0('coef_',id,'_',kind,'.csv')))
   write.csv(vcov(model),file.path(o,paste0('cov_',id,'_',kind,'.csv')))
  }
 }
}
tt<-rbindlist(tests);ee<-rbindlist(effects);fwrite(tt,file.path(o,'pretrend_tests.csv'));fwrite(ee,file.path(o,'event_study.csv'));print(tt)
