args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'preban_trends_2026_11_19')
m<-read.csv(file.path(o,'observed_means.csv'));m$date<-as.Date(m$week)
r<-read.csv(file.path(o,'pretrend_tests.csv'));e<-read.csv(file.path(o,'event_study.csv'))
draw<-function(src){
 par(mfrow=c(2,2),mar=c(6,5.2,4,1),oma=c(8.5,0,4,0),las=1)
 start<-min(m$date[m$source==src]);dates<-sort(unique(m$date[m$source==src]));xx<-as.Date(c(start, '2017-01-30'));cols<-c(ME='#B44E43',WPME='#176F91')
 for(tr in c(1,0)){
  z<-m[m$source==src&m$trump==tr,];yy<-range(m$mean_rating[m$source==src]);yy<-yy+c(-.12,.17)
  plot(xx,yy,type='n',axes=FALSE,xlab='',ylab='Mean rating (stars)',main=if(tr==1)'Trump-majority counties' else 'Non-Trump-majority counties')
  abline(h=pretty(yy),col='gray92');rect(as.Date('2016-12-19'),yy[1],as.Date('2017-01-09'),yy[2],col=adjustcolor('#D6B574',alpha.f=.14),border=NA)
  axis(2);axis.Date(1,at=dates[seq(1,length(dates),by=if(length(dates)>4)2 else 1)],format='%b %d');box(bty='l')
  abline(v=as.Date('2017-01-20'),col='gray60',lty=3);abline(v=as.Date('2017-01-27'),col='#934345',lty=2)
  for(g in c('ME','WPME')){a<-z[z$group==g,];a<-a[order(a$date),];lines(a$date,a$mean_rating,type='o',col=cols[g],lwd=2.4,pch=if(g=='ME')15 else 16,lty=if(g=='ME')1 else 2)}
  legend('topleft',legend=c('ME','WPME'),col=cols,lwd=2,lty=1:2,pch=c(15,16),bty='n',horiz=TRUE,cex=.85)
  nn<-sapply(c('ME','WPME'),function(g){a<-z[z$group==g,];sprintf('%s weekly N: %d-%d',g,min(a$restaurants),max(a$restaurants))})
  mtext(paste(nn,collapse=' | '),side=3,line=.3,cex=.8)
 }
 for(tr in c(1,0)){
  z<-e[e$source==src&e$trump==tr,];z$date<-start+7*z$t;q<-r[r$source==src&r$trump==tr,];full<-q[q$spec=='All controls x week',];simple<-q[q$spec=='FE only',]
  yy<-range(c(z$low,z$high,0));yy<-yy+c(-.05,.12)
  plot(xx,yy,type='n',axes=FALSE,xlab='Week starting',ylab='WPME - ME gap, relative to Jan 16',main=if(tr==1)'Adjusted pre-ban gap: Trump' else 'Adjusted pre-ban gap: non-Trump',cex.main=.95)
  abline(h=0,lty=2,col='gray55');axis(2);axis.Date(1,at=dates[seq(1,length(dates),by=if(length(dates)>4)2 else 1)],format='%b %d');box(bty='l')
  for(spec in c('FE only','All controls x week')){
   a<-z[z$spec==spec,];a<-a[order(a$t),];col<-if(spec=='FE only')'#9B9FA1' else '#176F91';offset<-if(spec=='FE only')-.45 else .45
   segments(a$date+offset,a$low,a$date+offset,a$high,col=col,lwd=1.4);lines(a$date+offset,a$estimate,type='o',col=col,pch=if(spec=='FE only')1 else 16,lwd=1.4)
  }
  mtext(sprintf('Joint pretrend p: FE %.3f | all controls %.3f',simple$joint_p,full$joint_p),side=3,line=.35,cex=.8)
  legend('topleft',legend=c('Restaurant + county-week FE','FE + controls x week'),col=c('#9B9FA1','#176F91'),lty=1,pch=c(1,16),bty='n',cex=.66)
  mtext(sprintf('All-controls test sample: %d ME / %d WPME; %d counties',full$ME,full$WPME,full$counties),side=1,line=4.5,cex=.73)
 }
 mtext(if(src=='exact_raw_10weeks')'Pre-ban trends | Ten weeks from the original raw reviews' else 'Pre-ban trends | Four-week baseline from the original raw reviews',side=3,outer=TRUE,line=2,font=2,cex=1.3)
 mtext('Final 11/18 ME/WPME definitions and paired ban cohort | No matching | Holidays included',side=3,outer=TRUE,line=.4,cex=.9)
 mtext('Top: observed means, equal restaurant weight within each week; restaurant composition varies with review activity.',side=1,outer=TRUE,line=1,cex=.8)
 mtext('Bottom: restaurant and county-by-week FE; each restaurant receives equal total weight across its observed weeks.',side=1,outer=TRUE,line=2.4,cex=.8)
 mtext('Tests require at least two observed pre-weeks. Bars are 95% county-clustered pointwise intervals; Jan 16 is the reference.',side=1,outer=TRUE,line=3.7,cex=.77)
 mtext('Shading: holiday period. Dotted: inauguration Jan 20. Dashed red: ban Jan 27. No post-ban outcomes shown.',side=1,outer=TRUE,line=5,cex=.78)
 mtext('Undated price/service controls are sensitivity adjustments. Non-rejection does not establish parallel trends.',side=1,outer=TRUE,line=6.2,cex=.78)
}
for(src in unique(m$source)){
 png(file.path(o,paste0(src,'_trends.png')),width=2200,height=1850,res=175);draw(src);dev.off()
 pdf(file.path(o,paste0(src,'_trends.pdf')),width=12.6,height=10.6,useDingbats=FALSE);draw(src);dev.off()
}
