args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(h,'full_pre_election_core');crosscounty<-'--cross-county' %in% args;o<-file.path(s,'attribute_matching',if(crosscounty)'price_distance_common' else 'common_triplets')
d<-fread(file.path(o,'common_matched_restaurants.csv'),colClasses=c(county_fips='character'))
w<-fread(file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');means<-list();tests<-list();estimates<-list();levels<-list();panels<-list();meanpanels<-list();covs<-list()
for(en in c('Election','Ban'))for(t in c(1,0)){
 a<-d[event==en&trump==t];a[,`:=`(isME=as.integer(group=='ME'),isWP=as.integer(group=='WPME'))]
 mf<-feols(change~isME+isWP|triplet_id,a,vcov=~county_fips,ssc=ss)
 for(pair in c('ME_WPME','ME_MED','WPME_MED')){
  L<-switch(pair,ME_WPME=c(1,-1),ME_MED=c(1,0),WPME_MED=c(0,1));b<-sum(L*coef(mf));se<-sqrt(as.numeric(t(L)%*%vcov(mf)%*%L));G<-uniqueN(a$county_fips);p<-2*pt(-abs(b/se),G-1)
  means[[length(means)+1]]<-data.table(event=en,trump=t,pair,estimate=b,se,p,first_N=nrow(a)/3,second_N=nrow(a)/3,counties=G,low=b-qt(.975,G-1)*se,high=b+qt(.975,G-1)*se)
 }
 ap<-a[,.(gmap_id,county_fips,triplet_id,group,isME,isWP,change)];ap[,`:=`(event=en,trump=t,df_K=attr(vcov(mf,attr=TRUE),'df.K'))];meanpanels[[length(meanpanels)+1]]<-ap
 mixed<-as.IDate(if(en=='Election')'2016-11-07' else '2017-01-23')
 dw<-merge(w[week>=mixed-70&week<=mixed+28&week!=mixed&reviews>0&!is.na(rating)],a[,.(gmap_id,county_fips,group,isME,isWP,triplet_id)],by='gmap_id')
 keep<-intersect(dw[week<mixed,.N,by=gmap_id][N>=2]$gmap_id,dw[week>mixed]$gmap_id);dw<-dw[gmap_id %chin% keep]
 dw<-dw[triplet_id %chin% dw[,.(n=uniqueN(gmap_id)),by=triplet_id][n==3]$triplet_id];dw[,weight:=1/.N,by=gmap_id];dw[,event_week:=as.integer((week-mixed)/7)]
 fit<-feols(rating~i(event_week,isME,ref=-1)+i(event_week,isWP,ref=-1)|gmap_id+county_fips^week,dw,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none')
 B<-coef(fit);V<-vcov(fit);G<-uniqueN(dw$county_fips);weeks<-sort(unique(dw$event_week));dfk<-attr(vcov(fit,attr=TRUE),'df.K')
 for(pair in c('ME_WPME','ME_MED','WPME_MED')){
  L<-matrix(0,length(weeks),length(B),dimnames=list(weeks,names(B)))
  for(j in seq_along(weeks))if(weeks[j]!= -1){
   nME<-paste0('event_week::',weeks[j],':isME');nWP<-paste0('event_week::',weeks[j],':isWP')
   if(pair %in% c('ME_WPME','ME_MED'))L[j,nME]<-1
   if(pair=='ME_WPME')L[j,nWP]<- -1
   if(pair=='WPME_MED')L[j,nWP]<-1
  }
  beta<-as.numeric(L%*%B);C<-L%*%V%*%t(L);se<-sqrt(pmax(0,diag(C)));ii<-which(weeks< -1);p<-NA_real_;F<-NA_real_;reason<-''
  if(G>length(ii)&&qr(C[ii,ii])$rank==length(ii)){
   F<-as.numeric(t(beta[ii])%*%solve(C[ii,ii],beta[ii])/length(ii));p<-pf(F,length(ii),G-1,lower.tail=FALSE)
  }else reason<-'Too few independent county scores for full joint pretest'
  z<-data.table(event=en,trump=t,pair,event_week=weeks,estimate=beta,se,low=beta-qt(.975,G-1)*se,high=beta+qt(.975,G-1)*se);estimates[[length(estimates)+1]]<-z
  tests[[length(tests)+1]]<-data.table(event=en,trump=t,pair,first_N=uniqueN(dw$gmap_id)/3,second_N=uniqueN(dw$gmap_id)/3,counties=G,restrictions=length(ii),F,p,reason)
 }
 dw[,`:=`(event=en,trump=t,df_K=dfk)];panels[[length(panels)+1]]<-dw
 lev<-dw[,.(rating=mean(rating),restaurants=.N),by=.(group,week)];lev[,`:=`(event=en,trump=t)];setorder(lev,group,week);levels[[length(levels)+1]]<-lev
 # Save full estimates/covariance for independent checks.
 covs[[paste(en,t,sep='_')]]<-list(names=names(B),b=as.numeric(B),V=unname(V),df_K=dfk)
 er<-rbindlist(estimates)[event==en&trump==t&pair!='ME_WPME'];cols<-c('#185b7a','#c45a3c','#6b7d35')
 png(file.path(o,paste0(en,'_',if(t==1)'Trump' else 'NonTrump','_common.png')),width=1600,height=1600,res=160);par(mfrow=c(3,1),mar=c(3.5,5,3,1),oma=c(3,0,1,0))
 dates<-sort(unique(lev$week));title<-paste(en,if(t==1)'| Trump counties' else '| Non-Trump counties',if(crosscounty)'| Common price + distance matches' else '| Common price-matched triplets')
 plot(range(dates),range(lev$rating),type='n',xaxt='n',xlab='',ylab='Raw average rating (stars)',main=title);axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=as.Date(mixed)+4,lty=2,col='grey50')
 for(k in 1:3){zz<-lev[group==c('ME','WPME','MED')[k]];lines(zz$week,zz$rating,col=cols[k],lwd=2);points(zz$week,zz$rating,col=cols[k],pch=c(16,17,15)[k])};legend('bottomleft',legend=c('ME','WPME','Mediterranean'),col=cols,lty=1,pch=c(16,17,15),bty='n',horiz=TRUE,cex=.8)
 plot(range(dates),range(c(er$low,er$high,0)),type='n',xaxt='n',xlab='',ylab='Rating gap vs Mediterranean',main='Adjusted gaps using the same Mediterranean restaurants');axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=as.Date(mixed)+4,lty=2,col='grey50');abline(h=0,lty=3,col='grey50')
 for(k in 1:2){zz<-er[pair==c('ME_MED','WPME_MED')[k]][order(event_week)];x<-as.Date(mixed)+7*zz$event_week;segments(x,zz$low,x,zz$high,col=adjustcolor(cols[k],alpha.f=.35));lines(x,zz$estimate,col=cols[k],lwd=2);points(x,zz$estimate,col=cols[k],pch=c(16,17)[k])};legend('topleft',legend=c('ME vs Mediterranean','WPME vs Mediterranean'),col=cols[1:2],lty=1,pch=c(16,17),bty='n',horiz=TRUE,cex=.8)
 plot(range(dates),c(0,max(lev$restaurants)+2),type='n',xaxt='n',xlab='',ylab='Restaurants observed',main=sprintf('Common weekly-eligible cohort: %d restaurants per group; %d counties',uniqueN(dw$gmap_id)/3,G));axis.Date(1,at=dates,format='%b %d',las=2,cex.axis=.7);abline(v=as.Date(mixed)+4,lty=2,col='grey50')
 for(k in 1:3){zz<-lev[group==c('ME','WPME','MED')[k]];lines(zz$week,zz$restaurants,col=cols[k],lwd=2);points(zz$week,zz$restaurants,col=cols[k],pch=c(16,17,15)[k])}
 mtext('Holidays retained; mixed event week omitted. Weekly observations vary within the fixed eligible cohort.',side=1,outer=TRUE,line=.6,cex=.72)
 mtext('Adjusted model: restaurant and county-by-week FE; total restaurant weight one; 95% county-clustered intervals.',side=1,outer=TRUE,line=1.7,cex=.67);dev.off()
}
fwrite(rbindlist(means),file.path(o,'mean_results.csv'));fwrite(rbindlist(tests),file.path(o,'pretrend_tests.csv'));fwrite(rbindlist(estimates),file.path(o,'weekly_estimates.csv'));fwrite(rbindlist(levels),file.path(o,'weekly_group_means.csv'))
fwrite(rbindlist(panels),file.path(o,'weekly_verification_inputs.csv'));fwrite(rbindlist(meanpanels),file.path(o,'mean_verification_inputs.csv'));jsonlite::write_json(covs,file.path(o,'weekly_model_coefficients.json'),auto_unbox=TRUE,digits=16)
print(rbindlist(means));print(rbindlist(tests))
