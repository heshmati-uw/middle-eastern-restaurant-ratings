"""Common three-group price matches with geographic preference, cross-county allowed."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'attribute_matching/price_distance_common';O.mkdir(exist_ok=True)
sys.path.insert(0,str(H.parent/'.analysis-python'))
from scipy.optimize import linear_sum_assignment
groups=['ME','WPME','MED'];out=[];flows=[];distances=[]
attrs=pd.read_csv(S/'attribute_matching/restaurant_attributes.csv',usecols=['gmap_id','price_tier'])
meta=pd.read_csv(S/'restaurant_precinct_assignments.csv',dtype={'county_fips':str},usecols=['gmap_id','group','county_fips','trump','latitude','longitude','state','primary_category'])
meta=meta[meta.group.isin(groups)&meta.trump.isin([0,1])&meta.county_fips.notna()&meta.latitude.notna()&meta.longitude.notna()]
assert not meta.gmap_id.duplicated().any()
def distance(a,b):
 la=np.radians(a.latitude.to_numpy())[:,None];lb=np.radians(b.latitude.to_numpy())[None,:];dl=np.radians(a.longitude.to_numpy())[:,None]-np.radians(b.longitude.to_numpy())[None,:]
 h=np.sin((la-lb)/2)**2+np.cos(la)*np.cos(lb)*np.sin(dl/2)**2
 return 6371.0088*2*np.arcsin(np.sqrt(np.clip(h,0,1)))
design={'groups':groups,'ratio':'1:1:1 without replacement','exact_matching':['price_tier'],'separate_samples':['event','Trump/non-Trump county status'],'county_must_match':False,'distance_preference':'Optimal squared great-circle-distance assignment from the smallest group in each price stratum to each other group. No hard distance cap. This is an anchor-based assignment, not a globally optimal three-way match.','outcomes_used_for_matching':False,'eligibility':'Known county vote, known pre-election core label, coordinates, price and observed four-week pre/post ratings. No same-county pairwise overlap or precinct-assignment restriction.','holidays':'Included','timing_caveat':'Price is undated metadata; descriptive sensitivity.'}
(O/'design.json').write_text(json.dumps(design,indent=2))
for event in ['Election','Ban']:
 periods=pd.read_csv(S/'inputs'/f'periods_{event.lower()}_4w.csv')
 q=periods.merge(meta,on='gmap_id',validate='one_to_one').merge(attrs,on='gmap_id',validate='one_to_one')
 q=q[q.rating_pre.notna()&q.rating_post.notna()&q.price_tier.notna()]
 assert np.allclose(q.change,q.rating_post-q.rating_pre)
 for t in [1,0]:
  eligible=q[q.trump.eq(t)].copy();matched=[];tid=0;ds=[]
  for price,z in eligible.groupby('price_tier',sort=True):
   parts={g:z[z.group.eq(g)].sort_values('gmap_id').reset_index(drop=True) for g in groups}
   if any(parts[g].empty for g in groups):continue
   anchor=min(groups,key=lambda g:len(parts[g]));a=parts[anchor];assignment={anchor:np.arange(len(a))}
   for g in groups:
    if g==anchor:continue
    row,col=linear_sum_assignment((distance(a,parts[g])/20)**2);assert np.array_equal(row,np.arange(len(a)));assignment[g]=col
   for j in range(len(a)):
    tid+=1;triplet=f'{event}_{t}_{tid}';members={g:parts[g].iloc[assignment[g][j]] for g in groups}
    for g,r in members.items():
     rr=r.to_dict();rr.update(event=event,triplet_id=triplet,anchor_group=anchor);matched.append(rr)
    for left,right in [('ME','WPME'),('ME','MED'),('WPME','MED')]:
     aa=pd.DataFrame([members[left]]);bb=pd.DataFrame([members[right]]);km=float(distance(aa,bb)[0,0]);ds.append(km)
     distances.append(dict(event=event,trump=t,triplet_id=triplet,pair=f'{left}_{right}',distance_km=km,same_county=members[left].county_fips==members[right].county_fips,same_state=members[left].state==members[right].state))
  m=pd.DataFrame(matched);assert m.groupby('triplet_id').group.nunique().eq(3).all() and not m.gmap_id.duplicated().any();assert m.groupby('triplet_id').price_tier.nunique().eq(1).all();out.append(m)
  flows.append(dict(event=event,trump=t,triplets=tid,restaurants=len(m),counties=m.county_fips.nunique(),median_pair_distance_km=np.median(ds),max_pair_distance_km=max(ds),**{f'eligible_{g}':sum(eligible.group.eq(g)) for g in groups}))
pd.concat(out,ignore_index=True).to_csv(O/'common_matched_restaurants.csv',index=False);pd.DataFrame(flows).to_csv(O/'sample_flow.csv',index=False);pd.DataFrame(distances).to_csv(O/'pair_distances.csv',index=False)
print(pd.DataFrame(flows).to_string(index=False))
