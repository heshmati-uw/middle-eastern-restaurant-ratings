"""Verify and explain direct average changes separately from voting gradients."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'ME_WPME_focus'
r=pd.read_csv(O/'direct_comparisons.csv');r['term']='ME';e=pd.read_csv(O/'direct_placebos_and_county_difference.csv');allr=pd.concat([r,e],ignore_index=True)
d=pd.read_csv(O/'verification_designs.csv',dtype={'county_fips':str,'fixed_effect':str});errors=[]
for row in allr.itertuples():
 z=d[d.model_id.eq(row.id)].copy();cols=row.variables.split(';');v=z[cols+['change']];v=v-v.groupby(z.fixed_effect).transform('mean')
 x=v[cols].to_numpy();y=v.change.to_numpy();inv=np.linalg.pinv(x.T@x);b=inv@x.T@y;res=y-x@b
 scores=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
 cov=inv@scores.T@scores@inv*g/(g-1)*(n-1)/(n-row.df_K);j=cols.index(row.term);errors.extend([abs(b[j]-row.estimate),abs(np.sqrt(cov[j,j])-row.se)])
assert len(allr)==32 and max(errors)<1e-8,max(errors)
verification={'models_independently_verified':len(allr),'max_coefficient_or_se_error':max(errors),'inference':'County-clustered CR1; t df=counties-1','equal_restaurant_weights':True,'only_ME_WPME_restaurants':True}
(O/'verification.json').write_text(json.dumps(verification,indent=2))
means=pd.read_csv(O/'group_means.csv')
for row in r[r.model.eq('Raw mean difference in changes')].itertuples():
 z=means[means.shock.eq(row.shock)&means.stratum.eq(row.stratum)].set_index('group');assert abs((z.loc['ME','change']-z.loc['WPME','change'])-row.estimate)<1e-10
gradient=pd.read_csv(S/'regressions/interaction_results.csv');gradient=gradient[gradient.comparison.eq('ME vs WPME')&gradient.model.eq('Precinct share + county FE')&gradient['sample'].eq('Main matched sample')]
def fmt(q):
 q=q.copy();q['Estimate (SE)']=q.apply(lambda x:f'{x.estimate:+.3f}{x.symbol if isinstance(x.symbol,str) else ""} ({x.se:.3f})',axis=1);q['95% CI']=q.apply(lambda x:f'[{x.low:+.3f}, {x.high:+.3f}]',axis=1);q['Raw p']=q.p.map(lambda x:f'{x:.4f}');q['N ME / WPME']=q.apply(lambda x:f'{x.ME:,} / {x.WPME:,}',axis=1) if 'ME'in q else '';return q
cols=['shock','stratum','Estimate (SE)','95% CI','Raw p','N ME / WPME','counties']
main=r[r.model.eq('County FE difference in changes')&~r.stratum.eq('All counties')]
g=gradient.rename(columns={'first_restaurants':'ME','second_restaurants':'WPME'})
tab=lambda q:q.to_html(index=False,border=0,float_format=lambda x:f'{x:.4f}')
html='''<!doctype html><html><head><meta charset="utf-8"><title>ME versus WPME: direct average changes</title><style>body{font:16px/1.5 system-ui;max-width:1350px;margin:36px auto;padding:0 24px;color:#243343}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3f6}td:nth-child(-n+3){text-align:left}.note{padding:18px;background:#edf3f6}.scroll{overflow:auto}</style></head><body><h1>ME versus WPME only</h1><p>Uses the completed national raw pre-election scan, 27 unchanged core tags, primary categories, four-week windows, and equal restaurant weights. Mediterranean restaurants are excluded from every model on this page.</p>
<div class="note"><b>Two different questions:</b> The previous precinct model already used only ME and WPME, but tested whether their relative change varies with local Trump vote share. The direct models below ask whether ME changed more or less than WPME on average within each county stratum. Removing the other comparisons from a report cannot change the original pairwise gradient estimates.</div>
<h2>Direct average-change comparisons: county fixed effects</h2><p>Estimate = ME change minus WPME change, in rating stars. Negative means ME lost ground relative to WPME. Raw two-sided p symbols: + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001.</p>'''+tab(fmt(main)[cols])+'''
<p>After the ban in Trump counties, the county-adjusted relative change is −.433 stars (raw p=.0191; 72 ME, 62 WPME, 23 counties). The raw group means show ME falling from 4.501 to 4.358 (−.144) and WPME rising from 4.319 to 4.542 (+.223): their unadjusted difference in changes is −.367 (p=.0142). The adjusted −.433 is a relative difference, not ME's own average decline.</p>
<h2>Descriptive means, each restaurant weighted equally</h2>'''+tab(means)+'''
<h2>Raw and adjusted specifications</h2><div class="scroll">'''+tab(fmt(r)[['shock','stratum','model','Estimate (SE)','95% CI','Raw p','p_holm_four_split','p_holm_six','N ME / WPME','counties']])+'''
</div><p>The raw model regresses restaurant change on ME. The main model adds county FE, absorbing county-wide rating changes; it is point-equivalent to restaurant FE plus county-by-period effects in a two-period panel. Rows retain unit restaurant weights. County-clustered CR1 standard errors use t degrees of freedom equal to counties minus one. Baseline sensitivity adds pre-period rating and log(1+pre-period reviews), changing the conditional identifying assumption. The ban Trump estimate becomes −.231 (raw p=.0175), so its magnitude is sensitive even though the raw p remains below .05.</p>
<p>For the main county-FE model, Holm across the four split-county event tests gives ban-Trump p=.0763; including the two pooled-event tests gives p=.1144. These are exploratory findings in a project with additional earlier tests, not a prespecified isolated hypothesis family.</p>
<h2>Is the average relative change different across county types?</h2>'''+tab(fmt(e[e.model.eq('Difference between county strata')])[cols])+'''
<p>These directly test the Trump-minus-non-Trump difference in ME–WPME changes. For the ban the estimate is −.503 (raw p=.0049), versus −.241 (p=.1471) for the election. The model includes ME, ME×TrumpCounty, and county FE; the TrumpCounty main effect is absorbed. This test does not involve a continuous precinct voting gradient.</p>
<h2>Pre-event changes and causal limits</h2>'''+tab(fmt(e[~e.model.eq('Difference between county strata')])[['shock','stratum','model','Estimate (SE)','95% CI','Raw p','N ME / WPME','counties']])+'''
<p>In the smaller observed-history Trump-county ban subset (117 restaurants), the pre-ban ME–WPME change gap is +.305 (raw p=.0757), followed by an event-period gap of −.411 (p=.0249). This pre-period movement raises a parallel-trends/mean-reversion concern. A non-significant pretest at 5% is not evidence that trends are parallel. The check is one coarse four-week-block difference, not a full weekly event study. Election placebo compares September 12–October 9 to October 10–November 6, 2016; ban placebo compares November 28–December 25 to December 26–January 22. Current results support an association, not a causal conclusion.</p>
<h2>Original continuous precinct gradients, unchanged</h2>'''+tab(fmt(g[~g.stratum.eq('All counties')])[cols])+'''
<p>These estimates are rating-change-gap gradients per +10 percentage points of precinct Trump share. The direct average-change estimates above are rating-star gaps, without that scaling. The gradient question and average-change question can yield different p-values without contradiction.</p>
<p>All 32 new average-change/placebo/direct-county-test coefficients and standard errors were independently reproduced in NumPy. Existing full-scan classification, outcomes, county overlap, and precinct eligibility are unchanged. <a href="direct_comparisons.csv">Direct results</a> · <a href="group_means.csv">Means</a> · <a href="direct_placebos_and_county_difference.csv">Placebos/direct county tests</a> · <a href="verification.json">Verification</a> · <a href="../full_core_report.html">Full scan report</a> · <a href="../../focus_full_ME_WPME.R">R code</a></p></body></html>'''
(O/'focus_report.html').write_text(html,encoding='utf-8')
print(fmt(main)[cols].to_string(index=False));print(json.dumps(verification))
