# Direct ME-WPME average changes, distinct from voting-gradient interactions.
args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
src<-file.path(here,'full_pre_election_core');out<-file.path(src,'ME_WPME_focus');dir.create(out,showWarnings=FALSE)
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');rows<-list();means<-list();designs<-list()
extra<-list();w<-fread(file=file.path(src,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
export_extra<-function(fit,d,event,stratum,type,term='ME'){
 ct<-coeftable(fit)[term,];ci<-as.matrix(confint(fit))[term,];G<-uniqueN(d$county_fips);id<-100L+length(extra)+1L
 extra[[length(extra)+1L]]<<-data.table(id,shock=event,stratum,model=type,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),ME=sum(d$ME),WPME=sum(1-d$ME),counties=G,df_K=attr(vcov(fit,attr=TRUE),'df.K'),term,variables=paste(names(coef(fit)),collapse=';'))
 z<-d[,.(gmap_id,county_fips,ME,change)];if(term=='ME_trump')z[,ME_trump:=d$ME_trump]
 z[,`:=`(model_id=id,fixed_effect=county_fips)];designs[[length(designs)+1L]]<<-z
}
for(event in c('Election','Ban')){
 q<-fread(file=file.path(src,'regressions',paste0('sample_ME_WPME_',tolower(event),'.csv')),colClasses=c(county_fips='character'))
 stopifnot(all(q$group %chin% c('ME','WPME')))
 for(stratum in c('All counties','Trump counties','Non-Trump counties')){
  d<-copy(if(stratum=='All counties')q else if(stratum=='Trump counties')q[trump==1] else q[trump==0]);d[,`:=`(ME=as.integer(group=='ME'),log_pre_reviews=log1p(reviews_pre))]
  m<-d[,.(restaurants=.N,pre=mean(rating_pre),post=mean(rating_post),change=mean(change)),by=group];m[,`:=`(shock=event,stratum=stratum)];means[[length(means)+1L]]<-m
  for(spec in c('Raw mean difference in changes','County FE difference in changes','County FE + baseline adjustment')){
   formula<-if(spec=='Raw mean difference in changes')change~ME else if(spec=='County FE difference in changes')change~ME|county_fips else change~ME+rating_pre+log_pre_reviews|county_fips
   fit<-feols(formula,data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
   ct<-coeftable(fit)['ME',];ci<-as.matrix(confint(fit))['ME',];G<-uniqueN(d$county_fips);id<-length(rows)+1L
   stopifnot(nobs(fit)==nrow(d),abs(ct[4]-2*pt(abs(ct[3]),G-1,lower.tail=FALSE))<1e-10)
   vars<-setdiff(names(coef(fit)),'(Intercept)')
   rows[[id]]<-data.table(id,shock=event,stratum,model=spec,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),ME=sum(d$ME),WPME=sum(1-d$ME),counties=G,df_K=attr(vcov(fit,attr=TRUE),'df.K'),variables=paste(vars,collapse=';'))
   z<-d[,unique(c('gmap_id','county_fips','change',vars)),with=FALSE];z[,`:=`(model_id=id,fixed_effect=if(spec=='Raw mean difference in changes')'all' else county_fips)];designs[[length(designs)+1L]]<-z
  }
  dates<-if(event=='Election')c('2016-09-12','2016-10-03') else c('2016-11-28','2016-12-19')
  pre<-w[week>=as.IDate(dates[1])&week<=as.IDate(dates[2])&reviews>0&!is.na(rating),.(prior_rating=sum(rating*reviews)/sum(reviews)),by=gmap_id]
  dd<-merge(d,pre,by='gmap_id');ids<-dd[,.(sides=uniqueN(ME)),by=county_fips][sides==2]$county_fips;dd<-dd[county_fips %chin% ids]
  fp<-feols(change~ME|county_fips,data=dd,vcov=~county_fips,ssc=ss,notes=FALSE);export_extra(fp,dd,event,stratum,'Event difference on placebo subset')
  dd[,change:=rating_pre-prior_rating];fp<-feols(change~ME|county_fips,data=dd,vcov=~county_fips,ssc=ss,notes=FALSE);export_extra(fp,dd,event,stratum,'Pre-event mean-change placebo')
 }
 q[,`:=`(ME=as.integer(group=='ME'),ME_trump=as.integer(group=='ME')*trump)]
 fd<-feols(change~ME+ME_trump|county_fips,data=q,vcov=~county_fips,ssc=ss,notes=FALSE);export_extra(fd,q,event,'Trump minus non-Trump','Difference between county strata','ME_trump')
}
r<-rbindlist(rows);r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
r[,p_holm_six:=p.adjust(p,'holm'),by=model]
r[,p_holm_four_split:=NA_real_];r[stratum!='All counties',p_holm_four_split:=p.adjust(p,'holm'),by=model]
e<-rbindlist(extra);e[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(e,file.path(out,'direct_placebos_and_county_difference.csv'))
fwrite(r,file.path(out,'direct_comparisons.csv'));fwrite(rbindlist(means),file.path(out,'group_means.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'verification_designs.csv'));print(r);print(e)
