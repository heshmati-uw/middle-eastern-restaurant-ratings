# Core-only pairwise precinct moderation; no changes to prior ME-WPME outputs.
args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
full_pre<-'--full-pre'%in%commandArgs(TRUE)
out<-file.path(here,if(full_pre)'full_pre_election_core/regressions' else 'precinct_core_mediterranean');dir.create(out,showWarnings=FALSE,recursive=TRUE)
src<-if(full_pre)file.path(here,'full_pre_election_core','inputs') else file.path(here,'county_fe_regressions','inputs')
a<-fread(file=file.path(here,if(full_pre)'full_pre_election_core' else 'precinct_core','restaurant_precinct_assignments.csv'),colClasses=c(county_fips='character'))
stopifnot(all(a$definition==if(full_pre)'full_core_pre' else 'expanded_core_pre'))
pairs<-if(full_pre)list(c('ME','WPME'),c('ME','MED'),c('WPME','MED')) else list(c('ME','MED'),c('WPME','MED'))
w<-fread(file=file.path(src,'expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
rows<-list();designs<-list();preds<-list();sizes<-list()
fit_one<-function(d,event,first_group,stratum,label,variables,fe='county_fips',exposure='Precinct',sample='Main matched sample'){
 if(fe=='county_group'){
  d<-d[county_group %chin% d[,.N,by=county_group][N>1]$county_group]
  d<-d[county_fips %chin% d[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips]
 }
 G<-uniqueN(d$county_fips);stopifnot(G>1)
 fit<-feols(as.formula(paste('change ~',paste(variables,collapse='+'),'|',fe)),data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
 stopifnot(nobs(fit)==nrow(d),'first_share'%in%names(coef(fit)))
 ct<-coeftable(fit)['first_share',];ci<-as.matrix(confint(fit))['first_share',];id<-length(rows)+1L
 stopifnot(abs(ct[4]-2*pt(abs(ct[3]),G-1,lower.tail=FALSE))<1e-9)
 rows[[id]]<<-data.table(id,shock=event,comparison=paste(first_group,'vs',second_group),first_group,second_group,stratum,model=label,sample,exposure,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),first_restaurants=sum(d$first),MED_restaurants=sum(1-d$first),counties=G,precincts=uniqueN(d$precinct_id),df_K=attr(vcov(fit,attr=TRUE),'df.K'),variables=paste(names(coef(fit)),collapse=';'))
 z<-copy(d[,unique(c('gmap_id','change','county_fips',fe,names(coef(fit)))),with=FALSE]);z[,`:=`(fixed_effect=as.character(get(fe)),model_id=id)];designs[[id]]<<-z
 if(label=='Precinct share + county FE' & stratum=='All counties' & sample=='Main matched sample'){
  b<-coef(fit);V<-vcov(fit);lo<-max(quantile(d[first==1]$precinct_share,.05),quantile(d[first==0]$precinct_share,.05));hi<-min(quantile(d[first==1]$precinct_share,.95),quantile(d[first==0]$precinct_share,.95))
  pp<-data.table(shock=event,first_group,second_group,share=seq(lo,hi,length.out=101));s<-(pp$share-.5)/.1
  pp[,estimate:=b['first']+s*b['first_share']];se<-sqrt(V['first','first']+s^2*V['first_share','first_share']+2*s*V['first','first_share'])
  pp[,`:=`(low=estimate-qt(.975,G-1)*se,high=estimate+qt(.975,G-1)*se)];preds[[length(preds)+1L]]<<-pp
 }
}
for(event in c('Election','Ban'))for(pair in pairs){
 first_group<-pair[1];second_group<-pair[2]
 p<-fread(file=file.path(src,paste0('periods_',tolower(event),'_4w.csv')))
 q<-merge(p,a[group %chin% c(first_group,second_group)],by='gmap_id')
 z<-q[,.(restaurants=.N,matched=sum(eligible_precinct)),by=.(group,trump)];z[,`:=`(shock=event,comparison=paste(first_group,'vs',second_group))];sizes[[length(sizes)+1L]]<-z
 q<-q[eligible_precinct==TRUE];q[,first:=as.integer(group==first_group)]
 shared<-q[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips;q<-q[county_fips %chin% shared]
 q[,`:=`(share10=(precinct_share-.5)/.1,county10=(gop_share-.5)/.1,log_pre_reviews=log1p(reviews_pre),county_group=paste(county_fips,first,sep='_'))]
 q[,`:=`(first_share=first*share10,first_county=first*county10)]
 for(stratum in c('All counties','Trump counties','Non-Trump counties')){
  d<-copy(if(stratum=='All counties')q else if(stratum=='Trump counties')q[trump==1] else q[trump==0])
  d[,first_share:=first*county10];fit_one(d,event,first_group,stratum,'County share benchmark',c('first','first_share'),exposure='County')
  d[,first_share:=first*share10];fit_one(d,event,first_group,stratum,'Precinct share + county FE',c('first','share10','first_share'))
  fit_one(d,event,first_group,stratum,'Precinct share + county gradient',c('first','share10','first_share','first_county'))
  fit_one(d,event,first_group,stratum,'Precinct share + county-by-group FE',c('share10','first_share'),fe='county_group')
  fit_one(d,event,first_group,stratum,'Precinct share + baseline adjustment',c('first','share10','first_share','rating_pre','log_pre_reviews'))
 }
 for(sens in c('At least 100 precinct votes','At least 50 m from precinct boundary','Two-party vote share')){
  d<-copy(if(sens=='At least 100 precinct votes')q[total_max>=100] else if(sens=='At least 50 m from precinct boundary')q[boundary_distance_m_approx>=50] else q)
  if(sens=='Two-party vote share'){
   d<-d[is.finite(precinct_share_2party)];d[,share10:=(precinct_share_2party-.5)/.1]
  }
  d[,first_share:=first*share10];shared<-d[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips;d<-d[county_fips %chin% shared]
  fit_one(d,event,first_group,'All counties','Precinct share + county FE',c('first','share10','first_share'),sample=sens)
 }
 dates<-if(event=='Election')c('2016-09-12','2016-10-03') else c('2016-11-28','2016-12-19')
 prior<-w[week>=as.IDate(dates[1]) & week<=as.IDate(dates[2]) & reviews>0 & !is.na(rating),.(prior_rating=sum(rating*reviews)/sum(reviews)),by=gmap_id]
 d<-merge(q,prior,by='gmap_id');shared<-d[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips;d<-d[county_fips %chin% shared]
 fit_one(d,event,first_group,'All counties','Event gradient on placebo subset',c('first','share10','first_share'),sample='Observed prior four-week block')
 d[,change:=rating_pre-prior_rating];fit_one(d,event,first_group,'All counties','Pre-event placebo gradient',c('first','share10','first_share'),sample='Observed prior four-week block')
 fwrite(q,file.path(out,paste0('sample_',first_group,if(full_pre)paste0('_',second_group) else '', '_',tolower(event),'.csv')))
}
r<-rbindlist(rows);r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
r[,p_holm_four_primary:=NA_real_];ii<-which(r$model=='Precinct share + county FE' & r$stratum=='All counties' & r$sample=='Main matched sample');r[ii,p_holm_four_primary:=p.adjust(p,'holm')]
r[,p_holm_twelve_main:=NA_real_];ii<-which(r$model=='Precinct share + county FE' & r$sample=='Main matched sample');r[ii,p_holm_twelve_main:=p.adjust(p,'holm')]
r[,p_holm_all_eighty:=p.adjust(p,'holm')]
if(full_pre)setnames(r,c('MED_restaurants','p_holm_four_primary','p_holm_twelve_main','p_holm_all_eighty'),c('second_restaurants','p_holm_six_primary','p_holm_eighteen_main','p_holm_all_120'))
fwrite(r,file.path(out,'interaction_results.csv'));fwrite(rbindlist(sizes),file.path(out,'event_linkage_counts.csv'));fwrite(rbindlist(designs,fill=TRUE),file.path(out,'verification_designs.csv'));pp<-rbindlist(preds);fwrite(pp,file.path(out,'predicted_differences.csv'))
for(pair in pairs){
 focal<-pair[1];second<-pair[2]
 png(file.path(out,paste0(focal,'_',second,'_gradient.png')),width=2100,height=1100,res=180);par(mfrow=c(1,2),mar=c(5,5,4,2),oma=c(4,0,1,0))
 for(event in c('Election','Ban')){
  z<-pp[first_group==focal & second_group==second & shock==event];plot(z$share*100,z$estimate,type='n',ylim=range(z$low,z$high,0),xlab='2016 precinct Trump vote share (%)',ylab=paste(focal,'minus',second,'change (rating stars)'),main=event)
  polygon(c(z$share,rev(z$share))*100,c(z$low,rev(z$high)),col='#dceaf1',border=NA);abline(h=0,lty=2,col='grey');lines(z$share*100,z$estimate,col='#185b7a',lwd=2)
  rr<-r[first_group==focal & second_group==second & shock==event & model=='Precinct share + county FE' & stratum=='All counties' & sample=='Main matched sample']
  mtext(sprintf('Per +10 pp: %+.3f; p=%.3f; N=%s',rr$estimate,rr$p,format(rr$restaurants,big.mark=',')),side=3,line=.3,cex=.8)
 }
 mtext('Core tags only; county fixed effects; equal restaurant weights; 95% county-clustered intervals.',outer=TRUE,side=1,line=.3,cex=.65)
 mtext('Shown over overlapping 5th-95th percentile precinct-share support.',outer=TRUE,side=1,line=1.4,cex=.7);dev.off()
}
print(r[model=='Precinct share + county FE' & sample=='Main matched sample'])
