"""Verify every full-corpus model; compare exact old/new samples and render report."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'full_pre_election_core';R=O/'regressions'
scan=json.loads((O/'scan_audit.json').read_text());classification=json.loads((O/'classification_audit.json').read_text())
assert scan['all_files_complete']
manifest=json.loads((O/'scan_manifest.json').read_text())
for f in manifest['files']:
 p=Path(manifest['source'])/f['file'];assert p.stat().st_size==f['bytes'] and p.stat().st_mtime_ns==f['mtime_ns'],'Raw source changed during scan'
r=pd.read_csv(R/'interaction_results.csv');d=pd.read_csv(R/'verification_designs.csv',dtype={'county_fips':str,'fixed_effect':str,'county_group':str},low_memory=False)
errors=[]
for row in r.itertuples():
 z=d[d.model_id.eq(row.id)].copy();cols=row.variables.split(';');v=z[cols+['change']];v=v-v.groupby(z.fixed_effect).transform('mean')
 x=v[cols].to_numpy();y=v.change.to_numpy();inv=np.linalg.pinv(x.T@x);b=inv@x.T@y;res=y-x@b
 scores=pd.DataFrame(x*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();g=z.county_fips.nunique();n=len(z)
 cov=inv@scores.T@scores@inv*g/(g-1)*(n-1)/(n-row.df_K);j=cols.index('first_share');errors.extend([abs(b[j]-row.estimate),abs(np.sqrt(cov[j,j])-row.se)])
assert len(r)==120 and max(errors)<1e-8
old1=pd.read_csv(H/'precinct_core/precinct_interaction_results.csv');old1['comparison']='ME vs WPME';old1=old1.rename(columns={'ME':'first_restaurants','WPME':'second_restaurants'})
old2=pd.read_csv(H/'precinct_core_mediterranean/interaction_results.csv').rename(columns={'MED_restaurants':'second_restaurants'})
old=pd.concat([old1,old2],ignore_index=True)
main=lambda t:t[t.model.eq('Precinct share + county FE')&t['sample'].eq('Main matched sample')].copy()
oldmain=main(old);newmain=main(r)
compare=newmain.merge(oldmain[['shock','comparison','stratum','estimate','se','p','restaurants','first_restaurants','second_restaurants','counties']],on=['shock','comparison','stratum'],suffixes=('','_old'),validate='one_to_one')
compare['N_change']=compare.restaurants-compare.restaurants_old;compare['N_change_pct']=100*compare.N_change/compare.restaurants_old
states=[];changes=[];means=[]
for row in newmain.itertuples():
 first,second=row.comparison.split(' vs ');newfile=R/f'sample_{first}_{second}_{row.shock.lower()}.csv'
 oldfile=H/'precinct_core'/f'model_sample_{row.shock.lower()}.csv' if second=='WPME' else H/'precinct_core_mediterranean'/f'sample_{first}_{row.shock.lower()}.csv'
 nq=pd.read_csv(newfile,dtype={'county_fips':str});oq=pd.read_csv(oldfile,dtype={'county_fips':str})
 if row.stratum!='All counties':
  t=1 if row.stratum=='Trump counties' else 0;nq=nq[nq.trump.eq(t)];oq=oq[oq.trump.eq(t)]
 assert len(nq)==row.restaurants and nq.group.eq(first).sum()==row.first_restaurants and nq.group.eq(second).sum()==row.second_restaurants
 assert nq.county_fips.nunique()==row.counties and nq.precinct_id.nunique()==row.precincts
 ni=set(nq.gmap_id);oi=set(oq.gmap_id)
 changes.append({'shock':row.shock,'comparison':row.comparison,'stratum':row.stratum,'old_N':len(oq),'new_N':len(nq),'retained_IDs':len(ni&oi),'added_IDs':len(ni-oi),'dropped_IDs':len(oi-ni),'state_count_excluding_DC':len(set(nq.state)-{'DC'}),'DC_included':'DC' in set(nq.state),'states':', '.join(sorted(set(nq.state)))})
 st=nq.groupby(['state','group']).size().reset_index(name='restaurants');st['shock']=row.shock;st['comparison']=row.comparison;st['stratum']=row.stratum;states.append(st)
 mm=nq.groupby('group').agg(restaurants=('gmap_id','size'),mean_rating_pre=('rating_pre','mean'),mean_rating_post=('rating_post','mean'),mean_change=('change','mean'));mm=mm.reset_index();mm['shock']=row.shock;mm['comparison']=row.comparison;mm['stratum']=row.stratum;means.append(mm)
compare.to_csv(O/'old_new_main_comparison.csv',index=False);pd.DataFrame(changes).to_csv(O/'sample_growth_attribution.csv',index=False);pd.concat(states,ignore_index=True).to_csv(O/'states_by_model.csv',index=False);pd.concat(means,ignore_index=True).to_csv(O/'restaurant_weighted_group_means.csv',index=False)
# Confirm that existing geography and pre/post outcomes stayed fixed for retained IDs.
geo=pd.read_csv(O/'restaurant_precinct_assignments.csv');oldgeo=pd.read_csv(H/'precinct_core/restaurant_precinct_assignments.csv')
matched=geo.merge(oldgeo,on='gmap_id',suffixes=('','_old'),validate='one_to_one')
assert len(matched)==len(oldgeo)
for c in ['precinct_id','eligible_precinct']:
 assert (matched[c].fillna('missing').astype(str)==matched[c+'_old'].fillna('missing').astype(str)).all(),c
assert np.allclose(matched.precinct_share,matched.precinct_share_old,equal_nan=True)
outcome_errors=[]
for event in ['election','ban']:
 p=pd.read_csv(O/'inputs'/f'periods_{event}_4w.csv');q=pd.read_csv(H/'county_fe_regressions/inputs'/f'periods_{event}_4w.csv')
 zz=p.merge(q,on='gmap_id',suffixes=('','_old'))
 for c in ['rating_pre','rating_post','reviews_pre','reviews_post','change']:outcome_errors.append(float((zz[c]-zz[c+'_old']).abs().max()))
assert max(outcome_errors)<1e-10
verification={'models_independently_verified':len(r),'maximum_coefficient_or_se_error':max(errors),'main_sample_counts_verified':len(newmain),'existing_geographic_assignments_unchanged':len(matched),'maximum_existing_outcome_difference':max(outcome_errors),'equal_restaurant_weights':True,'classification_frozen_before_both_events':True}
(O/'model_verification.json').write_text(json.dumps(verification,indent=2))
def fmt(q):
 q=q.copy();q['Gradient (SE)']=q.apply(lambda x:f'{x.estimate:+.4f}{x.symbol if isinstance(x.symbol,str) else ""} ({x.se:.4f})',axis=1);q['Raw p']=q.p.map(lambda x:f'{x:.4f}');q['95% CI']=q.apply(lambda x:f'[{x.low:+.4f}, {x.high:+.4f}]',axis=1)
 q['N first / second']=q.apply(lambda x:f'{x.first_restaurants:,} / {x.second_restaurants:,}',axis=1);return q
tab=lambda q:q.to_html(index=False,border=0)
cols=['shock','stratum','comparison','Gradient (SE)','95% CI','Raw p','N first / second','restaurants','counties']
sub=fmt(newmain[~newmain.stratum.eq('All counties')]);primary=fmt(newmain[newmain.stratum.eq('All counties')]);growth=compare[['shock','stratum','comparison','restaurants_old','restaurants','N_change','N_change_pct','first_restaurants_old','first_restaurants','second_restaurants_old','second_restaurants','counties_old','counties']]
fullcols=['shock','comparison','stratum','model','sample','exposure','Gradient (SE)','Raw p','restaurants','counties']
full=fmt(r)
placebos=r[r.model.eq('Pre-event placebo gradient')].copy()
ix=np.argsort(placebos.p.to_numpy());pv=placebos.p.to_numpy()[ix];adjusted=np.minimum(1,np.maximum.accumulate(pv*(len(pv)-np.arange(len(pv)))))
holm=np.empty(len(pv));holm[ix]=adjusted;placebos['p_holm_six_placebos']=holm
placebos.to_csv(O/'pre_event_placebo_summary.csv',index=False)
pop=pd.read_csv(O/'all_group_assignments.csv').groupby('group').size().reset_index(name='restaurants_all_geographies')
html='''<!doctype html><html><head><meta charset="utf-8"><title>Full pre-election core tags and precinct comparisons</title><style>body{font:16px/1.5 system-ui;max-width:1450px;margin:36px auto;padding:0 24px;color:#243343}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3f6;position:sticky;top:0}td:nth-child(-n+3){text-align:left}.note{padding:18px;background:#edf3f6}.scroll{overflow:auto;max-height:650px}img{width:100%}</style></head><body><h1>Full raw pre-election review scan: core tags and precinct comparisons</h1>
<p>All 52 raw review gzip files scanned; tags frozen before November 8, 2016 UTC; unchanged 27 core regexes. Primary categories, four-week outcome windows, equal restaurant weights, county fixed effects and county-clustered inference match the prior analysis.</p>
<div class="note">The interaction estimate is the <b>change in the first-group-minus-second-group rating-change gap per +10 percentage points of precinct Trump vote share</b>. Negative means the first group loses more ground as local Trump support rises. This is not the average event effect. Raw p-values: + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001.</div>
<h2>How much did text coverage and classifications change?</h2>'''+tab(pd.DataFrame([classification]).drop(columns=['county_linked_population_by_group','outcome_source']).T.reset_index().rename(columns={'index':'Measure',0:'Value'}))+tab(pop)+tab(pd.read_csv(O/'classification_transitions.csv'))+'''
<p>ME is assigned solely from primary category and is unchanged. WPME requires primary Mediterranean plus a core-dish mention in an eligible pre-election review; MED requires observed normalized pre-election text but no detected core tag. No eligible text remains Unknown. Shared foods are excluded. Pre-election text is not restricted to the food-screened saved panel or to July–November 2016. Tagging is based on mentions, not validated menu availability or nationality; non-Latin-only text can normalize to empty under the unchanged dictionary pipeline.</p>
<h2>Actual four-week sample growth</h2><div class="scroll">'''+tab(growth)+'''
</div><p>Restaurant classification growth is distinct from outcome-sample growth. Each pair needs observations in both four-week periods and a county containing both comparison groups. Newly tagged businesses can move from MED to WPME, or from Unknown into either group. ME sample counts can change through county overlap even though ME labels are fixed. Row Ns overlap and must not be summed into a unique restaurant count. <a href="sample_growth_attribution.csv">Added, retained and dropped IDs per model</a>.</p>
<h2>Pooled primary models</h2>'''+tab(primary[cols])+'''
<h2>All three comparisons, separately by county type</h2><div class="scroll">'''+tab(sub[cols])+'''
</div><h2>ME versus WPME</h2><img src="regressions/ME_WPME_gradient.png" alt="ME versus WPME full raw pre-election tags">
<h2>ME versus Mediterranean</h2><img src="regressions/ME_MED_gradient.png" alt="ME versus Mediterranean full raw pre-election tags">
<h2>WPME versus Mediterranean</h2><img src="regressions/WPME_MED_gradient.png" alt="WPME versus Mediterranean full raw pre-election tags">
<p>Plots show fitted differences in changes and pointwise 95% county-clustered confidence intervals over the intersection of each group's 5th–95th percentile local vote-share ranges. Pairwise samples differ, so coefficients need not add up across pairs.</p>
<h2>Scan audit and timestamp checks</h2>'''+tab(pd.DataFrame(list(scan.items()),columns=['Audit measure','Value']))+'''
<p>Every compressed file was read to completion (including gzip integrity checks). Only primary-Mediterranean businesses need dish tagging: ME labels remain category-based. Exact duplicates among selected pre-election reviews are removed by a hash of business ID, reviewer ID, timestamp, rating and text. Checkpoint exports retain hashes, timestamps, food masks and business IDs, not review text or reviewer identities. Source files are unchanged. Invalid/nonpositive timestamps are excluded. Positive timestamps before 2005 are included under “all pre-election” but flagged; the audit reports whether any label depends only on such early dates. Any missing recovery of prior saved-panel tags is exported for inspection, not silently filled by unioning old labels.</p>
<h2>Unchanged outcomes, geography and inference</h2><p>Existing full outcome aggregates are reused, including previously unclassified restaurants; missing ratings are not zero-filled. Within restaurant-periods, reviews are aggregated using review counts; each restaurant then receives one unit of regression weight. Existing precinct assignments and all retained pre/post outcomes have been checked against the prior analysis. New businesses are matched to the same 2016 SAGE polygons and vote source. Ambiguous/absent precincts and zero votes remain excluded; county FIPS is checked where explicitly supplied. Local resident votes do not identify reviewer residence or individual ideology.</p>
<p>Election: October 10–November 6 versus November 14–December 11, 2016. Ban: December 26, 2016–January 22, 2017 versus January 30–February 26, 2017. Mixed event weeks are excluded. Baseline and geographic sensitivities are reported as before. Pre-event placebo models use an additional earlier four-week block and a smaller observed-history subset; non-rejection does not prove parallel trends. This enlarged observational sample does not establish a causal effect.</p>
<h2>All 120 specifications</h2><p>Includes continuous-county benchmarks, precinct models, added county gradients, county-by-group FE, baseline adjustment, low-vote/boundary/two-party sensitivities, and pre-event placebos. Separate Holm columns cover six pooled primary tests, eighteen main pooled/subgroup tests, and all 120 specifications; this project also has earlier exploratory analyses.</p><div class="scroll">'''+tab(full[fullcols])+'''</div>
<p><a href="regressions/interaction_results.csv">Regression results CSV</a> · <a href="old_new_main_comparison.csv">Old versus new results/sample sizes</a> · <a href="restaurant_weighted_group_means.csv">Equal-weight restaurant means</a> · <a href="states_by_model.csv">State coverage/counts by model</a> · <a href="model_verification.json">Independent verification</a> · <a href="scan_manifest.json">Source manifest and frozen dictionary</a></p></body></html>'''
summary='''<h2>What the expanded sample shows</h2><p>Observed pre-election text rises from 2,765 to 3,450 businesses; core-tagged primary-Mediterranean restaurants rise from 661 to 1,293 before geographic restrictions. Every previous tag is recovered. Among newly tagged businesses, 539 move from MED to WPME and 93 move from Unknown to WPME; another 592 move from Unknown to MED. No restaurant's core tag depends solely on pre-2005 timestamps.</p><p>The pooled primary gradients are statistically uncertain for all six event/comparison combinations. The closest raw subgroup result is election WPME–MED in Trump counties: −.1456 per 10 points (p=.0513; Holm across eighteen main tests=.9240). Ban ME–WPME in non-Trump counties is positive (+.0465, p=.0802), as is ban ME–MED in Trump counties (+.1290, p=.0834). These are exploratory associations with differing samples, not established causal effects.</p>'''
html=html.replace('<h2>Pooled primary models</h2>',summary+'<h2>Pooled primary models</h2>')
placebo_section='<h2>Pre-event placebo gradients</h2>'+tab(fmt(placebos)[['shock','comparison','Gradient (SE)','Raw p','p_holm_six_placebos','restaurants','counties']])+'''<p><b>Identification concern:</b> The ban WPME–MED sample has a negative pre-event political gradient (−.0706 per 10 points, raw p=.0098; Holm across six placebos=.0588). Thus its political gradients were already changing before the ban, which weakens a causal interpretation of its post-ban pattern. The other five coarse placebo tests do not reject at 5%; this is not proof of parallel trends. These are four-week-block pre-event differences on history-observed subsets, not a full weekly event-study test.</p>'''
html=html.replace('<h2>All 120 specifications</h2>',placebo_section+'<h2>All 120 specifications</h2>')
(O/'full_core_report.html').write_text(html,encoding='utf-8')
print(json.dumps(verification,indent=2));print(primary[cols].to_string(index=False));print(sub[cols].to_string(index=False));print(growth.to_string(index=False))
