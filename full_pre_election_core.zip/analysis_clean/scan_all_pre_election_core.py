"""Checkpointed scan of ALL raw state review files for primary-Mediterranean IDs.

Only derived hashes, timestamps, food masks and restaurant IDs are retained.
Classification freezes before 2016-11-08 UTC and uses the unchanged core regexes.
"""
from pathlib import Path
import concurrent.futures,datetime,gzip,hashlib,json,os,re,sqlite3,time,unicodedata
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'full_pre_election_core';O.mkdir(exist_ok=True)
C=O/'scan_checkpoints';C.mkdir(exist_ok=True)
CFG=json.loads((H/'config.json').read_text());SRC=Path(CFG['source_root'])/'analysis/2025-08-18-rohan/inputs'
DICT=json.loads((H/'expanded_dish_dictionary.json').read_text())['core']
CUTOFF=1478563200000 # 2016-11-08 00:00:00 UTC
EARLY=1104537600000 # 2005-01-01; audit flag only, not primary exclusion
def normalize(s):
 s=unicodedata.normalize('NFKD',s.casefold()).encode('ascii','ignore').decode()
 return re.sub(r'[^\w\s]',' ',s)
def scan_file(arg):
 name,targets,signature=arg;f=SRC/name;stem=f.name.removesuffix('.json.gz');done=C/(stem+'.done.json');status=C/(stem+'.status.json');dest=C/(stem+'.selected.jsonl.gz')
 if done.exists():
  prior=json.loads(done.read_text())
  if prior.get('signature')==signature and dest.exists():return prior
 regex={k:re.compile(v) for k,v in DICT.items()};idregex=re.compile(rb'"gmap_id"\s*:\s*"([^"\\]+)"');ids={s.encode() for s in targets}
 stat={'file':name,'signature':signature,'source_bytes':f.stat().st_size,'source_mtime_ns':f.stat().st_mtime_ns,'rows':0,'target_rows':0,'pre_rows':0,'pre_text_rows':0,'core_hit_rows':0,'early_pre_rows':0,'early_core_rows':0,'invalid_time_target_rows':0,'json_errors':0,'compressed_bytes_read':0,'complete':False}
 start=time.monotonic();last=start
 with f.open('rb') as raw,gzip.GzipFile(fileobj=raw,mode='rb') as stream,gzip.open(dest,'wt',encoding='utf-8',compresslevel=1) as out:
  for line in stream:
   stat['rows']+=1
   # ID is usually last; search only its tail rather than regex-scanning full text.
   pos=line.rfind(b'"gmap_id"');m=idregex.match(line,pos) if pos>=0 else None
   if m and m.group(1) in ids:
    stat['target_rows']+=1
    try:row=json.loads(line)
    except (ValueError,UnicodeError):stat['json_errors']+=1;continue
    t=row.get('time')
    if isinstance(t,bool) or not isinstance(t,(int,float)) or not 0<t<253402300800000:
     stat['invalid_time_target_rows']+=1;continue
    if t<CUTOFF:
     stat['pre_rows']+=1;t=int(t);early=t<EARLY;stat['early_pre_rows']+=int(early)
     text=row.get('text');norm=normalize(text) if isinstance(text,str) else '';has_text=bool(norm.strip());mask=0
     if has_text:
      stat['pre_text_rows']+=1
      for i,(dish,pat) in enumerate(regex.items()):
       if pat.search(norm):mask|=1<<i
     if mask:stat['core_hit_rows']+=1;stat['early_core_rows']+=int(early)
     key=hashlib.sha256(json.dumps([row.get('gmap_id'),row.get('user_id'),t,row.get('rating'),text],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
     out.write(json.dumps([key,row['gmap_id'],t,int(has_text),mask],separators=(',',':'))+'\n')
   now=time.monotonic()
   if now-last>=15:
    stat['compressed_bytes_read']=raw.tell();stat['elapsed_seconds']=round(now-start,1);status.write_text(json.dumps(stat));last=now
  stat['compressed_bytes_read']=raw.tell()
 stat['complete']=True;stat['elapsed_seconds']=round(time.monotonic()-start,1);stat['derived_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
 status.write_text(json.dumps(stat));done.write_text(json.dumps(stat));return stat

def main():
 meta=pd.read_csv(H/'expanded_positioning/metadata_with_geography.csv',usecols=['gmap_id','primary_category'])
 targets=sorted(meta.loc[meta.primary_category.eq('Mediterranean restaurant'),'gmap_id'].unique())
 assert len(targets)==5442
 files=sorted(SRC.glob('review-*.json.gz'),key=lambda p:p.stat().st_size,reverse=True)
 assert len(files)==52
 signature=hashlib.sha256(json.dumps({'targets':targets,'core':DICT,'cutoff':CUTOFF,'version':1},sort_keys=True).encode()).hexdigest()
 manifest={'source':str(SRC),'cutoff_exclusive_utc':'2016-11-08T00:00:00Z','core':DICT,'target_primary_mediterranean_ids':len(targets),'signature':signature,'files':[{'file':p.name,'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in files],'workers':min(8,os.cpu_count() or 1),'dedup_key':'SHA256 of canonical [gmap_id,user_id,time,rating,text]; no user IDs/text retained','early_timestamp_policy':'Positive pre-election timestamps before 2005 are included but flagged; report sensitivity excluding their evidence','time_invalid_policy':'Reject nonnumeric, nonpositive, nonfinite or beyond-year-9999 timestamps'}
 (O/'scan_manifest.json').write_text(json.dumps(manifest,indent=2))
 stats=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=manifest['workers']) as ex:
  for s in ex.map(scan_file,[(p.name,targets,signature) for p in files]):
   stats.append(s);print(s['file'],s['rows'],'rows,',s['pre_text_rows'],'target pre-election text rows',flush=True)
 pd.DataFrame(stats).to_csv(O/'scan_source_counts.csv',index=False)
 assert all(s['complete'] for s in stats) and not any(s['json_errors'] for s in stats)
 # A fresh aggregate avoids silently mixing signatures or partially scanned files.
 db=sqlite3.connect(O/'derived_unique_reviews.sqlite');db.execute('DROP TABLE IF EXISTS reviews')
 db.execute('CREATE TABLE reviews (review_hash TEXT PRIMARY KEY, gmap_id TEXT NOT NULL, time INTEGER NOT NULL, has_text INTEGER NOT NULL, core_mask INTEGER NOT NULL) WITHOUT ROWID')
 selected=0
 for s in stats:
  f=C/(s['file'].removesuffix('.json.gz')+'.selected.jsonl.gz');batch=[]
  with gzip.open(f,'rt',encoding='utf-8') as stream:
   for line in stream:
    batch.append(json.loads(line));selected+=1
    if len(batch)>=20000:db.executemany('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?)',batch);batch=[]
  if batch:db.executemany('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?)',batch)
  db.commit()
 unique=db.execute('SELECT COUNT(*) FROM reviews').fetchone()[0]
 summary=pd.read_sql_query('SELECT gmap_id,COUNT(*) AS pre_reviews,SUM(has_text) AS pre_text_reviews,SUM(core_mask>0) AS pre_core_reviews,MIN(time) AS first_pre_time,MAX(time) AS last_pre_time,SUM(time<1104537600000) AS early_reviews,SUM(time<1104537600000 AND core_mask>0) AS early_core_reviews,SUM(time>=1104537600000 AND core_mask>0) AS post2004_core_reviews FROM reviews GROUP BY gmap_id',db)
 summary=pd.DataFrame({'gmap_id':targets}).merge(summary,on='gmap_id',how='left',validate='one_to_one')
 for col in ['pre_reviews','pre_text_reviews','pre_core_reviews','early_reviews','early_core_reviews','post2004_core_reviews']:summary[col]=summary[col].fillna(0).astype(int)
 summary['text_pre']=summary.pre_text_reviews.gt(0);summary['core_pre']=summary.pre_core_reviews.gt(0)
 summary.to_csv(O/'full_pre_election_dish_flags.csv',index=False)
 dishes=[]
 for i,dish in enumerate(DICT):
  q=pd.read_sql_query(f'SELECT gmap_id,COUNT(*) AS review_mentions,MIN(time) AS first_mention_time FROM reviews WHERE (core_mask & {1<<i})>0 GROUP BY gmap_id',db);q['dish']=dish;dishes.append(q)
 pd.concat(dishes,ignore_index=True).to_csv(O/'dish_business_mentions.csv',index=False);db.close()
 audit={'raw_review_rows_scanned':sum(s['rows'] for s in stats),'target_rows_all_dates':sum(s['target_rows'] for s in stats),'selected_pre_election_rows_before_dedup':selected,'unique_pre_election_reviews':unique,'duplicates_removed':selected-unique,'primary_mediterranean_businesses':len(summary),'businesses_with_pre_election_text':int(summary.text_pre.sum()),'businesses_with_core_tag':int(summary.core_pre.sum()),'businesses_tagged_only_by_pre2005_timestamps':int((summary.core_pre & summary.post2004_core_reviews.eq(0)).sum()),'all_files_complete':True,'json_errors_in_target_rows':sum(s['json_errors'] for s in stats),'invalid_target_timestamps':sum(s['invalid_time_target_rows'] for s in stats),'source_files_modified':False}
 (O/'scan_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2),flush=True)
if __name__=='__main__':main()
