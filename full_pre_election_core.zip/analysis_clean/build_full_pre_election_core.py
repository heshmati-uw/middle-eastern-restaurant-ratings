"""Build new frozen labels and full outcome inputs after the complete text scan."""
from pathlib import Path
import json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'full_pre_election_core';I=O/'inputs';I.mkdir(exist_ok=True)
audit=json.loads((O/'scan_audit.json').read_text());assert audit['all_files_complete']
cfg=json.loads((H/'config.json').read_text())
meta=pd.read_csv(H/'expanded_positioning/metadata_with_geography.csv',usecols=['gmap_id','primary_category','county_fips','gop_share','trump'],dtype={'county_fips':str})
meta=meta[meta.primary_category.isin(cfg['me_categories']+['Mediterranean restaurant'])].copy()
flags=pd.read_csv(O/'full_pre_election_dish_flags.csv');z=meta.merge(flags,on='gmap_id',how='left',validate='one_to_one')
z['definition']='full_core_pre';z['group']='ME';med=z.primary_category.eq('Mediterranean restaurant')
z.loc[med,'group']='Unknown';z.loc[med & z.text_pre.eq(True),'group']='MED';z.loc[med & z.core_pre.eq(True),'group']='WPME'
z.to_csv(O/'all_group_assignments.csv',index=False)
geo=pd.read_csv(O/'geography/restaurant_precinct_assignments.csv',dtype={'county_fips':str,'NAME2':str})
geo=geo.drop(columns=['definition','group']).merge(z[['gmap_id','definition','group','pre_reviews','pre_text_reviews','pre_core_reviews','early_reviews','early_core_reviews','post2004_core_reviews']],on='gmap_id',validate='one_to_one')
assert geo.loc[geo.primary_category.ne('Mediterranean restaurant'),'group'].eq('ME').all()
geo.to_csv(O/'restaurant_precinct_assignments.csv',index=False)
geo.groupby(['group','trump'],dropna=False).agg(population=('gmap_id','size'),spatial_matches=('precinct_id','count'),eligible=('eligible_precinct','sum')).reset_index().to_csv(O/'population_coverage.csv',index=False)
oldflags=pd.read_csv(H/'expanded_positioning/mediterranean_dish_flags.csv')
old=oldflags[['gmap_id','text_pre','core_pre']].rename(columns={'text_pre':'old_text_pre','core_pre':'old_core_pre'})
t=old.merge(flags,on='gmap_id',validate='one_to_one');t['old_group']='Unknown';t.loc[t.old_text_pre,'old_group']='MED';t.loc[t.old_core_pre,'old_group']='WPME';t['new_group']='Unknown';t.loc[t.text_pre,'new_group']='MED';t.loc[t.core_pre,'new_group']='WPME'
t.to_csv(O/'classification_crosswalk.csv',index=False);t.groupby(['old_group','new_group']).size().reset_index(name='restaurants').to_csv(O/'classification_transitions.csv',index=False)
t[t.old_core_pre & ~t.core_pre].to_csv(O/'previous_core_tags_not_recovered.csv',index=False)
geo_audit=json.loads((O/'geography/precinct_linkage_audit.json').read_text());geo_audit.update({'classification_pending':False,'definition':'full_core_pre','scan_signature':json.loads((O/'scan_manifest.json').read_text())['signature'],'observed_text_required_for_MED':True,'unchanged_ME_categories':True});(O/'precinct_linkage_audit.json').write_text(json.dumps(geo_audit,indent=2))
ids=set(geo.loc[geo.group.isin(['ME','WPME','MED']),'gmap_id'])
for event in ['election','ban']:
 p=pd.read_csv(H/'expanded_positioning'/f'periods_{event}_4w.csv');p[p.gmap_id.isin(ids)].to_csv(I/f'periods_{event}_4w.csv',index=False)
parts=[]
for q in pd.read_csv(H/'expanded_positioning/expanded_common_weekly.csv',chunksize=200000):parts.append(q[q.gmap_id.isin(ids)])
weekly=pd.concat(parts,ignore_index=True);weekly.to_csv(I/'expanded_common_weekly.csv',index=False)
summary={'primary_ME_population':int((~med).sum()),'primary_Mediterranean_population':int(med.sum()),'old_text_observed':int(t.old_text_pre.sum()),'new_text_observed':int(t.text_pre.sum()),'old_core_tagged':int(t.old_core_pre.sum()),'new_core_tagged':int(t.core_pre.sum()),'newly_text_observed':int((~t.old_text_pre & t.text_pre).sum()),'previous_core_tags_not_recovered':int((t.old_core_pre & ~t.core_pre).sum()),'previous_text_not_recovered':int((t.old_text_pre & ~t.text_pre).sum()),'new_unknown':int((t.new_group=='Unknown').sum()),'county_linked_population_by_group':geo.group.value_counts().to_dict(),'focal_county_linked_classified_businesses':len(ids),'businesses_with_observed_weekly_outcomes':int(weekly.gmap_id.nunique()),'outcome_source':'Existing full expanded_positioning weekly/period outcomes; no reweighting by review volume across restaurants'}
(O/'classification_audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
