# Equal weight per restaurant: infer contrasts in before/after mean changes.
args <- commandArgs(trailingOnly=FALSE)
here <- dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
out <- file.path(here,'outputs')
cfg <- fromJSON(file.path(here,'shock_specifications.json'),simplifyVector=FALSE)
w <- fread(file.path(out,'election_ban_common_weekly.csv'),colClasses=c(county_fips='character'))
w[,score_sum:=rating*reviews]
ssc_rule <- ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
pairs <- list(c('ME','American'),c('WPME','American'),c('WPME','ME'))
results <- list();descriptives <- list();restaurant_changes <- list();models <- list()

make_changes <- function(spec,data=w) {
  z <- copy(data[(week>=spec$pre_start & week<=spec$pre_end) |
                (week>=spec$post_start & week<=spec$post_end)])
  z[,period:=ifelse(week<=spec$pre_end,'pre','post')]
  q <- z[,.(rating=sum(score_sum)/sum(reviews),reviews=sum(reviews),weeks=.N),
         by=.(gmap_id,group,county_fips,period)]
  q <- dcast(q,gmap_id+group+county_fips~period,value.var=c('rating','reviews','weeks'))
  q <- q[!is.na(rating_pre)&!is.na(rating_post)]
  q[,change:=rating_post-rating_pre]
  stopifnot(!anyDuplicated(q$gmap_id))
  q
}

record_fit <- function(q,pair,label,spec,primary) {
  d <- copy(q[group %chin% pair]);d[,treated:=as.integer(group==pair[1])]
  fit <- feols(change~treated,data=d,vcov=~county_fips,ssc=ssc_rule)
  ct <- as.matrix(coeftable(fit))['treated',];ci <- as.matrix(confint(fit))['treated',]
  t <- d[treated==1];b <- d[treated==0]
  point <- mean(t$change)-mean(b$change)
  stopifnot(abs(point-ct[1])<1e-12)
  stopifnot(abs(2*pt(abs(ct[3]),df=uniqueN(d$county_fips)-1,lower.tail=FALSE)-ct[4])<1e-12)
  row <- data.table(shock=label,weeks=as.integer(spec$weeks),primary=primary,
    comparison=paste(pair,collapse=' vs '),estimate=unname(ct[1]),se=unname(ct[2]),
    statistic=unname(ct[3]),p=unname(ct[4]),low=unname(ci[1]),high=unname(ci[2]),
    restaurants=nrow(d),treated_restaurants=nrow(t),control_restaurants=nrow(b),
    counties=uniqueN(d$county_fips),treated_pre=mean(t$rating_pre),treated_post=mean(t$rating_post),
    control_pre=mean(b$rating_pre),control_post=mean(b$rating_post),
    pre_start=spec$pre_start,pre_last_week_start=spec$pre_end,
    post_start=spec$post_start,post_last_week_start=spec$post_end)
  models[[paste(label,spec$weeks,paste(pair,collapse='_'),sep='__')]] <<- fit
  results[[length(results)+1L]] <<- row
}

# Calculate the p-value of the previously reported -0.126 comparison exactly.
orig <- cfg$original_election_comparison;orig$weeks<-NA_integer_
ids <- fread(file.path(out,'ME_sample_attrition_by_restaurant.csv'))$gmap_id
original <- make_changes(orig,w[group!='ME'|gmap_id %chin% ids])
record_fit(original,c('ME','American'),'Original election comparison',orig,FALSE)

for(spec in c(cfg$main_windows,cfg$sensitivity_windows)) {
  q <- make_changes(spec)
  primary <- spec$weeks==10
  q[,`:=`(shock=spec$shock,window_weeks=spec$weeks)]
  restaurant_changes[[length(restaurant_changes)+1L]] <- q
  desc <- q[,.(restaurants=.N,counties=uniqueN(county_fips),pre=mean(rating_pre),
                post=mean(rating_post),change=mean(change),pre_reviews=sum(reviews_pre),post_reviews=sum(reviews_post)),by=group]
  desc[,`:=`(shock=spec$shock,weeks=spec$weeks)]
  descriptives[[length(descriptives)+1L]] <- desc
  for(pair in pairs) record_fit(q,pair,spec$shock,spec,primary)
}
r <- rbindlist(results,fill=TRUE)
r[primary==TRUE,p_holm_six_main:=p.adjust(p,'holm')]
r[shock!='Original election comparison',p_holm_three_within_shock:=p.adjust(p,'holm'),by=.(shock,weeks)]
r[shock!='Original election comparison',p_holm_all_eighteen:=p.adjust(p,'holm')]
fwrite(r,file.path(out,'election_ban_results.csv'))
fwrite(rbindlist(descriptives),file.path(out,'election_ban_descriptives.csv'))
fwrite(rbindlist(restaurant_changes),file.path(out,'election_ban_restaurant_changes.csv'))
saveRDS(models,file.path(out,'election_ban_models.rds'))
writeLines(capture.output(sessionInfo()),file.path(out,'election_ban_R_session.txt'))
cat('Original comparison p-value:\n');print(r[shock=='Original election comparison'])
cat('Main equal-ten-week comparisons:\n');print(r[primary==TRUE])
