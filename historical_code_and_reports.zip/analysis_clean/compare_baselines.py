"""Raw within-Trump-county mean comparisons with configurable baselines."""
from pathlib import Path
from html import escape
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'
CFG=json.loads((HERE/'baseline_choices.json').read_text())


def compare_pair(data,baseline,members,cohort,weighting,family_size=9):
    assert 'ME' not in members,'A baseline must not contain the focal ME group'
    d=data[data.group.isin(['ME']+members)].copy()
    d['side']=np.where(d.group.eq('ME'),'ME','baseline')
    if cohort=='same_restaurants':
        n=d.groupby('gmap_id').period.nunique()
        d=d[d.gmap_id.isin(n[n==2].index)]
    # First sum review score totals and review counts within restaurant/period.
    b=d.groupby(['gmap_id','county_fips','side','period'],as_index=False)[['score_sum','weight']].sum()
    if weighting=='restaurant':
        b['score_sum']=b.score_sum/b.weight
        b['weight']=1.0
    agg=b.groupby(['side','period'])[['score_sum','weight']].sum()
    if len(agg)!=4:
        return None
    means=agg.score_sum/agg.weight
    pre_gap=means['ME','pre']-means['baseline','pre']
    post_gap=means['ME','post']-means['baseline','post']
    gap_change=post_gap-pre_gap
    # Resample the same counties jointly across groups and periods.
    cells=b.groupby(['county_fips','side','period'])[['score_sum','weight']].sum()
    index=pd.MultiIndex.from_product([sorted(b.county_fips.unique()),['ME','baseline'],['pre','post']],
                                    names=['county_fips','side','period'])
    cells=cells.reindex(index,fill_value=0)
    sums=cells.score_sum.to_numpy().reshape(-1,4)
    weights=cells.weight.to_numpy().reshape(-1,4)
    rng=np.random.default_rng(CFG['seed'])
    # Batches cap peak memory for nationwide control groups.
    draw=[]
    for i in range(0,CFG['bootstrap_draws'],250):
        idx=rng.integers(0,len(sums),size=(min(250,CFG['bootstrap_draws']-i),len(sums)))
        numerator=sums[idx].sum(axis=1); denominator=weights[idx].sum(axis=1)
        with np.errstate(divide='ignore',invalid='ignore'):
            avg=numerator/denominator
        # Array order: ME post, ME pre, baseline post, baseline pre? Explicit
        # product above is ME/pre, ME/post, baseline/pre, baseline/post.
        draw.extend((avg[:,1]-avg[:,0])-(avg[:,3]-avg[:,2]))
    draw=np.asarray(draw)
    valid=np.isfinite(draw)
    assert valid.mean()>.995,'Insufficient bootstrap support'
    lo,hi=np.quantile(draw[valid],[.025,.975])
    family_lo,family_hi=np.quantile(draw[valid],[.025/family_size,1-.025/family_size])
    sizes=b.groupby(['side','period']).gmap_id.nunique()
    row={'baseline':baseline,'cohort':cohort,'weighting':weighting,
         'ME_pre':means['ME','pre'],'ME_post':means['ME','post'],
         'baseline_pre':means['baseline','pre'],'baseline_post':means['baseline','post'],
         'ME_change':means['ME','post']-means['ME','pre'],
         'baseline_change':means['baseline','post']-means['baseline','pre'],
         'pre_gap':pre_gap,'post_gap':post_gap,'relative_change':gap_change,
         'low':lo,'high':hi,'familywise_low':family_lo,'familywise_high':family_hi,
         'baseline_family_size':family_size,'ME_pre_restaurants':sizes['ME','pre'],
         'ME_post_restaurants':sizes['ME','post'],
         'baseline_pre_restaurants':sizes['baseline','pre'],
         'baseline_post_restaurants':sizes['baseline','post'],
         'counties':b.county_fips.nunique(),'valid_bootstrap_draws':int(valid.sum())}
    assert abs(row['relative_change']-(row['ME_change']-row['baseline_change']))<1e-12
    if cohort=='same_restaurants':
        assert row['ME_pre_restaurants']==row['ME_post_restaurants']
        assert row['baseline_pre_restaurants']==row['baseline_post_restaurants']
    return row


def main():
    rows=[]
    d=pd.read_csv(OUT/'reviews_clean.csv',dtype={'county_fips':'string'})
    d=d[d.group.isin(['ME','MED','WPME']) & d.rating.notna() &
        d.county_fips.notna() & (d.gop_share>.5)].copy()
    for window,start in [('all_available_pre','2016-07-01'),('equal_79_days','2016-08-21')]:
        z=d[((d.date>=start)&(d.date<'2016-11-08'))|
            ((d.date>='2016-11-09')&(d.date<'2017-01-27'))].copy()
        z['period']=np.where(z.date<'2016-11-08','pre','post')
        z['score_sum']=z.rating; z['weight']=1.0
        for baseline in ['MED','WPME']:
            for cohort in ['all_reviewed','same_restaurants']:
                for weighting in ['review','restaurant']:
                    r=compare_pair(z,baseline,[baseline],cohort,weighting,family_size=2)
                    rows.append({'source':'individual_reviews','window':window,**r})
    w=pd.read_csv(OUT/'broader_baseline_weekly.csv',dtype={'county_fips':'string'})
    disagreements=pd.read_csv(OUT/'baseline_geography_disagreements.csv')
    # Exclude businesses where saved and reconstructed county/share disagree,
    # rather than choosing the geography that favors a result.
    geography_rows_excluded=int(w.gmap_id.isin(disagreements.gmap_id).sum())
    w=w[~w.gmap_id.isin(disagreements.gmap_id)].copy()
    w=w[w.trump_county].copy()
    w['score_sum']=w.rating*w.reviews; w['weight']=w.reviews
    for window,start in [('all_available_pre','2016-07-04'),('equal_10_weeks','2016-08-29')]:
        z=w[(w.week>=start)|w.period.eq('post')].copy()
        for baseline,members in CFG['baselines'].items():
            for cohort in ['all_reviewed','same_restaurants']:
                for weighting in ['review','restaurant']:
                    r=compare_pair(z,baseline,members,cohort,weighting,family_size=len(CFG['baselines']))
                    if r is not None:rows.append({'source':'broader_weekly','window':window,**r})
    results=pd.DataFrame(rows)
    results.to_csv(OUT/'within_trump_baseline_results.csv',index=False)
    audit=json.loads((OUT/'broader_baseline_audit.json').read_text())
    assert len(results)==88
    broad=results[results.source=='broader_weekly']
    assert broad.groupby(['window','cohort','weighting'])[['ME_pre','ME_post','ME_pre_restaurants','ME_post_restaurants']].nunique().eq(1).all().all()
    # Point estimates must agree with the independently produced earlier means.
    old=pd.read_csv(OUT/'election_before_after_levels.csv')
    for r in results[results.source.eq('individual_reviews')].itertuples():
        me=old[(old.window==r.window)&(old.cohort==r.cohort)&(old.weighting==r.weighting)&
               old.group.eq('ME')&old.trump_majority].iloc[0]
        base=old[(old.window==r.window)&(old.cohort==r.cohort)&(old.weighting==r.weighting)&
                 old.group.eq(r.baseline)&old.trump_majority].iloc[0]
        assert abs(r.ME_pre-me.pre_mean)<1e-12 and abs(r.ME_post-me.post_mean)<1e-12
        assert abs(r.relative_change-(me.change-base.change))<1e-12
    def table(source,window,cohort,weighting):
        z=results[(results.source==source)&(results.window==window)&
                  (results.cohort==cohort)&(results.weighting==weighting)]
        text='<table><tr><th>ME compared with</th><th>ME before → after</th><th>Baseline before → after</th><th>ME change</th><th>Baseline change</th><th>ME relative change</th><th>95% county-bootstrap interval</th><th>Baseline-family-adjusted interval</th><th>Restaurants: ME / baseline</th></tr>'
        for r in z.itertuples():
            cells=[r.baseline,f'{r.ME_pre:.3f} → {r.ME_post:.3f}',
                   f'{r.baseline_pre:.3f} → {r.baseline_post:.3f}',f'{r.ME_change:+.3f}',
                   f'{r.baseline_change:+.3f}',f'{r.relative_change:+.3f}',
                   f'[{r.low:+.3f}, {r.high:+.3f}]',f'[{r.familywise_low:+.3f}, {r.familywise_high:+.3f}]',
                   f'{r.ME_pre_restaurants:,} → {r.ME_post_restaurants:,} / {r.baseline_pre_restaurants:,} → {r.baseline_post_restaurants:,}']
            text+='<tr>'+''.join('<td>'+escape(c)+'</td>' for c in cells)+'</tr>'
        return text+'</table>'
    body='''<h1>ME performance within Trump-majority counties: changing the baseline</h1>
    <p>Trump-majority means over 50% Republican vote share in the supplied 2016 county election results. Every table below uses only those counties. A <strong>negative ME relative change</strong> means ME lost ground against that baseline; positive means it gained ground. The contrast is (ME after − ME before) − (baseline after − baseline before).</p>
    <p><strong>What this shows:</strong> the exact-date review sample points to small relative ME losses when the same restaurants receive equal weight, but gains when reviews receive equal weight. Both ME–Mediterranean and ME–WPME intervals span zero. The broader weekly sample points to relative ME losses against each tested baseline; none of its nine fixed-restaurant comparisons is statistically clear after the baseline-family adjustment. These are directional patterns with substantial uncertainty.</p>
    <h2>1. Exact-date reviews: ME versus Mediterranean and WPME</h2>
    <p>Before: July 1–November 7, 2016. After: November 9, 2016–January 26, 2017. Election day and all dates on/after the ban are excluded. Definitions and deduplication match the preceding analysis.</p>
    <h3>Each review has equal weight; all reviewed restaurants</h3>'''
    body+=table('individual_reviews','all_available_pre','all_reviewed','review')
    body+='<h3>Same restaurants on both sides; each restaurant has equal weight</h3><p>Average each restaurant’s reviews within each period, then compare equally weighted restaurant means. This removes changing restaurant membership and review-volume weights, but reviewer composition can still change.</p>'
    body+=table('individual_reviews','all_available_pre','same_restaurants','restaurant')
    body+='<h3>Same restaurants; equal weight; equal 79-day windows</h3><p>Before: August 21–November 7. The post period is unchanged.</p>'
    body+=table('individual_reviews','equal_79_days','same_restaurants','restaurant')
    body+='''<h2>2. Broader baselines from the older weekly dataset</h2>
    <p>The source is the 3.9-million-row restaurant-week panel, including American and other restaurant categories beyond the food-keyword-selected review sample. ME/MED/WPME assignments come from the same modern business classifications, matched by business ID; unmatched ethnic restaurants are not silently assigned to WPME. Alternative controls use their historical primary categories. Baseline choices are separate models; the broad American pool intentionally contains the narrow American pool.</p>
    <p>The weekly source cannot split mixed weeks. Before: complete weeks July 4–November 6, 2016. After: November 14, 2016–January 22, 2017. Weeks containing the election and ban are excluded. These dates and business coverage differ from the exact-date review analysis, so estimates should not be treated as interchangeable.</p>
    <h3>Same restaurants; each restaurant has equal weight</h3>'''
    focal_n=int(results[(results.source=='broader_weekly')&(results.window=='all_available_pre')&
                        (results.cohort=='same_restaurants')&(results.weighting=='restaurant')].iloc[0].ME_pre_restaurants)
    body+=f'<p><strong>Different focal coverage:</strong> the weekly same-restaurant analysis contains {focal_n} ME restaurants in Trump-majority counties, versus 135 in the exact-date same-restaurant analysis above. The ME cohort is held constant across all nine weekly baseline choices. Differences between the two sources cannot be attributed solely to the baseline.</p>'
    body+=table('broader_weekly','all_available_pre','same_restaurants','restaurant')
    body+='<h3>Same restaurants; equal weight; ten complete weeks on each side</h3><p>Before starts August 29, 2016. After remains November 14, 2016–January 22, 2017.</p>'
    body+=table('broader_weekly','equal_10_weeks','same_restaurants','restaurant')
    body+='<h3>All reviewed restaurants; review-count-weighted averages</h3><p>Weekly averages are weighted by their number of reviews to reconstruct a review-weighted mean. These aggregate records cannot be deduplicated at the individual-review level.</p>'
    body+=table('broader_weekly','all_available_pre','all_reviewed','review')
    body+='<h2>Geographic reconstruction and checks</h2>'
    body+=f"<p>Scanned {audit['scanned_source_rows']:,} source rows. Retained {audit['retained_rows']:,} eligible restaurant-week observations across all counties before restricting the comparison to Trump-majority counties. Excluded {audit['conflicting_rows_excluded']} conflicting aggregate rows from {audit['conflicting_business_weeks_excluded']} business-week; their underlying review identities are unavailable. County polygons and precinct election results were independently rejoined by business ID. Missing geography excludes {audit['missing_geography_businesses']:,} eligible businesses; ambiguous county boundaries affect {audit['ambiguous_boundary_businesses']:,}. Among {audit['geography_comparison_businesses']:,} businesses comparable with the newer saved geography, {audit['geography_disagreements']:,} have a county/share disagreement. All such businesses ({geography_rows_excluded} weekly rows) are excluded from the broader comparisons. The disagreement file is saved for inspection.</p>"
    body+='''<h2>How to interpret baseline experiments</h2>
    <p>Baselines can differ in price, geography, chain prevalence, seasonality and customers. A change in the contrast when the baseline changes is evidence of specification sensitivity; it is not a reason to select whichever baseline gives the desired result. None of these tables establishes discrimination, reviewer ideology, or a causal effect of the election.</p>
    <p>Intervals use 5,000 county bootstrap resamples. Each draw resamples the same counties jointly across both groups and periods. In addition to individual 95% percentile intervals, baseline-family-adjusted intervals use Bonferroni percentile tails across the two exact-date baselines or nine broader baselines, separately within each window/cohort/weighting specification. These are approximate bootstrap intervals; adjustments do not cover searching across all specifications. The fixed-restaurant cohort conditions on review availability in both periods. County-level shocks and changing reviewer composition remain possible explanations.</p>
    <p>County assignment uses the supplied 2018 county polygons and geographical coordinates; unmatched or boundary-ambiguous points are excluded. GOP share is reconstructed using the project’s precinct-vote aggregation definition and checked against the saved modern shares. This does not independently validate the underlying election dataset.</p>
    <h2>Reproduce or change the baseline</h2><p>Edit <a href="../baseline_choices.json">baseline_choices.json</a>, then run <a href="../compare_baselines.py">compare_baselines.py</a>. The broader weekly inputs are built by <a href="../prepare_baseline_panel.py">prepare_baseline_panel.py</a>. They require the locally installed shapely and pyshp libraries in .analysis-python.</p>
    <p><a href="within_trump_baseline_results.csv">All 88 results, sample sizes and intervals</a> · <a href="broader_baseline_audit.json">Source hashes and geographic audit</a> · <a href="baseline_geography_disagreements.csv">Geographic disagreements</a></p>'''
    style='body{font:16px/1.6 system-ui;max-width:1250px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2,h3{color:#173f46}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px;border-bottom:1px solid #d8e2e5;text-align:left;vertical-align:top}th{background:#edf4f5}a{color:#14637d}h2{margin-top:36px}'
    (OUT/'within_trump_baselines.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Within-Trump-county baseline comparisons</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    verification={'result_rows':len(results),'previous_review_means_matched':True,
                  'relative_change_arithmetic_checked':True,'same_restaurant_counts_checked':True,
                  'ME_sample_held_constant_across_broader_baselines':True,
                  'geography_disagreement_rows_excluded':geography_rows_excluded,
                  'baseline_config':CFG}
    assert (results.familywise_low<=results.low).all() and (results.familywise_high>=results.high).all()
    assert results.valid_bootstrap_draws.ge(4975).all()
    (OUT/'baseline_comparison_verification.json').write_text(json.dumps(verification,indent=2))
    print('Exact-date review comparisons:')
    print(results[(results.source=='individual_reviews')&(results.window=='all_available_pre') &
                  ((results.cohort=='same_restaurants')|(results.weighting=='review'))][
                  ['baseline','cohort','weighting','ME_change','baseline_change','relative_change','low','high']].to_string(index=False))
    print('Broader weekly, same restaurants, equal restaurant weight:')
    print(results[(results.source=='broader_weekly')&(results.window=='all_available_pre') &
                  (results.cohort=='same_restaurants')&(results.weighting=='restaurant')][
                  ['baseline','ME_change','baseline_change','relative_change','low','high','baseline_pre_restaurants']].to_string(index=False))

if __name__=='__main__':main()
