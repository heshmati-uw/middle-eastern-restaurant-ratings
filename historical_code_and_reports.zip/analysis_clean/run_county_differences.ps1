param([string]$Python='C:/Users/heshmati/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
      [string]$Rscript='C:/Program Files/R/R-4.5.0/bin/Rscript.exe',
      [switch]$UseCache)
$ErrorActionPreference='Stop'
if($UseCache){& $Python "$PSScriptRoot/prepare_county_comparison.py" --use-cache}
else{& $Python "$PSScriptRoot/prepare_county_comparison.py"}
if($LASTEXITCODE -ne 0){throw 'Both-county source preparation failed'}
& $Rscript --vanilla "$PSScriptRoot/county_difference_models.R"
if($LASTEXITCODE -ne 0){throw 'County comparison models failed'}
& $Python "$PSScriptRoot/report_county_differences.py"
if($LASTEXITCODE -ne 0){throw 'County comparison verification/report failed'}
