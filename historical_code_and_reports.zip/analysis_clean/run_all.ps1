param(
    [string]$Python = 'C:/Users/heshmati/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
    [string]$Rscript = 'C:/Program Files/R/R-4.5.0/bin/Rscript.exe'
)
$ErrorActionPreference = 'Stop'
function Run-Step([string]$Executable, [string[]]$Arguments) {
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Analysis step failed with exit code $LASTEXITCODE" }
}
Run-Step $Python @("$PSScriptRoot/test_preparation.py")
Run-Step $Python @("$PSScriptRoot/prepare_data.py")
Run-Step $Rscript @('--vanilla', "$PSScriptRoot/run_models.R")
Run-Step $Rscript @('--vanilla', "$PSScriptRoot/verify_estimator.R")
Run-Step $Python @("$PSScriptRoot/build_results_report.py")
Run-Step $Python @("$PSScriptRoot/verify_outputs.py")
