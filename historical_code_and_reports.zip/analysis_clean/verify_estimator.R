# Independent verification against explicit fixed-effect dummies and sandwich.
args <- commandArgs(trailingOnly=FALSE)
here <- dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(fixest);library(sandwich);library(data.table)})
set.seed(20261026)
t <- expand.grid(id=1:45,period=1:10)
t <- t[runif(nrow(t))>.17,]
t$treated <- as.integer(t$id<=20)
t$post <- as.integer(t$period>=6)
t$x <- t$treated*t$post
t$z <- rnorm(nrow(t))
t$y <- 0.23*t$x+0.11*t$z+sin(t$id)+t$period/10+rnorm(nrow(t),sd=.2)
a <- feols(y~x+z|id+period,data=t,vcov=~id,
           ssc=ssc(K.adj=FALSE,G.adj=FALSE),fixef.rm='none',notes=FALSE)
b <- lm(y~x+z+factor(id)+factor(period),data=t)
v <- vcovCL(b,cluster=t$id,type='HC0',cadjust=FALSE)
coef_error <- max(abs(coef(a)-coef(b)[names(coef(a))]))
cov_error <- max(abs(vcov(a)-v[names(coef(a)),names(coef(a))]))
stopifnot(coef_error<1e-8,cov_error<1e-8)
# Confirm that observation indices identify the actual sample after singleton removal.
t2 <- rbind(t,transform(t[1,],id=999))
a2 <- feols(y~x+z|id+period,data=t2,vcov=~id,notes=FALSE)
stopifnot(nobs(a2)==nrow(t),!(nrow(t2) %in% obs(a2)))
res <- fread(file.path(here,'outputs','model_results.csv'))
stopifnot(all(res$low<=res$estimate),all(res$high>=res$estimate),
          all(res$p>=0 & res$p<=1),all(res$restaurants>1),
          all(res$p_holm[!is.na(res$p_holm)]>=res$p[!is.na(res$p_holm)]-1e-15))
capture.output(list(coefficient_max_error=coef_error,covariance_max_error=cov_error,
  dummy_regression_verified=TRUE,singleton_observation_index_verified=TRUE,
  result_interval_and_p_checks=TRUE),file=file.path(here,'outputs','estimator_verification.txt'))
cat('Independent estimator checks passed; coefficient error',coef_error,'covariance error',cov_error,'\n')
