"""Focused checks for mutually exclusive groups and the source-compatible dictionary."""
import unittest
import re
import pandas as pd
from prepare_data import classify, CFG, BABA, HUMMUS

class PreparationTests(unittest.TestCase):
    def test_exclusive_partition(self):
        primary = pd.Series(['Mediterranean restaurant','Mediterranean restaurant',
                             'Middle Eastern restaurant','Lebanese restaurant',
                             'American restaurant',None,' mediterranean restaurant '])
        baba = pd.Series([0,1,1,0,1,1,1])
        self.assertEqual(classify(primary,baba,CFG['me_categories']).tolist(),
                         ['MED','WPME','ME','ME','Excluded','Excluded','WPME'])

    def test_food_boundaries(self):
        for s in ['baba ghanoush','baba ganoush','babaghanouj','baba ghannouge']:
            self.assertIsNotNone(re.search(BABA,s),s)
        for s in ['baba','ghanoush','babaghanouji extra','garbanzo dip']:
            self.assertIsNone(re.search(BABA,s),s)
        self.assertIsNotNone(re.search(HUMMUS,'great hummus'))
        self.assertIsNone(re.search(HUMMUS,'hummuslike'))

    def test_complete_review_signature(self):
        d=pd.DataFrame({'id':['a']*3,'date':['2017-01-26']*3,'name':['n']*3,
                        'rating':[5]*3,'text':['good','good','different']})
        self.assertEqual(d.duplicated().tolist(),[False,True,False])

if __name__=='__main__':
    unittest.main()
