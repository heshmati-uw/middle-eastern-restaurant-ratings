# Draw identical vector and raster versions from the exported result tables.
res <- fread(file.path(out,'model_results.csv'))
ev <- fread(file.path(out,'event_study.csv'))
draw_did <- function(rr, outcome) {
  par(mar=c(4,10,2,2)); yy <- seq_len(nrow(rr))
  plot(rr$estimate,yy,xlim=range(c(rr$low,rr$high,0)),ylim=c(.5,nrow(rr)+.5),
       yaxt='n',xlab=if(outcome=='rating')'Differential post-ban change (stars)' else 'Differential post-ban change (reviews per week)',
       ylab='',pch=19,col='#17617d',cex=1.1)
  abline(v=0,lty=2,col='grey60'); segments(rr$low,yy,rr$high,yy,col='#17617d',lwd=2)
  axis(2,at=yy,labels=rr$comparison,las=1)
}
draw_events <- function(outcome) {
  target_outcome <- outcome
  par(mfrow=c(3,1),mar=c(3,5,2,2))
  for(pair in pairs) {
    ee <- ev[variant=='exclusive' & get('outcome')==target_outcome & comparison==paste(pair,collapse=' vs ')]
    stopifnot(nrow(ee)==10)
    setorder(ee,month); x <- match(ee$month,c(sprintf('2016-%02d',7:12),sprintf('2017-%02d',1:6)))
    plot(x,ee$estimate,xlim=c(.7,12.3),ylim=range(c(ee$low,ee$high,0)),xaxt='n',
         xlab='',ylab=if(outcome=='rating')'Stars vs Dec.' else 'Reviews/week vs Dec.',main=paste(pair,collapse=' vs '),pch=19,col='#17617d')
    segments(x,ee$low,x,ee$high,col='#17617d'); abline(h=0,lty=2,col='grey60')
    abline(v=7.5,lty=3,col='grey70'); points(6,0,pch=1)
    axis(1,at=1:12,labels=c(month.abb[7:12],month.abb[1:6]))
  }
}
for(outcome in c('rating','count')) {
  target_outcome <- outcome
  rr <- res[variant=='exclusive' & family=='DiD' & term=='did' & get('outcome')==target_outcome]
  stopifnot(nrow(rr)==3)
  for(fmt in c('svg','png')) {
    file <- file.path(out,paste0('did_',outcome,'.',fmt))
    if(fmt=='svg') svg(file,width=8,height=3.6) else png(file,width=1200,height=540,res=150)
    draw_did(rr,outcome); dev.off()
    file <- file.path(out,paste0('event_',outcome,'.',fmt))
    if(fmt=='svg') svg(file,width=10,height=8) else png(file,width=1500,height=1200,res=150)
    draw_events(outcome); dev.off()
  }
}
