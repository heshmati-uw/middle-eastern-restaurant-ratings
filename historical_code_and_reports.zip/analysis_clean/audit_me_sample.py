"""Audit ME sample attrition and extract common-source weekly outcomes."""
from pathlib import Path
import json,ast
import pandas as pd
import numpy as np
from prepare_data import sha256

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'
CFG=json.loads((HERE/'config.json').read_text())
ROOT=Path(CFG['source_root'])
SOURCE=ROOT/'data/Google Reviews/Reviews_Data_Combined.csv'

def main():
    reviews=pd.read_csv(OUT/'reviews_clean.csv',dtype={'county_fips':'string'})
    eligible=reviews[reviews.group.eq('ME')&reviews.gop_share.gt(.5)&reviews.county_fips.notna()&reviews.rating.notna()].copy()
    period=eligible[(eligible.date<'2016-11-08')|((eligible.date>='2016-11-09')&(eligible.date<'2017-01-27'))].copy()
    period['period']=np.where(period.date<'2016-11-08','pre','post')
    per=period.groupby('gmap_id').agg(pre=('period',lambda x:(x=='pre').any()),post=('period',lambda x:(x=='post').any()))
    target=per[per.pre&per.post].index
    groups=pd.read_csv(OUT/'restaurant_groups.csv')
    audit=groups[groups.gmap_id.isin(target)].copy()
    geo=reviews.drop_duplicates('gmap_id')[['gmap_id','county_fips','gop_share']]
    audit=audit.merge(geo,on='gmap_id',validate='one_to_one')
    cache=pd.read_pickle(OUT/'baseline_selected_cache.pkl')
    w=pd.read_csv(OUT/'broader_baseline_weekly.csv',dtype={'county_fips':'string'})
    disagreements=pd.read_csv(OUT/'baseline_geography_disagreements.csv')
    audit['legacy_selected_any_week']=audit.gmap_id.isin(cache.gmap_id)
    wp=w[w.group.eq('ME')]
    for name,subset in [('legacy_pre',wp[wp.period=='pre']),('legacy_post',wp[wp.period=='post']),
                        ('legacy_valid_geography',wp),('legacy_trump_geography',wp[wp.trump_county])]:
        audit[name]=audit.gmap_id.isin(subset.gmap_id)
    audit['geography_disagreement']=audit.gmap_id.isin(disagreements.gmap_id)
    audit['legacy_final_both']=audit.legacy_pre&audit.legacy_post&audit.legacy_trump_geography&~audit.geography_disagreement
    # Remove mixed weeks from the modern individual reviews. This isolates
    # window eligibility before testing source overlap.
    precise=reviews[reviews.gmap_id.isin(target)].copy()
    date=pd.to_datetime(precise.date)
    precise['week']=(date-pd.to_timedelta(date.dt.dayofweek,unit='D')).dt.strftime('%Y-%m-%d')
    complete=precise[(precise.week>='2016-07-04')&(precise.week<='2017-01-16')&precise.week.ne('2016-11-07')].copy()
    complete['period']=np.where(complete.week<'2016-11-07','pre','post')
    both=complete.groupby('gmap_id').period.nunique().eq(2)
    audit['modern_same_complete_weeks_both']=audit.gmap_id.isin(both[both].index)
    audit.to_csv(OUT/'ME_sample_attrition_by_restaurant.csv',index=False)
    # Extract outcomes for all modern focal groups plus American controls from
    # one combined weekly source, never splice modern review ratings onto legacy controls.
    focal=groups[groups.group.isin(['ME','MED','WPME'])][['gmap_id','group']].merge(geo,on='gmap_id',validate='one_to_one')
    focal=focal[focal.gop_share.gt(.5)&focal.county_fips.notna()]
    control_geo=pd.read_csv(OUT/'baseline_business_geography.csv',dtype={'county_fips':'string'})
    control_groups=cache[cache.group.isin(['American','New American','Traditional American'])][['gmap_id','group']].drop_duplicates('gmap_id')
    controls=control_groups.merge(control_geo[['gmap_id','county_fips','gop_share']],on='gmap_id',validate='one_to_one')
    controls=controls[controls.gop_share.gt(.5)&controls.county_fips.notna()&~controls.gmap_id.isin(disagreements.gmap_id)]
    candidates=pd.concat([focal,controls],ignore_index=True)
    assert candidates.gmap_id.is_unique
    candidates.to_csv(OUT/'expanded_american_candidates.csv',index=False)
    ids=set(candidates.gmap_id)
    collected=[]; count=0; target_seen=set()
    print('Scanning combined weekly source for focal restaurants and American controls...',flush=True)
    for chunk in pd.read_csv(SOURCE,usecols=['gmap_id','Date','Average Rating','Count of Reviews'],chunksize=20000):
        count+=len(chunk)
        z=chunk[chunk.gmap_id.isin(ids)].copy()
        if len(z):
            collected.append(z);target_seen.update(z.gmap_id)
        if count%100000==0:
            print(f'Scanned {count:,} business rows; found {len(target_seen):,} candidate IDs; target ME IDs {len(set(target)&target_seen)}/{len(target)}',flush=True)
    found=pd.concat(collected,ignore_index=True)
    found.to_pickle(OUT/'expanded_american_source_records.pkl')
    audit['combined_source_id_present']=audit.gmap_id.isin(target_seen)
    rows=[]; errors=[]
    for rec in found.itertuples(index=False,name=None):
        ident,dates,ratings,counts=rec
        try:
            ds=ast.literal_eval(dates);rs=ast.literal_eval(ratings);ns=ast.literal_eval(counts)
            assert len(ds)==len(rs)==len(ns)
            for day,rating,n in zip(ds,rs,ns):
                if '2016-07-04'<=day<='2017-01-16' and day!='2016-11-07':
                    rows.append((ident,day,float(rating),float(n)))
        except Exception as e:errors.append({'gmap_id':ident,'error':str(e)})
    z=pd.DataFrame(rows,columns=['gmap_id','week','rating','reviews'])
    ndup=int(z.duplicated().sum());z=z.drop_duplicates()
    conflict=z[z.duplicated(['gmap_id','week'],keep=False)]
    conflict.to_csv(OUT/'expanded_american_week_conflicts.csv',index=False)
    z=z.loc[~z.duplicated(['gmap_id','week'],keep=False)].copy()
    z=z[z.rating.between(1,5)&z.reviews.gt(0)]
    z=z.merge(candidates,on='gmap_id',validate='many_to_one')
    z['period']=np.where(z.week<'2016-11-07','pre','post')
    z.to_csv(OUT/'expanded_american_weekly.csv',index=False)
    for name,subset in [('combined_pre',z[z.period=='pre']),('combined_post',z[z.period=='post'])]:
        audit[name]=audit.gmap_id.isin(subset.gmap_id)
    audit['combined_both']=audit.combined_pre&audit.combined_post
    audit['primary_missing_reason']=np.select([
        audit.legacy_final_both,~audit.legacy_selected_any_week,
        ~audit.legacy_valid_geography,audit.geography_disagreement,
        ~audit.legacy_trump_geography,~(audit.legacy_pre&audit.legacy_post)],
        ['Retained','No eligible rows in legacy restaurant panel','Missing legacy geography',
         'Conflicting geography','Legacy geography not Trump-majority','Legacy reviews on only one side'],default='Other')
    audit.to_csv(OUT/'ME_sample_attrition_by_restaurant.csv',index=False)
    summary={'target_modern_ME_restaurants':len(target),'modern_complete_weeks_both':int(audit.modern_same_complete_weeks_both.sum()),
             'legacy_target_present':int(audit.legacy_selected_any_week.sum()),
             'legacy_target_final_both':int(audit.legacy_final_both.sum()),
             'attrition_reasons':audit.primary_missing_reason.value_counts().to_dict(),
             'combined_business_rows_scanned':count,'candidate_businesses':len(candidates),
             'combined_candidates_found':len(target_seen),'combined_target_ids_present':int(audit.combined_source_id_present.sum()),
             'combined_target_both':int(audit.combined_both.sum()),'exact_week_duplicates_removed':ndup,
             'conflicting_week_rows_excluded':len(conflict),'parse_errors':errors,
             'combined_source':{'path':str(SOURCE),'bytes':SOURCE.stat().st_size,'sha256':sha256(SOURCE)}}
    (OUT/'ME_sample_attrition_audit.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ['combined_source','parse_errors']},indent=2),flush=True)

if __name__=='__main__':main()
