"""Equal-restaurant American comparisons on a common rebuilt weekly source."""
from pathlib import Path
from html import escape
import json
import pandas as pd
import numpy as np
from compare_baselines import compare_pair

HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'

def main():
    audit=pd.read_csv(OUT/'ME_sample_attrition_by_restaurant.csv')
    # The separate ID audit may add columns; retain its completed conclusions.
    summary=json.loads((OUT/'ME_sample_attrition_audit.json').read_text())
    w=pd.read_csv(OUT/'expanded_american_weekly.csv',dtype={'county_fips':'string'})
    legacy=pd.read_csv(OUT/'broader_baseline_weekly.csv',dtype={'county_fips':'string'})
    # Compare the common keys before attributing a result change to sample size.
    overlap=w.merge(legacy[['gmap_id','week','rating','reviews']],on=['gmap_id','week'],
                    suffixes=('_rebuilt','_legacy'),validate='one_to_one')
    overlap['rating_difference']=overlap.rating_rebuilt-overlap.rating_legacy
    overlap['count_difference']=overlap.reviews_rebuilt-overlap.reviews_legacy
    mismatches=overlap[(overlap.rating_difference.abs()>1e-5)|overlap.count_difference.ne(0)]
    mismatches.to_csv(OUT/'combined_vs_legacy_outcome_mismatches.csv',index=False)
    substantive=overlap[(overlap.rating_difference.abs()>.005001)|overlap.count_difference.ne(0)]
    substantive.to_csv(OUT/'combined_vs_legacy_substantive_mismatches.csv',index=False)
    source_checks=json.loads((OUT/'expanded_source_comparison_audit.json').read_text())
    assert source_checks['raw_modern_ME_rating_and_count_match_combined']
    # Keep exactly the original 135-business ME target universe. Its 134 eligible
    # complete-week businesses are selected by the same pre/post rule as controls.
    ids=set(audit.gmap_id)
    w=w[~w.group.eq('ME')|w.gmap_id.isin(ids)].copy()
    w['score_sum']=w.rating*w.reviews;w['weight']=w.reviews
    subsets={'larger_ME_sample':set(audit[audit.combined_both].gmap_id),
             'old_56_ME_sample':set(audit[audit.legacy_final_both].gmap_id),
             'recovered_ME_restaurants':set(audit[audit.combined_both&~audit.legacy_final_both].gmap_id)}
    baselines={'American':['American'],'American broad':['American','New American','Traditional American'],
               'MED':['MED'],'WPME':['WPME']}
    rows=[]
    for window,start in [('all_available_pre','2016-07-04'),('equal_10_weeks','2016-08-29')]:
        for sample,focal_ids in subsets.items():
            z=w[((w.week>=start)|w.period.eq('post')) &
                (~w.group.eq('ME')|w.gmap_id.isin(focal_ids))].copy()
            for baseline,members in baselines.items():
                r=compare_pair(z,baseline,members,'same_restaurants','restaurant',family_size=len(baselines))
                if r is not None:rows.append({'window':window,'ME_sample':sample,**r})
    r=pd.DataFrame(rows)
    r.to_csv(OUT/'expanded_american_comparison.csv',index=False)
    assert len(r)==24
    assert r.groupby(['window','ME_sample'])[['ME_pre_restaurants','ME_pre','ME_post']].nunique().eq(1).all().all()
    # No review count enters the final cross-restaurant weighting: the generic
    # function uses count weights only to reconstruct each restaurant-period mean.
    main=r[r.window.eq('all_available_pre')&r.ME_sample.eq('larger_ME_sample')]
    def table(sample,window):
        x=r[(r.ME_sample==sample)&(r.window==window)]
        t='<table><tr><th>Baseline</th><th>ME before → after</th><th>Baseline before → after</th><th>ME relative change</th><th>95% county-bootstrap interval</th><th>Family-adjusted interval</th><th>ME restaurants</th><th>Control restaurants</th></tr>'
        for q in x.itertuples():
            cells=[q.baseline,f'{q.ME_pre:.3f} → {q.ME_post:.3f}',f'{q.baseline_pre:.3f} → {q.baseline_post:.3f}',
                   f'{q.relative_change:+.3f}',f'[{q.low:+.3f}, {q.high:+.3f}]',
                   f'[{q.familywise_low:+.3f}, {q.familywise_high:+.3f}]',f'{q.ME_pre_restaurants:,}',f'{q.baseline_pre_restaurants:,}']
            t+='<tr>'+''.join('<td>'+escape(c)+'</td>' for c in cells)+'</tr>'
        return t+'</table>'
    body='''<h1>Why the weekly ME sample fell to 56—and the larger American comparison</h1>
    <p><strong>We can use a substantially larger sample.</strong> The old prepared panel omitted eligible records for 79 of the 135 ME restaurants in Trump-majority counties that had individual reviews on both sides of the election. Their IDs were not absent from the original combined review file: all 135 are present there. Rebuilding weekly outcomes from that file retains 134 ME restaurants in the same complete-week windows.</p>
    <p>Every main result below gives <strong>each restaurant equal weight</strong>. Within each restaurant and period, reviews are first averaged; only then are restaurant averages compared. The same businesses must have reviews in both periods. Trump-majority means more than 50% Republican vote share.</p>
    <h2>Where the restaurants went</h2><table><tr><th>Check</th><th>ME restaurants</th></tr>'''
    stages=[('Original exact-date same-restaurant cohort',summary['target_modern_ME_restaurants']),
            ('Qualify for complete-week windows in modern reviews',summary['modern_complete_weeks_both']),
            ('Eligible records in the prepared legacy panel',summary['legacy_target_present']),
            ('Retained in the earlier weekly American comparison',summary['legacy_target_final_both']),
            ('IDs found in the original combined source',summary['combined_target_ids_present']),
            ('Before-and-after data rebuilt from the combined source',summary['combined_target_both'])]
    body+=''.join(f'<tr><td>{escape(label)}</td><td>{n}</td></tr>' for label,n in stages)+'</table>'
    missing=audit[~audit.combined_both]
    body+='<p>Only one original-cohort business lacks usable data on both sides in the complete-week windows: '+', '.join(escape(n) for n in missing.business_name)+'. Individual reviews during mixed election/ban weeks cannot be separated using weekly aggregates, so no partial-week average is invented.</p>'
    body+='<p>The exact-date group has 135 businesses, while 134 qualify for the conservative weekly windows. The old 56-business restriction is therefore a coverage issue in the prepared legacy extract, not a requirement to discard most of the ME restaurants. The audit identifies absent IDs and possible alternate-name matches; unverified fuzzy matches are not used.</p>'
    body+='<p>The separate scan of all 3,903,822 rows in the legacy sample confirms that only 56 target IDs occur anywhere in that file, before applying our narrower election windows. Canonical hexadecimal ID normalization recovers no additional IDs. The precise historical export/build step responsible for the omission has not been established; rebuilding from the common original source avoids depending on it.</p>'
    body+='<h2>Larger sample: equal restaurant weights</h2><p>Before: complete weeks July 4–November 6, 2016. After: November 14, 2016–January 22, 2017. The election and ban weeks are excluded. Negative ME relative change means ME lost ground against the baseline.</p>'
    body+=table('larger_ME_sample','all_available_pre')
    body+='<h2>Equal ten-week windows</h2><p>The pre period starts August 29, 2016; the post period is unchanged. Eligibility is checked again, so some businesses with only earlier pre-period reviews are excluded.</p>'
    body+=table('larger_ME_sample','equal_10_weeks')
    body+='<h2>Decompose the sample difference</h2><p>Both tables below use the same rebuilt weekly source and control universe. They separate the old ME cohort from the recovered restaurants rather than mixing sources or changing review-volume weights.</p><h3>The old 56 ME restaurants, rebuilt from the common source</h3>'
    body+=table('old_56_ME_sample','all_available_pre')
    body+='<h3>The recovered ME restaurants</h3>'+table('recovered_ME_restaurants','all_available_pre')
    body+=f"<h2>Source and measurement checks</h2><p>The combined file contains {summary['combined_business_rows_scanned']:,} business rows. All {summary['candidate_businesses']:,} candidate IDs were found, including the 135 target ME IDs. Its date/rating/count lists were parsed and aligned by business ID and week. Excluded {summary['conflicting_week_rows_excluded']} conflicting aggregate rows and removed {summary['exact_week_duplicates_removed']} exact week duplicates. Parse errors: {len(summary['parse_errors'])}.</p>"
    body+=f'<p>Across {len(overlap):,} business-week keys shared with the legacy panel, {len(mismatches):,} differ under a strict rating tolerance of 0.00001. Most are explained by the legacy file rounding ratings to two decimals. Only {len(substantive):,} remain beyond that rounding tolerance or have unequal counts; these involve {substantive.gmap_id.nunique()} businesses. Both sets of records are exported for inspection.</p>'
    body+=f"<p><strong>Direct validation against individual reviews:</strong> all {source_checks['validated_raw_ME_business_weeks']:,} ME business-weeks in the rebuilt combined source match the raw modern review panel exactly in rating and review count. Comparing against its deduplicated version leaves {source_checks['matched_weeks_count_disagrees']} count differences; this is consistent with removing duplicate reviews from the individual-review analysis. Aggregate-only American data cannot be deduplicated by review signature, so the common-source weekly analysis consistently uses the supplied aggregate outcomes.</p>"
    body+='''<p>American controls come from the audited legacy American candidate list, but <strong>their rating outcomes are also rebuilt from the combined source</strong>. Focal ratings from newer individual reviews are not spliced onto older American ratings. Broader American includes New American and Traditional American categories. This remains a selected control universe, not an exhaustive new census of all American restaurants.</p>
    <p>Geography for focal restaurants uses the newer audited county mapping. American controls use the reconstructed mapping, excluding known disagreements. The earlier raw-review deduplication cannot be reproduced within already-aggregated weekly lists; that is a remaining measurement difference from the exact-date review analysis.</p>
    <p>Intervals use 5,000 joint county bootstrap resamples and are exploratory. Family-adjusted percentile intervals use Bonferroni tails across the four displayed baseline choices, separately within each cohort/window. This does not adjust for searching across every alternative specification or establish a causal election effect. Holding restaurants fixed does not fix reviewer composition or local economic conditions.</p>
    <h2>Audit trail and reproducibility</h2><ul>
    <li><a href="ME_sample_attrition_by_restaurant.csv">Restaurant-by-restaurant missingness audit</a></li>
    <li><a href="ME_sample_attrition_audit.json">Source coverage, parsing checks and source hash</a></li>
    <li><a href="expanded_american_comparison.csv">All equal-restaurant results</a></li>
    <li><a href="combined_vs_legacy_outcome_mismatches.csv">Outcome disagreements between sources</a></li>
    <li><a href="../audit_me_sample.py">Combined-source extraction code</a></li>
    <li><a href="../expanded_american_comparison.py">Comparison code</a></li></ul>'''
    style='body{font:16px/1.6 system-ui;max-width:1200px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2,h3{color:#173f46}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;padding:10px;border-bottom:1px solid #d8e2e5;vertical-align:top}th{background:#edf4f5}a{color:#14637d}'
    (OUT/'expanded_american_report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Expanded ME sample and American comparison</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    checks={'equal_restaurant_weights':True,'same_restaurants_both_periods':True,
            'all_control_and_focal_outcomes_from_same_combined_source':True,
            'comparison_rows':len(r),'overlap_business_weeks':len(overlap),'outcome_mismatches':len(mismatches),
            'outcome_mismatches_beyond_rounding':len(substantive),
            'raw_review_ME_weeks_validated':source_checks['validated_raw_ME_business_weeks'],
            'recovered_original_target_ME':summary['combined_target_both']-summary['legacy_target_final_both']}
    (OUT/'expanded_american_verification.json').write_text(json.dumps(checks,indent=2))
    print(main[['baseline','ME_pre','ME_post','baseline_pre','baseline_post','relative_change','low','high',
                'ME_pre_restaurants','baseline_pre_restaurants']].to_string(index=False))
    print('Source overlap comparison:',checks)

if __name__=='__main__':main()
