"""Merge independent attrition audits and compare overlapping source outcomes."""
from pathlib import Path
import json
import pandas as pd
import numpy as np
HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'

def main():
    a=pd.read_csv(OUT/'ME_sample_attrition_by_restaurant.csv')
    w=pd.read_csv(OUT/'expanded_american_weekly.csv',dtype={'county_fips':'string'})
    found=pd.read_pickle(OUT/'expanded_american_source_records.pkl')
    legacy=pd.read_csv(OUT/'legacy_ME_exact_id_records.csv')
    a['id_present_anywhere_in_legacy_sample']=a.gmap_id.isin(legacy.gmap_id)
    a['combined_source_id_present']=a.gmap_id.isin(found.gmap_id)
    for name,part in [('combined_pre',w[w.period=='pre']),('combined_post',w[w.period=='post'])]:
        a[name]=a.gmap_id.isin(part.gmap_id)
    a['combined_both']=a.combined_pre&a.combined_post
    a['primary_missing_reason']=np.where(a.legacy_final_both,'Retained',
                                        'ID absent anywhere in prepared legacy panel')
    a.to_csv(OUT/'ME_sample_attrition_by_restaurant.csv',index=False)
    d=pd.read_csv(OUT/'reviews_clean.csv',dtype={'county_fips':'string'})
    d=d[d.gmap_id.isin(a.gmap_id)].copy()
    day=pd.to_datetime(d.date)
    d['week']=(day-pd.to_timedelta(day.dt.dayofweek,unit='D')).dt.strftime('%Y-%m-%d')
    d=d[(d.week>='2016-07-04')&(d.week<='2017-01-16')&d.week.ne('2016-11-07')]
    modern=d.groupby(['gmap_id','week']).agg(rating=('rating','mean'),reviews=('rating','count')).reset_index()
    q=w[w.gmap_id.isin(a.gmap_id)].merge(modern,on=['gmap_id','week'],how='outer',
        suffixes=('_combined','_modern'),indicator=True)
    q['rating_difference']=q.rating_combined-q.rating_modern
    q['count_difference']=q.reviews_combined-q.reviews_modern
    q.to_csv(OUT/'combined_vs_modern_ME_weeks.csv',index=False)
    matched=q[q['_merge']=='both']
    raw=pd.read_csv(OUT/'reviews_with_duplicates.csv')
    raw=raw[raw.gmap_id.isin(a.gmap_id)].copy()
    day=pd.to_datetime(raw.date)
    raw['week']=(day-pd.to_timedelta(day.dt.dayofweek,unit='D')).dt.strftime('%Y-%m-%d')
    rm=raw.groupby(['gmap_id','week']).agg(raw_rating=('rating','mean'),raw_reviews=('rating','count')).reset_index()
    rc=w[w.gmap_id.isin(a.gmap_id)].merge(rm,on=['gmap_id','week'],how='outer',indicator=True)
    rc=rc[rc.week.ge('2016-07-04')&rc.week.le('2017-01-16')&rc.week.ne('2016-11-07')]
    assert rc['_merge'].eq('both').all()
    assert (rc.rating-rc.raw_rating).abs().le(1e-8).all()
    assert rc.reviews.eq(rc.raw_reviews).all()
    old=pd.read_csv(OUT/'combined_vs_legacy_outcome_mismatches.csv')
    # Produce compact examples and distributions rather than hiding source changes.
    source_summary={'target_restaurants':len(a),'legacy_ids_present':int(a.id_present_anywhere_in_legacy_sample.sum()),
        'combined_ids_present':int(a.combined_source_id_present.sum()),'combined_both':int(a.combined_both.sum()),
        'modern_aggregate_weeks':len(modern),'combined_target_weeks':len(w[w.gmap_id.isin(a.gmap_id)]),
        'week_key_overlap':len(matched),'combined_only_weeks':int(q['_merge'].eq('left_only').sum()),
        'modern_only_weeks':int(q['_merge'].eq('right_only').sum()),
        'matched_weeks_rating_disagrees':int(matched.rating_difference.abs().gt(1e-5).sum()),
        'matched_weeks_count_disagrees':int(matched.count_difference.ne(0).sum()),
        'matched_combined_review_count':float(matched.reviews_combined.sum()),
        'matched_modern_review_count':float(matched.reviews_modern.sum()),
        'legacy_mismatch_rating_count':int(old.rating_difference.abs().gt(1e-5).sum()),
        'legacy_mismatches_beyond_two_decimal_rounding':int((old.rating_difference.abs().gt(.005001)|old.count_difference.ne(0)).sum()),
        'legacy_mismatch_review_count':int(old.count_difference.ne(0).sum()),
        'raw_modern_ME_week_keys_match_combined':True,
        'raw_modern_ME_rating_and_count_match_combined':True,
        'validated_raw_ME_business_weeks':len(rc),
        'missing_complete_week_businesses':a.loc[~a.combined_both,['gmap_id','business_name']].to_dict('records')}
    (OUT/'expanded_source_comparison_audit.json').write_text(json.dumps(source_summary,indent=2))
    print(json.dumps(source_summary,indent=2))
    print('Legacy mismatch examples:')
    print(old[['gmap_id','week','rating_rebuilt','rating_legacy','reviews_rebuilt','reviews_legacy']].head(8).to_string(index=False))

if __name__=='__main__':main()
