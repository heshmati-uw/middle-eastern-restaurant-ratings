# Restaurant positioning: reproducible rerun

This folder replaces the historical analysis fragments with a configurable pipeline for mutually exclusive ME, Mediterranean (`MED`), and WPME comparisons. It reads the saved 2025 review panel; it does not edit the Dropbox originals or rebuild all raw state archives. The earlier code remains historical source material.

## Run

From PowerShell:

```powershell
./analysis_clean/run_all.ps1
```

The wrapper accepts `-Python` and `-Rscript` paths. Python requires pandas and numpy. The default uses the bundled Python runtime. R 4.5.0 is installed locally; required R packages are in the project-local `.r-library`. For a fresh setup:

```powershell
& 'C:/Program Files/R/R-4.5.0/bin/Rscript.exe' --vanilla ./analysis_clean/install_dependencies.R
```

That step requires network access. Exact installed package versions and session details are recorded in `outputs/R_package_versions.json` and `outputs/R_sessionInfo.txt`; installation on another date may resolve newer package versions. Dependencies are not vendored into version control. The source locations and analysis dates are in `config.json`.

The steps are: focused preparation tests → data preparation → fixed-effect models and plots → independent estimator verification → HTML report → output verification. Every step must succeed; the wrapper stops on errors. The HTML report in `outputs/results_report.html` is the main reading artifact. CSVs are machine-readable analysis data/results, not interactive spreadsheet models.

## Group rules

Use the first stored category, matching the 2025 operationalization:

- **ME:** first category belongs to the exact 20-category list in `config.json`.
- **WPME:** first category contains Mediterranean, and the stored restaurant-level baba flag is 1.
- **MED:** first category contains Mediterranean, and the stored baba flag is 0.
- All other first categories are excluded. Secondary ME/MED tags do not override the first category.

WPME and MED partition Mediterranean. ME categories do not include Mediterranean. Each business receives one scalar group label. These are operational labels, not verified ethnicity, authenticity, or deliberate concealment.

The **preperiod_food** sensitivity recomputes mentions from July 1, 2016 through January 26, 2017, using the historical Python pipeline's word-boundary dictionary and punctuation normalization. Require any pre-ban hummus/baba evidence in all groups, then assign WPME only if baba is observed before the ban. This restricts the cohort and changes labels. The **prekeyword_cohort_original_labels** variant uses the identical restricted cohort with original stored labels to distinguish eligibility from relabeling. Upstream lifetime-keyword selection and unverified category timing remain limitations.

## Cleaning

Use the exact UTC `review_date`, not the rounded numerical Unix time column. Post begins January 27, 2017 inclusive. The saved panel covers July 1, 2016 through June 30, 2017.

Remove duplicate signatures `(gmap_id, review_date, name, text, rating)` while retaining the first record. This removes 3,905 rows. Without a stable review ID, even a complete signature is an operational duplicate definition; retaining duplicates is a sensitivity. Do not collapse reviews merely because dates or star ratings match. Rating missingness is not changed to zero. The lone missing rating lies outside the three eligible groups; all eligible reviews have valid ratings.

Restaurant attributes must be invariant within business and agree with the supplied business master. Source file hashes are recorded. Prepared review outputs omit reviewer names and text; original source records remain intact.

## Models and inference

Pairwise comparisons are ME vs MED, WPME vs ME, and WPME vs MED. The first group is treated. Positive coefficients mean the first group's post-minus-pre change exceeds the second's.

- Individual-rating OLS: restaurant FE + calendar-month FE + post × treated.
- Weekly-count OLS in levels: restaurant FE + calendar-week FE + post × treated.
- Political heterogeneity: add post × GOP share and post × treated × GOP share. Time-invariant group, share, and group × share are absorbed by restaurant FE. Center share at the unweighted restaurant mean for each pair, and scale it so the triple interaction is per 10 percentage points of GOP share.
- Cluster by restaurant; also report county-clustered sensitivity models. Do not infer reviewer ideology from county vote share.
- Use `fixest::feols`, remove singletons, apply `ssc(K.adj=TRUE, K.fixef='nonnested', G.adj=TRUE, t.df='min')`. Save fitted R models. Report cluster counts, estimation N, input N and removed observations.
- Holm-adjust the three pairwise DiD p-values within each outcome/specification and the three target GOP interactions within each outcome/classification. Other sensitivity and event coefficients are exploratory; no global adjustment across every model is claimed.

These estimate differential changes. Category levels and raw rating means are descriptive, not treatment effects.

## Review-count denominator

Retain complete weeks with Monday starts July 4, 2016 through June 19, 2017 (ending June 25), and omit the mixed ban week January 23–29. The main cohort requires an observed review on each side of the ban within those retained weeks. Fill all remaining 50 weeks per business, including zeros.

Alternatives: restrict zero-filling to each business's first-to-last observed week; include all observed businesses in the full-window grid; or retain positive-count weeks only (diagnostic of the older approach, not a preferred denominator). Review counts are not sales. Full-window filling assumes availability for review; observed-span filling cannot identify actual operating dates. Conditioning on post-period observation may introduce selection.

## Event studies

December 2016 is the reference. Exclude mixed January 2017. Interact treatment with July–November 2016 and February–June 2017 indicators; absorb restaurant and month FE for ratings, restaurant and week FE for counts. Jointly test the five pre-period coefficients using restaurant-clustered Wald F tests. Do not interpret non-rejection as proof of parallel trends. The count comparisons against MED reject the pre-trend null in the main run.

## Other sensitivities and historical comparisons

Narrow ME to the exact Middle Eastern category; retain duplicates; restrict ratings to businesses observed on both sides; use equal restaurant-month mean ratings excluding January; and examine the top five parsed address localities by eligible restaurant count. The latter are New York, Los Angeles, Chicago, Houston, and Brooklyn, as address labels; they are not standardized cities and cannot reproduce the old unnamed city sample.

The legacy diagnostic restores inclusive MED = MED + WPME and duplicates for two old rating comparisons. This approximately recovers the old saved coefficients. The missing expanded American-control dataset and model code prevent replication of the earlier American comparisons. The present analysis cannot establish or refute those claims.

## Verification and provenance

`test_preparation.py` checks hand-specified classification cases, word boundaries and duplicate signatures. `verify_estimator.R` compares fixed-effect coefficients and cluster covariance to an explicit-dummy `lm` plus `sandwich::vcovCL` on an unbalanced synthetic panel, and checks singleton observation indices. It also checks exported estimates, intervals, p-values and multiplicity adjustment. `verify_outputs.py` reconciles review counts, group assignments, source hashes and output completeness.

Source hashes and configuration: `outputs/data_audit.json`. Count denominator/cohort accounting: `outputs/count_panel_audit.json`. Code hashes: `outputs/executed_code_md5.json`. Numerical verification and package versions are saved alongside all estimates. See the report for findings and limitations; no original Dropbox file is overwritten.

## Election averages and alternative baselines

`post_election_averages.py` calculates average ratings after the election and before the ban. `election_before_after.py` compares pre/post levels across Trump-majority and other counties, using repeated cross sections and fixed restaurant cohorts. These are descriptive comparisons, not causal election estimates.

`run_baselines.ps1` separately compares ME with Mediterranean/WPME within Trump-majority counties and experiments with American, broader American, fast-food, Greek, Chinese, Italian and pizza baselines. Baseline memberships and bootstrap settings are in `baseline_choices.json`. The exact-date review tables use July 1–November 7 and November 9–January 26, plus equal 79-day windows. All election-day and ban-period reviews are excluded.

Broader controls come from the 3,903,822-row legacy restaurant-week panel, not from the keyword-selected American observations in the modern review sample. The broader analysis maps the existing focal ME/MED/WPME business classifications onto that panel. The primary fixed-restaurant sample in Trump-majority counties has only 56 ME businesses; it is not the 135-business focal cohort in the exact-date comparison. That ME sample is held constant across weekly baseline choices. Complete weekly windows are July 4–November 6 and November 14–January 22, or ten equal weeks on each side (pre starts August 29). Mixed election/ban weeks are excluded.

`prepare_baseline_panel.py` streams the legacy source and independently reconstructs county assignments from the supplied 2018 county polygons and precinct election results. Missing/ambiguous locations are excluded. One conflicting Chinese business-week has two different aggregate ratings; both rows are excluded rather than combined without review IDs. Two businesses disagree with the newer saved county/share assignment and are excluded from the broader comparisons. The geography/source audit and disagreements are saved. Geographic coordinates are treated in the county map's geographic coordinate space; no nearest-county substitution is made.

The optional `.analysis-python` library contains the pinned packages in `geospatial_requirements.txt`. For a fresh setup, install them with the Python executable above using `-m pip install --target ./.analysis-python --no-deps -r ./analysis_clean/geospatial_requirements.txt`. Run the baseline wrapper after the main preparation has generated the modern group assignments. `-UseCache` reuses the locally generated selected weekly-data cache after checking source size/mtime, classification hash and cache hash; omit it to reread the original source. When changing extraction dates, category mappings or selection logic, omit `-UseCache` to rebuild the cache.

`compare_baselines.py` produces all 88 window/cohort/weighting/baseline results. Its county bootstrap resamples counties jointly across both comparison groups and both periods; shared local shocks therefore remain together. It exports ordinary percentile 95% intervals and approximate Bonferroni intervals across two exact-date or nine weekly baseline choices within each specification. Adjustment does not cover searching across every alternative window/weighting. `test_baseline_comparisons.py` checks the contrast and bootstrap on a hand-specified constant-effect example. Results are in `outputs/within_trump_baselines.html` and `outputs/within_trump_baseline_results.csv`.

## Larger ME sample for the American comparison: equal restaurant weights

The earlier 56-ME-business result reflects coverage of the prepared legacy panel, not the maximum available sample. A complete scan finds only 56 of the original 135 target ME business IDs anywhere in that prepared file. All 135 IDs are present in `Reviews_Data_Combined.csv`; rebuilding its aligned weekly date/rating/count lists retains 134 in complete pre/post election weeks. The remaining business lacks observations in both periods after excluding mixed weeks. No unverified name-based linkage is substituted.

Run `run_expanded_american.ps1` for the full coverage audit, common-source reconstruction, comparisons and verification. This scans the original combined file once and the legacy panel once. If those extractions already exist and inputs have not changed, `-UseExistingExtraction` skips the scans but rechecks the combined source hash at verification. Dependencies and the earlier modern business/geography outputs must already be available. Source records and the per-restaurant attrition audit are retained locally.

The main rebuilt comparison uses 134 ME restaurants and 4,053 American restaurants in Trump-majority counties, each with a before-period mean and an after-period mean, and equal weight per restaurant. American controls are drawn from the audited control universe, but their outcomes are rebuilt from the same combined weekly source as ME. The focal modern review means are not spliced onto legacy American outcomes. Broader American adds New/Traditional American controls. The pre/post windows use complete weeks July 4–November 6 and November 14–January 22; equal ten-week windows are a sensitivity.

All 1,592 ME business-week rating/count records in that rebuilt source agree exactly with the raw modern individual-review panel before deduplication. The already-aggregated American data cannot be deduplicated by individual review signature, so aggregate outcomes are used consistently for both sides; differences from the deduplicated exact-date analysis remain explicit. Most overlap differences against the legacy file reflect two-decimal rounding; 17 business-weeks across three businesses differ beyond rounding or in counts and are exported separately.

`expanded_american_comparison.py` also separates the old 56-business ME cohort from the 78 recovered businesses on the same rebuilt source/control universe. It exports 24 window/cohort/baseline results, always equally weighting restaurants. `verify_expanded_american.py` independently reconstructs the restaurant-period means, checks the sample counts, exclusions, links and source hash. The report is `outputs/expanded_american_report.html`; the latest point estimates remain exploratory and sensitive to window choice and multiplicity adjustment.

## Election and ban shocks; ME, WPME and American

Run `run_election_ban.ps1` after the common-source extraction above. Settings and windows are recorded in `shock_specifications.json`. `prepare_shock_data.py` uses the previously extracted full weekly arrays to extend outcomes through April 9, 2017, without another scan of the multi-gigabyte original. All groups are restricted to Trump-majority counties. Each restaurant contributes one within-period review average before and after, and the change receives equal weight in the cross-restaurant comparison. Restaurants must appear in both periods.

Main windows are ten complete weeks on each side. Election: August 29–November 6, 2016 versus November 14, 2016–January 22, 2017, excluding election and ban weeks. Ban: November 14, 2016–January 22, 2017 versus January 30–April 9, 2017, excluding ban week and using an entirely post-election baseline. Four- and six-week windows are sensitivities. The full available candidate ME and WPME pools are used for each window, rather than conditioning the ban sample on the earlier election cohort. American is the narrow primary category.

`election_ban_models.R` estimates ME vs American, WPME vs American, and WPME vs ME using OLS on restaurant-level before/after rating changes. Pairwise point estimates equal differences in group mean changes. Standard errors cluster by county with G/(G−1) × (N−1)/(N−2) correction, and p-values use two-sided t tests with G−1 degrees of freedom. Matching intervals and p-values therefore use the same method. The earlier percentile bootstrap intervals remain recorded separately and are not used to infer p-values from their endpoints.

The original −0.126-star ME–American comparison is reproduced separately on its original 134/4,053 cohort and dates; its county-clustered t-test p-value is approximately 0.067. Main equal-ten-week tests, all shorter-window tests, and Holm adjustments across three contrasts per shock/window, six main tests, or all 18 window/contrast/shock tests are exported. The original historical comparison is not included in those families. Changing windows changes cohort eligibility as well as dates.

`report_election_ban.py` independently verifies every point estimate and county sandwich standard error using explicit NumPy matrices, and verifies sample sizes and report links. R checks every exported p-value against the specified t distribution. The report is `outputs/election_ban_report.html`, with model results, restaurant changes, descriptives and saved fitted models alongside it. These unadjusted group-change comparisons do not by themselves identify causal election/ban effects or establish parallel trends.

The user subsequently selected four weeks as the **working** window after reviewing the window sensitivities. `working_window_weeks` and the selection note in `shock_specifications.json` record that choice. `report_short_window.py` generates `outputs/short_window_report.html` and focused CSV exports from the verified results. It does not overwrite the original ten-week main designation or the full sensitivity table. The four-week choice is explicitly exploratory; within-window adjustments do not account for selecting the window after inspecting results.

## Non-Trump counties and direct county-type differences

`run_county_differences.ps1` extends the identical four-week comparisons to counties with Republican vote share at or below 50%, while retaining the same greater-than-50% Trump-majority definition. Missing geography/share is excluded. The full run scans the combined outcome source once for the additional candidate IDs; `-UseCache` verifies source size/mtime, candidate hash and source-record cache hash before reusing that extraction. Focal ME/WPME and primary-American eligibility/mapping rules are mirrored across both strata; the non-Trump American pool is not restricted to food-keyword-selected modern American observations.

Windows remain election October 10–November 6 versus November 14–December 11, 2016, and ban December 26, 2016–January 22, 2017 versus January 30–February 26, 2017. Restaurant-period means and equal cross-restaurant weights are unchanged. Adding the non-Trump data reproduces all six previous Trump-county estimates, standard errors and p-values exactly.

`county_difference_models.R` first runs the three pairwise contrasts in each county stratum. It then directly tests their differences with `change ~ treated * trump`, clustered by county. The interaction equals (first-group-minus-second-group change in Trump counties) minus that same contrast in other counties. In period-level notation this is post × group × Trump county. For ME vs American, negative means ME lost more ground in Trump counties. Comparing significance levels from separate subgroup models is not used as a test of the difference.

Two-sided county-clustered inference is the headline method. Negative-tail one-sided p-values are exported as additional directional statistics but are not substituted for the two-sided results. Holm adjustments cover the two ME–American shock interaction tests and, separately, all six direct interaction tests. These do not correct for every earlier window/baseline choice; the selected four-week results remain exploratory. No county fixed effects or demographic covariates are added to these raw mean-change comparisons.

`report_county_differences.py` independently reconstructs all restaurant-period means and verifies all 18 subgroup/interaction point estimates and covariance matrices using explicit NumPy regressions. The report is `outputs/county_difference_report.html`. All stratum comparisons, direct tests, descriptives, business-level changes, fitted models and source coverage audits are exported alongside it.
