"""Create a readable report from saved model results; no hand-entered estimates."""
from pathlib import Path
from html import escape
import json
import math
import re
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'

def number(x,d=3):
    return '—' if pd.isna(x) else f'{x:,.{d}f}'

def pval(x):
    return '—' if pd.isna(x) else ('<0.001' if x<.001 else f'{x:.3f}')

def html_table(headers,rows):
    return '<div class="table-scroll"><table><thead><tr>'+''.join('<th>'+escape(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'

def data_link(name,label=None):
    assert (OUT/name).exists(),name
    return f'<a href="{escape(name)}">{escape(label or name)}</a>'

def source_link(name,label=None):
    assert (HERE/name).exists(),name
    return f'<a href="../{escape(name)}">{escape(label or name)}</a>'

def svg(name):
    t=(OUT/name).read_text()
    t=t[t.index('<svg'):]
    # Cairo SVGs reuse glyph/clip IDs. Prefix them so four inline charts cannot
    # resolve their glyph references against another chart's definitions.
    prefix=Path(name).stem+'_'
    ids=re.findall(r'\bid="([^"]+)"',t)
    for ident in sorted(set(ids),key=len,reverse=True):
        t=t.replace(f'id="{ident}"',f'id="{prefix}{ident}"')
        t=t.replace(f'#{ident}"',f'#{prefix}{ident}"')
        t=t.replace(f'#{ident})',f'#{prefix}{ident})')
    return '<div class="figure">'+t+'</div>'

def main():
    r=pd.read_csv(OUT/'model_results.csv')
    e=pd.read_csv(OUT/'event_study.csv')
    pre=pd.read_csv(OUT/'pretrend_tests.csv')
    a=json.loads((OUT/'data_audit.json').read_text())
    counts=json.loads((OUT/'count_panel_audit.json').read_text())
    main=r[(r.variant=='exclusive')&(r.family=='DiD')]
    assert len(main)==6
    def row(variant,outcome,pair,family='DiD',term='did'):
        z=r[(r.variant==variant)&(r.outcome==outcome)&(r.comparison==pair)&(r.family==family)&(r.term==term)]
        assert len(z)==1,(variant,outcome,pair,family,term)
        return z.iloc[0]
    rating=row('exclusive','rating','ME vs MED')
    wp=row('exclusive','rating','WPME vs ME')
    prewp=row('preperiod_food','rating','WPME vs ME')
    body='''<h1>Restaurant positioning: cleaned rerun</h1>
    <p class="subtitle">October 26, 2026 · mutually exclusive ME, Mediterranean and WPME groups</p>
    <p class="lead">The corrected analyses do not establish a protective effect of Mediterranean positioning. ME ratings improve relative to Mediterranean in the main specification, but that result is sensitive to weighting and pre-period classification. WPME has no clear post-ban rating advantage over ME. Review-count differences persist, but failed pre-trend tests weaken a causal interpretation.</p>
    <nav><a href="#main">Main results</a><a href="#robustness">Sensitivity checks</a><a href="#events">Event studies</a><a href="#methods">Methods</a><a href="#files">Code and results</a></nav>
    <h2>What changed</h2><p>The cleanup replaces dated, state-specific fragments with one configurable Python/R pipeline. Original Dropbox files are unchanged. Each business gets one group; duplicates are removed using a full review signature; dates are read from the precise review_date field; county merges are reused as supplied and checked for within-business consistency. Every model exports estimates, confidence intervals, sample sizes and clustering choices. Source hashes and software versions are recorded.</p>'''
    body+=html_table(['Group','Operational definition','Restaurants','Clean reviews','Raw mean stars'],[
        [g['group'] if g['group']!='MED' else 'Mediterranean',
         {'ME':'First stored category in the 20-category ME list',
          'MED':'First stored category Mediterranean; no stored baba mention',
          'WPME':'First stored category Mediterranean; stored baba mention present'}[g['group']],
         f"{g['restaurants']:,}",f"{g['reviews']:,}",number(g['mean_rating'])] for g in a['groups']])
    body+=f"<p>Input: {a['input_rows']:,} reviews from {a['input_restaurants']:,} businesses. Removed {a['exact_duplicate_rows_removed']:,} exact review-signature duplicates. The three-group sample has <strong>{a['eligible_reviews']:,} reviews from {a['eligible_restaurants']:,} restaurants</strong>; other primary categories are excluded. WPME is a food-mention proxy, not verified owner ethnicity or deliberate concealment. Raw mean gaps are descriptive and do not identify positioning effects.</p>"
    body+='<h2 id="main">Main difference-in-differences results</h2><p>Each row compares the first group’s post-ban change with the second group’s change. Positive means a relative increase. Ratings use restaurant and calendar-month fixed effects; review counts use restaurant and week fixed effects. Standard errors cluster by restaurant. Confidence intervals are 95%; Holm p-values adjust the three comparisons within each outcome.</p>'
    body+=html_table(['Outcome / comparison','Estimate','95% CI','p','Holm p','Observations','Restaurants'],[
        [('Stars' if z.outcome=='rating' else 'Reviews/week')+' · '+z.comparison,number(z.estimate),
         f'[{number(z.low)}, {number(z.high)}]',pval(z.p),pval(z.p_holm),f'{z.n:,}',f'{z.restaurants:,}'] for z in main.itertuples()])
    body+=svg('did_rating.svg')+svg('did_count.svg')
    body+=f"<p><strong>Ratings:</strong> ME vs Mediterranean is {number(rating.estimate)} stars (p = {pval(rating.p)}; Holm p = {pval(rating.p_holm)}). WPME vs ME is {number(wp.estimate)} stars (p = {pval(wp.p)}), with a confidence interval spanning a small penalty and a small benefit. This does not establish protection for WPME.</p>"
    body+='<p><strong>Review counts:</strong> ME and WPME both increase relative to Mediterranean under several choices about zero-review weeks. However, their count event studies reject the joint pre-trend null against Mediterranean. These are persistent statistical associations, not clean evidence of a travel-ban effect on demand. Counts measure reviews, not transactions or profit.</p>'
    body+='<h2 id="robustness">What holds up under alternative choices?</h2>'
    variants=['exclusive','duplicates_retained','two_sided_cohort','equal_restaurant_month',
              'narrow_ME','top5_cities','prekeyword_cohort_original_labels','preperiod_food']
    labels={'exclusive':'Main: stored food flags', 'duplicates_retained':'Keep exact duplicates',
            'two_sided_cohort':'Reviews on both sides', 'equal_restaurant_month':'Equal restaurant-month weight; January omitted',
            'narrow_ME':'ME limited to exact Middle Eastern category', 'top5_cities':'Top five address localities (exploratory)',
            'prekeyword_cohort_original_labels':'Pre-keyword cohort, original labels',
            'preperiod_food':'Pre-keyword cohort, pre-ban labels',
            'counts_observed_span':'Count weeks between first/last observed review',
            'counts_positive_only':'Positive-review weeks only (diagnostic)',
            'counts_all_restaurants':'All restaurants; fill full-window zero weeks'}
    pairs=['ME vs MED','WPME vs ME','WPME vs MED']
    def sens_table(outcome,variants):
        rows=[]
        for v in variants:
            cells=[escape(labels.get(v,v))]
            for pair in pairs:
                z=r[(r.variant==v)&(r.outcome==outcome)&(r.family=='DiD')&(r.comparison==pair)]
                cells.append('—' if z.empty else f"{number(z.iloc[0].estimate)}<br><small>p = {pval(z.iloc[0].p)}; Holm = {pval(z.iloc[0].p_holm)}</small>")
            rows.append(cells)
        return html_table(['Specification']+pairs,rows)
    body+='<h3>Rating estimates (stars)</h3>'+sens_table('rating',variants)
    body+=f"<p>The pre-ban food sensitivity uses only reviews dated July 1, 2016–January 26, 2017 and the historical Python keyword dictionary. It keeps businesses with at least one pre-ban hummus/baba mention in all groups. That leaves <strong>{a['preperiod_eligible_restaurants']:,} restaurants</strong> before model-specific filtering. The extra cohort-only row separates changing eligibility from changing labels. WPME vs ME becomes {number(prewp.estimate)} stars (p = {pval(prewp.p)}), so a positive WPME advantage does not emerge when later food evidence is removed.</p>"
    body+='<p>This is a sensitivity analysis within the saved, historically keyword-selected panel. It does not recover businesses excluded upstream or establish historical category order. “No pre-ban baba mention” means no observed evidence in that six-to-seven-month window; it does not prove the dish was absent.</p>'
    x=pd.read_csv(OUT/'classification_transition.csv')
    body+=html_table(['Stored group → pre-ban group','Excluded: no pre-food evidence','ME','Mediterranean','WPME'],[
        [z['group']]+[f"{int(z[c]):,}" for c in ['Excluded','ME','MED','WPME']] for _,z in x.iterrows() if z['group']!='Excluded'])
    body+='<h3>Review-count estimates (reviews per week)</h3>'+sens_table('count',[
        'exclusive','counts_observed_span','counts_positive_only','counts_all_restaurants',
        'narrow_ME','top5_cities','prekeyword_cohort_original_labels','preperiod_food'])
    body+='<p>The main count panel requires at least one observed review before and after the ban, uses complete Monday–Sunday weeks July 4, 2016–June 25, 2017, and omits January 23–29. All remaining 50 weeks are filled, including zero counts. An alternative retains only weeks between each business’s first and last observed review; another includes all observed businesses. These choices cannot substitute for verified operating dates, and the two-sided cohort conditions on post-ban observation.</p>'
    body+='<h3>Local politics and clustering</h3><p>GOP interactions include both post × GOP share and post × group × GOP share, with restaurant and time fixed effects. GOP share is centered at the unweighted restaurant mean within each pair. The reported interaction is the change in the group’s DiD for a 10-percentage-point increase in county Republican vote share.</p>'
    h=r[(r.variant.isin(['exclusive','preperiod_food']))&(r.family=='GOP_interaction')&(r.term=='did_gop')]
    body+=html_table(['Classification','Outcome','Comparison','GOP interaction per 10 pp','95% CI','p'],[
        [labels[z.variant],z.outcome,z.comparison,number(z.estimate),f'[{number(z.low)}, {number(z.high)}]',pval(z.p)] for z in h.itertuples()])
    body+='<p>None of these restaurant-clustered political interactions is statistically significant at 5%. County-clustered versions are exported as well. County models exclude records without a county identifier, so their samples differ slightly. County clustering provides a check on common local shocks, but cannot correct missing historical treatment or reviewer ideology.</p>'
    cl=r[(r.variant=='exclusive')&(r.family=='DiD_county_cluster')]
    body+=html_table(['Main comparison','Outcome','County-cluster estimate','p','Counties'],[
        [z.comparison,z.outcome,number(z.estimate),pval(z.p),z.counties] for z in cl.itertuples()])
    cities=', '.join(k.replace('_',' ') for k in a['top5_cities_by_eligible_restaurant_count'])
    body+=f"<p><strong>Locality subsample:</strong> {escape(cities)}. These are the five largest parsed address localities by eligible restaurant count, chosen without using post-ban rating changes. New York and Brooklyn are distinct address labels, not standardized municipalities. Ten eligible businesses lack a parsed locality. The original analysis’s unnamed top-five-city sample cannot be replicated exactly; this check is explicitly exploratory.</p>"
    body+='<h2 id="events">Event studies and pre-trend tests</h2><p>December 2016 is the entirely pre-ban reference month. January 2017 is omitted because it spans the shock. Each model jointly tests the five July–November 2016 group interactions. A large p-value means the test does not detect a difference; it does not prove parallel trends. Event studies use restaurant/time fixed effects and restaurant-clustered errors.</p>'
    body+=html_table(['Classification','Outcome','Comparison','Joint pre-trend p','Observations'],[
        [labels[z.variant],z.outcome,z.comparison,pval(z.pre_p),f'{z.n:,}'] for z in pre.itertuples()])
    body+=svg('event_rating.svg')+svg('event_count.svg')
    body+='<p>The count comparisons against Mediterranean fail the main joint pre-trend tests. Their significant post estimates therefore cannot be read as persuasive causal effects without addressing those earlier differences. The WPME–ME comparison has no clear main post-ban effect. Rating event studies show no joint pre-trend rejection in the main sample, but the sensitivity results still prevent a stable positioning claim.</p>'
    body+='<h2>Comparison with the saved old tables</h2><p>The old “Mediterranean” group included WPME. A diagnostic restores those old inclusive labels and duplicates: ME vs inclusive MED is '
    old=row('legacy_diagnostic','rating','ME vs MED_inclusive')
    oldwp=row('legacy_diagnostic','rating','ME vs WPME')
    body+=f"{number(old.estimate)} stars (p = {pval(old.p)}), close to the saved +0.022 (p = 0.0467). ME vs WPME is {number(oldwp.estimate)} (p = {pval(oldwp.p)}), close to saved +0.014 (p = 0.264). Small differences can reflect estimator and singleton handling. This is a diagnostic match, not proof of exact replication.</p>"
    body+='<p>With exclusive groups, the main ME–MED gap is larger because the comparison excludes WPME. The result does not support Mediterranean protection. The historical negative differences relative to American restaurants remain unverified: the available modern panel lacks the much larger American-control sample and generating code. Those old claims are neither confirmed nor disproved by this three-group rerun.</p>'
    body+='<h2 id="methods">Methods, scope and remaining limitations</h2><ul><li>Rating model: rating = restaurant FE + calendar-month FE + post × group. Unit: individual review, so frequent reviewers/businesses contribute more observations. Equal restaurant-month means excluding mixed January are a sensitivity.</li><li>Count model: weekly count = restaurant FE + calendar-week FE + post × group. This is OLS in levels; no percentage or sales interpretation is imposed.</li><li>Post starts January 27, 2017 inclusive, using UTC review_date. Singletons are removed by fixest. Cluster degrees of freedom use the number of clusters minus one, with fixest’s nonnested fixed-effect small-sample correction.</li><li>Primary groups reuse the 2025 20-category ME list and stored baba flags. This is an explicitly chosen operationalization, not independent confirmation that the first stored category was a business’s chosen pre-ban primary category.</li><li>No reviewer demographics, owner ethnicity, menu validation, operating dates or sales are supplied. The existing election merge is reused; its underlying geocoding and precinct totals are not rebuilt here.</li><li>The Google Reviews folder was inventoried. Its combined review CSV stores aggregated rating/count arrays, not individual review text. The cleaned rerun uses the modern saved review panel linked to that project. It does not reprocess every multi-gigabyte state archive.</li><li>Holm adjustment covers the three main pairwise contrasts separately by outcome, and the three political interactions within each outcome/classification. Other sensitivity and monthly event p-values are exploratory and not globally multiplicity-adjusted.</li></ul>'
    body+='<p>Estimator and small-sample-correction documentation: <a href="https://lrberge.github.io/fixest/reference/feols.html">fixest feols</a> and <a href="https://lrberge.github.io/fixest/reference/ssc.html">fixest ssc</a>. The exact settings used here are stated above and in the code.</p>'
    body+='<h2 id="files">Reproducible code and outputs</h2><p>Run '+source_link('run_all.ps1')+' from PowerShell. Source locations, dates, and the ME category list are in '+source_link('config.json')+'. Dependency installation is separate and local to this project: '+source_link('install_dependencies.R')+'.</p>'
    body+='<ul>'+''.join('<li>'+source_link(n,label)+'</li>' for n,label in [
        ('prepare_data.py','Data preparation and classification'),('run_models.R','All statistical models and plots'),
        ('verify_estimator.R','Independent estimator verification against explicit FE dummies and sandwich'),
        ('test_preparation.py','Focused classification and duplicate tests'),('README.md','Methods and rerun instructions')])+'</ul>'
    body+='<ul>'+''.join('<li>'+data_link(n,label)+'</li>' for n,label in [
        ('model_results.csv','All DiD, sensitivity and political interaction estimates'),
        ('event_study.csv','Monthly event-study coefficients'),('pretrend_tests.csv','Joint pre-trend tests'),
        ('restaurant_groups.csv','Business-level group assignments'),('descriptives.csv','Group descriptives'),
        ('classification_transition.csv','Stored-to-preperiod classification changes'),
        ('data_audit.json','Source hashes, sample accounting and configuration'),
        ('count_panel_audit.json','Zero-week and cohort accounting'),('fitted_models.rds','Saved fitted R models'),
        ('estimator_verification.txt','Independent numerical verification'),('R_sessionInfo.txt','R software environment'),
        ('R_package_versions.json','Package version record')])+'</ul>'
    body+='<p>Verification compared fixed-effect estimates and cluster covariance with an explicit-dummy regression and sandwich calculation on an unbalanced synthetic panel. Automated checks also verify exclusivity, review totals, confidence intervals, p-values, duplicate handling, source hashes, and output completeness. Results are reproducible conditional on these source files and the recorded software environment.</p>'
    style='''body{font:16px/1.6 system-ui,sans-serif;color:#24323b;max-width:1080px;margin:45px auto;padding:0 28px}h1{font-size:36px;line-height:1.2;color:#173f46}h2{font-size:25px;color:#173f46;margin-top:44px}h3{font-size:20px;margin-top:30px}.lead{font-size:20px;border-left:4px solid #317d86;padding-left:20px}.subtitle,small{color:#526772}nav{display:flex;gap:20px;flex-wrap:wrap;padding:16px;background:#edf4f5}a{color:#14637d;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:14px;margin:18px 0}th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #d8e2e5;vertical-align:top}th{background:#edf4f5}tr:nth-child(even){background:#fafcfc}.table-scroll{overflow-x:auto}.figure{margin:24px auto;max-width:960px}.figure svg{width:100%;height:auto}li{margin:10px 0}@media print{body{font-size:11px;margin:0}h2{break-after:avoid}tr{break-inside:avoid}nav{display:none}.figure{max-width:700px}table{font-size:10px}}'''
    (OUT/'results_report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Restaurant positioning: cleaned rerun</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    # Compact machine-readable headline estimates for downstream review.
    main.to_json(OUT/'primary_results.json',orient='records',indent=2)
    print('Created outputs/results_report.html')

if __name__=='__main__':
    main()
