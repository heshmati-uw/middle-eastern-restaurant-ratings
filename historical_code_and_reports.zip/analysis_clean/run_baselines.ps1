param([string]$Python = 'C:/Users/heshmati/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
      [switch]$UseCache)
$ErrorActionPreference = 'Stop'
& $Python "$PSScriptRoot/test_baseline_comparisons.py"
if ($LASTEXITCODE -ne 0) { throw 'Baseline tests failed' }
if ($UseCache) {
    & $Python "$PSScriptRoot/prepare_baseline_panel.py" --use-cache
} else {
    & $Python "$PSScriptRoot/prepare_baseline_panel.py"
}
if ($LASTEXITCODE -ne 0) { throw 'Baseline data preparation failed' }
& $Python "$PSScriptRoot/compare_baselines.py"
if ($LASTEXITCODE -ne 0) { throw 'Baseline comparison failed' }
& $Python "$PSScriptRoot/verify_baseline_outputs.py"
if ($LASTEXITCODE -ne 0) { throw 'Baseline output verification failed' }
