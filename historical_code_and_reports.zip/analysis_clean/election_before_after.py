"""Compare rating levels/changes before and after the election, excluding ban."""
from pathlib import Path
from html import escape
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'
SEED=20261026
POST_START='2016-11-09'
POST_END='2017-01-27'
PRE_END='2016-11-08'  # exclude election day from both periods
WINDOWS={'all_available_pre':'2016-07-01','equal_79_days':'2016-08-21'}


def compute(z,weighting):
    if weighting=='restaurant':
        units=z.groupby(['gmap_id','county_fips','trump_county','period'],as_index=False).rating.mean()
    else:
        units=z
    points=units.groupby(['trump_county','period']).rating.mean()
    # Counties are resampled jointly across periods, preserving within-county
    # dependence. Strata keep Trump-majority classification fixed.
    agg=units.groupby(['trump_county','county_fips','period']).rating.agg(['sum','count'])
    wide=agg.unstack('period',fill_value=0)
    rng=np.random.default_rng(SEED)
    draws=[]; changes=[]; output=[]
    for status in [False,True]:
        w=wide.loc[status]
        idx=rng.integers(0,len(w),size=(5000,len(w)))
        means=[]
        for period in ['pre','post']:
            sums=w[('sum',period)].to_numpy()[idx].sum(axis=1)
            ns=w[('count',period)].to_numpy()[idx].sum(axis=1)
            assert (ns>0).all()
            means.append(sums/ns)
        dist=means[1]-means[0]
        draws.append(dist)
        change=points[status,'post']-points[status,'pre']
        changes.append(change)
        sample=z[z.trump_county==status]
        lo,hi=np.quantile(dist,[.025,.975])
        output.append({'trump_majority':bool(status),'pre_mean':points[status,'pre'],
            'post_mean':points[status,'post'],'change':change,'change_low':lo,'change_high':hi,
            'pre_reviews':int(sample.period.eq('pre').sum()),'post_reviews':int(sample.period.eq('post').sum()),
            'pre_restaurants':sample[sample.period=='pre'].gmap_id.nunique(),
            'post_restaurants':sample[sample.period=='post'].gmap_id.nunique(),
            'counties':sample.county_fips.nunique()})
    lo,hi=np.quantile(draws[1]-draws[0],[.025,.975])
    return output,{'trump_minus_other_change':changes[1]-changes[0],
                   'gap_change_low':lo,'gap_change_high':hi,
                   'pre_gap':points[True,'pre']-points[False,'pre'],
                   'post_gap':points[True,'post']-points[False,'post']}


def main():
    d=pd.read_csv(OUT/'reviews_clean.csv',dtype={'county_fips':'string'})
    d=d[d.group.isin(['ME','MED','WPME']) & d.rating.notna() &
        d.gop_share.notna() & d.county_fips.notna()].copy()
    d['trump_county']=d.gop_share>.5
    assert d.groupby('gmap_id').trump_county.nunique().le(1).all()
    rows=[]; gaps=[]
    for window,start in WINDOWS.items():
        pre=(d.date>=start)&(d.date<PRE_END)
        post=(d.date>=POST_START)&(d.date<POST_END)
        sample=d[pre|post].copy()
        sample['period']=np.where(sample.date<PRE_END,'pre','post')
        assert not sample.date.eq(PRE_END).any()
        assert sample.date.lt(POST_END).all()
        common=sample.groupby('gmap_id').period.nunique().eq(2)
        common_ids=set(common[common].index)
        for cohort in ['all_reviewed','same_restaurants']:
            s=sample if cohort=='all_reviewed' else sample[sample.gmap_id.isin(common_ids)]
            for group,z in s.groupby('group'):
                if cohort=='same_restaurants':
                    assert z.groupby('gmap_id').period.nunique().eq(2).all()
                for weighting in ['review','restaurant']:
                    levels,gap=compute(z,weighting)
                    meta={'window':window,'pre_start':start,'pre_end_exclusive':PRE_END,
                          'post_start':POST_START,'post_end_exclusive':POST_END,
                          'cohort':cohort,'group':group,'weighting':weighting}
                    rows.extend([{**meta,**v} for v in levels])
                    gaps.append({**meta,**gap})
    levels=pd.DataFrame(rows); effects=pd.DataFrame(gaps)
    levels.to_csv(OUT/'election_before_after_levels.csv',index=False)
    effects.to_csv(OUT/'election_gap_changes.csv',index=False)
    assert len(levels)==48 and len(effects)==24
    assert (levels.change-(levels.post_mean-levels.pre_mean)).abs().max()<1e-12
    assert (effects.trump_minus_other_change-(effects.post_gap-effects.pre_gap)).abs().max()<1e-12
    prior=pd.read_csv(OUT/'post_election_group_averages.csv')
    current=levels[(levels.window=='all_available_pre')&(levels.cohort=='all_reviewed')&
                   (levels.weighting=='review')].merge(prior,on=['group','trump_majority'],validate='one_to_one')
    assert (current.post_mean-current.review_weighted_rating).abs().max()<1e-12
    def table(window,cohort,weighting):
        z=levels[(levels.window==window)&(levels.cohort==cohort)&(levels.weighting==weighting)]
        q=effects[(effects.window==window)&(effects.cohort==cohort)&(effects.weighting==weighting)]
        text='<table><tr><th>Group</th><th>County type</th><th>Before</th><th>After</th><th>Change</th><th>Restaurants before / after</th><th>Review counts before / after</th></tr>'
        for group in ['ME','MED','WPME']:
            for status in [True,False]:
                r=z[(z.group==group)&z.trump_majority.eq(status)].iloc[0]
                text+='<tr>'+''.join('<td>'+v+'</td>' for v in [group,'Trump-majority' if status else 'Other',
                    f'{r.pre_mean:.3f}',f'{r.post_mean:.3f}',f'{r.change:+.3f}',
                    f'{r.pre_restaurants:,} / {r.post_restaurants:,}',f'{r.pre_reviews:,} / {r.post_reviews:,}'])+'</tr>'
        text+='</table><p><strong>Change in the Trump-minus-other gap:</strong></p><ul>'
        for r in q.itertuples():
            text+=f'<li>{r.group}: {r.trump_minus_other_change:+.3f} stars; 95% county-bootstrap interval [{r.gap_change_low:+.3f}, {r.gap_change_high:+.3f}].</li>'
        return text+'</ul>'
    text='''<h1>Did ME restaurants in Trump counties lose ground after the election?</h1>
    <p>Election day (November 8, 2016) is excluded. The post period is November 9, 2016–January 26, 2017. The travel-ban date and everything after it are excluded. Trump-majority means over 50% Republican vote share in the supplied 2016 county election merge; other counties are at or below 50%.</p>
    <p>A <strong>negative change in the Trump-minus-other gap</strong> would mean restaurants in Trump-majority counties lost ground relative to restaurants in other counties. A positive number means the gap moved in their favor.</p>
    <p><strong>No clear evidence of lost ground:</strong> the review-weighted ME gap increases after the election. Holding the restaurant cohort fixed and weighting each restaurant equally, the gap is essentially unchanged; its county-bootstrap interval spans losses and gains. Equal-length windows lead to the same substantive conclusion. The tables below quantify these differences.</p>
    <h2>Average of reviews: all available pre-election observations</h2><p>Before: July 1–November 7, 2016. These are repeated cross-sectional means: the restaurants and review weights can change across periods.</p>'''
    text+=table('all_available_pre','all_reviewed','review')
    text+='<h2>Same restaurants; equal weight per restaurant</h2><p>Use only restaurants with at least one review in each period. Average each restaurant’s reviews separately before and after, then average restaurants equally. Before: July 1–November 7. This removes changing restaurant membership and review-volume weights, but reviewers can still change.</p>'
    text+=table('all_available_pre','same_restaurants','restaurant')
    text+='<h2>Equal-length windows; same restaurants; equal restaurant weight</h2><p>Before: August 21–November 7, 2016 (79 days). After: November 9, 2016–January 26, 2017 (79 days).</p>'
    text+=table('equal_79_days','same_restaurants','restaurant')
    text+='<h2>Interpretation and reproducibility</h2><p>These are unadjusted differences in average ratings, not a causal estimate of the election’s effect. Holding the restaurant cohort fixed does not control reviewer composition, local conditions or category-specific seasonality. The earlier mutually exclusive definitions and deduplication are retained. Missing county/share observations are excluded. The same-restaurants cohort conditions on post-election review availability.</p><p>Intervals use 5,000 county bootstrap resamples, jointly across periods and separately within Trump-majority/other strata, with seed 20261026. Intervals are exploratory and not adjusted across comparisons. Only the available keyword-selected review panel is analyzed.</p>'
    text+='<p><a href="election_before_after_levels.csv">All means and sample counts</a> · <a href="election_gap_changes.csv">All gap changes and intervals</a> · <a href="../election_before_after.py">Reproducible code</a></p>'
    html='<!doctype html><html lang="en"><meta charset="utf-8"><title>Before and after the election</title><style>body{font:16px/1.6 system-ui;max-width:1150px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2{color:#173f46}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:10px;border-bottom:1px solid #d8e2e5;text-align:left}th{background:#edf4f5}a{color:#14637d}li{margin:7px 0}</style><body>'+text+'</body></html>'
    (OUT/'election_before_after.html').write_text(html,encoding='utf-8')
    audit={'election_day_excluded':True,'ban_and_later_excluded':True,'bootstrap_replicates':5000,
           'seed':SEED,'windows':WINDOWS,'post_start':POST_START,'post_end_exclusive':POST_END,
           'level_rows':len(levels),'gap_rows':len(effects),'arithmetic_checks_passed':True}
    (OUT/'election_before_after_audit.json').write_text(json.dumps(audit,indent=2))
    print(levels[(levels.group=='ME') & ((levels.cohort=='same_restaurants') |
        ((levels.window=='all_available_pre')&(levels.weighting=='review')))].to_string(index=False))
    print(effects[effects.group=='ME'].to_string(index=False))

if __name__=='__main__':
    main()
