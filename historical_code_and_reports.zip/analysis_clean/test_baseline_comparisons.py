"""Independent hand-specified change contrast and resampling check."""
import unittest
import pandas as pd
from compare_baselines import compare_pair

class BaselineTests(unittest.TestCase):
    def test_constant_known_relative_change(self):
        rows=[]
        for county in ['a','b','c','d']:
            for group in ['ME','American']:
                for period in ['pre','post']:
                    rating=4.0+(0.05 if group=='ME' else 0.10)*(period=='post')
                    rows.append({'gmap_id':county+group,'county_fips':county,'group':group,
                                 'period':period,'score_sum':rating,'weight':1.0})
        r=compare_pair(pd.DataFrame(rows),'American',['American'],'same_restaurants','restaurant')
        self.assertAlmostEqual(r['relative_change'],-.05)
        self.assertAlmostEqual(r['low'],-.05)
        self.assertAlmostEqual(r['high'],-.05)
        self.assertEqual(r['ME_pre_restaurants'],4)

    def test_reject_focal_group_as_its_own_baseline(self):
        with self.assertRaises(AssertionError):
            compare_pair(pd.DataFrame(),'bad',['ME'],'all_reviewed','review')

    def test_restaurant_weights_do_not_depend_on_review_volume(self):
        rows=[]
        for county,rating,n in [('a',5,100),('b',1,1)]:
            for group in ['ME','American']:
                for period in ['pre','post']:
                    score=rating if group=='ME' else 4
                    rows.append({'gmap_id':county+group,'county_fips':county,'group':group,
                                 'period':period,'score_sum':score*n,'weight':n})
        data=pd.DataFrame(rows)
        eq=compare_pair(data,'American',['American'],'same_restaurants','restaurant')
        rw=compare_pair(data,'American',['American'],'same_restaurants','review')
        self.assertAlmostEqual(eq['ME_pre'],3.0)
        self.assertAlmostEqual(rw['ME_pre'],501/101)

if __name__=='__main__':unittest.main()
