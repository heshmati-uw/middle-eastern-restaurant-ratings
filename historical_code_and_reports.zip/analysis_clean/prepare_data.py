"""Build analysis inputs without changing Dropbox sources. Run from any directory."""
from pathlib import Path
import hashlib
import json
import platform
import re
import pandas as pd
import numpy as np

HERE = Path(__file__).resolve().parent
OUT = HERE / 'outputs'
OUT.mkdir(exist_ok=True)
CFG = json.loads((HERE / 'config.json').read_text())
ROOT = Path(CFG['source_root'])
# Reuse the 2025 Python pipeline's dictionary and punctuation normalization.
# Keeping the dictionary fixed isolates the timing change in preperiod_food.
HUMMUS = r'\b(?:hummus|hummous|hommous|houmous|humus)\b'
BABA = (r'\b(?:baba ghanoush|baba ganoush|baba ghanouj|baba ghannouj|'
        r'baba ghannouge|baba gahnouge|baba ghannooj|baba ghanooj|'
        r'baba ganuj|baba gahnooj|baba ghanoug|baba ghannuj|baba ghannuge|'
        r'baba ghannoj|baba ghannouch|baba ganouj|babagannouji|babaghanouj)\b')


def classify(primary, baba, me_categories):
    """First category determines position; WPME and MED partition Mediterranean."""
    primary = primary.fillna('').str.strip().str.casefold()
    me = primary.isin({c.casefold() for c in me_categories})
    med = primary.str.contains('mediterranean', regex=False)
    assert not (me & med).any()
    return pd.Series(np.select([me, med & baba.eq(1), med & baba.eq(0)],
                               ['ME', 'WPME', 'MED'], default='Excluded'),
                     index=primary.index)


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    panel_path = ROOT / CFG['review_panel']
    master_path = ROOT / CFG['restaurant_master']
    print('Loading saved review panel...', flush=True)
    raw = pd.read_csv(panel_path, dtype={'county_fips': 'string'}, low_memory=False)
    master = pd.read_csv(master_path, low_memory=False)
    assert master.gmap_id.is_unique
    required = ['gmap_id', 'review_date', 'rating', 'text', 'name', 'category',
                'review_baba', 'state', 'address', 'county_fips',
                'republican_vote_share_2016']
    assert set(required).issubset(raw)
    for col in ['category', 'review_baba', 'county_fips', 'republican_vote_share_2016']:
        assert raw.groupby('gmap_id')[col].nunique(dropna=False).max() == 1, col
    # Confirm that classification information agrees with the restaurant master.
    attrs = raw.drop_duplicates('gmap_id').merge(
        master[['gmap_id', 'category', 'review_baba']], on='gmap_id',
        how='left', validate='one_to_one', suffixes=('', '_master'), indicator=True)
    assert attrs['_merge'].eq('both').all()
    for col in ['category', 'review_baba']:
        assert attrs[col].fillna('').eq(attrs[col + '_master'].fillna('')).all()
    raw['date'] = pd.to_datetime(raw.review_date, utc=True, errors='coerce').dt.strftime('%Y-%m-%d')
    assert raw.date.notna().all()
    assert ((raw.date >= CFG['window_start']) & (raw.date < CFG['window_end_exclusive'])).all()
    raw['rating'] = pd.to_numeric(raw.rating, errors='coerce')
    assert raw.rating.dropna().between(1, 5).all()
    raw['group'] = classify(raw.category, raw.review_baba, CFG['me_categories'])
    # Deduplicate complete review signatures, not just dates or rating values.
    signature = ['gmap_id', 'review_date', 'name', 'text', 'rating']
    dup = raw.duplicated(signature, keep='first')
    clean = raw.loc[~dup].copy()
    # Pre-period mentions are recomputed from text, never from restaurant flags.
    lower = clean.text.fillna('').str.casefold().str.replace(r'[^\w\s]', '', regex=True)
    clean['pre_baba'] = ((clean.date < CFG['shock_date']) & lower.str.contains(BABA, regex=True)).astype(int)
    clean['pre_food'] = ((clean.date < CFG['shock_date']) &
                         (lower.str.contains(HUMMUS, regex=True) | lower.str.contains(BABA, regex=True))).astype(int)
    pre = clean.groupby('gmap_id')[['pre_baba', 'pre_food']].max()
    clean = clean.join(pre.rename(columns={'pre_baba':'business_pre_baba', 'pre_food':'business_pre_food'}), on='gmap_id')
    clean['group_pre'] = classify(clean.category, clean.business_pre_baba, CFG['me_categories'])
    clean.loc[clean.business_pre_food.ne(1), 'group_pre'] = 'Excluded'
    clean['group_narrow'] = clean['group']
    clean.loc[(clean.group == 'ME') & clean.category.ne('Middle Eastern restaurant'), 'group_narrow'] = 'Excluded'
    primary = clean.drop_duplicates('gmap_id').copy()
    city = primary.address.str.extract(r',\s*([^,]+),\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?\b', expand=False)
    primary['city'] = city.str.strip().str.title()
    primary['city_key'] = primary['city'].fillna('') + ', ' + primary.state.fillna('')
    eligible = primary.loc[primary.group.ne('Excluded') & primary.city.notna()]
    top5 = eligible.groupby('city_key').size().sort_values(ascending=False).head(5)
    top_ids = set(primary.loc[primary.city_key.isin(top5.index), 'gmap_id'])
    clean['top5'] = clean.gmap_id.isin(top_ids).astype(int)
    raw['top5'] = raw.gmap_id.isin(top_ids).astype(int)
    clean['gop_share'] = clean.republican_vote_share_2016
    raw['gop_share'] = raw.republican_vote_share_2016
    # Never replace unavailable GOP shares with zero, or infer a county from votes.
    assert clean.gop_share.dropna().between(0, 1).all()
    clean['month'] = clean.date.str[:7]
    clean['post'] = (clean.date >= CFG['shock_date']).astype(int)
    raw['month'] = raw.date.str[:7]
    raw['post'] = (raw.date >= CFG['shock_date']).astype(int)
    keep = ['gmap_id','date','month','rating','group','group_pre','group_narrow',
            'post','gop_share','county_fips','top5']
    clean[keep].to_csv(OUT / 'reviews_clean.csv', index=False)
    raw[[c for c in keep if c in raw]].to_csv(OUT / 'reviews_with_duplicates.csv', index=False)
    # Include only business metadata in the classification export; omit reviewer data.
    primary[['gmap_id','business_name','state','category','review_baba','group',
             'business_pre_baba','business_pre_food','group_pre','group_narrow',
             'city_key']].to_csv(OUT / 'restaurant_groups.csv', index=False)
    mapping = pd.crosstab(primary.group, primary.group_pre).reset_index()
    mapping.to_csv(OUT / 'classification_transition.csv', index=False)
    d = clean.loc[clean.group.ne('Excluded')]
    desc = d.groupby('group').agg(reviews=('gmap_id','size'), restaurants=('gmap_id','nunique'),
                                 ratings=('rating','count'), mean_rating=('rating','mean'))
    desc.to_csv(OUT / 'descriptives.csv')
    flow = {'input_rows':len(raw),'input_restaurants':raw.gmap_id.nunique(),
            'exact_duplicate_rows_removed':int(dup.sum()),'clean_rows':len(clean),
            'missing_ratings':int(clean.rating.isna().sum()),
            'eligible_reviews':len(d),'eligible_restaurants':d.gmap_id.nunique(),
            'excluded_reviews':int(clean.group.eq('Excluded').sum()),
            'preperiod_eligible_reviews':int(clean.group_pre.ne('Excluded').sum()),
            'preperiod_eligible_restaurants':int(clean.loc[clean.group_pre.ne('Excluded'),'gmap_id'].nunique()),
            'groups':desc.reset_index().to_dict('records'),
            'top5_cities_by_eligible_restaurant_count':top5.to_dict(),
            'city_parse_missing_eligible_businesses':int((primary.group.ne('Excluded') & primary.city.isna()).sum()),
            'duplicate_definition':signature,
            'classification_crosswalk':mapping.to_dict('records'),
            'regex':{'hummus':HUMMUS,'baba':BABA},
            'sources':{str(p):{'bytes':p.stat().st_size,'sha256':sha256(p)} for p in [panel_path,master_path]},
            'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,
            'config':CFG}
    (OUT / 'data_audit.json').write_text(json.dumps(flow,indent=2,default=lambda x:int(x)),encoding='utf-8')
    print(json.dumps({k:flow[k] for k in ['input_rows','exact_duplicate_rows_removed','eligible_reviews','eligible_restaurants','groups','preperiod_eligible_restaurants']},indent=2),flush=True)


if __name__ == '__main__':
    main()
