"""Descriptive rating differences after the 2016 election and before the ban."""
from pathlib import Path
import json
from html import escape
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'
START='2016-11-09'  # first full day after election day, UTC
END='2017-01-27'    # exclude the travel-ban date
SEED=20261026


def clustered_gap(df,weighting,draws=5000):
    """Percentile bootstrap: resample counties within majority-status strata.

    For restaurant weighting, first average all eligible reviews per restaurant.
    County sums/counts retain the chosen weights in each bootstrap replication.
    """
    if weighting=='restaurant':
        units=df.groupby(['gmap_id','county_fips','trump_county'],as_index=False).rating.mean()
    else:
        units=df[['county_fips','trump_county','rating']]
    agg=units.groupby(['trump_county','county_fips']).rating.agg(['sum','count']).reset_index()
    rng=np.random.default_rng(SEED)
    means=[]
    for status in [False,True]:
        z=agg[agg.trump_county==status]
        sums=z['sum'].to_numpy(); ns=z['count'].to_numpy()
        if len(z)<2:
            return [None,None]
        indices=rng.integers(0,len(z),size=(draws,len(z)))
        means.append(sums[indices].sum(axis=1)/ns[indices].sum(axis=1))
    return np.quantile(means[1]-means[0],[.025,.975]).tolist()


def main():
    d=pd.read_csv(OUT/'reviews_clean.csv',dtype={'county_fips':'string'})
    eligible=d[d.group.isin(['ME','MED','WPME']) & d.rating.notna()].copy()
    period=eligible[(eligible.date>=START)&(eligible.date<END)].copy()
    missing=period.gop_share.isna() | period.county_fips.isna()
    # Require both county and share so the geographic grouping is auditable.
    n_missing=int(missing.sum())
    period=period[~missing].copy()
    period['trump_county']=period.gop_share>.5
    assert period.groupby('gmap_id').trump_county.nunique().le(1).all()
    assert period.groupby('county_fips').trump_county.nunique().le(1).all()
    rows=[]; gaps=[]
    for group,z in period.groupby('group'):
        for status,s in z.groupby('trump_county'):
            rows.append({'group':group,'trump_majority':bool(status),
                'reviews':len(s),'restaurants':s.gmap_id.nunique(),
                'counties':s.county_fips.nunique(),'review_weighted_rating':s.rating.mean(),
                'restaurant_weighted_rating':s.groupby('gmap_id').rating.mean().mean()})
        for weighting in ['review','restaurant']:
            if weighting=='restaurant':
                units=z.groupby(['gmap_id','trump_county'],as_index=False).rating.mean()
            else:
                units=z
            avg=units.groupby('trump_county').rating.mean()
            ci=clustered_gap(z,weighting)
            gaps.append({'group':group,'weighting':weighting,
                'trump_minus_other':avg[True]-avg[False],
                'county_bootstrap_low':ci[0],'county_bootstrap_high':ci[1]})
    summary=pd.DataFrame(rows)
    gap=pd.DataFrame(gaps)
    summary.to_csv(OUT/'post_election_group_averages.csv',index=False)
    gap.to_csv(OUT/'post_election_county_gaps.csv',index=False)
    # Simple pre-election context uses the same status definition, not a DiD.
    pre=eligible[(eligible.date>='2016-07-01')&(eligible.date<'2016-11-09') &
                 eligible.gop_share.notna() & eligible.county_fips.notna()].copy()
    pre['trump_county']=pre.gop_share>.5
    context=pre.groupby(['group','trump_county']).agg(mean_rating=('rating','mean'),reviews=('rating','size'))
    context.to_csv(OUT/'pre_election_descriptive_context.csv')
    meta={'start_inclusive':START,'end_exclusive':END,'timezone':'UTC',
          'definition':'County Republican vote share > 0.50 in supplied 2016 presidential election merge',
          'missing_geography_review_rows_excluded':n_missing,
          'bootstrap':'5000 county resamples, separately within majority-status strata; percentile 95% CI',
          'seed':SEED,'summary':rows,'gaps':gaps}
    (OUT/'post_election_averages.json').write_text(json.dumps(meta,indent=2,default=lambda x:int(x)))
    headers=['Group','Trump-majority average','Other-county average','Difference','Reviews (Trump / other)','Restaurants (Trump / other)']
    def table(weighting):
        col=weighting+'_weighted_rating'
        result='<table><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr>'
        for group in ['ME','MED','WPME']:
            t=summary[(summary.group==group)&summary.trump_majority].iloc[0]
            o=summary[(summary.group==group)&~summary.trump_majority].iloc[0]
            result+='<tr>'+''.join('<td>'+c+'</td>' for c in [group,f'{t[col]:.3f}',f'{o[col]:.3f}',
                f'{t[col]-o[col]:+.3f}',f'{t.reviews:,} / {o.reviews:,}',f'{t.restaurants:,} / {o.restaurants:,}'])+'</tr>'
        return result+'</table>'
    text='''<h1>Average ratings after the election, before the ban</h1>
    <p>November 9, 2016–January 26, 2017, inclusive. Trump-majority means more than 50% Republican vote share in the supplied county-level 2016 presidential election data. Other counties include every county at or below 50%; this is not necessarily a county-winner definition in plurality elections.</p>
    <h2>Each review has equal weight</h2>'''+table('review')+'''
    <h2>Each restaurant has equal weight</h2><p>First average each restaurant’s reviews within this period, then average across restaurants in each county group. No weighting by its number of reviews.</p>'''+table('restaurant')
    text+='<h2>Uncertainty in the Trump-minus-other gap</h2><p>95% percentile bootstrap intervals from 5,000 county resamples, separately within the two county-status strata. These reflect within-sample uncertainty; they do not correct nonrandom restaurant/reviewer selection or measurement errors. They are exploratory and not adjusted across groups.</p><table><tr><th>Group</th><th>Weighting</th><th>Gap</th><th>95% county-bootstrap interval</th></tr>'
    for z in gaps:
        text+=f"<tr><td>{z['group']}</td><td>{z['weighting']}</td><td>{z['trump_minus_other']:+.3f}</td><td>[{z['county_bootstrap_low']:+.3f}, {z['county_bootstrap_high']:+.3f}]</td></tr>"
    text+='</table><p>These are differences in average rating levels during the specified period, not effects of Trump’s election. All three groups use the mutually exclusive stored-category/food-flag definition from the cleaned rerun, with exact duplicate reviews removed. Review text and owner identity are not used as evidence of political affiliation.</p>'
    text+=f'<p>Excluded {n_missing} eligible review rows with missing county or vote share. The source panel is historically keyword-selected; category order and historical timing remain unvalidated.</p>'
    text+='<p>Files: <a href="post_election_group_averages.csv">Group averages</a> · <a href="post_election_county_gaps.csv">Differences and intervals</a> · <a href="post_election_averages.json">Definitions and audit</a> · <a href="../post_election_averages.py">Reproducible code</a></p>'
    html='<!doctype html><html lang="en"><meta charset="utf-8"><title>Post-election average ratings</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2{color:#173f46}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:12px;border-bottom:1px solid #d8e2e5}th{background:#edf4f5}a{color:#14637d}</style><body>'+text+'</body></html>'
    (OUT/'post_election_averages.html').write_text(html,encoding='utf-8')
    assert summary.reviews.sum()==len(period)
    assert len(summary)==6 and len(gap)==6
    print(summary.to_string(index=False)); print(gap.to_string(index=False))

if __name__=='__main__':
    main()
