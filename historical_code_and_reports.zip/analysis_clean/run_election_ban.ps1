param([string]$Python = 'C:/Users/heshmati/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
      [string]$Rscript = 'C:/Program Files/R/R-4.5.0/bin/Rscript.exe')
$ErrorActionPreference='Stop'
& $Python "$PSScriptRoot/prepare_shock_data.py"
if($LASTEXITCODE -ne 0) { throw 'Shock data preparation failed' }
& $Rscript --vanilla "$PSScriptRoot/election_ban_models.R"
if($LASTEXITCODE -ne 0) { throw 'Shock models failed' }
& $Python "$PSScriptRoot/report_election_ban.py"
if($LASTEXITCODE -ne 0) { throw 'Shock verification/report failed' }
& $Python "$PSScriptRoot/report_short_window.py"
if($LASTEXITCODE -ne 0) { throw 'Working-window report failed' }
