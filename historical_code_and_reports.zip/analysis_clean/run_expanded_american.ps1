param([string]$Python = 'C:/Users/heshmati/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
      [switch]$UseExistingExtraction)
$ErrorActionPreference='Stop'
function Run-Step([string]$Script) {
    & $Python "$PSScriptRoot/$Script"
    if($LASTEXITCODE -ne 0) { throw "Failed: $Script" }
}
Run-Step 'test_baseline_comparisons.py'
if(-not $UseExistingExtraction) {
    Run-Step 'audit_me_sample.py'
    Run-Step 'audit_legacy_me_ids.py'
}
Run-Step 'check_expanded_source.py'
Run-Step 'expanded_american_comparison.py'
Run-Step 'verify_expanded_american.py'
