"""Check exact/canonical ID and name coverage before date/category selection."""
from pathlib import Path
import json,re
import pandas as pd
HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'
CFG=json.loads((HERE/'config.json').read_text());ROOT=Path(CFG['source_root'])

def normalize_name(x):return re.sub('[^a-z0-9]','',str(x).lower())
def canonical(x):
    try:return ':'.join(hex(int(s,16)) for s in str(x).split(':'))
    except ValueError:return str(x)

def main():
    target=pd.read_csv(OUT/'ME_sample_attrition_by_restaurant.csv')
    ids=set(target.gmap_id);canon={canonical(x):x for x in ids}
    names=set(target.business_name.map(normalize_name))
    exact=[]; alternatives=[];n=0
    source=ROOT/'analysis/panel_restaurants_sample.dta'
    cols=['gmap_id','location_name','category','city','region','latitude','longitude','week_start_mr']
    for chunk in pd.read_stata(source,columns=cols,chunksize=250000,convert_categoricals=False):
        n+=len(chunk)
        x=chunk[chunk.gmap_id.isin(ids)]
        if len(x):exact.append(x)
        b=chunk.drop_duplicates('gmap_id').copy()
        b['canonical_match']=b.gmap_id.map(canonical).map(canon)
        b['name_match']=b.location_name.map(normalize_name).isin(names)
        b=b[(b.canonical_match.notna()|b.name_match)&~b.gmap_id.isin(ids)]
        if len(b):alternatives.append(b)
        print('Scanned',n,'rows; exact target IDs',pd.concat(exact).gmap_id.nunique() if exact else 0,flush=True)
    e=pd.concat(exact,ignore_index=True).drop_duplicates()
    a=pd.concat(alternatives,ignore_index=True).drop_duplicates('gmap_id') if alternatives else pd.DataFrame()
    e.to_csv(OUT/'legacy_ME_exact_id_records.csv',index=False)
    a.to_csv(OUT/'legacy_ME_possible_name_or_id_matches.csv',index=False)
    # Read the latest audit before adding fields; another independent extraction
    # may have added source-coverage columns while this scan was running.
    latest=pd.read_csv(OUT/'ME_sample_attrition_by_restaurant.csv')
    latest['id_present_anywhere_in_legacy_sample']=latest.gmap_id.isin(e.gmap_id)
    latest.to_csv(OUT/'ME_sample_attrition_by_restaurant.csv',index=False)
    s={'target_restaurants':len(target),'source_rows_scanned':n,'exact_ids_present_any_date':e.gmap_id.nunique(),
       'canonical_only_ID_matches':int(a.canonical_match.notna().sum()) if len(a) else 0,
       'alternative_name_matches':len(a),'unique_historical_categories_for_targets':e.category.value_counts().to_dict()}
    (OUT/'legacy_ME_id_audit.json').write_text(json.dumps(s,indent=2,default=lambda x:int(x)))
    print(json.dumps(s,indent=2),flush=True)

if __name__=='__main__':main()
