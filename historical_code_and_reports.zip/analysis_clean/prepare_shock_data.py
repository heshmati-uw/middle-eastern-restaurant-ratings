"""Rebuild event-window weekly outcomes from previously extracted full arrays."""
from pathlib import Path
import ast,json
import pandas as pd
HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'

def main():
    c=pd.read_csv(OUT/'expanded_american_candidates.csv',dtype={'county_fips':'string'})
    c=c[c.group.isin(['ME','WPME','American'])]
    assert c.gmap_id.is_unique and c.gop_share.gt(.5).all()
    records=pd.read_pickle(OUT/'expanded_american_source_records.pkl')
    records=records[records.gmap_id.isin(c.gmap_id)]
    rows=[]
    for ident,dates,ratings,counts in records.itertuples(index=False,name=None):
        dates,ratings,counts=map(ast.literal_eval,[dates,ratings,counts])
        assert len(dates)==len(ratings)==len(counts)
        for day,rating,count in zip(dates,ratings,counts):
            if '2016-07-04'<=day<='2017-04-03':
                rows.append((ident,day,float(rating),float(count)))
    w=pd.DataFrame(rows,columns=['gmap_id','week','rating','reviews'])
    before=len(w);w=w.drop_duplicates()
    conflicts=w[w.duplicated(['gmap_id','week'],keep=False)]
    assert conflicts.empty,'Resolve conflicting source records before analysis'
    w=w[w.rating.between(1,5)&w.reviews.gt(0)].merge(c,on='gmap_id',validate='many_to_one')
    assert pd.to_datetime(w.week).dt.dayofweek.eq(0).all()
    w.to_csv(OUT/'election_ban_common_weekly.csv',index=False)
    audit={'candidate_businesses_by_group':c.groupby('group').size().to_dict(),
           'weekly_rows':len(w),'exact_duplicates_removed':before-len(w),
           'conflicting_week_records':len(conflicts),'scope':'Trump-majority counties',
           'outcome_source':'Full date/rating/count arrays extracted from Reviews_Data_Combined.csv',
           'individual_review_signature_deduplication_available':False}
    (OUT/'shock_data_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))

if __name__=='__main__':main()
