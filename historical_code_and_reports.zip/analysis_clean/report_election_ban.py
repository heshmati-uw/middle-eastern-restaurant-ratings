"""Report coherent p-values/intervals and all prespecified shock windows."""
from pathlib import Path
from html import escape
from html.parser import HTMLParser
import json
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'

def fmt(x):return '<0.001' if x<.001 else f'{x:.3f}'
def main():
    r=pd.read_csv(OUT/'election_ban_results.csv')
    desc=pd.read_csv(OUT/'election_ban_descriptives.csv')
    q=pd.read_csv(OUT/'election_ban_restaurant_changes.csv',dtype={'county_fips':'string'})
    w=pd.read_csv(OUT/'election_ban_common_weekly.csv',dtype={'county_fips':'string'})
    original=r[r.shock.eq('Original election comparison')].iloc[0]
    previous=pd.read_csv(OUT/'expanded_american_comparison.csv')
    previous=previous[previous.window.eq('all_available_pre')&previous.ME_sample.eq('larger_ME_sample')&previous.baseline.eq('American')].iloc[0]
    assert abs(original.estimate-previous.relative_change)<1e-12
    # Independent matrix OLS and county sandwich check for all exported models.
    errors=[]
    for z in r.itertuples():
        if z.shock=='Original election comparison':
            ids=pd.read_csv(OUT/'ME_sample_attrition_by_restaurant.csv').gmap_id
            x=w[(~w.group.eq('ME')|w.gmap_id.isin(ids)) &
                (((w.week>=z.pre_start)&(w.week<=z.pre_last_week_start))|
                 ((w.week>=z.post_start)&(w.week<=z.post_last_week_start)))].copy()
            x['period']=np.where(x.week<=z.pre_last_week_start,'pre','post')
            x['score_sum']=x.rating*x.reviews
            b=x.groupby(['gmap_id','group','county_fips','period'])[['score_sum','reviews']].sum()
            b['mean']=b.score_sum/b.reviews
            b=b['mean'].unstack('period').dropna().reset_index()
            b['change']=b.post-b.pre
        else:
            b=q[q.shock.eq(z.shock)&q.window_weeks.eq(z.weeks)].copy()
        treated,control=z.comparison.split(' vs ')
        b=b[b.group.isin([treated,control])]
        X=np.column_stack([np.ones(len(b)),b.group.eq(treated).astype(float)])
        y=b.change.to_numpy()
        inv=np.linalg.inv(X.T@X);coef=inv@X.T@y
        residual=y-X@coef
        code=pd.factorize(b.county_fips)[0];G=int(code.max()+1);N=len(b)
        score=np.zeros((G,2));np.add.at(score,code,X*residual[:,None])
        vcov=inv@score.T@score@inv*(G/(G-1))*((N-1)/(N-2))
        se=np.sqrt(vcov[1,1])
        assert abs(coef[1]-z.estimate)<1e-10
        assert abs(se-z.se)<1e-10
        assert len(b)==z.restaurants and G==z.counties
        errors.append({'comparison':z.comparison,'shock':z.shock,'weeks':z.weeks,
                       'coef_error':abs(coef[1]-z.estimate),'se_error':abs(se-z.se)})
    checks={'models_checked':len(errors),'equal_restaurant_point_estimates_verified':True,
            'county_cluster_sandwich_verified':True,'max_coefficient_error':max(e['coef_error'] for e in errors),
            'max_se_error':max(e['se_error'] for e in errors),
            'p_values_verified_against_cluster_t_distribution_in_R':True}
    def table(data):
        headers=['Shock','Weeks each side','Comparison','Relative change (stars)','95% CI','p','Holm p within three comparisons','Treated / control restaurants']
        s='<table><tr>'+''.join('<th>'+h+'</th>' for h in headers)+'</tr>'
        for a in data.itertuples():
            cells=[a.shock,str(int(a.weeks)),a.comparison,f'{a.estimate:+.3f}',f'[{a.low:+.3f}, {a.high:+.3f}]',
                   fmt(a.p),fmt(a.p_holm_three_within_shock),f'{a.treated_restaurants:,} / {a.control_restaurants:,}']
            s+='<tr>'+''.join('<td>'+escape(c)+'</td>' for c in cells)+'</tr>'
        return '<div class="scroll">'+s+'</table></div>'
    body='<h1>Election and travel-ban comparisons: ME, WPME and American restaurants</h1>'
    body+=f'<p><strong>The previously reported ME–American election difference of {original.estimate:+.3f} stars has p = {fmt(original.p)}</strong> using a two-sided county-clustered t test. Its matching 95% confidence interval is [{original.low:+.3f}, {original.high:+.3f}]. This is the original unequal-length pre/post window and the original 134 ME versus 4,053 American restaurants.</p>'
    body+='''<p>The earlier report gave a percentile county-bootstrap interval. A skewed percentile bootstrap interval and a symmetric clustered-t test need not agree at the 5% threshold. The p-values and intervals in this report use one consistent clustered-t method; they are not p-values inferred from the earlier bootstrap endpoints.</p>
    <p><strong>Main finding:</strong> in equal ten-week windows, none of ME versus American, WPME versus American, or WPME versus ME is statistically clear for either shock. Shorter election windows produce a stronger ME–American contrast, but the result is sensitive to the window/cohort and to accounting for all the comparisons examined.</p>
    <h2>Equal restaurant weights, throughout</h2>
    <p>Each restaurant has one before-period rating mean and one after-period rating mean. Reviews are averaged within the restaurant-period using their weekly counts; all restaurant changes then receive equal weight. The same restaurant must be observed in both periods. No business receives extra cross-restaurant weight because it has more reviews.</p>
    <p>Every comparison is restricted to Trump-majority counties (2016 Republican vote share greater than 50%). Outcomes for all groups are rebuilt from the same original combined weekly source. Primary American means the exact American restaurant category; New/Traditional American categories are not pooled here. WPME is the existing Mediterranean-first plus baba-mention proxy.</p>
    <h2>Primary equal-ten-week comparisons</h2>
    <p><strong>Election:</strong> before August 29–November 6, 2016; after November 14, 2016–January 22, 2017. The election week and ban week are excluded.</p>
    <p><strong>Ban:</strong> before November 14, 2016–January 22, 2017; after January 30–April 9, 2017. Both periods are after the election, so this compares the additional post-ban change against a post-election baseline. The ban week is excluded.</p>
    <p>A negative ME–American estimate means ME lost ground relative to American. A positive WPME–ME estimate means WPME improved relative to ME. These are group differences in average rating changes, not absolute rating gaps.</p>'''
    body+=table(r[r.primary])
    body+='<h3>Average levels and restaurant counts in the main windows</h3><table><tr><th>Shock</th><th>Group</th><th>Restaurants</th><th>Before</th><th>After</th><th>Change</th></tr>'
    for a in desc[desc.weeks.eq(10)].itertuples():
        body+=f'<tr><td>{a.shock}</td><td>{a.group}</td><td>{a.restaurants:,}</td><td>{a.pre:.3f}</td><td>{a.post:.3f}</td><td>{a.change:+.3f}</td></tr>'
    body+='</table><h2>Shorter-window sensitivities</h2>'
    body+=table(r[r.shock.ne('Original election comparison')&~r.primary])
    four=r[r.shock.eq('Election')&r.weeks.eq(4)&r.comparison.eq('ME vs American')].iloc[0]
    body+=f'<p>The four-week election ME–American contrast is {four.estimate:+.3f} stars (p = {fmt(four.p)}; Holm p across its three comparisons = {fmt(four.p_holm_three_within_shock)}). After adjusting across all 18 shock/window/comparison tests, its Holm p is {fmt(four.p_holm_all_eighteen)}. Changing windows also changes which restaurants have observations on both sides; this is not a pure time-horizon comparison on an identical cohort.</p>'
    body+='''<h2>Inference and limits</h2>
    <p>The outcome for regression is each restaurant’s after-minus-before rating change. Pairwise OLS regresses that change on a group indicator and an intercept, with standard errors clustered by county and the small-sample correction G/(G−1) × (N−1)/(N−2). Two-sided p-values and intervals use a t distribution with the county-cluster count minus one degrees of freedom. The reported point estimate is exactly the difference between equally weighted group mean changes.</p>
    <p>The six primary tests have a separate Holm adjustment across both shocks; their adjusted p-values range from 0.871 to 1.000. Within-shock three-comparison and all-18 sensitivity-family adjustments are also exported. The original historical comparison is reported separately. The windows and three comparisons were saved in the specification file before the shock models were fitted.</p>
    <p>Each shock/window uses the full available ME, WPME and American candidate pools, with a balanced before/after cohort for that window. The original p-value alone reproduces the earlier 135-ID target universe. Categories and food proxies remain historically unvalidated; the candidate universe is selected. Aggregate-only American data cannot be deduplicated at the individual review-signature level, so source aggregates are used consistently for every group.</p>
    <p>These are unadjusted group-change comparisons within Trump-majority counties. They do not identify the election/ban’s causal effect or establish discrimination. Reviewer composition, category-specific seasonality and local conditions may differ across groups. No parallel-trend guarantee is implied.</p>
    <h2>Files and reproducibility</h2><ul>
    <li><a href="election_ban_results.csv">All 19 estimates, p-values, intervals and adjustments</a></li>
    <li><a href="election_ban_descriptives.csv">Group averages and sample counts</a></li>
    <li><a href="election_ban_restaurant_changes.csv">Restaurant-period means and changes</a></li>
    <li><a href="election_ban_models.rds">Fitted models</a></li>
    <li><a href="../shock_specifications.json">Window, group and inference specifications</a></li>
    <li><a href="../prepare_shock_data.py">Source extraction</a> and <a href="../election_ban_models.R">model code</a></li>
    <li><a href="election_ban_verification.json">Independent verification</a></li></ul>'''
    style='body{font:16px/1.6 system-ui;max-width:1250px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2,h3{color:#173f46}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px;text-align:left;border-bottom:1px solid #d8e2e5;vertical-align:top}th{background:#edf4f5}.scroll{overflow-x:auto}a{color:#14637d}'
    (OUT/'election_ban_report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Election and ban comparisons</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    assert len(r)==19 and len(r[r.primary])==6
    assert r.low.le(r.estimate).all() and r.high.ge(r.estimate).all()
    assert r.p.between(0,1).all()
    assert not q.duplicated(['gmap_id','shock','window_weeks']).any()
    (OUT/'election_ban_verification.json').write_text(json.dumps(checks,indent=2))
    class Links(HTMLParser):
        def handle_starttag(self,tag,attrs):
            if tag=='a':
                href=dict(attrs).get('href','')
                if href and not href.startswith(('http','#')):assert (OUT/href).exists(),href
    Links().feed((OUT/'election_ban_report.html').read_text(encoding='utf-8'))
    print(json.dumps(checks,indent=2))
    print('Original p-value:',original.p)

if __name__=='__main__':main()
