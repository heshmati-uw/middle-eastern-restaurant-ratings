from pathlib import Path
from html.parser import HTMLParser
import json
import pandas as pd
from prepare_data import sha256

HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'
a=pd.read_csv(OUT/'ME_sample_attrition_by_restaurant.csv')
w=pd.read_csv(OUT/'expanded_american_weekly.csv',dtype={'county_fips':'string'})
r=pd.read_csv(OUT/'expanded_american_comparison.csv')
s=json.loads((OUT/'ME_sample_attrition_audit.json').read_text())
assert len(a)==135 and a.gmap_id.is_unique
assert a.id_present_anywhere_in_legacy_sample.sum()==56
assert a.combined_source_id_present.sum()==135 and a.combined_both.sum()==134
assert not w.duplicated(['gmap_id','week']).any()
assert not w.week.isin(['2016-11-07','2017-01-23']).any()
assert w.week.ge('2016-07-04').all() and w.week.le('2017-01-16').all()
assert w.gop_share.gt(.5).all()
assert len(r)==24 and r.weighting.eq('restaurant').all()
assert r.ME_pre_restaurants.eq(r.ME_post_restaurants).all()
assert r.baseline_pre_restaurants.eq(r.baseline_post_restaurants).all()
assert (r.familywise_low<=r.low).all() and (r.familywise_high>=r.high).all()
# Independently calculate each restaurant's two means, then the mean over
# restaurants with observations in both periods. Review counts only reconstruct
# the within-restaurant mean; they are not cross-restaurant weights.
w['score_sum']=w.rating*w.reviews
b=w.groupby(['gmap_id','group','period'])[['score_sum','reviews']].sum()
b['mean']=b.score_sum/b.reviews
p=b['mean'].unstack('period').dropna(subset=['pre','post']).reset_index()
p=p[~p.group.eq('ME')|p.gmap_id.isin(a.gmap_id)]
main=r[r.ME_sample.eq('larger_ME_sample')&r.window.eq('all_available_pre')&r.baseline.eq('American')].iloc[0]
for group,n,pre,post in [('ME',main.ME_pre_restaurants,main.ME_pre,main.ME_post),
                       ('American',main.baseline_pre_restaurants,main.baseline_pre,main.baseline_post)]:
    q=p[p.group==group]
    assert len(q)==n
    assert abs(q.pre.mean()-pre)<1e-12 and abs(q.post.mean()-post)<1e-12
assert main.ME_pre_restaurants==134 and main.baseline_pre_restaurants==4053
assert sha256(Path(s['combined_source']['path']))==s['combined_source']['sha256']

class CheckLinks(HTMLParser):
    def handle_starttag(self,tag,attrs):
        if tag=='a':
            href=dict(attrs).get('href','')
            if href and not href.startswith(('#','http')):assert (OUT/href).exists(),href
CheckLinks().feed((OUT/'expanded_american_report.html').read_text(encoding='utf-8'))
v=json.loads((OUT/'expanded_american_verification.json').read_text())
v.update({'independent_equal_restaurant_means_verified':True,'source_hash_rechecked':True,
          'sample_attrition_reconciled':True,'report_links_verified':True,
          'ME_main_restaurants':int(main.ME_pre_restaurants),
          'American_main_restaurants':int(main.baseline_pre_restaurants)})
(OUT/'expanded_american_verification.json').write_text(json.dumps(v,indent=2))
print(json.dumps(v,indent=2))
