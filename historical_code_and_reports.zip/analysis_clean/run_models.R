# Reproduce the mutually exclusive group analyses from prepare_data.py outputs.
args <- commandArgs(trailingOnly=FALSE)
script <- sub('^--file=', '', args[grepl('^--file=', args)])
here <- dirname(normalizePath(script))
.libPaths(c(file.path(dirname(here), '.r-library'), .libPaths()))
suppressPackageStartupMessages({library(fixest); library(data.table); library(jsonlite)})
setFixest_nthreads(2)
out <- file.path(here, 'outputs')
cfg <- fromJSON(file.path(here, 'config.json'))
audit <- fromJSON(file.path(out, 'data_audit.json'))
sink(file.path(out, 'model_run.log'), split=TRUE)
cat('Run started:', format(Sys.time(), tz='UTC'), 'UTC\n')
d <- fread(file.path(out, 'reviews_clean.csv'), colClasses=c(county_fips='character'))
raw <- fread(file.path(out, 'reviews_with_duplicates.csv'), colClasses=c(county_fips='character'))
d[, date := as.Date(date)]; raw[, date := as.Date(date)]
d[, week := date - (as.integer(format(date, '%u')) - 1L)]
raw[, week := date - (as.integer(format(date, '%u')) - 1L)]
correction <- ssc(K.adj=TRUE, K.fixef='nonnested', G.adj=TRUE, t.df='min')
pairs <- list(c('ME','MED'), c('WPME','ME'), c('WPME','MED'))
results <- list(); events <- list(); pretests <- list(); models <- list(); flows <- list()
record <- function(m, dat, variant, outcome, pair, family, terms=NULL, cluster='restaurant') {
  ct <- coeftable(m); ci <- confint(m)
  if (is.null(terms)) terms <- rownames(ct)
  terms <- intersect(terms, rownames(ct))
  used <- dat[obs(m)]
  rows <- data.table(variant=variant, outcome=outcome, comparison=paste(pair,collapse=' vs '),
    family=family, term=terms, estimate=ct[terms,1], se=ct[terms,2],
    statistic=ct[terms,3], p=ct[terms,4], low=ci[terms,1], high=ci[terms,2],
    n=nobs(m), restaurants=uniqueN(used$gmap_id),
    counties=uniqueN(used$county_fips[!is.na(used$county_fips) & used$county_fips!='']),
    input_n=nrow(dat), singleton_or_missing_rows=nrow(dat)-nobs(m),
    cluster=cluster, fixed_effects=ifelse(outcome=='rating','restaurant + month','restaurant + week'),
    within_r2=unname(fitstat(m,'wr2')$wr2))
  results[[length(results)+1L]] <<- rows
  models[[paste(variant,outcome,paste(pair,collapse='_'),family,cluster,sep='__')]] <<- m
  invisible(rows)
}

pair_data <- function(dat, gcol, pair) {
  z <- copy(dat[get(gcol) %chin% pair])
  z[, treat := as.integer(get(gcol)==pair[1])]
  z
}

run_did <- function(dat, gcol, variant, outcome, period, heterogeneity=FALSE, county=FALSE) {
  for (pair in pairs) {
    z <- pair_data(dat, gcol, pair)
    if (outcome=='rating') z <- z[!is.na(rating)]
    z[, did := post*treat]
    f <- as.formula(paste(outcome,'~ did | gmap_id +',period))
    cat('Estimating',variant,outcome,paste(pair,collapse=' vs '),'N=',nrow(z),'\n')
    m <- feols(f, data=z, vcov=~gmap_id, ssc=correction, fixef.rm='perfect_fit', notes=FALSE)
    record(m,z,variant,outcome,pair,'DiD','did')
    if (county) {
      zc <- z[!is.na(county_fips) & county_fips!='']
      mc <- feols(f,data=zc,vcov=~county_fips,ssc=correction,notes=FALSE)
      record(mc,zc,variant,outcome,pair,'DiD_county_cluster','did','county')
    }
    if (heterogeneity) {
      h <- copy(z[!is.na(gop_share)])
      center <- mean(unique(h,by='gmap_id')$gop_share)
      h[, gop10 := (gop_share-center)/0.1]
      h[, `:=`(post_gop=post*gop10, did_gop=did*gop10)]
      hf <- as.formula(paste(outcome,'~ did + post_gop + did_gop | gmap_id +',period))
      hm <- feols(hf,data=h,vcov=~gmap_id,ssc=correction,notes=FALSE)
      rr <- record(hm,h,variant,outcome,pair,'GOP_interaction',c('did','did_gop'))
      rr[, gop_center := center]
      results[[length(results)]] <<- rr
      hc <- h[!is.na(county_fips) & county_fips!='']
      hmc <- feols(hf,data=hc,vcov=~county_fips,ssc=correction,notes=FALSE)
      record(hmc,hc,variant,outcome,pair,'GOP_interaction_county_cluster',c('did','did_gop'),'county')
    }
  }
}

make_counts <- function(dat,gcol,balanced=TRUE,support='full',audit_label=NULL) {
  z <- copy(dat[get(gcol)!='Excluded'])
  z <- z[week>=as.Date(cfg$full_weeks_start) & week<=as.Date(cfg$full_weeks_end)]
  z <- z[week!=as.Date(cfg$transition_week)]
  # Cohort with observed reviews on each side; applied to all groups identically.
  active <- z[,.(pre=any(date<as.Date(cfg$shock_date)),
                 post_seen=any(date>=as.Date(cfg$shock_date)),first=min(week),last=max(week)),by=gmap_id]
  if (balanced) active <- active[pre & post_seen]
  z <- z[gmap_id %chin% active$gmap_id]
  weeks <- seq(as.Date(cfg$full_weeks_start),as.Date(cfg$full_weeks_end),by='week')
  weeks <- weeks[weeks!=as.Date(cfg$transition_week)]
  grid <- CJ(gmap_id=sort(unique(z$gmap_id)),week=weeks)
  attrs <- unique(z[,c('gmap_id',gcol,'gop_share','county_fips','top5'),with=FALSE],by='gmap_id')
  n <- z[,.(count=.N),by=.(gmap_id,week)]
  grid <- merge(grid,attrs,by='gmap_id',all.x=TRUE,sort=FALSE)
  grid <- merge(grid,n,by=c('gmap_id','week'),all.x=TRUE,sort=FALSE)
  grid[is.na(count),count:=0L]
  if (support=='observed_span') {
    grid <- merge(grid,active[,.(gmap_id,first,last)],by='gmap_id')
    grid <- grid[week>=first & week<=last]
  }
  if (support=='positive_only') grid <- grid[count>0]
  grid[, `:=`(post=as.integer(week>as.Date(cfg$transition_week)),month=format(week,'%Y-%m'))]
  key <- if(is.null(audit_label)) paste(gcol,balanced,support,sep='_') else audit_label
  flows[[key]] <<- list(
    restaurants=uniqueN(grid$gmap_id),weeks=uniqueN(grid$week),rows=nrow(grid),
    zero_weeks=sum(grid$count==0),counted_reviews=sum(grid$count),
    mean_count=mean(grid$count),groups=grid[,.(restaurants=uniqueN(gmap_id),rows=.N,
      pre_mean=mean(count[post==0]),post_mean=mean(count[post==1])),by=gcol])
  stopifnot(!anyDuplicated(grid[,.(gmap_id,week)]),sum(grid$count)==nrow(z))
  grid
}

run_events <- function(dat,gcol,variant,outcome,period) {
  # December 2016 is an entirely pre-ban reference month. Omit mixed January.
  for(pair in pairs) {
    z <- pair_data(dat,gcol,pair)[month!='2017-01']
    if(outcome=='rating') z <- z[!is.na(rating)]
    f <- as.formula(paste(outcome,"~ i(month,treat,ref='2016-12') | gmap_id +",period))
    m <- feols(f,data=z,vcov=~gmap_id,ssc=correction,notes=FALSE)
    ct <- coeftable(m); ci <- confint(m)
    ev <- data.table(variant=variant,outcome=outcome,comparison=paste(pair,collapse=' vs '),
      term=rownames(ct),estimate=ct[,1],se=ct[,2],p=ct[,4],low=ci[,1],high=ci[,2],
      n=nobs(m),restaurants=uniqueN(z[obs(m)]$gmap_id))
    ev[,month:=sub('month::([^:]+):treat','\\1',term)]
    events[[length(events)+1L]] <<- ev
    w <- wald(m,keep='month::2016-(07|08|09|10|11):treat',print=FALSE)
    pretests[[length(pretests)+1L]] <<- data.table(variant=variant,outcome=outcome,
      comparison=paste(pair,collapse=' vs '),reference='2016-12',mixed_month_omitted='2017-01',
      pre_F=w$stat,pre_p=w$p,df1=w$df1,df2=w$df2,n=nobs(m))
    models[[paste('event',variant,outcome,paste(pair,collapse='_'),sep='__')]] <<- m
  }
}

run_did(d,'group','exclusive','rating','month',TRUE,TRUE)
run_did(raw,'group','duplicates_retained','rating','month')
run_did(d,'group_pre','preperiod_food','rating','month',TRUE,TRUE)
run_did(d[group_pre!='Excluded'],'group','prekeyword_cohort_original_labels','rating','month')
run_did(d,'group_narrow','narrow_ME','rating','month')
run_did(d[top5==1],'group','top5_cities','rating','month')
# Same two-sided cohort as the count model; test compositional dependence.
two_sided <- d[group!='Excluded',.(both=any(post==0)&any(post==1)),by=gmap_id][both==TRUE]$gmap_id
run_did(d[gmap_id %chin% two_sided],'group','two_sided_cohort','rating','month')
# Equal weight to each reviewed restaurant-month, instead of each review.
rm <- d[group!='Excluded' & !is.na(rating),.(rating=mean(rating),
     group=first(group),post=first(post),gop_share=first(gop_share),county_fips=first(county_fips)),
     by=.(gmap_id,month)]
# January contains both pre/post dates: exclude it rather than assign a mixed mean.
run_did(rm[month!='2017-01'],'group','equal_restaurant_month','rating','month')
cmain <- make_counts(d,'group')
fwrite(cmain,file.path(out,'weekly_counts.csv'))
run_did(cmain,'group','exclusive','count','week',TRUE,TRUE)
for(support in c('observed_span','positive_only')) {
  cs <- make_counts(d,'group',TRUE,support)
  run_did(cs,'group',paste0('counts_',support),'count','week')
}
call <- make_counts(d,'group',FALSE)
run_did(call,'group','counts_all_restaurants','count','week')
cpre <- make_counts(d,'group_pre')
run_did(cpre,'group_pre','preperiod_food','count','week',TRUE,TRUE)
ccohort <- make_counts(d[group_pre!='Excluded'],'group',audit_label='prekeyword_cohort_original_labels')
run_did(ccohort,'group','prekeyword_cohort_original_labels','count','week')
cnarrow <- make_counts(d,'group_narrow')
run_did(cnarrow,'group_narrow','narrow_ME','count','week')
run_did(cmain[top5==1],'group','top5_cities','count','week')
run_events(d,'group','exclusive','rating','month')
run_events(d,'group_pre','preperiod_food','rating','month')
run_events(cmain,'group','exclusive','count','week')
run_events(cpre,'group_pre','preperiod_food','count','week')

# Legacy diagnostic: reproduce two nonoverlapping old comparisons, including
# broad MED = MED + WPME. This is separate from the corrected three-group models.
for (pair in list(c('ME','MED_inclusive'),c('ME','WPME'))) {
  z <- copy(raw)
  z[, legacy_group:=group]
  if(pair[2]=='MED_inclusive') z[group %chin% c('MED','WPME'),legacy_group:='MED_inclusive']
  z <- pair_data(z,'legacy_group',pair)[!is.na(rating)]
  z[,did:=post*treat]
  m <- feols(rating~did|gmap_id+month,data=z,vcov=~gmap_id,ssc=correction,notes=FALSE)
  record(m,z,'legacy_diagnostic','rating',pair,'DiD','did')
}
res <- rbindlist(results,fill=TRUE)
res[family=='DiD',p_holm:=p.adjust(p,'holm'),by=.(variant,outcome)]
res[family=='GOP_interaction' & term=='did_gop',p_holm:=p.adjust(p,'holm'),by=.(variant,outcome)]
fwrite(res,file.path(out,'model_results.csv'))
ev <- rbindlist(events); pt <- rbindlist(pretests)
fwrite(ev,file.path(out,'event_study.csv')); fwrite(pt,file.path(out,'pretrend_tests.csv'))
write_json(flows,file.path(out,'count_panel_audit.json'),pretty=TRUE,auto_unbox=TRUE)
saveRDS(models,file.path(out,'fitted_models.rds'))
writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo.txt'))
write_json(as.list(sapply(c('fixest','data.table','jsonlite','sandwich','dreamerr','stringmagic','numDeriv','Rcpp','Formula','zoo'),function(p)as.character(packageVersion(p)))),
           file.path(out,'R_package_versions.json'),pretty=TRUE,auto_unbox=TRUE)
write_json(as.list(tools::md5sum(file.path(here,c('run_models.R','config.json','prepare_data.py')))),
           file.path(out,'executed_code_md5.json'),pretty=TRUE,auto_unbox=TRUE)

source(file.path(here,'plot_results.R'))
cat('\nPrimary estimates:\n'); print(res[variant=='exclusive' & family=='DiD'])
cat('\nPretrend tests:\n'); print(pt)
cat('Run completed:',format(Sys.time(),tz='UTC'),'UTC\n')
sink()
