"""Focused working-window report; keep the original full comparison intact."""
from pathlib import Path
from html import escape
from html.parser import HTMLParser
import json
import pandas as pd

HERE=Path(__file__).resolve().parent;OUT=HERE/'outputs'

def main():
    cfg=json.loads((HERE/'shock_specifications.json').read_text())
    weeks=cfg['working_window_weeks']
    r=pd.read_csv(OUT/'election_ban_results.csv')
    d=pd.read_csv(OUT/'election_ban_descriptives.csv')
    z=r[r.weeks.eq(weeks)].copy()
    means=d[d.weeks.eq(weeks)].copy()
    assert len(z)==6 and len(means)==6
    z.to_csv(OUT/'working_window_results.csv',index=False)
    means.to_csv(OUT/'working_window_descriptives.csv',index=False)
    windows=[v for v in cfg['main_windows']+cfg['sensitivity_windows'] if v['weeks']==weeks]
    def endday(day):return (pd.Timestamp(day)+pd.Timedelta(days=6)).strftime('%B %d, %Y')
    body=f'<h1>{weeks}-week working window: election and travel ban</h1>'
    body+='<p>Equal weight per restaurant, using only restaurants with reviews in both periods. Average reviews within each restaurant-period first, then compare restaurant-level changes. All comparisons are within Trump-majority counties (Republican vote share over 50%). The complete shock week is excluded.</p>'
    body+='<p><strong>Exploratory working specification:</strong> '+escape(cfg['working_window_selection'])+'</p>'
    body+='<h2>Windows</h2><ul>'
    for w in windows:
        body+=f"<li><strong>{w['shock']}:</strong> before {pd.Timestamp(w['pre_start']).strftime('%B %d, %Y')}–{endday(w['pre_end'])}; after {pd.Timestamp(w['post_start']).strftime('%B %d, %Y')}–{endday(w['post_end'])}.</li>"
        assert (pd.Timestamp(w['pre_end'])-pd.Timestamp(w['pre_start'])).days==7*(weeks-1)
        assert (pd.Timestamp(w['post_end'])-pd.Timestamp(w['post_start'])).days==7*(weeks-1)
    body+='</ul><h2>Relative changes in average ratings</h2><p>Negative ME–American means ME lost ground. Positive WPME–ME means WPME improved relative to ME. P-values are two-sided, with standard errors clustered by county.</p><div class="scroll"><table><tr><th>Shock</th><th>Comparison</th><th>Relative change</th><th>95% CI</th><th>Unadjusted p</th><th>Holm p: three contrasts within shock</th><th>Restaurants: first / second group</th></tr>'
    for a in z.itertuples():
        cells=[a.shock,a.comparison,f'{a.estimate:+.3f}',f'[{a.low:+.3f}, {a.high:+.3f}]',
               f'{a.p:.3f}',f'{a.p_holm_three_within_shock:.3f}',
               f'{a.treated_restaurants:,} / {a.control_restaurants:,}']
        body+='<tr>'+''.join('<td>'+escape(c)+'</td>' for c in cells)+'</tr>'
    body+='</table></div><h2>Average levels: each restaurant equally weighted</h2><table><tr><th>Shock</th><th>Group</th><th>Before</th><th>After</th><th>Change</th><th>Restaurants</th></tr>'
    for a in means.itertuples():
        body+=f'<tr><td>{a.shock}</td><td>{a.group}</td><td>{a.pre:.3f}</td><td>{a.post:.3f}</td><td>{a.change:+.3f}</td><td>{a.restaurants:,}</td></tr>'
    body+='</table><h2>Reading the results</h2><p>The short election window shows a ME decline relative to American restaurants. WPME–American and WPME–ME are statistically unclear. None of the three ban contrasts is statistically clear at 5%.</p>'
    me=z[z.shock.eq('Election')&z.comparison.eq('ME vs American')].iloc[0]
    body+=f'<p>The election ME–American unadjusted p-value is {me.p:.3f}, and its within-shock three-comparison Holm p-value is {me.p_holm_three_within_shock:.3f}. Accounting for all 18 shock/window/comparison tests already examined gives Holm p = {me.p_holm_all_eighteen:.3f}. Choosing the four-week window after seeing the estimates does not make its unadjusted p-value confirmatory evidence.</p>'
    body+='<p>Short windows also retain fewer restaurants: election ME has 92 businesses, versus 128 in the ten-week analysis. The working result therefore changes both the time horizon and cohort. Reviewer composition, seasonality, local conditions and the food/category proxies remain limitations. No causal effect of the election or ban is established by these comparisons alone.</p>'
    body+='<p><a href="election_ban_report.html">Original full report with all four-, six-, and ten-week results</a> · <a href="working_window_results.csv">Working-window estimates</a> · <a href="working_window_descriptives.csv">Restaurant-level group means</a> · <a href="../shock_specifications.json">Working settings</a></p>'
    style='body{font:16px/1.6 system-ui;max-width:1150px;margin:40px auto;padding:0 24px;color:#24323b}h1,h2{color:#173f46}table{border-collapse:collapse;width:100%;font-size:14px}td,th{text-align:left;padding:10px;border-bottom:1px solid #d8e2e5;vertical-align:top}th{background:#edf4f5}.scroll{overflow-x:auto}a{color:#14637d}'
    path=OUT/'short_window_report.html'
    path.write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Four-week working comparison</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    class Links(HTMLParser):
        def handle_starttag(self,tag,attrs):
            if tag=='a':
                href=dict(attrs).get('href','')
                if href:assert (OUT/href).exists(),href
    Links().feed(path.read_text(encoding='utf-8'))
    print('Working window:',weeks,'weeks; six comparisons exported; original results preserved.')

if __name__=='__main__':main()
