"""Build a broader weekly sample and independently reconstruct county politics."""
from pathlib import Path
import sys,json,zipfile,io
import pandas as pd
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'.analysis-python'))
import shapely
import shapefile
from shapely.strtree import STRtree
from prepare_data import sha256

OUT=HERE/'outputs'
CFG=json.loads((HERE/'config.json').read_text())
ROOT=Path(CFG['source_root'])
SOURCE=ROOT/'analysis/panel_restaurants_sample.dta'
GEO=ROOT/'analysis/2025-08-18-rohan/lat to fips/cb_2018_us_county_500k.zip'
VOTES=ROOT/'analysis/2025-08-18-rohan/lat to fips/2016-precinct-president.csv'
CONTROLS={'American restaurant':'American','New American restaurant':'New American',
          'Traditional American restaurant':'Traditional American',
          'Fast food restaurant':'Fast food','Greek restaurant':'Greek',
          'Chinese restaurant':'Chinese','Italian restaurant':'Italian',
          'Pizza restaurant':'Pizza'}

def main():
    groups=pd.read_csv(OUT/'restaurant_groups.csv')
    fmap=groups[groups.group.isin(['ME','MED','WPME'])].set_index('gmap_id').group
    cols=['gmap_id','category','week_start_mr','averagerating_mr','countofreviews_mr','latitude','longitude']
    cache=OUT/'baseline_selected_cache.pkl'
    fingerprint={'source_bytes':SOURCE.stat().st_size,'source_mtime_ns':SOURCE.stat().st_mtime_ns,
                 'classification_sha256':sha256(OUT/'restaurant_groups.csv')}
    if '--use-cache' in sys.argv:
        meta=json.loads((OUT/'baseline_cache_metadata.json').read_text())
        assert meta['fingerprint']==fingerprint,'Cache inputs changed'
        assert meta['cache_sha256']==sha256(cache),'Cache changed'
        d=pd.read_pickle(cache); nraw=meta['scanned_rows']
        print('Using verified local extraction cache:',len(d),'rows',flush=True)
    else:
        chunks=[]; nraw=0
        print('Reading broader restaurant-week panel...',flush=True)
        reader=pd.read_stata(SOURCE,iterator=True,convert_categoricals=False)
        while True:
            try:chunk=reader.read(250000,columns=cols)
            except StopIteration:break
            nraw+=len(chunk)
            keep=(chunk.week_start_mr>='2016-07-04')&(chunk.week_start_mr<='2017-01-16')
            keep &= ~chunk.week_start_mr.eq('2016-11-07')
            z=chunk[keep].copy()
            z['group']=z.gmap_id.map(fmap)
            z['group']=z.group.fillna(z.category.map(CONTROLS))
            z=z[z.group.notna()]
            chunks.append(z)
            print(f'Chunk {len(chunks)}: scanned {nraw:,}; retained {sum(map(len,chunks)):,}',flush=True)
            if len(chunk)<250000:break
        assert nraw==reader._nobs
        d=pd.concat(chunks,ignore_index=True)
        d.rename(columns={'week_start_mr':'week','averagerating_mr':'rating','countofreviews_mr':'reviews'},inplace=True)
        d.to_pickle(cache)
        (OUT/'baseline_cache_metadata.json').write_text(json.dumps({'fingerprint':fingerprint,
             'cache_sha256':sha256(cache),'scanned_rows':nraw},indent=2))
    assert d.rating.dropna().between(1,5).all()
    assert (d.reviews.dropna()>0).all()
    # Legacy exports may repeat business-week rows: remove only exact selected
    # records and fail on conflicting business-week observations.
    ndups=int(d.duplicated().sum()); d=d.drop_duplicates()
    conflicts=d[d.duplicated(['gmap_id','week'],keep=False)]
    if len(conflicts):
        conflicts.to_csv(OUT/'baseline_week_conflicts.csv',index=False)
        print('Conflict details:',conflicts.groupby(['gmap_id','week'])[['rating','reviews','latitude','longitude','group']].nunique(dropna=False).max().to_dict(),flush=True)
        print(conflicts.head(12).to_string(index=False),flush=True)
    nconflicts=len(conflicts)
    conflictweeks=len(conflicts[['gmap_id','week']].drop_duplicates())
    # Two unequal ratings for the same business-week cannot be resolved from
    # aggregates without review IDs. Exclude all records for that week.
    d=d.loc[~d.duplicated(['gmap_id','week'],keep=False)].copy()
    assert not d.duplicated(['gmap_id','week']).any()
    assert d.groupby('gmap_id').group.nunique().le(1).all()
    assert d.groupby('gmap_id').latitude.nunique().le(1).all()
    assert d.groupby('gmap_id').longitude.nunique().le(1).all()
    businesses=d[['gmap_id','latitude','longitude']].drop_duplicates('gmap_id').copy()
    print('Spatially assigning counties...',flush=True)
    with zipfile.ZipFile(GEO) as z:
        base=next(n[:-4] for n in z.namelist() if n.endswith('.shp'))
        sf=shapefile.Reader(shp=io.BytesIO(z.read(base+'.shp')),
                            shx=io.BytesIO(z.read(base+'.shx')),dbf=io.BytesIO(z.read(base+'.dbf')))
        names=[f[0] for f in sf.fields[1:]]
        records=list(sf.iterShapeRecords())
        polygons=np.array([shapely.geometry.shape(r.shape.__geo_interface__) for r in records],dtype=object)
        fips=np.array([str(r.record[names.index('GEOID')]).zfill(5) for r in records])
    valid=businesses.latitude.notna()&businesses.longitude.notna()
    valid &= businesses.latitude.between(-90,90)&businesses.longitude.between(-180,180)
    positions=np.flatnonzero(valid.to_numpy())
    pts=shapely.points(businesses.loc[valid,'longitude'].to_numpy(),businesses.loc[valid,'latitude'].to_numpy())
    match=STRtree(polygons).query(pts,predicate='intersects')
    matches=pd.DataFrame({'position':positions[match[0]],'county_fips':fips[match[1]]})
    ambiguous=matches[matches.duplicated('position',keep=False)].position.nunique()
    # Boundary ambiguity is not resolved arbitrarily: exclude those businesses.
    matches=matches.drop_duplicates().loc[lambda x:~x.duplicated('position',keep=False)]
    businesses=businesses.reset_index(drop=True)
    businesses['county_fips']=pd.Series(matches.county_fips.to_numpy(),index=matches.position)
    print('Aggregating county presidential votes...',flush=True)
    votes=pd.read_csv(VOTES,usecols=['county_fips','votes','party','candidate_normalized'],
                      dtype={'county_fips':'string'},encoding='latin-1',low_memory=False)
    votes['county_fips']=votes.county_fips.str.replace(r'\.0$','',regex=True).str.zfill(5)
    votes['votes']=pd.to_numeric(votes.votes,errors='coerce')
    assert votes.votes.notna().all()
    total=votes.groupby('county_fips').votes.sum()
    rep=votes[votes.party.eq('republican')|votes.candidate_normalized.eq('trump')].groupby('county_fips').votes.sum()
    shares=(rep.reindex(total.index,fill_value=0)/total).rename('gop_share')
    shares=shares[shares.between(0,1)]
    businesses=businesses.merge(shares,on='county_fips',how='left',validate='many_to_one')
    # Validate reconstructed geography/politics against the newer saved panel.
    modern=pd.read_csv(OUT/'reviews_clean.csv',usecols=['gmap_id','county_fips','gop_share'],dtype={'county_fips':'string'}).drop_duplicates('gmap_id')
    check=businesses.merge(modern,on='gmap_id',suffixes=('_new','_saved'))
    complete=check.dropna(subset=['county_fips_new','county_fips_saved','gop_share_new','gop_share_saved'])
    disagreement=complete[complete.county_fips_new.ne(complete.county_fips_saved)|
                          ((complete.gop_share_new-complete.gop_share_saved).abs()>1e-8)]
    disagreement.to_csv(OUT/'baseline_geography_disagreements.csv',index=False)
    missing=int(businesses.gop_share.isna().sum())
    businesses.to_csv(OUT/'baseline_business_geography.csv',index=False)
    d=d.merge(businesses[['gmap_id','county_fips','gop_share']],on='gmap_id',validate='many_to_one')
    d=d[d.gop_share.notna()&d.rating.notna()&d.reviews.notna()].copy()
    d['trump_county']=d.gop_share>.5
    d['period']=np.where(d.week<'2016-11-07','pre','post')
    d['post']=(d.period=='post').astype(int)
    d['month']=d.week.str[:7]
    d.to_csv(OUT/'broader_baseline_weekly.csv',index=False)
    audit={'scanned_source_rows':nraw,'retained_rows':len(d),'businesses':d.gmap_id.nunique(),
           'exact_duplicates_removed':ndups,'conflicting_rows_excluded':nconflicts,
           'conflicting_business_weeks_excluded':conflictweeks,'missing_geography_businesses':missing,
           'ambiguous_boundary_businesses':int(ambiguous),'geography_comparison_businesses':len(complete),
           'geography_disagreements':len(disagreement),
           'max_gop_share_difference_on_comparable_businesses':float((complete.gop_share_new-complete.gop_share_saved).abs().max()),
           'controls':CONTROLS,'pre_weeks':'2016-07-04 through 2016-10-31',
           'post_weeks':'2016-11-14 through 2017-01-16',
           'excluded_mixed_weeks':['2016-11-07','2017-01-23'],
           'spatial_method':'Intersects with supplied 2018 county polygons; lon/lat used as geographic coordinates. Ambiguous or unmatched points excluded.',
           'versions':{'shapely':shapely.__version__,'pyshp':shapefile.__version__},
           'sources':{str(p):{'bytes':p.stat().st_size,'sha256':sha256(p)} for p in [SOURCE,GEO,VOTES]}}
    (OUT/'broader_baseline_audit.json').write_text(json.dumps(audit,indent=2,default=lambda x:int(x)))
    print(json.dumps({k:v for k,v in audit.items() if k not in ['sources','controls']},indent=2),flush=True)
    print(d[d.trump_county].groupby('group').agg(weeks=('rating','size'),businesses=('gmap_id','nunique')).to_string(),flush=True)

if __name__=='__main__':main()
