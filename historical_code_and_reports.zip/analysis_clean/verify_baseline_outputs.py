from pathlib import Path
from html.parser import HTMLParser
import json
import pandas as pd
from prepare_data import sha256

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'
r=pd.read_csv(OUT/'within_trump_baseline_results.csv')
a=json.loads((OUT/'broader_baseline_audit.json').read_text())
assert len(r)==88
assert not r.duplicated(['source','window','baseline','cohort','weighting']).any()
assert ((r.relative_change-(r.ME_change-r.baseline_change)).abs()<1e-12).all()
assert ((r.relative_change-(r.post_gap-r.pre_gap)).abs()<1e-12).all()
assert (r.low<=r.high).all()
assert (r.familywise_low<=r.low).all() and (r.familywise_high>=r.high).all()
w=pd.read_csv(OUT/'broader_baseline_weekly.csv',dtype={'county_fips':'string'})
assert not w.duplicated(['gmap_id','week']).any()
assert not w.week.isin(['2016-11-07','2017-01-23']).any()
assert w.week.min()=='2016-07-04' and w.week.max()=='2017-01-16'
assert w.groupby('gmap_id').group.nunique().le(1).all()
assert w.groupby('gmap_id').county_fips.nunique().le(1).all()
for path,metadata in a['sources'].items():
    assert sha256(Path(path))==metadata['sha256'],path

class Links(HTMLParser):
    def handle_starttag(self,tag,attrs):
        if tag=='a':
            href=dict(attrs).get('href','')
            if href and not href.startswith(('#','http')):
                assert (OUT/href).exists(),href

Links().feed((OUT/'within_trump_baselines.html').read_text(encoding='utf-8'))
v=json.loads((OUT/'baseline_comparison_verification.json').read_text())
v.update({'output_checks_passed':True,'source_hashes_rechecked':True,
          'weekly_keys_unique':True,'mixed_weeks_excluded':True,'report_links_verified':True})
(OUT/'baseline_comparison_verification.json').write_text(json.dumps(v,indent=2))
print(json.dumps({k:v[k] for k in ['result_rows','output_checks_passed','source_hashes_rechecked',
    'ME_sample_held_constant_across_broader_baselines','geography_disagreement_rows_excluded']},indent=2))
