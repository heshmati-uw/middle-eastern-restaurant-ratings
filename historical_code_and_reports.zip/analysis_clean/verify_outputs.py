"""Reconcile exported research results and confirm sources remained unchanged."""
from pathlib import Path
import hashlib
import json
import re
from urllib.parse import unquote
import pandas as pd
from prepare_data import sha256

HERE=Path(__file__).resolve().parent
OUT=HERE/'outputs'
a=json.loads((OUT/'data_audit.json').read_text())
d=pd.read_csv(OUT/'reviews_clean.csv')
g=pd.read_csv(OUT/'restaurant_groups.csv')
w=pd.read_csv(OUT/'weekly_counts.csv')
r=pd.read_csv(OUT/'model_results.csv')
e=pd.read_csv(OUT/'event_study.csv')
p=pd.read_csv(OUT/'pretrend_tests.csv')
assert g.gmap_id.is_unique
assert len(d)==a['clean_rows']
assert len(d[d.group!='Excluded'])==a['eligible_reviews']
assert not w.duplicated(['gmap_id','week']).any()
assert w.groupby('gmap_id').size().eq(50).all()
assert (w['count']>=0).all() and (w['count']==0).any()
assert not w.week.eq('2017-01-23').any()
ids=set(w.gmap_id)
expected=d[(d.gmap_id.isin(ids))&(d.date>='2016-07-04')&(d.date<'2017-06-26')&
           ~d.date.between('2017-01-23','2017-01-29')]
assert w['count'].sum()==len(expected)
assert len(r[(r.variant=='exclusive')&(r.family=='DiD')])==6
assert len(p)==12 and len(e)==120
assert set(e.month)=={'2016-07','2016-08','2016-09','2016-10','2016-11',
                      '2017-02','2017-03','2017-04','2017-05','2017-06'}
assert (r.se>0).all()
assert r.n.le(r.input_n).all()
assert (r.low<=r.estimate).all() and (r.estimate<=r.high).all()
assert not r.duplicated(['variant','outcome','comparison','family','term','cluster']).any()
for path,meta in a['sources'].items():
    assert sha256(Path(path))==meta['sha256'],f'Source changed: {path}'
for path,digest in json.loads((OUT/'executed_code_md5.json').read_text()).items():
    assert hashlib.md5(Path(path).read_bytes()).hexdigest()==digest,f'Code changed after models ran: {path}'
report=(OUT/'results_report.html').read_text(encoding='utf-8')
for href in re.findall(r'href="([^"]+)"',report):
    if not href.startswith(('#','http')):
        assert (OUT/unquote(href)).exists(),href
assert report.count('<svg')==4
ids=re.findall(r'\bid="([^"]+)"',report)
assert len(ids)==len(set(ids)), 'Duplicate inline SVG or section IDs'
status={'all_checks_passed':True,'source_files_unchanged':True,
        'review_total_reconciled':int(w['count'].sum()),
        'weekly_restaurants':int(w.gmap_id.nunique()),'weekly_rows':len(w),
        'weekly_zero_rows':int(w['count'].eq(0).sum()),
        'model_result_rows':len(r),'event_coefficients':len(e),'joint_pretrend_tests':len(p)}
(OUT/'output_verification.json').write_text(json.dumps(status,indent=2))
print(json.dumps(status,indent=2))
