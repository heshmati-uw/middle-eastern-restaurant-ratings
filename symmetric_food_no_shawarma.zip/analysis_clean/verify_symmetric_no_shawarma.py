from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;root=H/'symmetric_food_no_shawarma';expanded='--expanded-country' in sys.argv;O=root/'expanded_country' if expanded else root
sys.path.insert(0,str(H.parent/'.analysis-python'))
from scipy.stats import t as student_t
info=pd.read_csv(O/'model_info.csv');co=pd.read_csv(O/'model_coefficients.csv');cv=pd.read_csv(O/'model_covariances.csv');inputs=pd.read_csv(O/'model_verification_inputs.csv',dtype={'county_fips':str},low_memory=False);results=pd.read_csv(O/'pairwise_results.csv');stronger=pd.read_csv(O/'targeted_stronger_tests.csv');models={};errors=[];contrasts=[]
for r in info.itertuples():
 z=inputs[inputs.model_id.eq(r.model_id)];old=co[co.model_id.eq(r.model_id)];terms=list(old.term);a=z[['y']+terms].copy()
 if str(r.within_county).lower()=='true':a-=a.groupby(z.county_fips).transform('mean')
 X=a[terms].to_numpy();y=a.y.to_numpy();assert np.linalg.matrix_rank(X)==len(terms)
 bread=np.linalg.inv(X.T@X);b=bread@(X.T@y);res=y-X@b;G=z.county_fips.nunique();N=len(z);scores=pd.DataFrame(X*res[:,None]).groupby(z.county_fips.to_numpy()).sum().to_numpy();V=bread@scores.T@scores@bread*G/(G-1)*(N-1)/(N-r.df_K)
 oldV=cv[cv.model_id.eq(r.model_id)].pivot(index='term1',columns='term2',values='value').loc[terms,terms].to_numpy();errors.extend([np.max(np.abs(b-old.estimate.to_numpy())),np.max(np.abs(V-oldV))]);assert N==r.restaurants and G==r.counties;models[r.model_id]=(terms,b,V,G)
for frame,kind in [(results,'pair'),(stronger,'stronger')]:
 for r in frame.itertuples():
  if pd.isna(r.estimate):assert isinstance(r.reason,str) and r.reason;continue
  terms,b,V,G=models[r.model_id];L=np.zeros(len(terms))
  if kind=='pair':
   if r.trump!=2:L[terms.index('first')]=1
   if r.trump in [1,2]:L[terms.index('first_trump')]=1
  else:
   if r.trump!=2:L[terms.index('ME_other')]=1;L[terms.index('ME_target')]=-1
   if r.trump in [1,2]:L[terms.index('other_trump')]=1;L[terms.index('target_trump')]=-1
  est=L@b;se=np.sqrt(L@V@L);p=2*student_t.sf(abs(est/se),G-1);crit=student_t.ppf(.975,G-1);contrasts.extend([abs(est-r.estimate),abs(se-r.se),abs(p-r.p),abs(est-crit*se-r.low),abs(est+crit*se-r.high)])
  if kind=='pair' and r.support_df>0:assert abs(2*student_t.sf(abs(est/se),r.support_df)-r.p_support_df)<1e-10
assert max(errors)<1e-8 and max(contrasts)<1e-8,(max(errors),max(contrasts))
decomp=pd.read_csv(O/'county_FE_decomposition.csv');assert np.allclose(decomp.WP_change-decomp.ME_change,decomp.implied_FE_gap,atol=1e-10)
key=['dictionary','event','ME_sample','population','trump'];a=decomp.merge(results[results.specification.eq('County FE shared counties')],on=key,validate='one_to_one');assert np.allclose(a.implied_FE_gap,a.estimate,atol=1e-9)
means=pd.read_csv(O/'group_before_after_means.csv');assert np.allclose(means.post-means.pre,means.change,atol=1e-10)
def holm(z):
 p=z.p.to_numpy();ix=np.argsort(p);out=np.empty(len(p));out[ix]=np.minimum(1,np.maximum.accumulate((len(p)-np.arange(len(p)))*p[ix]));return out
primary=results[results.population.eq('All ME')&results.specification.eq('County FE shared counties')&results.trump.eq(2)].copy();assert len(primary)==8;primary['p_holm_primary8']=holm(primary);primary.to_csv(O/'primary_direct_tests.csv',index=False)
if expanded:
 original=pd.read_csv(root/'pairwise_results.csv');a=results[results.population.eq('All ME')].merge(original[original.population.eq('All ME')],on=['dictionary','event','ME_sample','population','specification','trump'],validate='one_to_one',suffixes=('_new','_old'))
 for name in ['estimate','se','p','WPME_N','ME_N']:assert np.allclose(a[name+'_new'],a[name+'_old'],atol=1e-10,equal_nan=True)
audit={'models_verified':len(info),'pairwise_contrasts_verified':len(results),'stronger_targeted_contrasts_verified':len(stronger),'max_model_error':max(errors),'max_contrast_p_CI_error':max(contrasts),'exact_county_FE_decompositions':len(decomp),'before_after_arithmetic_verified':True,'equal_restaurant_weights':True,'expanded_country_does_not_change_food_tags_or_all_ME_results':expanded}
(O/'verification.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));print(primary[['dictionary','event','ME_sample','estimate','p','p_holm_primary8']].to_string(index=False))
