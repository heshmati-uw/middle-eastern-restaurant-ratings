from pathlib import Path
import sys
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'symmetric_food_no_shawarma';sys.path.insert(0,str(H.parent/'.analysis-python'))
from scipy.stats import t as student_t
d=pd.read_csv(O/'restaurant_periods.csv',dtype={'county_fips':str});out=[]
for ms in ['All ME labels','Food-verified ME']:
 q=d if ms=='All ME labels' else d[~d.group.eq('ME')|d.food_verified.eq(True)]
 for (dictionary,event,trump,group),z in q.groupby(['dictionary','event','trump','group']):
  N=len(z);G=z.county_fips.nunique()
  for outcome in ['rating_pre','rating_post','change']:
   y=z[outcome];b=y.mean();scores=(y-b).groupby(z.county_fips).sum().to_numpy();se=np.sqrt(G/(G-1)*np.sum(scores*scores))/N if G>1 else np.nan;crit=student_t.ppf(.975,G-1);p=2*student_t.sf(abs(b/se),G-1)
   out.append(dict(dictionary=dictionary,event=event,ME_sample=ms,trump=int(trump),group=group,outcome=outcome,restaurants=N,counties=G,estimate=b,se=se,p=p,low=b-crit*se,high=b+crit*se))
r=pd.DataFrame(out);r.to_csv(O/'raw_group_mean_uncertainty.csv',index=False)
print(r[r.dictionary.eq('Broad')&r.event.eq('Ban')&r.ME_sample.eq('Food-verified ME')&r.outcome.eq('change')][['trump','group','restaurants','estimate','low','high','p']].to_string(index=False))
