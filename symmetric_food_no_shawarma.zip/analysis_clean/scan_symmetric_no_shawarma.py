"""Checkpointed raw pre-election core/broad review tagging for ME and MED labels.

Stores restaurant IDs, review hashes, timestamps and dish masks only. Raw source
files are read-only. Shawarma is retained solely as an exclusion audit bit.
"""
from pathlib import Path
import concurrent.futures,gzip,hashlib,json,math,os,re,sqlite3,time,unicodedata
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'symmetric_food_no_shawarma';O.mkdir(exist_ok=True);C=O/'scan_checkpoints';C.mkdir(exist_ok=True)
CFG=json.loads((H/'config.json').read_text());SRC=Path(CFG['source_root'])/'analysis/2025-08-18-rohan/inputs'
ORIGINAL=json.loads((H/'expanded_dish_dictionary.json').read_text());CORE=ORIGINAL['core'];SHARED=ORIGINAL['shared_sensitivity'];CUTOFF=1478563200000;EARLY=1104537600000
def normalize(s):
 s=unicodedata.normalize('NFKD',s.casefold()).encode('ascii','ignore').decode();return re.sub(r'[^\w\s]',' ',s)
def scan_file(arg):
 name,targets,signature=arg;f=SRC/name;stem=f.name.removesuffix('.json.gz');done=C/(stem+'.done.json');status=C/(stem+'.status.json');dest=C/(stem+'.selected.jsonl.gz')
 if done.exists():
  previous=json.loads(done.read_text())
  if previous.get('signature')==signature and dest.exists():return previous
 cr=[re.compile(v) for v in CORE.values()];sr=[re.compile(v) for v in SHARED.values()];ids={x.encode() for x in targets};idregex=re.compile(rb'"gmap_id"\s*:\s*"([^"\\]+)"')
 stat=dict(file=name,signature=signature,source_bytes=f.stat().st_size,source_mtime_ns=f.stat().st_mtime_ns,rows=0,target_rows=0,pre_rows=0,pre_text_rows=0,old_core_hits=0,shared_hits=0,invalid_time_target_rows=0,json_errors=0,compressed_bytes_read=0,complete=False);start=time.monotonic();last=start
 with f.open('rb') as raw,gzip.GzipFile(fileobj=raw,mode='rb') as stream,gzip.open(dest,'wt',encoding='utf-8',compresslevel=1) as out:
  for line in stream:
   stat['rows']+=1;pos=line.rfind(b'"gmap_id"');m=idregex.match(line,pos) if pos>=0 else None
   if m and m.group(1) in ids:
    stat['target_rows']+=1
    try:row=json.loads(line)
    except (ValueError,UnicodeError):stat['json_errors']+=1;continue
    t=row.get('time')
    if isinstance(t,bool) or not isinstance(t,(int,float)) or not math.isfinite(t) or not 0<t<253402300800000:stat['invalid_time_target_rows']+=1;continue
    if t<CUTOFF:
     stat['pre_rows']+=1;t=int(t);text=row.get('text');norm=normalize(text) if isinstance(text,str) else '';has_text=bool(norm.strip());cm=0;sm=0
     if has_text:
      stat['pre_text_rows']+=1
      for i,pat in enumerate(cr):
       if pat.search(norm):cm|=1<<i
      for i,pat in enumerate(sr):
       if pat.search(norm):sm|=1<<i
     stat['old_core_hits']+=int(cm>0);stat['shared_hits']+=int(sm>0)
     key=hashlib.sha256(json.dumps([row.get('gmap_id'),row.get('user_id'),t,row.get('rating'),text],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
     out.write(json.dumps([key,row['gmap_id'],t,int(has_text),cm,sm],separators=(',',':'))+'\n')
   now=time.monotonic()
   if now-last>=15:stat['compressed_bytes_read']=raw.tell();stat['elapsed_seconds']=round(now-start,1);status.write_text(json.dumps(stat));last=now
  stat['compressed_bytes_read']=raw.tell()
 stat['complete']=True;stat['elapsed_seconds']=round(time.monotonic()-start,1);stat['derived_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest();status.write_text(json.dumps(stat));done.write_text(json.dumps(stat));return stat
def main():
 frozen=O/'inputs/metadata_with_geography.csv';meta=pd.read_csv(frozen if frozen.exists() else H/'expanded_positioning/metadata_with_geography.csv',usecols=['gmap_id','primary_category'])
 targeted_categories=['Persian restaurant','Iranian restaurant','Iraqi restaurant','Syrian restaurant','Yemenite restaurant','Yemeni restaurant','Libyan restaurant','Somali restaurant','Somalian restaurant','Sudanese restaurant']
 meta=meta[meta.primary_category.isin(CFG['me_categories']+['Mediterranean restaurant']+targeted_categories)];targets=sorted(meta.gmap_id.unique());files=sorted(SRC.glob('review-*.json.gz'),key=lambda p:p.stat().st_size,reverse=True);assert len(files)==52
 signature=hashlib.sha256(json.dumps(dict(targets=targets,core=CORE,shared=SHARED,cutoff=CUTOFF,version='symmetric_no_shawarma_v1'),sort_keys=True).encode()).hexdigest()
 revised={**ORIGINAL,'version':'2026-11-03-no-shawarma-v1','core':{k:v for k,v in CORE.items() if k!='shawarma'},'main_timing':'All eligible raw pre-election reviews, before 2016-11-08 UTC, for BOTH ME and primary Mediterranean restaurants','main_definition':'core_no_shawarma','interpretation':'Core excludes shawarma entirely; broad = revised core + original shared dictionary. Same patterns and timing for both label groups. Core and broad evidence are food-mention proxies, not authenticity or nationality.'}
 (O/'food_dictionary_no_shawarma.json').write_text(json.dumps(revised,indent=2))
 manifest=dict(source=str(SRC),signature=signature,cutoff_exclusive_utc='2016-11-08T00:00:00Z',target_businesses=len(targets),target_categories=meta.primary_category.value_counts().to_dict(),core_original_for_audit=CORE,core_revised=revised['core'],shared=SHARED,workers=min(8,os.cpu_count() or 1),files=[dict(file=p.name,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns) for p in files],dedup_key='SHA256 canonical [gmap_id,user_id,time,rating,text]; no reviewer IDs or text retained')
 (O/'scan_manifest.json').write_text(json.dumps(manifest,indent=2));stats=[];print('Scanning',len(files),'files for',len(targets),'ME/Mediterranean restaurants',flush=True)
 with concurrent.futures.ProcessPoolExecutor(max_workers=manifest['workers']) as ex:
  futures=[ex.submit(scan_file,(p.name,targets,signature)) for p in files]
  for future in concurrent.futures.as_completed(futures):
   stat=future.result();stats.append(stat);print(stat['file'],stat['rows'],'rows;',stat['pre_text_rows'],'pre-election text reviews',flush=True)
 assert all(s['complete'] for s in stats) and not any(s['json_errors'] for s in stats);pd.DataFrame(stats).to_csv(O/'scan_source_counts.csv',index=False)
 db=sqlite3.connect(O/'derived_unique_reviews.sqlite');db.execute('DROP TABLE IF EXISTS reviews');db.execute('CREATE TABLE reviews (review_hash TEXT PRIMARY KEY,gmap_id TEXT NOT NULL,time INTEGER NOT NULL,has_text INTEGER NOT NULL,core_mask INTEGER NOT NULL,shared_mask INTEGER NOT NULL) WITHOUT ROWID');selected=0
 for stat in stats:
  batch=[]
  with gzip.open(C/(stat['file'].removesuffix('.json.gz')+'.selected.jsonl.gz'),'rt',encoding='utf-8') as f:
   for line in f:
    batch.append(json.loads(line));selected+=1
    if len(batch)>=20000:db.executemany('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?,?)',batch);batch=[]
  if batch:db.executemany('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?,?)',batch)
  db.commit()
 shaw=1<<list(CORE).index('shawarma');newmask=((1<<len(CORE))-1)^shaw
 query=f'''SELECT gmap_id,COUNT(*) pre_reviews,SUM(has_text) pre_text_reviews,SUM(core_mask>0) old_core_reviews,SUM((core_mask & {newmask})>0) core_reviews,SUM((core_mask & {newmask})>0 OR shared_mask>0) broad_reviews,SUM((core_mask & {shaw})>0) shawarma_reviews,SUM(time<{EARLY}) early_reviews,SUM(time>={EARLY} AND (core_mask & {newmask})>0) post2004_core_reviews FROM reviews GROUP BY gmap_id'''
 summary=pd.DataFrame({'gmap_id':targets}).merge(pd.read_sql_query(query,db),on='gmap_id',how='left',validate='one_to_one')
 for col in summary.columns[1:]:summary[col]=summary[col].fillna(0).astype(int)
 for col,source in [('text_pre','pre_text_reviews'),('old_core_pre','old_core_reviews'),('core_pre','core_reviews'),('broad_pre','broad_reviews')]:summary[col]=summary[source]>0
 summary.to_csv(O/'pre_election_food_flags.csv',index=False);dishes=[]
 for family,patterns,col in [('core_original',CORE,'core_mask'),('shared',SHARED,'shared_mask')]:
  for i,name in enumerate(patterns):
   a=pd.read_sql_query(f'SELECT gmap_id,COUNT(*) review_mentions FROM reviews WHERE ({col} & {1<<i})>0 GROUP BY gmap_id',db);a['dish']=name;a['family']=family;dishes.append(a)
 pd.concat(dishes,ignore_index=True).to_csv(O/'dish_business_mentions.csv',index=False);unique=db.execute('SELECT COUNT(*) FROM reviews').fetchone()[0];db.close()
 audit=dict(files_complete=len(stats),raw_review_rows_scanned=sum(s['rows'] for s in stats),selected_pre_rows_before_dedup=selected,unique_pre_election_reviews=unique,duplicates_removed=selected-unique,target_businesses=len(targets),businesses_with_text=int(summary.text_pre.sum()),businesses_old_core=int(summary.old_core_pre.sum()),businesses_revised_core=int(summary.core_pre.sum()),businesses_revised_broad=int(summary.broad_pre.sum()),shawarma_only_core_businesses=int((summary.old_core_pre&~summary.core_pre).sum()),json_errors=sum(s['json_errors'] for s in stats),invalid_timestamps=sum(s['invalid_time_target_rows'] for s in stats),source_files_modified=False)
 (O/'scan_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit),flush=True)
if __name__=='__main__':main()
