args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(h),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
root<-file.path(h,'symmetric_food_no_shawarma');expanded<-'--expanded-country' %in% args;o<-if(expanded)file.path(root,'expanded_country') else root;dir.create(o,showWarnings=FALSE)
d<-fread(file.path(root,'restaurant_periods.csv'),colClasses=c(county_fips='character'))
if(expanded){
 cues<-fread(file.path(root,'country_cuisine_cues','country_cuisine_flags.csv'))[,.(gmap_id,review_country_cue)]
 d<-merge(d,cues,by='gmap_id',all.x=TRUE,sort=FALSE);d[,targeted_by_category:=targeted];d[is.na(review_country_cue),review_country_cue:=FALSE];d[,targeted:=targeted|review_country_cue]
}
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');results<-list();stronger<-list();means<-list();decomp<-list();flow<-list();infos<-list();coeffs<-list();covs<-list();inputs<-list();warnings<-list();mid<-0L
export_model<-function(fit,x,meta,within){
 mid<<-mid+1L;B<-coef(fit);V<-vcov(fit);G<-uniqueN(x$county_fips);K<-attr(vcov(fit,attr=TRUE),'df.K');stopifnot(nobs(fit)==nrow(x))
 infos[[mid]]<<-cbind(data.table(model_id=mid,within_county=within,restaurants=nrow(x),counties=G,df_K=K),meta)
 coeffs[[mid]]<<-data.table(model_id=mid,term=names(B),estimate=unname(B),se=sqrt(diag(V)))
 vv<-as.data.table(as.table(V));setnames(vv,c('term1','term2','value'));vv[,model_id:=mid];covs[[mid]]<<-vv
 ip<-data.table(model_id=mid,gmap_id=x$gmap_id,county_fips=x$county_fips,y=x$change)
 for(n in names(B))ip[[n]]<-if(n=='(Intercept)')rep(1,nrow(x)) else x[[n]]
 inputs[[mid]]<<-ip
 list(id=mid,B=B,V=V,G=G)
}
calc<-function(s,terms){
 if(any(!names(terms)%in%names(s$B)))return(list(estimate=NA_real_,se=NA_real_,p=NA_real_,low=NA_real_,high=NA_real_,reason='Contrast not identified in available county-type support'))
 L<-setNames(rep(0,length(s$B)),names(s$B));L[names(terms)]<-terms;b<-sum(L*s$B);se<-sqrt(as.numeric(t(L)%*%s$V%*%L));p<-2*pt(-abs(b/se),s$G-1)
 list(estimate=b,se=se,p=p,low=b-qt(.975,s$G-1)*se,high=b+qt(.975,s$G-1)*se,reason='')
}
for(def in c('Core','Broad'))for(en in c('Election','Ban'))for(ms in c('All ME labels','Food-verified ME')){
 q<-d[dictionary==def&event==en];if(ms=='Food-verified ME')q<-q[group!='ME'|food_verified==TRUE]
 gm<-q[,.(restaurants=.N,pre=mean(rating_pre),post=mean(rating_post),change=mean(change),counties=uniqueN(county_fips)),by=.(trump,group)];gm[,`:=`(dictionary=def,event=en,ME_sample=ms,sample='Full eligible')];means[[length(means)+1L]]<-gm
 for(pop in c('All ME','Targeted ME')){
  pair<-q[group=='WPME'|(group=='ME'&(if(pop=='Targeted ME')targeted==TRUE else TRUE))];pair[,`:=`(first=as.integer(group=='WPME'),first_trump=as.integer(group=='WPME')*trump)]
  shared<-pair[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips
  for(spec in c('Unadjusted full sample','County FE shared counties')){
   within<-spec=='County FE shared counties';x<-if(within)pair[county_fips %chin% shared] else copy(pair)
   meta<-data.table(dictionary=def,event=en,ME_sample=ms,population=pop,specification=spec,model_kind='Pairwise interaction')
   fl<-x[,.(WPME_N=sum(first),ME_N=sum(1-first),restaurants=.N,counties=uniqueN(county_fips)),by=trump];fl[,`:=`(dictionary=def,event=en,ME_sample=ms,population=pop,specification=spec)];flow[[length(flow)+1L]]<-fl
   if(nrow(x)<5||uniqueN(x$county_fips)<2||uniqueN(x$first)<2){warnings[[length(warnings)+1L]]<-cbind(meta,data.table(reason='Too few restaurants/groups/counties to estimate'));next}
   f<-if(within)change~first+first_trump|county_fips else change~first+trump+first_trump
   fit<-tryCatch(feols(f,x,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE),error=function(e)NULL)
   if(is.null(fit)){warnings[[length(warnings)+1L]]<-cbind(meta,data.table(reason='Model not estimable'));next}
   s<-export_model(fit,x,meta,within)
   for(t in c(0,1,2)){
    L<-if(t==2)c(first_trump=1) else if(t==1)c(first=1,first_trump=1) else c(first=1)
    a<-calc(s,L);xx<-if(t==2)x else x[trump==t]
    g0<-uniqueN(x[trump==0]$county_fips);g1<-uniqueN(x[trump==1]$county_fips);df_support<-(if(t==2)min(g0,g1) else if(t==1)g1 else g0)-1
    p_support<-if(is.finite(a$estimate)&&df_support>0)2*pt(-abs(a$estimate/a$se),df_support) else NA_real_
    results[[length(results)+1L]]<-cbind(data.table(model_id=s$id,dictionary=def,event=en,ME_sample=ms,population=pop,specification=spec,trump=t,contrast=if(t==2)'Trump minus non-Trump difference in WPME-minus-ME gap' else 'WPME minus ME change',WPME_N=sum(xx$first),ME_N=sum(1-xx$first),counties=uniqueN(xx$county_fips),Trump_counties=g1,non_Trump_counties=g0,support_df=df_support,p_support_df=p_support,few_county_support=min(g0,g1)<10),as.data.table(a))
   }
   # Exact decomposition of the unit-weight county-FE slope. These component
   # means use the county weights implicit in that regression; no estimator
   # reweighting is introduced. Raw restaurant means are exported separately.
   if(within){
    g<-x[,.(nWP=sum(first),nME=sum(1-first),WP_pre=mean(rating_pre[first==1]),WP_post=mean(rating_post[first==1]),ME_pre=mean(rating_pre[first==0]),ME_post=mean(rating_post[first==0])),by=.(county_fips,trump)];g[,cw:=nWP*nME/(nWP+nME)]
    for(t in c(0,1)){
     a<-g[trump==t];if(!nrow(a))next
     wp0<-weighted.mean(a$WP_pre,a$cw);wp1<-weighted.mean(a$WP_post,a$cw);me0<-weighted.mean(a$ME_pre,a$cw);me1<-weighted.mean(a$ME_post,a$cw);gap<-(wp1-wp0)-(me1-me0);fitgap<-calc(s,if(t==1)c(first=1,first_trump=1) else c(first=1))$estimate
     if(is.finite(fitgap))stopifnot(abs(gap-fitgap)<1e-9)
     decomp[[length(decomp)+1L]]<-data.table(model_id=s$id,dictionary=def,event=en,ME_sample=ms,population=pop,trump=t,WP_pre=wp0,WP_post=wp1,WP_change=wp1-wp0,ME_pre=me0,ME_post=me1,ME_change=me1-me0,implied_FE_gap=gap,counties=nrow(a),WPME_N=sum(a$nWP),ME_N=sum(a$nME))
    }
   }
   g<-x[,.(restaurants=.N,pre=mean(rating_pre),post=mean(rating_post),change=mean(change),counties=uniqueN(county_fips)),by=.(trump,group)];g[,`:=`(dictionary=def,event=en,ME_sample=ms,sample=paste(pop,spec,sep=' | '))];means[[length(means)+1L]]<-g
  }
 }
 # Direct comparison of targeted versus other ME in the SAME joint model,
 # using WPME as reference. Positive means a larger WPME advantage relative
 # to targeted ME than to other ME; the direct t=2 tests political difference.
 z<-q[group %chin% c('ME','WPME')];z[,`:=`(ME_target=as.integer(group=='ME'&targeted),ME_other=as.integer(group=='ME'&!targeted))];z[,`:=`(target_trump=ME_target*trump,other_trump=ME_other*trump)]
 for(spec in c('Joint unadjusted','Joint county FE')){
  within<-spec=='Joint county FE';meta<-data.table(dictionary=def,event=en,ME_sample=ms,population='Targeted versus other ME',specification=spec,model_kind='Stronger targeted association')
  if(!any(z$ME_target)||!any(z$ME_other))next
  f<-if(within)change~ME_target+ME_other+target_trump+other_trump|county_fips else change~ME_target+ME_other+trump+target_trump+other_trump
  fit<-tryCatch(feols(f,z,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE),error=function(e)NULL);if(is.null(fit))next
  s<-export_model(fit,z,meta,within)
  for(t in c(0,1,2)){
   L<-if(t==2)c(other_trump=1,target_trump=-1) else if(t==1)c(ME_other=1,ME_target=-1,other_trump=1,target_trump=-1) else c(ME_other=1,ME_target=-1)
   xx<-if(t==2)z else z[trump==t]
   tg0<-uniqueN(z[trump==0&ME_target==1]$county_fips);tg1<-uniqueN(z[trump==1&ME_target==1]$county_fips)
   stronger[[length(stronger)+1L]]<-cbind(data.table(model_id=s$id,dictionary=def,event=en,ME_sample=ms,specification=spec,trump=t,targeted_N=sum(xx$ME_target),other_ME_N=sum(xx$ME_other),WPME_N=sum(xx$group=='WPME'),counties=uniqueN(xx$county_fips),targeted_Trump_counties=tg1,targeted_non_Trump_counties=tg0,few_targeted_counties=min(tg0,tg1)<10),as.data.table(calc(s,L)))
  }
 }
}
write<-function(rows,name,adjust=FALSE){z<-rbindlist(rows,fill=TRUE);if(!nrow(z)){fwrite(data.table(reason=character()),file.path(o,name));return(invisible(z))};if('p'%in%names(z)){z[,symbol:=fcase(is.na(p),'',p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')];if(adjust)z[,p_holm:=p.adjust(p,'holm')]};fwrite(z,file.path(o,name));invisible(z)}
write(results,'pairwise_results.csv',TRUE);write(stronger,'targeted_stronger_tests.csv',TRUE);write(means,'group_before_after_means.csv');write(decomp,'county_FE_decomposition.csv');write(flow,'model_sample_sizes.csv');write(infos,'model_info.csv');write(coeffs,'model_coefficients.csv');write(covs,'model_covariances.csv');write(inputs,'model_verification_inputs.csv');write(warnings,'estimation_warnings.csv')
print(rbindlist(results)[trump==2,.(dictionary,event,ME_sample,population,specification,estimate,p,WPME_N,ME_N)]);print(rbindlist(stronger)[specification=='Joint county FE',.(dictionary,event,ME_sample,trump,estimate,p,targeted_N)])
