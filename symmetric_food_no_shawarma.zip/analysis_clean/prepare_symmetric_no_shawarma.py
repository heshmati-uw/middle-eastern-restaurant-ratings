"""Frozen classifications and event data for symmetric food verification."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'symmetric_food_no_shawarma';S=H/'full_pre_election_core';I=O/'inputs';I.mkdir(exist_ok=True)
cfg=json.loads((H/'config.json').read_text());flags=pd.read_csv(O/'pre_election_food_flags.csv');audit=json.loads((O/'scan_audit.json').read_text());assert audit['files_complete']==52 and audit['json_errors']==0
target_map={'Persian restaurant':'Iran','Iranian restaurant':'Iran','Iraqi restaurant':'Iraq','Syrian restaurant':'Syria','Yemenite restaurant':'Yemen','Yemeni restaurant':'Yemen','Libyan restaurant':'Libya','Somali restaurant':'Somalia','Somalian restaurant':'Somalia','Sudanese restaurant':'Sudan'}
frozen_meta=I/'metadata_with_geography.csv'
meta=pd.read_csv(frozen_meta if frozen_meta.exists() else H/'expanded_positioning/metadata_with_geography.csv',dtype={'county_fips':str},usecols=['gmap_id','primary_category','county_fips','gop_share','latitude','longitude'])
meta=meta[meta.primary_category.isin(cfg['me_categories']+['Mediterranean restaurant']+list(target_map))].copy();assert set(meta.gmap_id)==set(flags.gmap_id)
if not frozen_meta.exists():meta.to_csv(frozen_meta,index=False)
meta['is_ME_label']=meta.primary_category.ne('Mediterranean restaurant');meta['target_country']=meta.primary_category.map(target_map);meta['targeted']=meta.target_country.notna();meta['county_valid']=meta.county_fips.notna()&meta.gop_share.between(0,1);meta['trump']=np.where(meta.county_valid,(meta.gop_share>.5).astype(int),np.nan)
meta=meta.merge(flags,on='gmap_id',validate='one_to_one');meta.to_csv(O/'food_classification_population.csv',index=False)
old=pd.read_csv(S/'full_pre_election_dish_flags.csv');check=meta[meta.primary_category.eq('Mediterranean restaurant')].merge(old[['gmap_id','pre_reviews','pre_text_reviews','pre_core_reviews']],on='gmap_id',validate='one_to_one',suffixes=('_new','_old'))
assert len(check)==5442
assert check.pre_reviews_new.eq(check.pre_reviews_old).all() and check.pre_text_reviews_new.eq(check.pre_text_reviews_old).all() and check.old_core_reviews.eq(check.pre_core_reviews).all()
(O/'old_scan_reproduction.json').write_text(json.dumps({'all_5442_Mediterranean_restaurants_checked':True,'old_review_counts_exact':True,'old_text_counts_exact':True,'old_core_hit_counts_exact':True},indent=2))
design={'date':'2026-11-03','dictionaries':{'Core':'Original 27 core dishes minus shawarma (26); same patterns applied to ME and Mediterranean labels','Broad':'Revised 26 core dishes plus existing 10 shared dishes; shawarma excluded'},'review_period':'All raw eligible reviews before 2016-11-08 UTC; groups frozen for both election and ban','food_verification':'At least one dictionary hit in eligible pre-election review text, identical criteria for both label families','ME_categories':cfg['me_categories'],'main_category_rule':'Primary category, as previously chosen','ME_samples':['All ME labels','Food-verified ME'],'WPME':'Primary Mediterranean with positive dictionary food evidence','MED':'Primary Mediterranean with observed pre-election text and no evidence under the same dictionary; unknown histories excluded','targeted_countries':['Iran','Iraq','Syria','Yemen','Libya','Somalia','Sudan'],'targeted_category_map':target_map,'targeted_definition':'Explicit primary national-cuisine categories only; names, ownership and generic Halal/Arab labels do not assign a targeted country','county_type':'Trump share strictly >50% of all-candidate county votes versus <=50%','windows':{'Election':['2016-10-10/2016-11-06','2016-11-14/2016-12-11'],'Ban':['2016-12-26/2017-01-22','2017-01-30/2017-02-26']},'holidays':'Included; mixed event weeks omitted','weights':'One equally weighted rating change per restaurant','models':['Unadjusted full eligible WPME-versus-ME interaction with county type','County-FE WPME-versus-ME interaction on shared-county support','Same pairwise comparisons for targeted ME','Joint WPME/targeted-ME/other-ME model for direct stronger-targeted contrasts'],'inference':'County-clustered CR1; fixest nonnested FE correction; t df=counties-1','interpretation':'Observational rating-change associations; direct interactions are differences of observed cuisine gaps across county types, not identified causal shocks'}
(O/'analysis_design.json').write_text(json.dumps(design,indent=2))
country=[]
for c in design['targeted_countries']:
 z=meta[meta.target_country.eq(c)];country.append(dict(country=c,primary_category_labels='; '.join(sorted(z.primary_category.unique())),metadata_restaurants=len(z),county_linked_restaurants=int(z.county_valid.sum()),with_pre_text=int(z.text_pre.sum()),core_verified=int(z.core_pre.sum()),broad_verified=int(z.broad_pre.sum())))
pd.DataFrame(country).to_csv(O/'targeted_country_population.csv',index=False)
classifications=[];populations=[];transitions=[];frames=[];size=[];target_event=[]
for definition,flag in [('Core','core_pre'),('Broad','broad_pre')]:
 z=meta.copy();z['dictionary']=definition;z['food_verified']=z[flag].eq(True);z['group']=np.where(z.is_ME_label,'ME','Unknown');med=~z.is_ME_label;z.loc[med&z.text_pre&~z.food_verified,'group']='MED';z.loc[med&z.food_verified,'group']='WPME';classifications.append(z)
 z.groupby(['primary_category','group','food_verified','targeted'],dropna=False).size().rename('restaurants').reset_index().assign(dictionary=definition).to_csv(O/f'population_{definition.lower()}.csv',index=False)
 if definition=='Core':
  a=z[med].copy();a['old_group']=np.where(a.old_core_pre,'WPME',np.where(a.text_pre,'MED','Unknown'));a.groupby(['old_group','group']).size().rename('restaurants').reset_index().to_csv(O/'shawarma_removal_transitions.csv',index=False)
 for event in ['Election','Ban']:
  frozen=I/f'periods_{event.lower()}_4w.csv'
  if frozen.exists():p=pd.read_csv(frozen)
  else:
   p=pd.read_csv(H/'expanded_positioning'/f'periods_{event.lower()}_4w.csv');p=p[p.gmap_id.isin(meta.gmap_id)];p.to_csv(frozen,index=False)
  d=p.merge(z[z.county_valid&z.group.isin(['ME','WPME','MED'])],on='gmap_id',validate='one_to_one');d=d[d.rating_pre.between(1,5)&d.rating_post.between(1,5)&d.reviews_pre.gt(0)&d.reviews_post.gt(0)];d['event']=event;assert np.allclose(d.change,d.rating_post-d.rating_pre);frames.append(d)
  for me_sample in ['All ME labels','Food-verified ME']:
   q=d.copy() if me_sample=='All ME labels' else d[~d.group.eq('ME')|d.food_verified].copy()
   q.groupby(['trump','group']).agg(restaurants=('gmap_id','size'),counties=('county_fips','nunique')).reset_index().assign(dictionary=definition,event=event,ME_sample=me_sample).to_csv(O/f'sample_{definition}_{event}_{me_sample.replace(" ","_")}.csv',index=False)
   for key,zz in q.groupby(['trump','group']):size.append(dict(dictionary=definition,event=event,ME_sample=me_sample,trump=key[0],group=key[1],restaurants=len(zz),counties=zz.county_fips.nunique()))
  for c in design['targeted_countries']:
   a=d[d.target_country.eq(c)];target_event.append(dict(dictionary=definition,event=event,country=c,restaurants=len(a),Trump_counties=int(a.trump.eq(1).sum()),non_Trump_counties=int(a.trump.eq(0).sum()),core_or_broad_verified=int(a.food_verified.sum()),verified_Trump=int((a.trump.eq(1)&a.food_verified).sum()),verified_non_Trump=int((a.trump.eq(0)&a.food_verified).sum())))
pd.concat(frames,ignore_index=True).to_csv(O/'restaurant_periods.csv',index=False);pd.DataFrame(size).to_csv(O/'sample_sizes.csv',index=False);pd.DataFrame(target_event).to_csv(O/'targeted_country_event_counts.csv',index=False)
comparison=meta.groupby(meta.is_ME_label.map({True:'ME label',False:'Mediterranean label'})).agg(restaurants=('gmap_id','size'),with_pre_text=('text_pre','sum'),old_core=('old_core_pre','sum'),revised_core=('core_pre','sum'),revised_broad=('broad_pre','sum')).reset_index();comparison.to_csv(O/'food_verification_coverage.csv',index=False)
print(comparison.to_string(index=False));print(pd.DataFrame(country).to_string(index=False));print(pd.DataFrame(size).to_string(index=False))
