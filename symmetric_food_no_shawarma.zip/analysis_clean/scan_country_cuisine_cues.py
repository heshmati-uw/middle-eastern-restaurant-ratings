"""Explicit pre-election seven-country cuisine phrases, not incidental nationality."""
from pathlib import Path
import concurrent.futures,gzip,hashlib,json,math,os,re,sqlite3,time,unicodedata
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'symmetric_food_no_shawarma/country_cuisine_cues';O.mkdir(exist_ok=True);C=O/'scan_checkpoints';C.mkdir(exist_ok=True)
SRC=Path(json.loads((H/'config.json').read_text())['source_root'])/'analysis/2025-08-18-rohan/inputs';CUTOFF=1478563200000
COUNTRIES={'Iran':{'adjectives':['persian','iranian'],'places':['iran','persia']},'Iraq':{'adjectives':['iraqi'],'places':['iraq']},'Syria':{'adjectives':['syrian'],'places':['syria']},'Yemen':{'adjectives':['yemeni','yemenite'],'places':['yemen']},'Libya':{'adjectives':['libyan'],'places':['libya']},'Somalia':{'adjectives':['somali','somalian'],'places':['somalia']},'Sudan':{'adjectives':['sudanese'],'places':['sudan']}}
MODS='style|inspired|traditional|authentic|homestyle|home|cooked|and|mediterranean|middle|eastern|delicious|tasty|amazing|excellent|great|classic|regional|national|local'
NOUNS='food|cuisine|cooking|dishes|restaurant|restaurants|menu|recipes|meal|meals|flavors|flavours'
PATTERNS={country:rf'\b(?:{"|".join(c["adjectives"])})(?:\s+(?:{MODS})){{0,4}}\s+(?:{NOUNS})\b|\b(?:food|cuisine|cooking|dishes|flavors|flavours|recipes)\s+(?:from|of|inspired\s+by)\s+(?:the\s+)?(?:{"|".join(c["places"])})\b' for country,c in COUNTRIES.items()}
NEG=re.compile(r'\b(?:not|no|never)\s+(?:(?:really|authentic|traditional|real)\s+)?$')
def normalize(s):return re.sub(r'[^\w\s]',' ',unicodedata.normalize('NFKD',s.casefold()).encode('ascii','ignore').decode())
def scan_file(arg):
 name,targets,signature=arg;f=SRC/name;stem=f.name.removesuffix('.json.gz');done=C/(stem+'.done.json');status=C/(stem+'.status.json');dest=C/(stem+'.selected.jsonl.gz')
 if done.exists():
  previous=json.loads(done.read_text())
  if previous.get('signature')==signature and dest.exists():return previous
 regs=[re.compile(v) for v in PATTERNS.values()];ids={s.encode() for s in targets};idregex=re.compile(rb'"gmap_id"\s*:\s*"([^"\\]+)"');stat=dict(file=name,signature=signature,source_bytes=f.stat().st_size,rows=0,target_rows=0,pre_text_rows=0,positive_cue_reviews=0,negated_cue_reviews=0,json_errors=0,compressed_bytes_read=0,complete=False);start=time.monotonic();last=start
 with f.open('rb') as raw,gzip.GzipFile(fileobj=raw,mode='rb') as stream,gzip.open(dest,'wt',encoding='utf-8',compresslevel=1) as out:
  for line in stream:
   stat['rows']+=1;pos=line.rfind(b'"gmap_id"');m=idregex.match(line,pos) if pos>=0 else None
   if m and m.group(1) in ids:
    stat['target_rows']+=1
    try:r=json.loads(line)
    except (ValueError,UnicodeError):stat['json_errors']+=1;continue
    t=r.get('time')
    if isinstance(t,bool) or not isinstance(t,(int,float)) or not math.isfinite(t) or not 0<t<CUTOFF:continue
    text=r.get('text');norm=normalize(text) if isinstance(text,str) else ''
    if norm.strip():
     stat['pre_text_rows']+=1;mask=0;negmask=0;phrases=[]
     for i,pat in enumerate(regs):
      for hit in pat.finditer(norm):
       if NEG.search(norm[max(0,hit.start()-35):hit.start()]):negmask|=1<<i
       else:mask|=1<<i;phrases.append([i,hit.group(0)])
     if mask or negmask:
      stat['positive_cue_reviews']+=int(mask>0);stat['negated_cue_reviews']+=int(negmask>0);t=int(t);key=hashlib.sha256(json.dumps([r.get('gmap_id'),r.get('user_id'),t,r.get('rating'),text],ensure_ascii=False,separators=(',',':')).encode()).hexdigest();out.write(json.dumps([key,r['gmap_id'],t,mask,negmask,phrases],separators=(',',':'))+'\n')
   now=time.monotonic()
   if now-last>=15:stat['compressed_bytes_read']=raw.tell();stat['elapsed_seconds']=round(now-start,1);status.write_text(json.dumps(stat));last=now
  stat['compressed_bytes_read']=raw.tell()
 stat['complete']=True;stat['elapsed_seconds']=round(time.monotonic()-start,1);stat['derived_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest();status.write_text(json.dumps(stat));done.write_text(json.dumps(stat));return stat
def main():
 targets=sorted(pd.read_csv(O.parent/'food_classification_population.csv',usecols=['gmap_id']).gmap_id);files=sorted(SRC.glob('review-*.json.gz'),key=lambda p:p.stat().st_size,reverse=True);assert len(files)==52
 signature=hashlib.sha256(json.dumps(dict(targets=targets,patterns=PATTERNS,cutoff=CUTOFF,version=1),sort_keys=True).encode()).hexdigest();manifest=dict(signature=signature,patterns=PATTERNS,countries=COUNTRIES,cutoff_exclusive_utc='2016-11-08T00:00:00Z',targets=len(targets),workers=min(8,os.cpu_count() or 1),files=[dict(file=p.name,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns) for p in files],purpose='Country association only; does not change core/broad food verification',negation_policy='Exclude matches immediately preceded by no/not/never with optional really/authentic/traditional/real',caveat='Cuisine mentions are associations, not verified nationality, authenticity or menu dominance')
 (O/'scan_manifest.json').write_text(json.dumps(manifest,indent=2));stats=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=manifest['workers']) as ex:
  futures=[ex.submit(scan_file,(p.name,targets,signature)) for p in files]
  for future in concurrent.futures.as_completed(futures):
   st=future.result();stats.append(st);print(st['file'],st['rows'],'rows;',st['positive_cue_reviews'],'positive country-cuisine reviews',flush=True)
 assert not any(s['json_errors'] for s in stats);pd.DataFrame(stats).to_csv(O/'scan_source_counts.csv',index=False)
 db=sqlite3.connect(O/'country_cuisine_reviews.sqlite');db.execute('DROP TABLE IF EXISTS reviews');db.execute('CREATE TABLE reviews (review_hash TEXT PRIMARY KEY,gmap_id TEXT,time INTEGER,country_mask INTEGER,negative_mask INTEGER,phrases TEXT) WITHOUT ROWID');selected=0
 for st in stats:
  batch=[]
  with gzip.open(C/(st['file'].removesuffix('.json.gz')+'.selected.jsonl.gz'),'rt',encoding='utf-8') as f:
   for line in f:
    row=json.loads(line);row[-1]=json.dumps(row[-1]);batch.append(row);selected+=1
    if len(batch)>=20000:db.executemany('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?,?)',batch);batch=[]
  if batch:db.executemany('INSERT OR IGNORE INTO reviews VALUES (?,?,?,?,?,?)',batch)
  db.commit()
 frames=[]
 for i,country in enumerate(COUNTRIES):
  a=pd.read_sql_query(f'SELECT gmap_id,SUM((country_mask & {1<<i})>0) positive_review_mentions,SUM((negative_mask & {1<<i})>0) negated_review_mentions,MIN(CASE WHEN (country_mask & {1<<i})>0 THEN time END) first_positive_time FROM reviews WHERE ((country_mask | negative_mask) & {1<<i})>0 GROUP BY gmap_id',db);a['country']=country;frames.append(a)
 long=pd.concat(frames,ignore_index=True);long.to_csv(O/'business_country_mentions.csv',index=False)
 summary=long.groupby('gmap_id').agg(cuisine_review_mentions=('positive_review_mentions','sum'),countries_with_positive_evidence=('positive_review_mentions',lambda x:int((x>0).sum()))).reset_index();summary=pd.DataFrame({'gmap_id':targets}).merge(summary,on='gmap_id',how='left').fillna(0);summary['review_country_cue']=summary.countries_with_positive_evidence.gt(0);summary.to_csv(O/'country_cuisine_flags.csv',index=False)
 phrase_rows=[]
 for key,gmap,t,mask,negative,phrases in db.execute('SELECT * FROM reviews'):
  for i,phrase in json.loads(phrases):phrase_rows.append(dict(gmap_id=gmap,country=list(COUNTRIES)[i],matched_cuisine_phrase=phrase))
 pd.DataFrame(phrase_rows).groupby(['country','matched_cuisine_phrase']).size().rename('review_matches').reset_index().sort_values('review_matches',ascending=False).to_csv(O/'matched_phrase_audit.csv',index=False)
 unique=db.execute('SELECT COUNT(*) FROM reviews').fetchone()[0];db.close();audit=dict(files_complete=len(stats),raw_rows_scanned=sum(s['rows'] for s in stats),selected_cue_rows_before_dedup=selected,unique_cue_reviews=unique,restaurants_with_positive_country_cue=int(summary.review_country_cue.sum()),json_errors=0,source_files_modified=False);(O/'scan_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit),flush=True)
if __name__=='__main__':main()
