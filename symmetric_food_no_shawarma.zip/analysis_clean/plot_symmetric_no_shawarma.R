args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
o<-file.path(h,'symmetric_food_no_shawarma');r<-read.csv(file.path(o,'pairwise_results.csv'));means<-read.csv(file.path(o,'group_before_after_means.csv'))
rows<-data.frame(dictionary=c('Core','Core','Broad','Broad'),ME_sample=c('All ME labels','Food-verified ME','All ME labels','Food-verified ME'),label=c('Core: all ME labels','Core: food-verified ME','Broad: all ME labels','Broad: food-verified ME'))
ordered<-function(z){merge(rows,z,by=c('dictionary','ME_sample'),sort=FALSE)[match(rows$label,merge(rows,z,by=c('dictionary','ME_sample'),sort=FALSE)$label),]}
forest<-function(d,path,title,panels){
 b<-range(c(d$low,d$high,0),na.rm=TRUE);span<-diff(b);left<-b[1]-.06*span;right<-b[2]+.08*span;pcol<-right+.08*span;far<-right+.4*span
 png(file.path(o,path),width=if(length(panels)==2)1900 else 2100,height=if(length(panels)==2)1000 else 1500,res=170);par(mfrow=if(length(panels)==2)c(1,2) else c(2,2),mar=c(5,10,4,1),oma=c(3,0,3,0),las=1)
 for(panel in panels){z<-d[d$event==panel$event&d$trump==panel$trump,];z<-ordered(z);yy<-4:1;cols<-ifelse(z$dictionary=='Core','#376B92','#B64B40');plot(c(left,far),c(.5,4.8),type='n',xaxt='n',yaxt='n',xlab='',ylab='',bty='l');ticks<-pretty(c(left,right),5);ticks<-ticks[ticks>=left&ticks<=right];axis(1,at=ticks,cex.axis=.8);axis(2,at=yy,labels=paste0(z$label,'\nN WPME/ME=',z$WPME_N,'/',z$ME_N),tick=FALSE,cex.axis=.7);abline(v=0,lty=2,col='grey55');segments(left,yy,right,yy,col='#e5eaed');arrows(z$low,yy,z$high,yy,angle=90,code=3,length=.04,col=cols,lwd=1.5);points(z$estimate,yy,pch=ifelse(z$ME_sample=='Food-verified ME',16,1),col=cols,cex=1.2);pv<-ifelse(z$p<.001,'<.001',formatC(z$p,format='f',digits=4));text(pcol,yy,paste0(pv,ifelse(is.na(z$symbol),'',z$symbol)),adj=0,cex=.75,col=cols);text(pcol,4.65,'Raw p',adj=0,font=2,cex=.8);title(main=panel$title,cex.main=1);mtext(if(panel$trump==2)'Trump minus non-Trump WPME-ME change gap (stars)' else 'WPME minus ME rating change (stars)',side=1,line=2.8,cex=.7)}
 mtext(title,side=3,outer=TRUE,line=1,font=2,cex=1.05);mtext('Shawarma excluded; all raw pre-election text; unit restaurant weights; pointwise 95% county-clustered intervals.',side=1,outer=TRUE,line=.4,cex=.7);mtext('County-FE shared-county support. Filled = both label groups food-verified; open = ME category alone.',side=1,outer=TRUE,line=1.5,cex=.7);dev.off()
}
d<-r[r$population=='All ME'&r$specification=='County FE shared counties',]
forest(d[d$trump==2,],'direct_county_interactions.png','Direct tests of different WPME-ME changes across county types',list(list(event='Election',trump=2,title='Election'),list(event='Ban',trump=2,title='Ban')))
forest(d[d$trump!=2,],'within_county_cuisine_contrasts.png','Within-county WPME-ME contrasts',list(list(event='Election',trump=1,title='Election | Trump-majority'),list(event='Election',trump=0,title='Election | Non-Trump'),list(event='Ban',trump=1,title='Ban | Trump-majority'),list(event='Ban',trump=0,title='Ban | Non-Trump')))
for(def in c('Core','Broad'))for(en in c('Election','Ban')){
 a<-means[means$dictionary==def&means$event==en&means$ME_sample=='Food-verified ME'&means$sample=='Full eligible',];yr<-range(a$pre,a$post)
 png(file.path(o,paste0(def,'_',en,'_group_means.png')),width=1700,height=950,res=170);par(mfrow=c(1,2),mar=c(5,5,4,1),oma=c(3,0,2,0));cols<-c('#185b7a','#c45a3c','#6b7d35')
 for(t in c(1,0)){
  plot(c(.85,2.15),yr,type='n',xaxt='n',xlab='',ylab='Average restaurant rating (stars)',main=if(t==1)'Trump-majority counties' else 'Non-Trump counties');axis(1,at=c(1,2),labels=c('Before','After'))
  for(k in 1:3){z<-a[a$trump==t&a$group==c('ME','WPME','MED')[k],];lines(c(1,2),c(z$pre,z$post),col=cols[k],lwd=2);points(c(1,2),c(z$pre,z$post),col=cols[k],pch=c(16,17,15)[k])}
  legend('bottomleft',legend=c('ME (food verified)','WPME (food verified)','MED (no matching food evidence)'),col=cols,lty=1,pch=c(16,17,15),bty='n',cex=.6)
 }
 mtext(paste(def,'dictionary without shawarma |',en,'| Full eligible raw means'),side=3,outer=TRUE,line=.5,font=2,cex=1)
 mtext('Each restaurant unit weight; raw group means are not adjusted for county composition.',side=1,outer=TRUE,line=.5,cex=.75)
 mtext('County-FE decomposition is reported separately using the county weights implicit in that regression.',side=1,outer=TRUE,line=1.7,cex=.7);dev.off()
}
