args<-commandArgs(FALSE);h<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])));o<-file.path(h,'symmetric_food_no_shawarma')
r<-read.csv(file.path(o,'raw_group_mean_uncertainty.csv'));r<-r[r$ME_sample=='Food-verified ME'&r$group %in% c('ME','WPME'),]
for(def in c('Core','Broad')){
 a<-r[r$dictionary==def,];yr<-range(a$low[a$outcome!='change'],a$high[a$outcome!='change'])
 png(file.path(o,paste0(def,'_ME_WPME_before_after.png')),width=2100,height=1500,res=180);par(mfrow=c(2,2),mar=c(4,5,4,1),oma=c(3,0,3,0))
 for(en in c('Election','Ban'))for(t in c(1,0)){
  z<-a[a$event==en&a$trump==t,];plot(c(.55,2.5),yr,type='n',xaxt='n',xlab='',ylab='Average rating (stars)',main=paste(en,if(t==1)'| Trump-majority counties' else '| Non-Trump counties'))
  ns<-sapply(c('ME','WPME'),function(g)z$restaurants[z$group==g&z$outcome=='change']);axis(1,at=1:2,labels=paste0(c('ME','WPME'),'\nN=',format(ns,big.mark=',')))
  for(k in 1:2){
   pre<-z[z$group==c('ME','WPME')[k]&z$outcome=='rating_pre',];post<-z[z$group==c('ME','WPME')[k]&z$outcome=='rating_post',];ch<-z[z$group==c('ME','WPME')[k]&z$outcome=='change',]
   segments(k-.12,pre$estimate,k+.12,post$estimate,col='#466579',lwd=2);arrows(c(k-.12,k+.12),c(pre$low,post$low),c(k-.12,k+.12),c(pre$high,post$high),angle=90,code=3,length=.04,col=c('#6f7f88','#b64b40'))
   points(c(k-.12,k+.12),c(pre$estimate,post$estimate),pch=c(16,17),col=c('#6f7f88','#b64b40'),cex=1.1)
   text(k-.16,pre$estimate,sprintf('%.3f',pre$estimate),adj=1,cex=.65,col='#53636c');text(k+.16,post$estimate,sprintf('%.3f',post$estimate),adj=0,cex=.65,col='#b64b40')
   mtext(sprintf('%s change %+.3f (p=%.3f)',c('ME','WPME')[k],ch$estimate,ch$p),side=3,line=1.0-(k-1)*.7,cex=.63)
  }
  legend('bottomleft',legend=c('Before','After'),pch=c(16,17),col=c('#6f7f88','#b64b40'),bty='n',horiz=TRUE,cex=.75)
 }
 mtext(paste(def,'dictionary, shawarma excluded | ME and WPME shown directly'),side=3,outer=TRUE,line=1,font=2,cex=1.05)
 mtext('Full eligible food-verified samples; same restaurants before and after; each restaurant unit weight.',side=1,outer=TRUE,line=.5,cex=.75)
 mtext('Pointwise 95% county-clustered intervals. Raw group means; county-FE comparisons are separate.',side=1,outer=TRUE,line=1.6,cex=.73);dev.off()
}
