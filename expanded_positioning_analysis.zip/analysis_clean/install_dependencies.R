# Install only into this project's local library; never update system libraries.
args <- commandArgs(trailingOnly=FALSE)
here <- dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
lib <- file.path(dirname(here),'.r-library')
dir.create(lib,showWarnings=FALSE)
.libPaths(c(lib,.libPaths()))
packages <- c('fixest','data.table','jsonlite','dreamerr','sandwich','numDeriv',
              'Rcpp','stringmagic','zoo','Formula')
missing <- packages[!vapply(packages,requireNamespace,logical(1),quietly=TRUE)]
if(length(missing)) install.packages(missing,repos='https://cloud.r-project.org',lib=lib)
stopifnot(all(vapply(packages,requireNamespace,logical(1),quietly=TRUE)))
