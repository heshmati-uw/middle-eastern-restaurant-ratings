"""Losslessly restore repeated group assignments from compact archive inputs."""
from pathlib import Path
import hashlib,json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'expanded_positioning'
def main():
    cfg=json.loads((O/'compact_assignment_manifest.json').read_text())
    dest=O/'expanded_group_assignments.csv'
    if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==cfg['original_sha256']:
        print('Full assignments already match the snapshot.');return
    attrs=pd.read_csv(O/'compact_business_attributes.csv',dtype=str,keep_default_na=False)
    labels=pd.read_csv(O/'compact_mediterranean_labels.csv',dtype=str,keep_default_na=False)
    parts=[]
    for definition in cfg['definitions']:
        z=attrs.copy();z['definition']=definition;z['group']=z.frame_group
        med=z.frame_group.eq('Mediterranean label')
        mapping=labels[labels.definition.eq(definition)].set_index('gmap_id').group
        z.loc[med,'group']=z.loc[med,'gmap_id'].map(mapping)
        assert z.group.notna().all();parts.append(z[cfg['columns']])
    pd.concat(parts,ignore_index=True).to_csv(dest,index=False,lineterminator=cfg['line_terminator'])
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==cfg['original_sha256'],'Assignment reconstruction changed bytes'
    print('Lossless assignments reconstructed:',dest)
if __name__=='__main__':main()
