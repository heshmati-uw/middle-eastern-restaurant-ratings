"""Count the full Google metadata frame; select exact primary categories before outcomes."""
from pathlib import Path
import ast,json,re
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'expanded_positioning';O.mkdir(exist_ok=True)
CFG=json.loads((H/'config.json').read_text());ROOT=Path(CFG['source_root'])
CONTROLS={'American restaurant':'American','New American restaurant':'New American','Traditional American restaurant':'Traditional American','Pizza restaurant':'Pizza','Italian restaurant':'Italian','Steak house':'Steakhouse','Steakhouse':'Steakhouse','Fast food restaurant':'Fast food'}
def main():
    source=ROOT/'data/Google Reviews/Meta_data_combined.csv';parts=[];rows=0;counts={};primary_counts={}
    for x in pd.read_csv(source,usecols=['gmap_id','name','category','latitude','longitude'],chunksize=50000):
        rows+=len(x)
        # The source column is a serialized category list, not a comma-separated scalar.
        primary=x.category.fillna('').str.extract(r'''^\[\s*['"]([^'"]+)['"]''',expand=False).fillna('')
        primary_counts.update({k:primary_counts.get(k,0)+int(v) for k,v in primary.value_counts().items()})
        group=primary.map(CONTROLS)
        group.loc[primary.isin(CFG['me_categories'])]='ME'
        group.loc[primary.str.contains('mediterranean',case=False,regex=False)]='Mediterranean label'
        keep=group.notna();z=x[keep].copy();z['primary_category']=primary[keep];z['frame_group']=group[keep]
        # Assert the fast primary-category extraction against full parsing on selected records.
        parsed=z.category.map(ast.literal_eval)
        assert parsed.map(lambda a:a[0] if a else '').eq(z.primary_category).all()
        parts.append(z)
        if rows%500000==0:print('Metadata rows scanned:',rows,flush=True)
    d=pd.concat(parts,ignore_index=True)
    duplicates=int(d.duplicated('gmap_id',keep=False).sum())
    if duplicates:
        conflict=d.groupby('gmap_id')[['primary_category','latitude','longitude']].nunique(dropna=False).max(axis=1)
        assert conflict.le(1).all(),'Resolve metadata conflicts before classification'
        d=d.drop_duplicates('gmap_id')
    d.to_csv(O/'full_metadata_selected.csv',index=False)
    pd.Series(primary_counts,name='metadata_rows').rename_axis('primary_category').sort_values(ascending=False).to_csv(O/'all_primary_category_counts.csv')
    d.groupby(['frame_group','primary_category']).size().reset_index(name='businesses').to_csv(O/'full_metadata_population_counts.csv',index=False)
    audit={'metadata_rows':rows,'selected_unique_businesses':d.gmap_id.nunique(),'selected_duplicate_rows':duplicates,
           'groups':d.groupby('frame_group').size().to_dict(),'source':str(source),'bytes':source.stat().st_size,
           'note':'Counts describe the supplied Google metadata frame, not all US restaurants or restaurants operating in 2016. Primary category only.'}
    (O/'metadata_population_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
