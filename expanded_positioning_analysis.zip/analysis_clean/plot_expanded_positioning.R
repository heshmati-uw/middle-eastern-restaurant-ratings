args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages(library(data.table));out<-file.path(here,'expanded_positioning')
r<-fread(file.path(out,'expanded_comparison_results.csv'))
draw<-function(name,f){
  png(file.path(out,paste0(name,'.png')),width=2100,height=1500,res=160,type='cairo');f();dev.off()
  svg(file.path(out,paste0(name,'.svg')),width=2100/160,height=1500/160);f();dev.off()
}
controls<-c('American','New American','Traditional American','American broad','Pizza','Italian','Steakhouse','Fast food','ME','MED')
draw('expanded_wpme_baselines',function(){
  par(mfrow=c(2,2),mar=c(4,8.8,4,1),oma=c(2,0,3,0),family='sans',las=1)
  for(event in c('Election','Ban'))for(t in c(1,0)){
    d<-r[definition=='expanded_broad_pre'&weeks==4&shock==event&trump==t&grepl('^WPME vs ',comparison)]
    d[,baseline:=sub('WPME vs ','',comparison)];d<-d[match(controls,baseline)]
    y<-rev(seq_len(nrow(d)));col<-if(t==1)'#B64B40' else '#376B92'
    plot(c(-.4,.55),c(.5,10.5),type='n',yaxt='n',xlab='WPME change minus comparison-group change (stars)',ylab='',bty='l',cex.lab=.85)
    abline(v=0,lty=2,col='#8B959D');abline(h=y,col='#E7EBEE',lwd=.6)
    axis(2,at=y,labels=controls,tick=FALSE,cex.axis=.85)
    arrows(d$low,y,d$high,y,angle=90,code=3,length=.035,col=col,lwd=1.5);points(d$estimate,y,pch=16,col=col,cex=1.2)
    title(main=paste(event,if(t==1)'| Trump counties' else '| Non-Trump counties'),cex.main=1.05,
          sub=paste0('WPME restaurants: ',d$focal_restaurants[1]),cex.sub=.8)
  }
  mtext('Four-week WPME comparisons using expanded pre-election dish tags',outer=TRUE,side=3,line=1,font=2,cex=1.15)
  mtext('Equal restaurant weights; pointwise 95% county-clustered intervals. Positive means WPME gained ground relative to the named baseline.',outer=TRUE,side=1,line=.3,cex=.85)
})
defs<-c('legacy_baba','pre_baba','expanded_core_pre','expanded_broad_pre','expanded_broad_all_saved')
labels<-c('Legacy baba\nflag','Pre-election\nbaba','Pre-election\ncore dishes','Pre-election\nbroad dishes','All-saved\nbroad dishes')
draw('expanded_tag_sensitivity',function(){
  par(mfrow=c(2,2),mar=c(4,10,4,1),oma=c(2,0,3,0),family='sans',las=1)
  for(event in c('Election','Ban'))for(t in c(1,0)){
    d<-r[weeks==4&shock==event&trump==t&comparison=='WPME vs American'];d<-d[match(defs,definition)]
    y<-rev(seq_len(nrow(d)));col<-if(t==1)'#B64B40' else '#376B92'
    plot(range(c(d$low,d$high,0))+.02*c(-1,1),c(.5,5.5),type='n',yaxt='n',
      xlab='WPME minus American change (stars)',ylab='',bty='l',cex.lab=.9)
    abline(v=0,lty=2,col='#8B959D');abline(h=y,col='#E7EBEE',lwd=.6)
    axis(2,at=y,labels=paste0(labels,' (n=',d$focal_restaurants,')'),tick=FALSE,cex.axis=.8)
    arrows(d$low,y,d$high,y,angle=90,code=3,length=.035,col=col,lwd=1.5);points(d$estimate,y,pch=16,col=col,cex=1.2)
    title(main=paste(event,if(t==1)'| Trump counties' else '| Non-Trump counties'),cex.main=1.05)
  }
  mtext('Dish definitions change the WPME cohort',outer=TRUE,side=3,line=1,font=2,cex=1.15)
  mtext('Four-week windows; same expanded American frame. Panel scales differ to show wide intervals in small cohorts. All-saved tags use post-event information.',outer=TRUE,side=1,line=.3,cex=.82)
})
