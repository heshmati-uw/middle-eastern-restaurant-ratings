param([string]$Python='python',[string]$Rscript='Rscript',[switch]$RebuildSourceInputs)
$ErrorActionPreference='Stop'
if($RebuildSourceInputs){
  & $Python "$PSScriptRoot/audit_full_metadata.py"
  if($LASTEXITCODE -ne 0){throw 'Full metadata audit failed'}
  & $Python "$PSScriptRoot/prepare_expanded_positioning.py"
  if($LASTEXITCODE -ne 0){throw 'Expanded data preparation failed'}
}
if(-not(Test-Path "$PSScriptRoot/expanded_positioning/expanded_group_assignments.csv")){
  & $Python "$PSScriptRoot/materialize_expanded_inputs.py"
  if($LASTEXITCODE -ne 0){throw 'Compact input reconstruction failed'}
}
& $Rscript --vanilla "$PSScriptRoot/expanded_positioning_models.R"
if($LASTEXITCODE -ne 0){throw 'Expanded models failed'}
& $Python "$PSScriptRoot/verify_expanded_positioning.py"
if($LASTEXITCODE -ne 0){throw 'Independent expanded verification failed'}
& $Rscript --vanilla "$PSScriptRoot/plot_expanded_positioning.R"
if($LASTEXITCODE -ne 0){throw 'Expanded plots failed'}
& $Python "$PSScriptRoot/report_expanded_positioning.py"
if($LASTEXITCODE -ne 0){throw 'Expanded report failed'}
