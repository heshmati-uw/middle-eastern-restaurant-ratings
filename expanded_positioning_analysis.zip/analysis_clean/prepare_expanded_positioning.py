"""Build audited, mutually exclusive cuisine/tag groups and common-source outcomes."""
from pathlib import Path
import ast,hashlib,io,json,re,sys,unicodedata,zipfile
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'expanded_positioning';O.mkdir(exist_ok=True)
CFG=json.loads((H/'config.json').read_text());ROOT=Path(CFG['source_root'])
sys.path.insert(0,str(H.parent/'.analysis-python'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def normalize(s):
    s=unicodedata.normalize('NFKD',s.casefold()).encode('ascii','ignore').decode()
    return re.sub(r'[^\w\s]',' ',s)
def geography(meta):
    import shapely,shapefile
    from shapely.strtree import STRtree
    source=ROOT/'analysis/2025-08-18-rohan/lat to fips/cb_2018_us_county_500k.zip'
    with zipfile.ZipFile(source) as z:
        base=next(n[:-4] for n in z.namelist() if n.endswith('.shp'))
        sf=shapefile.Reader(shp=io.BytesIO(z.read(base+'.shp')),shx=io.BytesIO(z.read(base+'.shx')),dbf=io.BytesIO(z.read(base+'.dbf')))
        names=[x[0] for x in sf.fields[1:]];rec=list(sf.iterShapeRecords())
        polygons=np.array([shapely.geometry.shape(x.shape.__geo_interface__) for x in rec],dtype=object)
        fips=np.array([str(x.record[names.index('GEOID')]).zfill(5) for x in rec])
    good=meta.latitude.between(-90,90)&meta.longitude.between(-180,180);positions=np.flatnonzero(good.to_numpy())
    pts=shapely.points(meta.loc[good,'longitude'].to_numpy(),meta.loc[good,'latitude'].to_numpy())
    ix=STRtree(polygons).query(pts,predicate='intersects')
    matches=pd.DataFrame({'position':positions[ix[0]],'county_fips':fips[ix[1]]}).drop_duplicates()
    ambiguous=matches[matches.duplicated('position',keep=False)].position.nunique()
    matches=matches[~matches.duplicated('position',keep=False)]
    meta['county_fips']=pd.Series(matches.county_fips.to_numpy(),index=matches.position)
    # Rebuild shares rather than filling missing new counties with an approximation.
    vp=O/'county_vote_shares.csv'
    if not vp.exists():
        parts=[]
        for x in pd.read_csv(ROOT/'analysis/2025-08-18-rohan/lat to fips/2016-precinct-president.csv',usecols=['county_fips','votes','party','candidate_normalized'],dtype={'county_fips':'string'},encoding='latin-1',chunksize=250000,low_memory=False):
            x['county_fips']=x.county_fips.str.replace(r'\.0$','',regex=True).str.zfill(5)
            x['votes']=pd.to_numeric(x.votes,errors='raise');x['rep']=x.votes.where(x.party.eq('republican')|x.candidate_normalized.eq('trump'),0)
            parts.append(x.groupby('county_fips')[['votes','rep']].sum())
        v=pd.concat(parts).groupby('county_fips').sum();v['gop_share']=v.rep/v.votes
        v.reset_index().to_csv(vp,index=False)
    v=pd.read_csv(vp,dtype={'county_fips':'string'})
    meta=meta.merge(v[['county_fips','gop_share']],on='county_fips',how='left',validate='many_to_one')
    meta['trump']=np.where(meta.gop_share.notna(),(meta.gop_share>.5).astype(int),np.nan)
    print('Geography assigned; ambiguous businesses:',ambiguous,'missing shares:',meta.gop_share.isna().sum(),flush=True)
    return meta
def tags(meta):
    dic=json.loads((H/'expanded_dish_dictionary.json').read_text())
    r=pd.read_csv(ROOT/CFG['review_panel'],usecols=['gmap_id','review_date','rating','text','name'],low_memory=False)
    raw_review_rows=len(r)
    r=r.drop_duplicates(['gmap_id','review_date','rating','text','name']).copy()
    r['date']=pd.to_datetime(r.review_date,utc=True,errors='raise').dt.strftime('%Y-%m-%d')
    assert r.date.between('2016-07-01','2017-06-30').all()
    r=r[r.gmap_id.isin(meta.loc[meta.frame_group.eq('Mediterranean label'),'gmap_id'])].copy()
    r['normalized']=r.text.fillna('').map(normalize);r['pre']=r.date.lt('2016-11-08')
    r['has_text']=r.normalized.str.strip().ne('')
    core=list(dic['core']);shared=list(dic['shared_sensitivity']);allterms={**dic['core'],**dic['shared_sensitivity']}
    hits=[];contexts=[]
    for dish,pat in allterms.items():
        matched=r.normalized.str.contains(pat,regex=True)
        z=r.loc[matched,['gmap_id','date','pre','text','normalized']].copy();z['dish']=dish
        hits.append(z[['gmap_id','date','pre','dish']])
        # Contexts are local QA evidence only; no reviewer names or full corpus exported.
        pre=z[z.pre].drop_duplicates(['gmap_id','normalized']).head(12)
        regex=re.compile(pat)
        for row in pre.itertuples():
            m=regex.search(row.normalized);snippet=row.normalized[max(0,m.start()-70):m.end()+100]
            contexts.append({'gmap_id':row.gmap_id,'date':row.date,'dish':dish,'context':snippet,
                'possible_negation':bool(re.search(r'\b(?:no|not|never|without|dont|doesnt)\b',snippet))})
    h=pd.concat(hits,ignore_index=True)
    h.to_csv(O/'dish_review_hits.csv',index=False)
    pd.DataFrame(contexts).to_csv(O/'dish_context_audit_local.csv',index=False)
    ids=meta.loc[meta.frame_group.eq('Mediterranean label'),['gmap_id']].copy()
    for timing,mask in [('pre',r.pre),('all_saved',pd.Series(True,index=r.index))]:
        available=set(r.loc[mask&r.has_text,'gmap_id']);ids['text_'+timing]=ids.gmap_id.isin(available)
        hh=h[h.pre] if timing=='pre' else h
        for label,ds in [('baba',['baba_ghanoush']),('core',core),('broad',core+shared)]:
            positive=set(hh.loc[hh.dish.isin(ds),'gmap_id']);ids[label+'_'+timing]=ids.gmap_id.isin(positive)
            assert positive<=available
    old=pd.read_csv(H/'outputs/restaurant_groups.csv',usecols=['gmap_id','group','review_baba'])
    ids=ids.merge(old.rename(columns={'group':'legacy_group','review_baba':'legacy_baba'}),on='gmap_id',how='left',validate='one_to_one')
    ids.to_csv(O/'mediterranean_dish_flags.csv',index=False)
    h.groupby(['dish','pre']).agg(review_mentions=('gmap_id','size'),businesses=('gmap_id','nunique')).reset_index().to_csv(O/'dish_dictionary_coverage.csv',index=False)
    audit={'raw_review_rows_in_saved_panel':raw_review_rows,'deduplicated_mediterranean_review_rows':len(r),
      'pre_election_text_businesses':int(ids.text_pre.sum()),'all_saved_text_businesses':int(ids.text_all_saved.sum()),
      'main_definition':'expanded_broad_pre','cutoff_exclusive':'2016-11-08','dictionary_sha256':sha(H/'expanded_dish_dictionary.json'),
      'review_source':str(ROOT/CFG['review_panel']),'review_source_sha256':sha(ROOT/CFG['review_panel']),
      'missing_text_is_not_negative':True,'dedup_signature':['gmap_id','review_date','rating','text','name'],
      'limitations':'Saved review corpus is food-mention-screened upstream and spans July 2016–June 2017 only; classification applies only to observed Mediterranean text. Dish mentions do not prove menu availability or authenticity.'}
    (O/'dish_tag_audit.json').write_text(json.dumps(audit,indent=2))
    return ids
def classify(meta,flags):
    m=meta.merge(flags,on='gmap_id',how='left',validate='one_to_one');versions=[]
    variants={'legacy_baba':('legacy_baba',None),'pre_baba':('baba_pre','text_pre'),
      'expanded_core_pre':('core_pre','text_pre'),'expanded_broad_pre':('broad_pre','text_pre'),
      'expanded_broad_all_saved':('broad_all_saved','text_all_saved')}
    for definition,(flag,observed) in variants.items():
        z=m.copy();z['group']=z.frame_group
        med=z.frame_group.eq('Mediterranean label')
        obs=z[observed].fillna(False).astype(bool) if observed else z.legacy_group.isin(['MED','WPME'])
        pos=z[flag].fillna(0).astype(bool)
        z.loc[med,'group']='MED unknown';z.loc[med&obs&~pos,'group']='MED';z.loc[med&obs&pos,'group']='WPME'
        z['definition']=definition;versions.append(z)
    d=pd.concat(versions,ignore_index=True)
    assert not d.duplicated(['definition','gmap_id']).any()
    d[['gmap_id','definition','group','primary_category','county_fips','gop_share','trump']].to_csv(O/'expanded_group_assignments.csv',index=False)
    d.groupby(['definition','group'],dropna=False).size().reset_index(name='metadata_population').to_csv(O/'definition_population_counts.csv',index=False)
    d[d.gop_share.notna()].groupby(['definition','group','trump']).size().reset_index(name='geocoded_population').to_csv(O/'definition_county_population_counts.csv',index=False)
    # Descriptive category labels; no owner nationality inferred.
    m0=d[d.definition.eq('expanded_broad_pre')]
    m0.groupby(['group','primary_category']).size().reset_index(name='restaurants').to_csv(O/'primary_category_composition.csv',index=False)
    cc=[]
    for row in m0[m0.group.isin(['ME','WPME','MED'])].itertuples():
        for c in ast.literal_eval(row.category):cc.append((row.group,c))
    pd.DataFrame(cc,columns=['group','category']).groupby(['group','category']).size().reset_index(name='restaurants').to_csv(O/'all_category_label_composition.csv',index=False)
    return d
def outcomes(meta):
    target=set(meta.loc[meta.gop_share.notna(),'gmap_id']);source=ROOT/'data/Google Reviews/Reviews_Data_Combined.csv'
    rows=[];found=set();scanned=0;exact=0
    for x in pd.read_csv(source,chunksize=20000):
        scanned+=len(x);z=x[x.gmap_id.isin(target)]
        for ident,days,ratings,counts in z.itertuples(index=False,name=None):
            found.add(ident);ds,rs,ns=map(ast.literal_eval,[days,ratings,counts]);assert len(ds)==len(rs)==len(ns)
            for day,r,n in zip(ds,rs,ns):
                if '2016-07-04'<=day<='2017-04-03':rows.append((ident,day,float(r),float(n)))
        if scanned%500000==0:print('Outcome rows scanned:',scanned,'retained weeks:',len(rows),flush=True)
    w=pd.DataFrame(rows,columns=['gmap_id','week','rating','reviews']);before=len(w);w=w.drop_duplicates();exact=before-len(w)
    conflict=w[w.duplicated(['gmap_id','week'],keep=False)];conflict.to_csv(O/'outcome_week_conflicts.csv',index=False)
    assert conflict.empty,'Resolve conflicting same-business-week records before estimation'
    w=w[w.rating.between(1,5)&w.reviews.gt(0)]
    assert pd.to_datetime(w.week).dt.dayofweek.eq(0).all()
    w.to_csv(O/'expanded_common_weekly.csv',index=False)
    meta[meta.gmap_id.isin(target-found)].to_csv(O/'metadata_ids_missing_outcome_source.csv',index=False)
    audit={'source_business_rows':scanned,'target_geocoded_metadata_ids':len(target),'ids_found':len(found),
      'ids_missing':len(target-found),'businesses_with_weeks_in_range':w.gmap_id.nunique(),'weekly_rows':len(w),
      'exact_duplicate_weeks_removed':exact,'source':str(source),'bytes':source.stat().st_size,'mtime_ns':source.stat().st_mtime_ns,
      'metadata_geography_sha256':sha(O/'metadata_with_geography.csv'),'weekly_sha256':sha(O/'expanded_common_weekly.csv')}
    (O/'expanded_outcome_audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
def main():
    meta=pd.read_csv(O/'full_metadata_selected.csv')
    geo=O/'metadata_with_geography.csv'
    if '--use-geography-cache' in sys.argv:
        cache_audit=json.loads((O/'geography_cache_audit.json').read_text())
        assert cache_audit['selected_metadata_sha256']==sha(O/'full_metadata_selected.csv')
        assert cache_audit['geography_sha256']==sha(geo)
        meta=pd.read_csv(geo,dtype={'county_fips':'string'},float_precision='round_trip')
    else:
        meta=geography(meta);meta.to_csv(geo,index=False)
        (O/'geography_cache_audit.json').write_text(json.dumps({'selected_metadata_sha256':sha(O/'full_metadata_selected.csv'),'geography_sha256':sha(geo)},indent=2))
    flags=tags(meta);classify(meta,flags)
    if '--use-outcome-cache' not in sys.argv:outcomes(meta)
    else:
        a=json.loads((O/'expanded_outcome_audit.json').read_text())
        assert a['weekly_sha256']==sha(O/'expanded_common_weekly.csv')
        assert a['metadata_geography_sha256']==sha(geo)
        source=ROOT/'data/Google Reviews/Reviews_Data_Combined.csv'
        assert a['bytes']==source.stat().st_size and a['mtime_ns']==source.stat().st_mtime_ns
if __name__=='__main__':main()
