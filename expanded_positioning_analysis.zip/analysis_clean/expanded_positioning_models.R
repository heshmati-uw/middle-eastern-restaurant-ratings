# Same equal-restaurant change estimator, broader source frame, frozen tag variants.
args<-commandArgs(trailingOnly=FALSE)
here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest);library(jsonlite)})
out<-file.path(here,'expanded_positioning')
cfg<-fromJSON(file.path(here,'shock_specifications.json'),simplifyVector=FALSE)
specs<-c(cfg$main_windows,cfg$sensitivity_windows)
w<-fread(file.path(out,'expanded_common_weekly.csv'))
a<-fread(file.path(out,'expanded_group_assignments.csv'),colClasses=c(county_fips='character'))
a<-a[!is.na(gop_share)&group!='MED unknown'];a[,trump:=as.integer(trump)]
ssc_rule<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min')
baselines<-c('ME','MED','American','New American','Traditional American','Pizza','Italian','Steakhouse','Fast food','American broad')
pairs<-c(lapply(baselines,function(b)c('WPME',b)),list(c('ME','MED'),c('ME','American')))
results<-list();directs<-list();sizes<-list();levels<-list();skips<-list();pretests<-list();prepaths<-list()
good<-function(d,direct=FALSE){
  cells<-if(direct)d[,.(n=.N,g=uniqueN(county_fips)),by=.(treated,trump)] else d[,.(n=.N,g=uniqueN(county_fips)),by=treated]
  nrow(cells)==(if(direct)4L else 2L) && all(cells$n>=5) && all(cells$g>=2)
}
subset_pair<-function(q,pair){
  members<-if(pair[2]=='American broad')c('American','New American','Traditional American') else pair[2]
  d<-copy(q[group %chin% c(pair[1],members)]);d[,treated:=as.integer(group==pair[1])];d
}
w[,score:=rating*reviews]
for(spec in specs){
  z<-w[(week>=spec$pre_start & week<=spec$pre_end)|(week>=spec$post_start & week<=spec$post_end)]
  z[,period:=ifelse(week<=spec$pre_end,'pre','post')]
  b<-z[,.(rating=sum(score)/sum(reviews),reviews=sum(reviews),observed_weeks=.N),by=.(gmap_id,period)]
  q0<-dcast(b,gmap_id~period,value.var=c('rating','reviews','observed_weeks'))
  q0<-q0[!is.na(rating_pre)&!is.na(rating_post)];q0[,change:=rating_post-rating_pre]
  # One group-neutral period table makes every dictionary variant independently reproducible.
  fwrite(q0,file.path(out,paste0('periods_',tolower(spec$shock),'_',spec$weeks,'w.csv')))
  for(def in unique(a$definition)){
    q<-merge(q0,a[definition==def],by='gmap_id',allow.cartesian=FALSE)
    g<-q[,.(restaurants=.N,counties=uniqueN(county_fips),pre=mean(rating_pre),post=mean(rating_post),change=mean(change)),by=.(group,trump)]
    g[,`:=`(definition=def,shock=spec$shock,weeks=spec$weeks)];levels[[length(levels)+1L]]<-g
    for(pair in pairs){
      label<-paste(pair,collapse=' vs ');d<-subset_pair(q,pair)
      for(t in 0:1){
        s<-d[trump==t]
        if(!good(s)){skips[[length(skips)+1L]]<-data.table(definition=def,shock=spec$shock,weeks=spec$weeks,trump=t,comparison=label,reason='Fewer than 5 restaurants or 2 counties in a group');next}
        fit<-feols(change~treated,data=s,vcov=~county_fips,ssc=ssc_rule,notes=FALSE)
        ct<-coeftable(fit)['treated',];ci<-confint(fit)['treated',]
        stopifnot(abs(ct[1]-(mean(s[treated==1]$change)-mean(s[treated==0]$change)))<1e-10)
        G<-uniqueN(s$county_fips);stopifnot(abs(ct[4]-2*pt(abs(ct[3]),G-1,lower.tail=FALSE))<1e-10)
        results[[length(results)+1L]]<-data.table(definition=def,shock=spec$shock,weeks=spec$weeks,trump=t,
          comparison=label,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(s),
          focal_restaurants=sum(s$treated),control_restaurants=sum(1-s$treated),counties=G,
          focal_counties=uniqueN(s[treated==1]$county_fips),control_counties=uniqueN(s[treated==0]$county_fips),
          focal_pre=mean(s[treated==1]$rating_pre),focal_post=mean(s[treated==1]$rating_post),
          control_pre=mean(s[treated==0]$rating_pre),control_post=mean(s[treated==0]$rating_post))
      }
      if(good(d,TRUE)){
        fit<-feols(change~treated*trump,data=d,vcov=~county_fips,ssc=ssc_rule,notes=FALSE)
        ct<-coeftable(fit)['treated:trump',];ci<-confint(fit)['treated:trump',]
        directs[[length(directs)+1L]]<-data.table(definition=def,shock=spec$shock,weeks=spec$weeks,
          comparison=label,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),counties=uniqueN(d$county_fips))
      }
    }
  }
}
r<-rbindlist(results);di<-rbindlist(directs);g<-rbindlist(levels)
# Main WPME baseline family includes all ten comparison choices; no baseline selected by significance.
r[grepl('^WPME vs ',comparison),p_holm_baselines:=p.adjust(p,'holm'),by=.(definition,shock,weeks,trump)]
di[grepl('^WPME vs ',comparison),p_holm_baselines:=p.adjust(p,'holm'),by=.(definition,shock,weeks)]
r[,p_holm_all_specifications:=p.adjust(p,'holm')]
di[,p_holm_all_specifications:=p.adjust(p,'holm')]
fwrite(r,file.path(out,'expanded_comparison_results.csv'))
fwrite(di,file.path(out,'expanded_county_difference_results.csv'))
fwrite(g,file.path(out,'expanded_sample_sizes_and_means.csv'))
skipped<-if(length(skips))rbindlist(skips,fill=TRUE) else data.table(definition=character(),shock=character(),weeks=integer(),trump=integer(),comparison=character(),reason=character())
fwrite(skipped,file.path(out,'skipped_comparisons.csv'))
# Four-week primary-definition pre-trend checks on fixed history-balanced cohorts.
pcfg<-fromJSON(file.path(here,'pretrend_specifications.json'),simplifyVector=FALSE)
for(spec in pcfg$shocks){
  q0<-fread(file.path(out,paste0('periods_',tolower(spec$shock),'_4w.csv')))
  cohort<-merge(q0,a[definition=='expanded_broad_pre'],by='gmap_id')
  bins<-list()
  for(bl in spec$blocks){
    z<-w[gmap_id %chin% cohort$gmap_id & week>=bl$start & week<=bl$end]
    b<-z[,.(rating=sum(score)/sum(reviews)),by=gmap_id];b[,block:=bl$block];bins[[length(bins)+1L]]<-b
  }
  b<-rbindlist(bins);complete<-b[,.(n=.N),by=gmap_id][n==length(spec$blocks)]$gmap_id
  b<-b[gmap_id %chin% complete]
  wide<-dcast(b,gmap_id~block,value.var='rating');wide<-merge(wide,cohort[,.(gmap_id,group,county_fips,trump)],by='gmap_id')
  earlier<-sort(sapply(spec$blocks,function(x)x$block));earlier<-earlier[earlier< -1]
  for(pair in pairs){
    d0<-subset_pair(wide,pair);label<-paste(pair,collapse=' vs ')
    for(t in 0:2){
      d<-if(t==2)copy(d0) else copy(d0[trump==t])
      if(!good(d,t==2))next
      X<-if(t==2)cbind(1,d$treated,d$trump,d$treated*d$trump) else cbind(1,d$treated)
      Y<-sapply(earlier,function(bl)d[[as.character(bl)]]-d[['-1']]);Y<-matrix(Y,nrow=nrow(d))
      A<-solve(crossprod(X));B<-A%*%crossprod(X,Y);E<-Y-X%*%B
      h<-as.vector(X%*%A[,ncol(X)]);U<-rowsum(E*h,d$county_fips);G<-nrow(U);N<-nrow(d);K<-ncol(X)
      V<-crossprod(U)*G/(G-1)*(N-1)/(N-K);beta<-as.numeric(B[ncol(X),]);q<-length(beta)
      if(qr(V)$rank<q)next
      F<-as.numeric(t(beta)%*%solve(V,beta)/q);p<-pf(F,q,G-1,lower.tail=FALSE)
      pretests[[length(pretests)+1L]]<-data.table(shock=spec$shock,trump=t,comparison=label,p=p,joint_F=F,restrictions=q,
        restaurants=N,focal_restaurants=sum(d$treated),control_restaurants=sum(1-d$treated),counties=G)
    }
  }
}
pr<-rbindlist(pretests)
pr[,p_holm_all_pretests:=p.adjust(p,'holm')]
fwrite(pr,file.path(out,'expanded_four_week_pretrend_tests.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'expanded_R_session.txt'))
cat('Estimated subgroup comparisons:',nrow(r),'direct county differences:',nrow(di),'pretrend checks:',nrow(pr),'\n')
print(r[definition=='expanded_broad_pre'&weeks==4])
