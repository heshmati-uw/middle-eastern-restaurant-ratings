"""Independently verify group construction, period means and county-clustered estimates."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'expanded_positioning'
def fit(d,direct):
    t=d.treated.to_numpy(dtype=float);tr=d.trump.to_numpy(dtype=float)
    X=np.column_stack([np.ones(len(d)),t,tr,t*tr] if direct else [np.ones(len(d)),t])
    y=d.change.to_numpy();A=np.linalg.inv(X.T@X);beta=A@X.T@y;E=y-X@beta
    codes=pd.factorize(d.county_fips)[0];G=codes.max()+1;U=np.zeros((G,X.shape[1]))
    np.add.at(U,codes,X*E[:,None])
    V=A@U.T@U@A*G/(G-1)*(len(d)-1)/(len(d)-X.shape[1])
    return beta[-1],np.sqrt(V[-1,-1]),G
def members(pair):
    focal,baseline=pair.split(' vs ')
    return focal,['American','New American','Traditional American'] if baseline=='American broad' else [baseline]
def main():
    a=pd.read_csv(O/'expanded_group_assignments.csv',dtype={'county_fips':str})
    assert not a.duplicated(['definition','gmap_id']).any()
    flags=pd.read_csv(O/'mediterranean_dish_flags.csv')
    for definition,flag,observed in [('expanded_broad_pre','broad_pre','text_pre'),('expanded_core_pre','core_pre','text_pre'),('pre_baba','baba_pre','text_pre')]:
        z=a[a.definition.eq(definition)].merge(flags,on='gmap_id',how='inner',validate='one_to_one')
        expected=np.where(~z[observed],'MED unknown',np.where(z[flag],'WPME','MED'))
        assert np.array_equal(z.group.to_numpy(),expected)
    hits=pd.read_csv(O/'dish_review_hits.csv');assert hits.loc[hits.pre,'date'].lt('2016-11-08').all()
    w=pd.read_csv(O/'expanded_common_weekly.csv');w['score']=w.rating*w.reviews
    cfg=json.loads((H/'shock_specifications.json').read_text());stats=[];tables={}
    for spec in cfg['main_windows']+cfg['sensitivity_windows']:
        key=(spec['shock'],spec['weeks'])
        x=w[w.week.between(spec['pre_start'],spec['pre_end'])|w.week.between(spec['post_start'],spec['post_end'])].copy()
        x['period']=np.where(x.week<=spec['pre_end'],'pre','post')
        p=x.groupby(['gmap_id','period']).agg(score=('score','sum'),reviews=('reviews','sum'),observed_weeks=('week','size'))
        p['rating']=p.score/p.reviews;p=p[['rating','reviews','observed_weeks']].unstack('period').dropna()
        p.columns=['_'.join(c) for c in p.columns];p=p.reset_index();p['change']=p.rating_post-p.rating_pre
        saved=pd.read_csv(O/f'periods_{spec["shock"].lower()}_{spec["weeks"]}w.csv')
        check=p.merge(saved,on='gmap_id',suffixes=('_manual','_saved'),validate='one_to_one')
        assert len(check)==len(p)==len(saved)
        for c in ['rating_pre','rating_post','reviews_pre','reviews_post','observed_weeks_pre','observed_weeks_post','change']:
            assert (check[c+'_manual']-check[c+'_saved']).abs().max()<1e-11
        tables[key]=saved
    rs=pd.read_csv(O/'expanded_comparison_results.csv');ds=pd.read_csv(O/'expanded_county_difference_results.csv')
    count=0;errors=[]
    for (definition,shock,weeks),rows in rs.groupby(['definition','shock','weeks']):
        p=tables[(shock,weeks)].merge(a[a.definition.eq(definition)&a.group.ne('MED unknown')&a.gop_share.notna()],on='gmap_id',validate='one_to_one')
        for row in rows.itertuples():
            focal,bs=members(row.comparison);d=p[p.group.isin([focal]+bs)&p.trump.eq(row.trump)].copy();d['treated']=d.group.eq(focal).astype(int)
            b,se,G=fit(d,False);err=max(abs(b-row.estimate),abs(se-row.se));assert err<1e-10
            assert len(d)==row.restaurants and d.treated.sum()==row.focal_restaurants and G==row.counties
            errors.append(err);count+=1
        for row in ds[ds.definition.eq(definition)&ds.shock.eq(shock)&ds.weeks.eq(weeks)].itertuples():
            focal,bs=members(row.comparison);d=p[p.group.isin([focal]+bs)].copy();d['treated']=d.group.eq(focal).astype(int)
            b,se,G=fit(d,True);err=max(abs(b-row.estimate),abs(se-row.se));assert err<1e-10
            assert len(d)==row.restaurants and G==row.counties;errors.append(err);count+=1
    # Independently reconstruct history-balanced pretrend nulls.
    tests=pd.read_csv(O/'expanded_four_week_pretrend_tests.csv');pcfg=json.loads((H/'pretrend_specifications.json').read_text())
    for spec in pcfg['shocks']:
        cohort=tables[(spec['shock'],4)].merge(a[a.definition.eq('expanded_broad_pre')&a.group.ne('MED unknown')&a.gop_share.notna()],on='gmap_id',validate='one_to_one')
        rows=[]
        for block in spec['blocks']:
            z=w[w.gmap_id.isin(cohort.gmap_id)&w.week.between(block['start'],block['end'])]
            b=z.groupby('gmap_id')[['score','reviews']].sum();b['rating']=b.score/b.reviews;b['block']=block['block'];rows.append(b.reset_index()[['gmap_id','rating','block']])
        b=pd.concat(rows).pivot(index='gmap_id',columns='block',values='rating').dropna().reset_index().merge(cohort[['gmap_id','group','county_fips','trump']],on='gmap_id')
        earlier=sorted(c['block'] for c in spec['blocks'] if c['block']<-1)
        for row in tests[tests.shock.eq(spec['shock'])].itertuples():
            focal,bs=members(row.comparison);d=b[b.group.isin([focal]+bs)].copy()
            if row.trump!=2:d=d[d.trump.eq(row.trump)]
            t=d.group.eq(focal).to_numpy(dtype=float);tr=d.trump.to_numpy(dtype=float)
            X=np.column_stack([np.ones(len(d)),t,tr,t*tr] if row.trump==2 else [np.ones(len(d)),t]);A=np.linalg.inv(X.T@X)
            Y=np.column_stack([d[c]-d[-1] for c in earlier]);B=A@X.T@Y;E=Y-X@B;h=X@A[:,-1]
            codes=pd.factorize(d.county_fips)[0];G=codes.max()+1;U=np.zeros((G,Y.shape[1]));np.add.at(U,codes,E*h[:,None])
            V=U.T@U*G/(G-1)*(len(d)-1)/(len(d)-X.shape[1]);beta=B[-1]
            F=float(beta@np.linalg.solve(V,beta)/len(earlier));assert abs(F-row.joint_F)<1e-9
            assert len(d)==row.restaurants;errors.append(abs(F-row.joint_F))
    result={'restaurant_period_windows_verified':len(tables),'subgroup_estimates_and_county_SE_verified':len(rs),
            'direct_estimates_and_county_SE_verified':len(ds),'history_pretrend_joint_statistics_verified':len(tests),
            'pre_election_group_construction_verified':True,'max_numerical_error':max(errors)}
    (O/'expanded_independent_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
