"""Audited report: full frame, cuisine construction, dish tags and baseline sensitivities."""
from pathlib import Path
from html import escape
from html.parser import HTMLParser
import json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'expanded_positioning'
MAIN='expanded_broad_pre'
def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+escape(str(x))+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def star(p):return '***' if p<.01 else '**' if p<.05 else '*' if p<.1 else ''
def fmt(p):return '<.001' if p<.001 else f'{p:.3f}'
def main():
    r=pd.read_csv(O/'expanded_comparison_results.csv');di=pd.read_csv(O/'expanded_county_difference_results.csv')
    s=pd.read_csv(O/'expanded_sample_sizes_and_means.csv');pop=pd.read_csv(O/'definition_population_counts.csv')
    county=pd.read_csv(O/'definition_county_population_counts.csv');comp=pd.read_csv(O/'primary_category_composition.csv')
    labels=pd.read_csv(O/'all_category_label_composition.csv');dish=pd.read_csv(O/'dish_dictionary_coverage.csv')
    tag=json.loads((O/'dish_tag_audit.json').read_text());meta=json.loads((O/'metadata_population_audit.json').read_text())
    audit=json.loads((O/'expanded_outcome_audit.json').read_text());v=json.loads((O/'expanded_independent_verification.json').read_text())
    pre=pd.read_csv(O/'expanded_four_week_pretrend_tests.csv');dictionary=json.loads((H/'expanded_dish_dictionary.json').read_text())
    groups=['ME','WPME','MED','MED unknown','American','New American','Traditional American','Pizza','Italian','Steakhouse','Fast food']
    pairs=['WPME vs '+x for x in ['American','New American','Traditional American','American broad','Pizza','Italian','Steakhouse','Fast food','ME','MED']]
    body='''<h1>Expanded restaurant positioning and comparison groups</h1>
    <p class="lead">Using primary categories and dish tags frozen before Election Day, WPME does not show a clear four-week decline relative to American, Pizza, Italian, Steakhouse or Fast-food restaurants in Trump counties. In non-Trump counties, WPME loses ground relative to Fast food after the election (−0.096 stars; raw p&lt;.001; Holm p=.002 across ten baseline choices). The expanded metadata frame also weakens the previous ME election finding. These are descriptive rating changes, not validated causal election or ban effects.</p>
    <p><strong>User-selected definitions:</strong> primary Mediterranean category; dish evidence dated before November 8, 2016, frozen for both election and ban. Existing primary-ME categories retain precedence and groups remain mutually exclusive. Four-week windows are primary working comparisons; six- and ten-week windows remain sensitivity analyses. Each restaurant receives equal weight, after review-count-weighted aggregation within each restaurant-period. Restaurants must have reviews on both sides.</p>
    <h2>Population frame versus analysis sample</h2>'''
    body+=f'<p>The supplied metadata file has {meta["metadata_rows"]:,} rows. The selected categories contain {meta["selected_unique_businesses"]:,} unique business IDs; {audit["target_geocoded_metadata_ids"]:,} have usable county/vote data. All of those IDs occur in the combined weekly outcome source; {audit["businesses_with_weeks_in_range"]:,} have positive-review weeks somewhere in July 2016–April 2017. These are counts in the supplied Google frame, not an estimate of all US restaurants or of restaurants operating on Election Day.</p>'
    rows=[]
    for group in groups:
        n=int(pop[pop.definition.eq(MAIN)&pop.group.eq(group)].iloc[0].metadata_population)
        geo=county[county.definition.eq(MAIN)&county.group.eq(group)]
        row=[group,f'{n:,}']
        for t in [1,0]:row.append(f'{int(geo[geo.trump.eq(t)].geocoded_population.sum()):,}')
        for event in ['Election','Ban']:
            for t in [1,0]:
                x=s[s.definition.eq(MAIN)&s.weeks.eq(4)&s.shock.eq(event)&s.trump.eq(t)&s.group.eq(group)]
                row.append('Excluded' if group=='MED unknown' else f'{int(x.restaurants.sum()):,}')
        rows.append(row)
    body+=table(['Group','Metadata pool','Geocoded Trump pool','Geocoded non-Trump pool','Election 4w Trump','Election 4w non-Trump','Ban 4w Trump','Ban 4w non-Trump'],rows)
    body+='''<p>“Population” here is the operational frame before the event-review requirement. Its sizes are not the regression N. Mediterranean coverage is incomplete: 5,442 have the primary label, 2,765 have usable pre-election text, and 2,677 remain unknown. Among the observed-text subset, 1,719 meet the broad dish rule and 1,046 have no detected tag. The four-week comparison contains only those with outcome reviews before and after; missing ratings are not zero stars. American broad pools American, New American and Traditional American; it overlaps the separate American baseline deliberately as a sensitivity.</p>
    <h2>How ME and WPME are constructed</h2>
    <p><strong>ME:</strong> The first Google category matches the fixed project category list, independently of food mentions. The full metadata frame replaces the old food-screened focal universe. This finds 3,227 primary-ME businesses, including 1,705 absent from the saved restaurant-group file. The category labels below describe cuisine/positioning; they do not identify owners’ nationality, ethnicity, religion, or perceived race.</p>'''
    me=comp[comp.group.eq('ME')].sort_values('restaurants',ascending=False)
    body+=table(['Observed primary-ME label','Businesses in metadata frame'],[[x.primary_category,f'{x.restaurants:,}'] for x in me.itertuples()])
    body+='<p>The complete fixed category list also includes Iraqi, Palestinian, Jordanian, Kuwaiti, Qatari, Bahraini and Omani labels, although none appears as a primary category in this source frame. Turkish, Israeli and Greek are not explicit entries in the current ME category list. A restaurant from one of those cuisines may still be included if its primary label is Middle Eastern, Halal or another listed category. Halal, Kebab and generic Middle Eastern labels are not nationality-specific and can capture cuisines outside a narrow geographic Middle East definition.</p>'
    body+='''<p><strong>WPME:</strong> Primary category contains Mediterranean, plus at least one pre-election review mentioning a dictionary dish. This is the user’s operational definition of a Mediterranean-labeled restaurant serving Middle Eastern-associated food. It is not evidence about owner identity or whether consumers see the business as “white.” ME and Mediterranean-primary groups cannot overlap under this rule.</p>
    <p><strong>MED (“true Mediterranean” proxy):</strong> Primary Mediterranean label, at least one usable pre-election review text, and no detected dish tag. We call it MED/no detected ME-dish tag because the absence of a mention does not establish that the restaurant serves no such dishes or that its cuisine is authentically/non-authentically Mediterranean. No usable text means unknown and exclusion from WPME–MED tests.</p>
    <p>The WPME pool has secondary category labels including Middle Eastern (410), Greek (260), Lebanese (188), Turkish (103), Halal (107), and Persian (52). These labels overlap; they are not a nationality partition. Country-specific identities cannot be recovered from the primary Mediterranean label or dish names alone.</p>
    <h2>Expanded dish evidence</h2>
    <p>The main broad dictionary adds shawarma, kibbeh, fattoush, muhammara, manakish, mujaddara, mansaf, maqluba, musakhan, koshari, kabsa, several Persian dishes (ghormeh sabzi, fesenjan, tahdig, koobideh and others), Afghan-associated terms such as bolani/mantu/qabili pulao, and lahmacun. It also includes shared-dish terms such as hummus, falafel, kebab, kofta, tabbouleh, labneh, dolma, shakshuka and baklava. Shared foods are intentionally separated into a sensitivity tier because they also occur in Greek, Turkish, Balkan and other cuisines. Generic pita/rice/lamb/salad/wrap/grill terms are excluded.</p>
    <p>The conservative core dictionary excludes the shared tier. The dictionary and spelling variants were fixed before inspecting the new outcome estimates. It uses English/Romanized spellings, not a comprehensive Arabic/Persian-language classifier. Mentions are proxies for offerings; they can discuss an unavailable dish, a comparison restaurant or a negative experience. Local context snippets were inspected for rare dish names and common terms; this is not a validated precision/recall study. No reviewer names are exported in the analysis artifacts.</p>'''
    variants=['legacy_baba','pre_baba','expanded_core_pre','expanded_broad_pre','expanded_broad_all_saved']
    rows=[]
    for definition in variants:
        x=pop[pop.definition.eq(definition)].set_index('group').metadata_population
        row=[definition,int(x['WPME']),int(x['MED']),int(x['MED unknown'])]
        for event in ['Election','Ban']:
            z=s[s.definition.eq(definition)&s.weeks.eq(4)&s.shock.eq(event)&s.trump.eq(1)&s.group.eq('WPME')]
            row.append(int(z.restaurants.sum()))
        rows.append(row)
    body+=table(['Definition','Tagged WPME frame','MED/no tag frame','Unknown frame','Election Trump WPME N','Ban Trump WPME N'],rows)
    body+='''<p>The legacy baba flag can use reviews outside the saved July 2016–June 2017 period, including after the events. Pre-election baba alone identifies only 113 Mediterranean businesses in the available text. Expanded core tags identify 661; broad tags identify 1,719. All-saved broad tags identify 2,717 but use post-event information and are not the main definition. Changes across rows combine differences in timing, dictionary and eligible restaurant composition.</p>'''
    dh=dish[dish.pre].sort_values('businesses',ascending=False)
    body+=table(['Dish tag','Pre-election Mediterranean businesses with a mention','Review mentions'],[[x.dish,int(x.businesses),int(x.review_mentions)] for x in dh.itertuples()])
    body+='<h2>Four-week WPME results across comparison groups</h2><p>Each entry is the WPME after-minus-before change minus the baseline change, in stars, with the raw two-sided county-clustered p-value in parentheses. Positive means WPME gained ground. * p&lt;.10; ** p&lt;.05; *** p&lt;.01. These stars do not adjust for testing multiple baselines.</p>'
    q=r[r.definition.eq(MAIN)&r.weeks.eq(4)];rows=[]
    for pair in pairs:
        row=[pair.removeprefix('WPME vs ')]
        for event in ['Election','Ban']:
            for t in [1,0]:
                x=q[q.comparison.eq(pair)&q.shock.eq(event)&q.trump.eq(t)].iloc[0]
                row.append(f'{x.estimate:+.3f}{star(x.p)} ({fmt(x.p)})')
        rows.append(row)
    body+=table(['WPME versus','Election Trump','Election non-Trump','Ban Trump','Ban non-Trump'],rows)
    body+='<img src="expanded_wpme_baselines.png" alt="WPME four-week comparisons by event and county type">'
    body+='''<p><strong>Multiplicity:</strong> Holm corrections are exported across the ten WPME baselines for each definition × event × window × county stratum, and separately across all 720 subgroup comparisons. Election WPME–Fast food in non-Trump counties has raw p=.000195, within-baseline-family p=.00195, and all-specification p=.140. Ban non-Trump WPME–Pizza has raw p=.00863 and within-family p=.0863; WPME–Fast food has raw p=.00886 and the same adjusted p=.0863. The election Trump WPME–MED p=.082 becomes .823 within its baseline family. These are baseline/window/dictionary experiments, not prespecified confirmatory tests.</p>
    <p>The non-Trump election WPME–Fast food contrast is −.096, −.079 and −.056 in the four-, six- and ten-week windows, respectively; within-window baseline-family p-values are .002, .029 and .040. Trump-county WPME–Fast food contrasts are not statistically clear in any of those election windows. Comparing subgroup significance is not itself a test of the county difference.</p>
    <h2>Direct differences across county types</h2>'''
    q=di[di.definition.eq(MAIN)&di.weeks.eq(4)]
    body+=table(['Event','Comparison','Trump minus non-Trump difference','Raw p','Holm p across ten WPME baselines'],[[x.shock,x.comparison,f'{x.estimate:+.3f}{star(x.p)}',fmt(x.p),'' if pd.isna(x.p_holm_baselines) else fmt(x.p_holm_baselines)] for x in q.itertuples()])
    body+='<h2>Dictionary sensitivity: WPME versus American</h2><img src="expanded_tag_sensitivity.png" alt="WPME vs American across five dish classifications">'
    body+='''<h2>What happened to the earlier ME election result?</h2>
    <p>With the same four-week dates but the full metadata ME/control frame, ME–American in Trump counties is −0.136 (p=.164), versus the previous −0.249 (p=.008). The direct county-type difference is −0.152 (p=.142), versus −0.217 (p=.031) previously. All 92 earlier Trump ME restaurants remain; nine additional restaurants bring the new sample to 101. The retained 92 have mean change −.205, while the nine additions have mean change +.866. American controls also expand from 3,001 to 6,572. This is a substantive sample-definition sensitivity, not a pre-trend correction and not grounds to prefer one cohort because of its p-value. The old result is preserved in the existing project outputs.</p>
    <h2>Pre-trends and causal limits</h2>
    <p>Longer-history diagnostics use the same four-week primary-definition cohorts restricted to restaurants reviewed in every plotted four-week block. Election uses three pre-blocks; ban uses two entirely post-election pre-blocks. Joint county-clustered tests cover both county strata and the direct county-type gap. These are smaller history-balanced subsets, not a test on every original restaurant. Non-rejection is not proof of parallel trends. The full metadata removes the earlier food-screen restriction for ME and controls, but WPME/MED are still limited by the food-screened text corpus, measured review availability, contemporary category labels and potentially changing reviewers.</p>'''
    body+=table(['Event','County type (2 = direct difference)','Comparison','Joint pre-trend p','History N','WPME/first-group N'],[[x.shock,int(x.trump),x.comparison,fmt(x.p)+star(x.p),int(x.restaurants),int(x.focal_restaurants)] for x in pre.itertuples()])
    body+='''<h2>All windows and definitions</h2><p>The interactive table below includes four-, six- and ten-week windows and all five tag definitions. It contains the two extra ME comparisons as well. American broad is a pooled alternative, not an additional mutually exclusive category.</p>
    <label>Definition <select id="definition"></select></label> <label>Weeks each side <select id="weeks"><option>4</option><option>6</option><option>10</option></select></label>
    <div id="results"></div><h3>Direct county-type differences</h3><div id="direct"></div>'''
    # Controlled category strings only; escape the JSON closing-script sequence defensively.
    rd=r.fillna('').to_dict('records');dd=di.fillna('').to_dict('records')
    js='''const R=DATA_R,D=DATA_D;
    const sel=document.getElementById('definition'),w=document.getElementById('weeks');
    [...new Set(R.map(x=>x.definition))].forEach(v=>{let o=document.createElement('option');o.value=v;o.textContent=v;sel.appendChild(o)});sel.value='expanded_broad_pre';
    const p=x=>x<.001?'&lt;.001':Number(x).toFixed(3),stars=x=>x<.01?'***':x<.05?'**':x<.1?'*':'';
    function render(){let keep=x=>x.definition===sel.value&&x.weeks===Number(w.value);
      document.getElementById('results').innerHTML='<div class="scroll"><table><tr><th>Event</th><th>County</th><th>Comparison</th><th>Relative change</th><th>p</th><th>Holm baseline p</th><th>First group N</th><th>Baseline N</th></tr>'+R.filter(keep).map(x=>'<tr><td>'+x.shock+'</td><td>'+(x.trump?'Trump':'Non-Trump')+'</td><td>'+x.comparison+'</td><td>'+Number(x.estimate).toFixed(3)+stars(x.p)+'</td><td>'+p(x.p)+'</td><td>'+(x.p_holm_baselines===''?'':p(x.p_holm_baselines))+'</td><td>'+x.focal_restaurants+'</td><td>'+x.control_restaurants+'</td></tr>').join('')+'</table></div>';
      document.getElementById('direct').innerHTML='<div class="scroll"><table><tr><th>Event</th><th>Comparison</th><th>Trump minus non-Trump</th><th>p</th><th>Holm baseline p</th></tr>'+D.filter(keep).map(x=>'<tr><td>'+x.shock+'</td><td>'+x.comparison+'</td><td>'+Number(x.estimate).toFixed(3)+stars(x.p)+'</td><td>'+p(x.p)+'</td><td>'+(x.p_holm_baselines===''?'':p(x.p_holm_baselines))+'</td></tr>').join('')+'</table></div>';
    }sel.onchange=render;w.onchange=render;render();'''
    js=js.replace('DATA_R',json.dumps(rd).replace('</','<\\/')).replace('DATA_D',json.dumps(dd).replace('</','<\\/'))
    body+='<script>'+js+'</script>'
    body+='<h2>Verification and files</h2>'
    body+=f'<p>Independent NumPy calculations reproduce {v["subgroup_estimates_and_county_SE_verified"]} subgroup estimates and county standard errors, {v["direct_estimates_and_county_SE_verified"]} direct county differences, all six restaurant-period constructions, and {v["history_pretrend_joint_statistics_verified"]} joint history tests. Maximum discrepancy: {v["max_numerical_error"]:.2g}. On 264,141 overlapping weekly records, new and previous inputs have exactly identical ratings and review counts. Six IDs have differences against the saved old county/share mapping; all new analyses consistently use coordinates from the full metadata and the supplied county polygons/vote source, with disagreement records exported.</p>'
    body+='<p>Dish examples and shared-cuisine context: <a href="https://ich.unesco.org/en/RL/al-man-ouche-an-emblematic-culinary-practice-in-lebanon-02000">UNESCO on man’ouché</a>, <a href="https://edutravel.visitjordan.com/en/page/79/Food-and-Drinks">Jordan food traditions</a>, <a href="https://goturkiye.com/gastronomy/southeastern-anatolia">Türkiye regional cuisine</a>. These sources inform dictionary context; they do not validate review-tag accuracy.</p>'
    files=['metadata_population_audit.json','full_metadata_population_counts.csv','definition_population_counts.csv','definition_county_population_counts.csv','dish_tag_audit.json','mediterranean_dish_flags.csv','dish_dictionary_coverage.csv','primary_category_composition.csv','all_category_label_composition.csv','expanded_comparison_results.csv','expanded_county_difference_results.csv','expanded_sample_sizes_and_means.csv','expanded_four_week_pretrend_tests.csv','expanded_independent_verification.json','expanded_outcome_audit.json','old_new_geography_disagreements.csv','ME_trump_election_cohort_summary.csv','../expanded_dish_dictionary.json','../audit_full_metadata.py','../prepare_expanded_positioning.py','../expanded_positioning_models.R','../verify_expanded_positioning.py','../plot_expanded_positioning.R','../report_expanded_positioning.py']
    body+='<ul>'+''.join(f'<li><a href="{x}">{escape(x)}</a></li>' for x in files)+'</ul>'
    style='body{font:16px/1.6 system-ui;max-width:1400px;margin:35px auto;padding:0 24px;color:#26343d}h1,h2{color:#173f46}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:9px;border-bottom:1px solid #d9e2e6}th{background:#eef4f5}.scroll{overflow-x:auto}img{width:100%;height:auto}.lead{font-size:19px}a{color:#17657d}select{font:inherit;padding:6px;margin:10px}'
    path=O/'expanded_positioning_report.html';path.write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Expanded positioning and baselines</title><style>'+style+'</style><body>'+body+'</body></html>',encoding='utf-8')
    class Links(HTMLParser):
        def handle_starttag(self,tag,attrs):
            a=dict(attrs);url=a.get('href',a.get('src',''))
            if url and not url.startswith(('http','#')):assert (O/url).exists(),url
    Links().feed(path.read_text(encoding='utf-8'))
    print(path)
if __name__=='__main__':main()
