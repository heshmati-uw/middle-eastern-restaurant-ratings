"""Read-only audit of raw Google inputs versus current analytical restaurant data."""
from pathlib import Path
import collections,gzip,json,re,time
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'raw_inputs_audit';O.mkdir(exist_ok=True)
cfg=json.loads((H/'config.json').read_text());root=Path(cfg['source_root']);src=root/'analysis/2025-08-18-rohan/inputs'
inventory=[{'file':p.name,'kind':p.name.split('-')[0],'bytes':p.stat().st_size} for p in sorted(src.iterdir()) if p.is_file()]
pd.DataFrame(inventory).to_csv(O/'file_inventory.csv',index=False)
current=pd.read_csv(H/'precinct_core/restaurant_precinct_assignments.csv',dtype={'county_fips':str})
meta=pd.read_csv(H/'expanded_positioning/metadata_with_geography.csv',usecols=['gmap_id','primary_category'])
focus=meta[meta.primary_category.isin(cfg['me_categories']+['Mediterranean restaurant'])].copy()
focus['population_group']=focus.primary_category.map(lambda x:'Primary Mediterranean' if x=='Mediterranean restaurant' else 'Primary ME')
target=set(focus.gmap_id);current_ids=set(current.gmap_id)
fields=['name','address','gmap_id','description','latitude','longitude','category','avg_rating','num_of_reviews','price','hours','MISC','state','relative_results','url']
extras=['description','avg_rating','num_of_reviews','price','hours','state','relative_results']
def present(v):return v is not None and v!='' and v!=[] and v!={}
record={};schemas=collections.Counter();misc=collections.Counter();misc_values=collections.defaultdict(collections.Counter);byfile=[];price_values=collections.Counter();status_values=collections.Counter();conflicts=collections.Counter()
idpat=re.compile(r'"gmap_id"\s*:\s*"([^"\\]+)"')
for f in sorted(src.glob('meta-*.json.gz')):
 n=0;found=0;sample=0
 with gzip.open(f,'rt',encoding='utf-8') as stream:
  for line in stream:
   n+=1;m=idpat.search(line)
   if n<=1000 or (m and m.group(1) in target):row=json.loads(line)
   else:continue
   if n<=1000:
    sample+=1;schemas.update(row.keys())
   gid=row.get('gmap_id')
   if gid not in target:continue
   found+=1
   if gid not in record:record[gid]={'gmap_id':gid,'metadata_rows':0,**{x:False for x in fields if x!='gmap_id'},'misc_keys':set(),'sources':set(),'price_values':set(),'status_values':set()}
   r=record[gid];r['metadata_rows']+=1;r['sources'].add(f.name)
   for k in fields:
    if k!='gmap_id':r[k]|=present(row.get(k))
   if present(row.get('price')):r['price_values'].add(str(row['price']));price_values[str(row['price'])]+=1
   if present(row.get('state')):r['status_values'].add(str(row['state']));status_values[str(row['state'])]+=1
   for k,values in (row.get('MISC') or {}).items():
    if present(values):
     r['misc_keys'].add(k);misc[k]+=1
     for val in values if isinstance(values,list) else [values]:misc_values[k][str(val)]+=1
 byfile.append({'file':f.name,'rows_scanned':n,'focus_metadata_rows':found,'schema_sample_rows':sample})
 print(f.name,n,found,flush=True)

rr=[]
for gid,r in record.items():
 rr.append({**{k:v for k,v in r.items() if not isinstance(v,set)},'misc_keys':' | '.join(sorted(r['misc_keys'])),'source_files':' | '.join(sorted(r['sources'])),'price_levels':' | '.join(sorted(r['price_values'])),'status_values':' | '.join(sorted(r['status_values'])),'conflicting_price':len(r['price_values'])>1})
avail=pd.DataFrame(rr).rename(columns={x:'has_'+x for x in fields if x!='gmap_id'})
avail=focus.merge(avail,on='gmap_id',how='left',validate='one_to_one');avail['in_current_core_population']=avail.gmap_id.isin(current_ids)
avail=avail.merge(current[['gmap_id','group']],on='gmap_id',how='left',validate='one_to_one')
avail['metadata_matched']=avail.metadata_rows.notna()
for col in ['has_'+k for k in fields if k!='gmap_id']:avail[col]=avail[col].fillna(False).astype(bool)
avail.to_csv(O/'business_field_availability.csv',index=False)
pd.DataFrame(byfile).to_csv(O/'metadata_scan_counts.csv',index=False)
rows=[]
for label,sub in [('All primary ME and Mediterranean',avail),('Current core population',avail[avail.in_current_core_population]),*[(g,avail[avail.group.eq(g)]) for g in ['ME','WPME','MED']]]:
 for field in extras+['MISC','category','address']:
  rows.append({'sample':label,'field':field,'restaurants':len(sub),'metadata_matches':int(sub.metadata_matched.sum()),'populated':int(sub['has_'+field].sum()),'percent':100*sub['has_'+field].mean()})
pd.DataFrame(rows).to_csv(O/'field_coverage.csv',index=False)
pd.DataFrame([{'attribute':k,'focus_metadata_rows_with_attribute':v,'examples':' | '.join(x for x,_ in misc_values[k].most_common(12))} for k,v in misc.most_common()]).to_csv(O/'misc_attributes.csv',index=False)
pd.DataFrame(price_values.items(),columns=['value','focus_metadata_rows']).to_csv(O/'price_values.csv',index=False)
pd.DataFrame(status_values.items(),columns=['value','focus_metadata_rows']).to_csv(O/'status_values.csv',index=False)

# Bounded schema inspection, not a full review-corpus coverage/count audit.
reviews=[];reviewkeys=collections.Counter();review_nested=collections.defaultdict(collections.Counter)
for f in sorted(src.glob('review-*.json.gz')):
 rows=[]
 with gzip.open(f,'rt',encoding='utf-8') as stream:
  for i,line in enumerate(stream):
   if i>=1000:break
   row=json.loads(line);rows.append(row);reviewkeys.update(row.keys())
   for k in ['resp','pics']:
    v=row.get(k)
    if isinstance(v,dict):review_nested[k].update(v.keys())
    elif isinstance(v,list):
     for item in v:
      if isinstance(item,dict):review_nested[k].update(item.keys())
 times=pd.to_datetime([r.get('time') for r in rows],unit='ms',utc=True,errors='coerce')
 reviews.append({'file':f.name,'sample_rows':len(rows),'sample_businesses':len({r.get('gmap_id') for r in rows}),'sample_text_present':sum(present(r.get('text')) for r in rows),'sample_pre_election':int((times<pd.Timestamp('2016-11-08',tz='UTC')).sum()),'sample_min_date':str(times.min()),'sample_max_date':str(times.max()),'sample_has_response':sum(present(r.get('resp')) for r in rows),'sample_has_photos':sum(present(r.get('pics')) for r in rows)})
 print('review schema',f.name,flush=True)
pd.DataFrame(reviews).to_csv(O/'bounded_review_schema_audit.csv',index=False)
original_meta=pd.read_csv(root/'data/Google Reviews/Meta_data_combined.csv',nrows=0).columns.tolist()
original_out=pd.read_csv(root/'data/Google Reviews/Reviews_Data_Combined.csv',nrows=0).columns.tolist()
saved_review_columns=pd.read_csv(root/cfg['review_panel'],nrows=0).columns.tolist()
audit={'source_directory':str(src),'meta_files':len(byfile),'review_files':len(reviews),'metadata_rows_scanned':sum(x['rows_scanned'] for x in byfile),'metadata_schema_sample_counts':dict(schemas),'primary_focus_businesses':len(avail),'current_core_businesses':len(current),'focus_matches':int(avail.metadata_matched.sum()),'current_core_matches':int(avail.loc[avail.in_current_core_population,'metadata_matched'].sum()),'unique_focus_businesses_with_multiple_raw_metadata_rows':sum(r['metadata_rows']>1 for r in record.values()),'conflicting_price_businesses':sum(len(r['price_values'])>1 for r in record.values()),'original_combined_metadata_columns':original_meta,'original_combined_outcome_columns':original_out,'review_schema_counts':dict(reviewkeys),'review_nested_keys':{k:dict(v) for k,v in review_nested.items()},'review_sampling':'First 1,000 records per gzip file only; not random/representative, not full counts or full date ranges','source_files_modified':False,'historical_covariate_warning':'Metadata snapshot has no as-of date and can include post-2016 information. Do not treat current price/status/rating/hours or COVID-era amenities as predetermined 2016 controls. No opening date or chain identifier in observed top-level schema.'}
audit['saved_review_panel_columns']=saved_review_columns
(O/'audit.json').write_text(json.dumps(audit,indent=2))
print(json.dumps(audit,indent=2))
