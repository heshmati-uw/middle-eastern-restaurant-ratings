args<-commandArgs(FALSE);here<-dirname(normalizePath(sub('^--file=','',args[grepl('^--file=',args)])))
.libPaths(c(file.path(dirname(here),'.r-library'),.libPaths()))
suppressPackageStartupMessages({library(data.table);library(fixest)})
s<-file.path(here,'full_pre_election_core');out<-file.path(s,'attribute_matching')
original<-fread(file=file.path(out,'original_restaurant_data.csv'),colClasses=c(county_fips='character'))
matched<-fread(file=file.path(out,'matched_restaurant_data.csv'),colClasses=c(county_fips='character'))
w<-fread(file=file.path(s,'inputs','expanded_common_weekly.csv'));w[,week:=as.IDate(week)]
ss<-ssc(K.adj=TRUE,K.fixef='nonnested',G.adj=TRUE,t.df='min');means<-list();meaninputs<-list();tests<-list();leads<-list();weeklyinputs<-list();groupmeans<-list()
for(event_name in c('Election','Ban'))for(pair_name in c('ME_WPME','ME_MED','WPME_MED'))for(t in c(1,0)){
 q<-original[event==event_name&pair==pair_name&trump==t]
 price<-q[!is.na(price_tier)];ids<-price[,.(sides=uniqueN(first)),by=county_fips][sides==2]$county_fips;price<-price[county_fips %chin% ids]
 subsets<-list(Original=q,PriceObserved=price,Price=matched[event==event_name&pair==pair_name&trump==t&method=='Price'],PriceFormat=matched[event==event_name&pair==pair_name&trump==t&method=='PriceFormat'])
 for(stage_name in names(subsets)){
  d<-copy(subsets[[stage_name]]);if(nrow(d)==0)next
  fe<-if(stage_name %in% c('Price','PriceFormat'))'match_id' else 'county_fips';G<-uniqueN(d$county_fips)
  if(G<2)next
  fit<-feols(as.formula(paste('change~first|',fe)),data=d,vcov=~county_fips,ssc=ss,notes=FALSE)
  ct<-coeftable(fit)['first',];ci<-as.matrix(confint(fit))['first',];id<-length(means)+1L;stopifnot(nobs(fit)==nrow(d))
  means[[id]]<-data.table(id,event=event_name,pair=pair_name,trump=t,stage=stage_name,estimate=ct[1],se=ct[2],p=ct[4],low=ci[1],high=ci[2],restaurants=nrow(d),first_N=sum(d$first),second_N=sum(1-d$first),counties=G,df_K=attr(vcov(fit,attr=TRUE),'df.K'))
  mi<-d[,.(gmap_id,county_fips,first,change)];mi[,fixed_effect:=d[[fe]]];mi[,model_id:=id];meaninputs[[id]]<-mi
  gm<-d[,.(restaurants=.N,rating_pre=mean(rating_pre),rating_post=mean(rating_post),change=mean(change)),by=group];gm[,`:=`(event=event_name,pair=pair_name,trump=t,stage=stage_name)];groupmeans[[id]]<-gm
  # Validate balanced-pair point estimate against the county-FE version.
  if(stage_name %in% c('Price','PriceFormat')){
   check<-feols(change~first|county_fips,data=d,vcov=~county_fips,ssc=ss,notes=FALSE);stopifnot(abs(coef(check)['first']-coef(fit)['first'])<1e-10)
  }
  mixed<-as.IDate(if(event_name=='Election')'2016-11-07' else '2017-01-23')
  dw<-merge(w[week>=mixed-70&week<=mixed+28&week!=mixed&reviews>0&!is.na(rating)],d[,unique(c('gmap_id','county_fips','first',if(fe=='match_id')'match_id')),with=FALSE],by='gmap_id')
  if(event_name=='Ban')dw<-dw[!week %in% as.IDate(c('2016-12-19','2016-12-26'))]
  np<-dw[week<mixed,.N,by=gmap_id];keep<-intersect(np[N>=2]$gmap_id,dw[week>mixed]$gmap_id);dw<-dw[gmap_id %chin% keep]
  if(fe=='match_id')dw<-dw[match_id %chin% dw[,.(members=uniqueN(gmap_id)),by=match_id][members==2]$match_id]
  dw[,nweeks:=.N,by=gmap_id];dw[,weight:=1/nweeks];dw[,event_week:=as.integer((week-mixed)/7)]
  if(nrow(dw)==0||uniqueN(dw$first)<2)next
  wid<-length(tests)+1L;warning_reason<-''
  wf<-tryCatch(feols(rating~i(event_week,first,ref=-1)|gmap_id+county_fips^week,data=dw,weights=~weight,vcov=~county_fips,ssc=ss,fixef.rm='none',notes=FALSE),error=function(e)NULL)
  if(is.null(wf)){warning_reason<-'Weekly model not estimable';next}
  b<-coef(wf);V<-vcov(wf);ci<-as.matrix(confint(wf));ev<-as.integer(sub(':first$','',sub('^event_week::','',names(b))));ii<-which(ev< -1);expected<-length(unique(dw[event_week< -1]$event_week));F<-NA_real_;pv<-NA_real_;GG<-uniqueN(dw$county_fips)
  if(length(ii)==expected&&length(ii)>0&&GG>length(ii)&&qr(V[ii,ii,drop=FALSE])$rank==length(ii)){
   F<-as.numeric(t(b[ii])%*%solve(V[ii,ii,drop=FALSE],b[ii])/length(ii));pv<-pf(F,length(ii),GG-1,lower.tail=FALSE)
  }else warning_reason<-'Too few independent county scores or unidentified pre-week coefficients for the joint test'
  tests[[wid]]<-data.table(id=wid,event=event_name,pair=pair_name,trump=t,stage=stage_name,restaurants=uniqueN(dw$gmap_id),first_N=uniqueN(dw[first==1]$gmap_id),second_N=uniqueN(dw[first==0]$gmap_id),counties=GG,observations=nrow(dw),df_K=attr(vcov(wf,attr=TRUE),'df.K'),pre_restrictions=length(ii),joint_F=F,joint_p=pv,warning_reason)
  leads[[wid]]<-rbind(data.table(model_id=wid,event_week=ev,estimate=unname(b),se=sqrt(diag(V)),low=ci[,1],high=ci[,2]),data.table(model_id=wid,event_week=-1,estimate=0,se=0,low=0,high=0));dw[,model_id:=wid];weeklyinputs[[wid]]<-dw
 }
}
r<-rbindlist(means);r[,symbol:=fcase(p<.001,'***',p<.01,'**',p<.05,'*',p<.1,'+',default='')]
fwrite(r,file.path(out,'matched_mean_results.csv'));fwrite(rbindlist(meaninputs),file.path(out,'mean_verification_inputs.csv'));fwrite(rbindlist(groupmeans),file.path(out,'group_means.csv'))
tt<-rbindlist(tests);ee<-rbindlist(leads);fwrite(tt,file.path(out,'matched_weekly_pretests.csv'));fwrite(ee,file.path(out,'matched_weekly_estimates.csv'));fwrite(rbindlist(weeklyinputs,fill=TRUE),file.path(out,'weekly_verification_inputs.csv'))
for(pair_code in c('ME_WPME','ME_MED','WPME_MED'))for(stage_name in c('Price','PriceFormat')){
 a<-tt[pair==pair_code&stage==stage_name];rr<-ee[model_id %in% a$id];yr<-range(rr$low,rr$high)
 png(file.path(out,paste0(pair_code,'_',stage_name,'_trends.png')),width=2100,height=1550,res=180);par(mfrow=c(2,2),mar=c(4.5,5,3.5,1),oma=c(3,0,1,0))
 for(event_name in c('Election','Ban'))for(t in c(1,0)){
  test<-a[event==event_name&trump==t];z<-rr[model_id==test$id][order(event_week)]
  plot(c(-10,4),yr,type='n',xlab='Weeks from omitted event week',ylab=paste(gsub('_','-',pair_code),'gap relative to last pre-week'),main=paste(event_name,if(t==1)'| Trump' else '| Non-Trump'))
  abline(h=0,lty=3,col='grey50');abline(v=0,lty=2,col='grey50');segments(z$event_week,z$low,z$event_week,z$high,col='#185b7a');points(z$event_week,z$estimate,pch=19,col=ifelse(z$event_week<0,'#185b7a','#c45a3c'))
  plab<-if(is.na(test$joint_p))'not estimable' else if(test$joint_p<.001)'<.001' else sprintf('=%.3f',test$joint_p)
  mtext(sprintf('Joint pre p%s; N first/second=%s/%s',plab,test$first_N,test$second_N),side=3,line=.3,cex=.7)
 }
 mtext(paste('Undated price/format matching sensitivity:',stage_name,'| Equal total restaurant weights; county-clustered intervals.'),side=1,outer=TRUE,line=.7,cex=.65);dev.off()
}
print(r[pair=='ME_WPME',.(event,trump,stage,estimate,p,first_N,second_N,counties)]);print(tt[pair=='ME_WPME',.(event,trump,stage,joint_p,first_N,second_N,counties,warning_reason)])
