"""Optimal symmetric 1:1 matches selected without looking at rating outcomes."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'attribute_matching';sys.path.insert(0,str(H.parent/'.analysis-python'))
from scipy.optimize import linear_sum_assignment
attrs=pd.read_csv(O/'restaurant_attributes.csv').drop(columns=['group','trump'])
features=['dine_in','takeout','delivery','drive_through','counter_service','alcohol','reservations','casual','upscale','service_recorded','atmosphere_recorded','offerings_recorded','planning_recorded']
design={'methods':{'Price':'Exact county and dollar-sign price tier; optimal geographic distance','PriceFormat':'Exact county, price, service-recorded status and dine-in/takeout/delivery listings; optimize other recorded format differences and geographic distance'},'replacement':False,'ratio':'1:1; every matched restaurant unit weight','target':'Matched common-support restaurants, not all restaurants','selection_uses_ratings':False,'geographic_cost':'Squared great-circle km / 20; no hard distance threshold','format_cost':'Sum of squared binary recorded-listing differences','timing':'Undated snapshot attributes: descriptive sensitivity, cannot establish historical causality','event_windows':'Election original 4 weeks each side; ban excludes Dec 19/26 weeks, leaving 3 baseline weeks and 4 post weeks'}
(O/'matching_design.json').write_text(json.dumps(design,indent=2))
pairrows=[];modelrows=[];balances=[];flow=[];base=[];metadata=[]
def haversine(a,b):
 lat1=np.radians(a.latitude.to_numpy())[:,None];lat2=np.radians(b.latitude.to_numpy())[None,:];lon1=np.radians(a.longitude.to_numpy())[:,None];lon2=np.radians(b.longitude.to_numpy())[None,:]
 h=np.sin((lat1-lat2)/2)**2+np.cos(lat1)*np.cos(lat2)*np.sin((lon1-lon2)/2)**2;return 6371.0088*2*np.arcsin(np.sqrt(np.clip(h,0,1)))
for event in ['Election','Ban']:
 for pair in ['ME_WPME','ME_MED','WPME_MED']:
  first,second=pair.split('_');q=pd.read_csv(S/'regressions'/f'sample_{pair}_{event.lower()}.csv',dtype={'county_fips':str});q['first']=(q.group==first).astype(int)
  if event=='Ban':
   p=S/'ban_holiday_sensitivity'/('' if pair=='ME_WPME' else pair)/'retained_restaurant_periods.csv';p=pd.read_csv(p,dtype={'county_fips':str});p=p[p['mask'].eq('Calendar')].set_index('gmap_id');q=q[q.gmap_id.isin(p.index)].copy()
   for c in ['rating_pre','rating_post','reviews_pre','change']:q[c]=q.gmap_id.map(p[c])
  q=q.merge(attrs,on='gmap_id',how='left',validate='one_to_one');q['event']=event;q['pair']=pair;base.append(q)
  for t in [1,0]:
   full=q[q.trump.eq(t)].copy();eligible=full[full.price_tier.notna()].copy()
   for method in ['Price','PriceFormat']:
    stratum=['county_fips','price_tier']+(['service_recorded','dine_in','takeout','delivery'] if method=='PriceFormat' else [])
    matched_ids=[];km=[];n_pairs=0
    for key,z in eligible.groupby(stratum,sort=True,dropna=False):
     a=z[z['first'].eq(1)].sort_values('gmap_id');b=z[z['first'].eq(0)].sort_values('gmap_id')
     if a.empty or b.empty:continue
     distance=haversine(a,b);cost=(distance/20)**2
     if method=='PriceFormat':cost+=((a[features].to_numpy()[:,None,:]-b[features].to_numpy()[None,:,:])**2).sum(axis=2)
     ai,bi=linear_sum_assignment(cost)
     for i,j in zip(ai,bi):
      n_pairs+=1;pid=f'{event}_{pair}_{t}_{method}_{n_pairs}';left=a.iloc[i];right=b.iloc[j]
      pairrows.append({'event':event,'pair':pair,'trump':t,'method':method,'match_id':pid,'first_id':left.gmap_id,'second_id':right.gmap_id,'county_fips':left.county_fips,'price_tier':left.price_tier,'distance_km':distance[i,j],'matching_cost':cost[i,j]})
      for row in [left,right]:
       rr=row.to_dict();rr['method']=method;rr['match_id']=pid;modelrows.append(rr);matched_ids.append(row.gmap_id)
      km.append(float(distance[i,j]))
    matched=eligible[eligible.gmap_id.isin(matched_ids)]
    flow.append({'event':event,'pair':pair,'trump':t,'method':method,'original_N':len(full),'original_first':sum(full['first']),'original_second':sum(1-full['first']),'price_observed_N':len(eligible),'price_first':sum(eligible['first']),'price_second':sum(1-eligible['first']),'pairs':n_pairs,'matched_N':len(matched),'matched_counties':matched.county_fips.nunique(),'median_distance_km':float(np.median(km)) if km else None,'max_distance_km':max(km) if km else None})
    for col in ['price_tier',*features,'rating_pre','reviews_pre']:
     a=eligible[eligible['first'].eq(1)][col];b=eligible[eligible['first'].eq(0)][col];scale=np.sqrt((a.var(ddof=1)+b.var(ddof=1))/2)
     for stage,d in [('Before (price observed)',eligible),('After matching',matched)]:
      aa=d[d['first'].eq(1)][col];bb=d[d['first'].eq(0)][col];diff=aa.mean()-bb.mean();smd=diff/scale if scale>0 else (0 if diff==0 else np.nan)
      balances.append({'event':event,'pair':pair,'trump':t,'method':method,'variable':col,'stage':stage,'first_mean':aa.mean(),'second_mean':bb.mean(),'SMD':smd,'abs_SMD':abs(smd),'used_for_matching':col not in ['rating_pre','reviews_pre']})
    print(event,pair,t,method,'pairs',n_pairs,flush=True)
pd.DataFrame(pairrows).to_csv(O/'matched_pairs.csv',index=False);pd.DataFrame(modelrows).to_csv(O/'matched_restaurant_data.csv',index=False);pd.concat(base,ignore_index=True).to_csv(O/'original_restaurant_data.csv',index=False)
pd.DataFrame(flow).to_csv(O/'sample_flow.csv',index=False);pd.DataFrame(balances).to_csv(O/'covariate_balance.csv',index=False)
for key,z in pd.DataFrame(pairrows).groupby(['event','pair','trump','method']):
 assert not z.first_id.duplicated().any() and not z.second_id.duplicated().any()
 assert z.first_id.nunique()==z.second_id.nunique()
print(pd.DataFrame(flow).to_string(index=False))
