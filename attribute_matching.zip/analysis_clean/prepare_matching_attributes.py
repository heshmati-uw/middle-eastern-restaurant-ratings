"""Read raw metadata for price and recorded restaurant-format characteristics."""
from pathlib import Path
import collections,gzip,json,re
import pandas as pd
H=Path(__file__).resolve().parent;S=H/'full_pre_election_core';O=S/'attribute_matching';O.mkdir(exist_ok=True)
c=json.loads((H/'config.json').read_text());src=Path(c['source_root'])/'analysis/2025-08-18-rohan/inputs'
q=pd.read_csv(S/'restaurant_precinct_assignments.csv');q=q[q.group.isin(['ME','WPME','MED'])];ids=set(q.gmap_id)
features=['dine_in','takeout','delivery','drive_through','counter_service','alcohol','reservations','casual','upscale']
records={};counts=[];pat=re.compile(r'"gmap_id"\s*:\s*"([^"\\]+)"')
def norm(s):return re.sub(r'[^a-z0-9 ]',' ',s.casefold()).strip()
for f in sorted(src.glob('meta-*.json.gz')):
 n=0;found=0
 with gzip.open(f,'rt',encoding='utf-8') as stream:
  for line in stream:
   n+=1;m=pat.search(line)
   if not m or m.group(1) not in ids:continue
   row=json.loads(line);gid=row['gmap_id'];found+=1
   if gid not in records:records[gid]={'gmap_id':gid,'raw_prices':set(),**{k:False for k in features},'service_recorded':False,'atmosphere_recorded':False,'offerings_recorded':False,'planning_recorded':False}
   r=records[gid];price=row.get('price')
   if price:r['raw_prices'].add(price)
   misc=row.get('MISC') or {};service={norm(v) for v in misc.get('Service options',[])};atmo={norm(v) for v in misc.get('Atmosphere',[])};offers={norm(v) for v in misc.get('Offerings',[])};dining={norm(v) for v in misc.get('Dining options',[])};plan={norm(v) for v in misc.get('Planning',[])}
   vals={'dine_in':'dine in' in service,'takeout':bool(service&{'takeout','takeaway'}),'delivery':any('delivery'in v for v in service),'drive_through':any('drive through'in v for v in service),'counter_service':'counter service'in dining,'alcohol':bool(offers&{'alcohol','beer','wine','cocktails'}),'reservations':'accepts reservations'in plan,'casual':'casual'in atmo,'upscale':bool(atmo&{'upscale','upmarket'})}
   for k,v in vals.items():r[k]|=v
   for key,family in [('service_recorded','Service options'),('atmosphere_recorded','Atmosphere'),('offerings_recorded','Offerings'),('planning_recorded','Planning')]:r[key]|=bool(misc.get(family))
 counts.append({'file':f.name,'metadata_rows':n,'focal_rows':found});print(f.name,found,flush=True)
rows=[]
for gid,r in records.items():
 prices=r.pop('raw_prices');assert len(prices)<=1,(gid,prices);price=next(iter(prices),'');r['price_raw']=price;r['price_tier']=len(price) if re.fullmatch(r'\${1,4}',price) else None;rows.append(r)
a=q[['gmap_id','group','trump']].merge(pd.DataFrame(rows),on='gmap_id',how='left',validate='one_to_one');assert len(a)==len(q)
for k in features+['service_recorded','atmosphere_recorded','offerings_recorded','planning_recorded']:a[k]=a[k].fillna(False).astype(int)
a.to_csv(O/'restaurant_attributes.csv',index=False);pd.DataFrame(counts).to_csv(O/'metadata_scan_counts.csv',index=False)
a.groupby(['group','trump'],dropna=False).agg(restaurants=('gmap_id','size'),price_available=('price_tier','count'),service_recorded=('service_recorded','sum')).reset_index().to_csv(O/'attribute_coverage.csv',index=False)
(O/'attribute_definitions.json').write_text(json.dumps({'primary_price':'Exact number of dollar symbols ($ to $$$$); non-dollar/missing labels excluded, never imputed','format_variables':features,'recorded_flags':['service_recorded','atmosphere_recorded','offerings_recorded','planning_recorded'],'missing_semantics':'0 means not recorded, not verified absence. Format-exact matching distinguishes service-recorded status.','historical_warning':'Undated Google snapshot; includes post-2016/COVID-era information. These matches cannot establish a historical causal effect. No rating trends/post-event ratings used to select pairs.'},indent=2))
print(a.groupby('group').price_tier.agg(['size','count']).to_string())
