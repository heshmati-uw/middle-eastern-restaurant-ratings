"""Combine existing primary core-tag precinct results; audit exact state coverage."""
from pathlib import Path
import json
import pandas as pd
H=Path(__file__).resolve().parent;O=H/'precinct_core_summary';O.mkdir(exist_ok=True)
a=pd.read_csv(H/'precinct_core/precinct_interaction_results.csv')
a=a[a.model.eq('Precinct share + county FE')&a['sample'].eq('Main matched sample')&~a.stratum.eq('All counties')].copy()
a['comparison']='ME vs WPME';a=a.rename(columns={'ME':'first_restaurants','WPME':'second_restaurants'})
b=pd.read_csv(H/'precinct_core_mediterranean/interaction_results.csv')
b=b[b.model.eq('Precinct share + county FE')&b['sample'].eq('Main matched sample')&~b.stratum.eq('All counties')].rename(columns={'MED_restaurants':'second_restaurants'})
cols=['shock','stratum','comparison','estimate','se','low','high','p','symbol','restaurants','first_restaurants','second_restaurants','counties','precincts']
r=pd.concat([a[cols],b[cols]],ignore_index=True)
assert len(r)==12 and not r.duplicated(['shock','stratum','comparison']).any()
states=[];coverage=[];union_by_event={};mapping={}
for row in r.itertuples():
 if row.comparison=='ME vs WPME':f=H/'precinct_core'/f'model_sample_{row.shock.lower()}.csv'
 else:f=H/'precinct_core_mediterranean'/f'sample_{row.comparison.split(" vs ")[0]}_{row.shock.lower()}.csv'
 q=pd.read_csv(f,dtype={'county_fips':str});q=q[q.trump.eq(1 if row.stratum=='Trump counties' else 0)]
 first,second=row.comparison.split(' vs ')
 assert len(q)==row.restaurants and q.group.eq(first).sum()==row.first_restaurants and q.group.eq(second).sum()==row.second_restaurants
 assert q.county_fips.nunique()==row.counties and q.precinct_id.nunique()==row.precincts
 mapping.update(dict(zip(q.state,q.NAME1)))
 names=sorted(q.state.unique());union_by_event.setdefault(row.shock,set()).update(names)
 coverage.append({'shock':row.shock,'stratum':row.stratum,'comparison':row.comparison,'state_count_excluding_DC':len(set(names)-{'DC'}),'DC_included':'DC' in names,'states':', '.join(names)})
 c=q.groupby(['state','group'],observed=True).agg(restaurants=('gmap_id','size'),counties=('county_fips','nunique'),precincts=('precinct_id','nunique')).reset_index()
 c['shock']=row.shock;c['stratum']=row.stratum;c['comparison']=row.comparison;states.append(c)
order={'Election':0,'Ban':1,'Trump counties':0,'Non-Trump counties':1,'ME vs WPME':0,'ME vs MED':1,'WPME vs MED':2}
r=r.sort_values(['shock','stratum','comparison'],key=lambda s:s.map(order)).reset_index(drop=True)
c=pd.DataFrame(coverage);r=r.merge(c,on=['shock','stratum','comparison'],validate='one_to_one')
r.to_csv(O/'combined_results.csv',index=False);pd.concat(states,ignore_index=True).to_csv(O/'state_restaurant_counts.csv',index=False)
allstates=set.union(*union_by_event.values())
audit={'source_models':'Previously computed core-tag primary precinct models; no regressions rerun','rows_verified':len(r),'sample_and_county_and_precinct_counts_verified':True,'union_states_excluding_DC':len(allstates-{'DC'}),'DC_included':'DC' in allstates,'state_abbreviations':sorted(allstates),'state_names':[mapping[s] for s in sorted(allstates)],'by_event':{e:{'states_excluding_DC':len(v-{'DC'}),'DC_included':'DC'in v,'abbreviations':sorted(v)} for e,v in union_by_event.items()}}
(O/'coverage_audit.json').write_text(json.dumps(audit,indent=2))
display=r.copy();display['Comparison']=display.comparison.str.replace('MED','Mediterranean',regex=False)
display['Gradient']=display.apply(lambda x:f'{x.estimate:+.3f}{x.symbol if isinstance(x.symbol,str) else ""}',axis=1)
display['Raw p']=display.p.map(lambda x:f'{x:.4f}')
display['N first / second']=display.apply(lambda x:f'{x.first_restaurants:,} / {x.second_restaurants:,}',axis=1)
display['95% CI']=display.apply(lambda x:f'[{x.low:+.3f}, {x.high:+.3f}]',axis=1)
tablecols=['shock','stratum','Comparison','Gradient','95% CI','Raw p','N first / second','restaurants','counties']
statetext='; '.join(f'<b>{e}:</b> {len(v-{"DC"})} states'+(' plus DC' if 'DC'in v else '') for e,v in union_by_event.items())
state_list=', '.join(mapping[s] for s in sorted(allstates-{'DC'},key=lambda s:mapping[s]))+('; District of Columbia' if 'DC'in allstates else '')
html='''<!doctype html><html><head><meta charset="utf-8"><title>All core-tag precinct comparisons</title><style>body{font:16px/1.5 system-ui;max-width:1400px;margin:36px auto;padding:0 24px;color:#243343}h1,h2{color:#15516c}table{border-collapse:collapse;font-size:13px;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:right}th{background:#edf3f6}td:nth-child(-n+3){text-align:left}.note{padding:18px;background:#edf3f6}.scroll{overflow:auto}</style></head><body><h1>All three core-tag precinct comparisons</h1><div class="note">The gradient is the change in the <b>first-group-minus-second-group rating-change gap per +10 percentage points of precinct Trump vote share</b>. Negative means the first group loses more ground as local Trump support rises. These are continuous precinct gradients within county strata, not average election/ban effects.</div>
<p>27 core dish tags; primary cuisine categories; pre-election review tags; four complete weeks on either side; equal restaurant weights; county fixed effects; county-clustered CR1 inference. County strata use the original county Trump share above 50%. Raw p-values and symbols: + &lt;.10, * &lt;.05, ** &lt;.01, *** &lt;.001.</p><div class="scroll">'''+display[tablecols].to_html(index=False,border=0)+'''</div><p>Counts are restaurants, not reviews. N first/second follows the comparison order. Each pair retains counties containing both groups, so sample sizes and state coverage differ across rows. Restaurants appear in multiple comparisons; row counts must not be added to obtain a unique sample. Mediterranean means primary Mediterranean with observed pre-election text and no detected core tag, including shared-only tags.</p><h2>Which states contribute?</h2><p>'''+statetext+'''</p><p>Across the twelve rows, '''+str(len(allstates-{'DC'}))+''' states plus DC contribute at least one restaurant:</p><p>'''+state_list+'''</p><h2>Exact coverage by comparison and county stratum</h2><div class="scroll">'''+c.to_html(index=False,border=0)+'''</div><p>Coverage describes these analyzed samples, not a nationally representative restaurant sample. <a href="state_restaurant_counts.csv">Restaurant counts by state, group, event, and county stratum</a> · <a href="combined_results.csv">Combined results CSV</a> · <a href="coverage_audit.json">Coverage audit</a></p></body></html>'''
(O/'combined_report.html').write_text(html,encoding='utf-8')
print(display[tablecols].to_string(index=False));print(json.dumps(audit,indent=2))
